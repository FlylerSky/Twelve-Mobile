# PATCH 17 — v2.4.1.191026: sửa trang Profile (bo góc · kéo/thu phóng ảnh bìa · huy hiệu · ghim · hệ tab chung)

Nền: v2.4.0. Không đổi `firestore.rules`, `firestore.indexes.json`, biến môi trường. Test: backend **181/181** (175 → +6), frontend **240/240** (213 → +27), `vite build` sạch.

## 1. Ảnh bìa bo góc quá mức
Nguyên nhân: 2.4.0 đặt `borderRadius: 2` — MUI nhân với `shape.borderRadius` của theme Twelve (16px) nên ra **32px**. Nay bo **8px** (`COVER_RADIUS` trong `components/profile/ProfileCover.jsx`, đổi một chỗ). Ảnh bìa ở trang Profile và bản xem trước trong Cài đặt dùng **cùng một component** `ProfileCover`. Test mới dùng theme THẬT của Twelve (theme mặc định của MUI chỉ bo 4px nên không bắt được lỗi này); đã thử làm hỏng lại để chắc test báo lỗi.

## 2. Kéo & thu phóng ảnh bìa như avatar
Ở 2.4.0 tải ảnh lên có kéo/thu phóng nhưng **cắt cứng** thành 1500×500 ngay lúc tải: ảnh dán bằng URL ngoài không kéo/thu phóng được, và muốn chỉnh lại phải tải lại ảnh. Mình hiểu đó là chỗ bạn thấy thiếu, nên đổi cách làm:
- Ảnh được lưu **nguyên** (Cloudinary giới hạn cạnh dài 2400px) cùng **khung hiển thị** `users/{uid}.coverCrop` = `{x, y, width, height}` theo % ảnh gốc. Hiển thị bằng CSS thuần (phóng + dời), không cần canvas ⇒ dùng được cả cho **URL ngoài** (không dính CORS).
- Cài đặt › Tài khoản › Thông tin › Ảnh bìa: **Tải ảnh lên** (chọn → tự thu nhỏ nếu >2400px/>2.5MB → kéo/thu phóng → Lưu), **Dùng đường dẫn** (lưu xong **mở luôn** hộp kéo/thu phóng), **Điều chỉnh** (mở lại bất cứ lúc nào cho ảnh đang có, không tải lại ảnh), **Gỡ ảnh bìa**.
- API mới: `PUT /api/users/me/cover/crop` `{crop}` (null = về canh giữa). `POST /me/cover` nhận thêm trường multipart `crop`; `PUT /me/cover` nhận thêm `crop`. Đổi sang ảnh khác ⇒ khung về mặc định; dán lại đúng URL cũ ⇒ giữ khung.
- Ảnh bìa tải lên từ 2.4.0 (đã cắt sẵn 1500×500) **vẫn hiển thị đúng** (khung = null ⇒ canh giữa); muốn chỉnh thì tải lại ảnh một lần.
- Giới hạn: `og:image` cho bot dùng ảnh gốc, không áp khung. Hộp "Điều chỉnh" cần ảnh tải được trong trình duyệt; ảnh URL hỏng thì báo lỗi và khoá nút Lưu.

## 3. Huy hiệu không hiện — nguyên nhân & cách sửa
Nguyên nhân (suy ra từ code, **chưa kiểm trên dữ liệu thật của bạn**): mọi quyền của Twelve dựa vào `accountGroup` (SA/RA/LLA), còn `accountRole` chỉ được ghi lúc đăng ký (= `"user"`) và lúc di chuyển dữ liệu cũ. Tài khoản SA do bạn đặt tay (chỉ đổi `accountGroup`) vẫn mang `accountRole: "user"` ⇒ 2.4.0 (chỉ nhìn `accountRole`) không cho huy hiệu nào.

Nay **nhóm là căn cứ chính**, vai trò chỉ làm rõ trong nhóm:
| Điều kiện | Huy hiệu |
|---|---|
| `accountGroup = SA` + role admin / dev / moderator | `admin` / `dev` / `moderator` |
| `accountGroup = SA`, role khác hoặc không ghi | **`sa` — "Tài khoản cấp cao"** (mới) |
| `accountGroup = LLA` | `tester` |
| `accountGroup = RA` + role `pro_user` | `pro` |
| `isLegacyMember = true` | thêm `legacy` |
| RA + role thường | không có (cố ý) |
Thiếu `accountGroup` (hồ sơ rất cũ) ⇒ suy nhóm từ role như trước. Cách kiểm nhanh: mở `/api/users/<uid>` xem trường `badges`.

**Đồng nhất ở mọi nơi:** backend trả `badges` trong mọi hồ sơ công khai; frontend dùng đúng danh sách đó (`resolveBadgeIds`), riêng hồ sơ của chính mình được tính lại mỗi lần Firestore đổi (không dính huy hiệu cũ). Cỡ icon theo kiểu chữ của tên đứng cạnh (`badgeSizeForVariant`, một bảng duy nhất) nên thẻ bài, bình luận, Menu, đầu trang Profile, bảng xếp hạng nhìn như nhau. **Test quét mã nguồn** (`profile241.test.jsx`): file `.jsx` nào hiện `displayName` thành chữ mà không dùng `UserName`/`UserBadges` (trừ danh sách miễn trừ có lý do: form, bảng thống kê SA) sẽ làm test đỏ — thêm một nơi hiện tên mà quên huy hiệu là biết ngay.

## 4. Ghim: bỏ chữ "Đã ghim"
Thẻ bài chỉ còn **icon ghim**; nhãn nằm trong `<title>` của icon (tooltip + trình đọc màn hình). Test khẳng định không còn chữ hiển thị.

## 5. Hệ tab dùng chung
Điều tra: trước đây **không có component tab dùng chung** — Cài đặt và Xu hướng mỗi trang tự lặp cùng một khuôn (hàng sticky dưới AppBar, Container md, Tabs cuộn ngang, `TAB_SX`, z-index tăng dần theo cấp). Bản 2.4.0 của Profile là bản sao thứ ba, lệch khuôn. Nay:
- `components/tabs/StickyTabs.jsx` — **một** hàng tab sticky (khuôn y hệt Xu hướng: cùng `top`, `level` tăng ⇒ z-index 11/12/13, hàng con đè hàng cha).
- `components/tabs/useTabTree.js` + `TabTreeBars.jsx` — **cây tab nhiều cấp đồng bộ URL** (`?tab=…&sub=…&sub2=…`, mặc định giữ URL sạch, khoá lạ ⇒ mặc định, tab `visible(ctx)`).
- **Cài đặt, Xu hướng và Profile đều dùng StickyTabs** (hai trang đầu chuyển sang mà hành vi giữ nguyên; test cũ của chúng vẫn xanh). Khác biệt duy nhất: hàng tab Cài đặt bỏ `backdrop-filter: blur` (nền đặc nên không nhìn thấy khác). Test quét mã nguồn: `<Tabs>` của MUI chỉ được phép nằm trong `StickyTabs.jsx` — trang nào tự dựng tab riêng là đỏ.
- **Thêm tab / sub-tab cho Profile = sửa DUY NHẤT `components/profile/profileTabs.jsx`:**
  ```jsx
  { key: "posts", label: "Bài viết", Component: ProfilePostsTab,
    children: [ { key: "all", label: "Tất cả", Component: AllPosts },
                { key: "media", label: "Ảnh", Component: MediaPosts } ] },   // hàng sub-tab tự xuất hiện
  { key: "saved", label: "Đã lưu", Component: Saved, visible: (ctx) => ctx.isOwn },
  ```
  Đã kiểm bằng test với cây 3 cấp; nội dung của node sâu nhất được vẽ, nhận `{ uid, isOwn, user }`.
- ⚠ Mình đã **sửa cả SettingsPage và TrendingPage** (bạn chỉ yêu cầu Profile) vì "hệ tab dùng chung" chưa thật sự tồn tại; nếu bạn muốn giữ hai trang đó đúng như cũ, báo mình, nhưng khi đó sẽ có hai bản khuôn song song.

## 6. Bề mặt mới (đã rà, có test)
`coverCrop` do người dùng gửi và đi vào CSS: backend chỉ nhận 4 số hữu hạn trong biên (width/height ≥ 10%, x+width ≤ 100%), làm tròn 2 số lẻ, bỏ khoá thừa, từ chối chuỗi/NaN/Infinity/mảng/JSON hỏng (kể cả trường multipart) **trước** khi chạm Cloudinary; frontend kiểm lại lần nữa trước khi dựng CSS. `PUT /me/cover/crop` yêu cầu đã có ảnh bìa, chỉ chủ tài khoản đổi được, cùng limiter ghi hồ sơ. Gỡ ảnh bìa xoá luôn khung; hồ sơ công khai không trả khung khi không còn ảnh.

## 7. Chưa kiểm chứng
Như 2.4.0: chỉ có Firestore/Cloudinary giả + jsdom. Nên thử tay: (a) kéo/thu phóng ảnh bìa trên điện thoại (cảm ứng, hộp cao 220px), (b) ảnh lớn thật từ camera đi qua bước thu nhỏ (`prepareCoverImage` dùng canvas — jsdom không có nên chỉ test phần tính kích thước), (c) hàng tab sticky của Profile khi cuộn (đè đúng như Xu hướng), (d) huy hiệu `sa` trên tài khoản SA thật.

## 8. File chính đã đổi
Backend: `utils/badges.js` (theo nhóm), `utils/helpers.js` (`parseCoverCrop`, `toPublicProfile` có `coverCrop`), `controllers/users.controller.js` (`setCoverCrop`, crop ở upload/URL), `services/assets.service.js` (lưu nguyên ảnh), `routes/users.routes.js`, `utils/constants.js`; test `profile-240.test.js` (+6).
Frontend mới: `components/tabs/{StickyTabs,useTabTree,TabTreeBars}`, `components/profile/{ProfileCover,CoverAdjustDialog,profileTabs}`, `utils/imageDownscale.js`; test `profile241.test.jsx`. Đổi: `PublicProfilePage`, `SettingsPage`, `TrendingPage`, `ProfileHeader`, `PostCard`, `CoverImageRow`, `UserBadges`, `UserIdentity`, `Navbar`, `RankingList`, `AuthContext`, `utils/badges.js`, `api/users.api.js`; `AvatarCropper` trả về nguyên bản 2.3.0 (các tuỳ chọn mình thêm ở 2.4.0 không còn dùng).
