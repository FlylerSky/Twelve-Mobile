#!/usr/bin/env node
/**
 * list-reserved-tags.js  (v2.2.2 — báo cáo kiểm tra lại 2.2.1, R-03)
 * CHỈ ĐỌC. Liệt kê các Tag Name Search đang tồn tại mà bộ so khớp "dành riêng" hiện tại sẽ chặn (admin, twelve, support, the_twelve, adm1n…), kèm nhóm tài khoản chủ.
 * Tài khoản SA giữ tag như vậy là bình thường; tài khoản thường thì nên xem xét liên hệ để đổi tên.
 *   npm run tags:reserved
 */
require("dotenv").config();
const { auditReservedTags } = require("../src/services/reservedTagAudit");

auditReservedTags()
  .then((r) => {
    console.log(`Đã quét ${r.scanned} tag; trùng danh sách dành riêng: ${r.hits.length}.`);
    r.hits.forEach((h) => console.log(`  - @${h.tag}  uid=${h.uid}  nhóm=${h.accountGroup}  trạng thái=${h.status}${h.accountGroup === "SA" ? "  (SA — bình thường)" : ""}`));
    process.exit(0);
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
