#!/usr/bin/env node
/**
 * print-csp-sources.js  (v2.5.3 — báo cáo bảo mật 2.5.2, TW-02)
 * In danh sách nguồn `frame-src` / `img-src` để dán vào `frontend/vercel.json` khi chuyển hai directive này sang chế độ ENFORCE.
 * Vì sao cần: danh sách domain nhúng do SA sửa lúc chạy (Cài đặt › Quản trị › Domain nhúng → `config/embedDomains`), còn `vercel.json` là tĩnh — nên mỗi lần
 * SA thêm/bớt domain, CSP tĩnh lệch dần. Chạy script này sau mỗi lần SA đổi danh sách rồi cập nhật `vercel.json` (hoặc trước khi bật enforce lần đầu).
 *
 * Nguồn dữ liệu: `config/embedDomains` trên Firestore nếu có cấu hình `FIREBASE_*` hợp lệ trong môi trường; không thì dùng DEFAULT_EMBED_DOMAINS của mã nguồn.
 * Chỉ ĐỌC, không ghi gì. Dùng:  npm run csp:sources
 */
require("dotenv").config();
const { DEFAULT_EMBED_DOMAINS, setEmbedDomainsConfig, getEmbedDomainsConfig, getFrameSrcCspSources } = require("../src/services/sanitize.service");

async function main() {
  let source = "mặc định trong mã nguồn (DEFAULT_EMBED_DOMAINS) — không đọc được Firestore";
  try {
    const { db } = require("../src/config/firebase");
    const snap = await db.collection("config").doc("embedDomains").get();
    if (snap.exists) {
      setEmbedDomainsConfig(snap.data());
      source = "Firestore config/embedDomains";
    } else {
      setEmbedDomainsConfig({ enabled: true, domains: DEFAULT_EMBED_DOMAINS });
      source = "mặc định (Firestore chưa có config/embedDomains)";
    }
  } catch (err) {
    console.error(`Không đọc được Firestore (${err.message}); dùng danh sách mặc định.`);
  }

  const cfg = getEmbedDomainsConfig();
  const frame = ["https://challenges.cloudflare.com", ...getFrameSrcCspSources()];
  // img-src: ảnh trong bài cũng phải thuộc allowlist này (isAllowedEmbedSrc) — chỉ domain (CSP bỏ qua path), cộng Cloudinary cho avatar/ảnh bìa.
  const img = ["'self'", "data:", "blob:", "https://res.cloudinary.com", ...[...new Set(cfg.domains.map((d) => d.domain))].map((d) => `https://${d}`)];

  console.log(`# Nguồn dữ liệu: ${source}`);
  console.log(`# Allowlist ${cfg.enabled ? "đang BẬT" : "đang TẮT (frame-src sẽ chỉ còn Cloudflare Turnstile)"}; ${cfg.domains.length} domain.\n`);
  console.log(`frame-src ${(cfg.enabled ? frame : frame.slice(0, 1)).join(" ")}`);
  console.log(`img-src ${[...new Set(img)].join(" ")}`);
  console.log("\n# Dán hai dòng trên vào giá trị header trong frontend/vercel.json (đầu tiên ở Content-Security-Policy-Report-Only, theo dõi bảng báo cáo CSP ≥ 7 ngày, rồi mới chuyển sang Content-Security-Policy).");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
