#!/usr/bin/env node
/**
 * purge-orphan-subcollections.js  (v2.0.5)
 * Dọn `comments` / `views` / `reactions` / `shares` MỒ CÔI của bài viết/blog đã bị xoá TRƯỚC khi deletePost/
 * deleteBlog biết xoá đệ quy. Quét collection group, kiểm tra document cha còn tồn tại không.
 *
 * MẶC ĐỊNH LÀ DRY-RUN (chỉ đếm). Thêm `--apply` để xoá thật (không hoàn tác).
 *   node scripts/purge-orphan-subcollections.js
 *   node scripts/purge-orphan-subcollections.js --apply
 *
 * Cần index "collection group" cho các subcollection nếu Firestore yêu cầu (chỉ khi dùng orderBy; script này không dùng).
 */
require("dotenv").config();
const { db } = require("../src/config/firebase");
const { SUBCOLLECTIONS } = require("../src/utils/constants");

const APPLY = process.argv.includes("--apply");
const PARENTS = new Set(["posts", "blogs"]);
const GROUPS = [SUBCOLLECTIONS.COMMENTS, SUBCOLLECTIONS.VIEWS, SUBCOLLECTIONS.REACTIONS, SUBCOLLECTIONS.SHARES];

async function main() {
  const parentExists = new Map(); // "posts/abc" -> boolean
  const orphanParents = new Set();
  let scanned = 0;
  let orphanDocs = 0;

  for (const group of GROUPS) {
    const snap = await db.collectionGroup(group).select().get();
    for (const doc of snap.docs) {
      const parent = doc.ref.parent.parent; // posts/{id} | blogs/{id} (null nếu collection gốc trùng tên)
      if (!parent || !PARENTS.has(parent.parent.id)) continue;
      scanned += 1;
      if (!parentExists.has(parent.path)) parentExists.set(parent.path, (await parent.get()).exists);
      if (!parentExists.get(parent.path)) {
        orphanDocs += 1;
        orphanParents.add(parent.path);
      }
    }
  }

  console.log(`Đã quét ${scanned} tài liệu con; mồ côi: ${orphanDocs} thuộc ${orphanParents.size} bài/blog đã xoá.`);
  if (!APPLY) {
    console.log("DRY-RUN — chạy lại với --apply để xoá.");
    return;
  }
  for (const path of orphanParents) {
    await db.recursiveDelete(db.doc(path));
    console.log("đã dọn", path);
  }
}

main().then(() => process.exit(0), (err) => { console.error(err); process.exit(1); });
