#!/usr/bin/env node
/**
 * cleanup-orphan-auth-users.js  (v2.0.12 — Báo cáo bảo mật Phiên 3, N3)
 * Dọn tài khoản Firebase Auth "mồ côi" do `POST /auth/register` bị ngắt giữa chừng (có dấu `registrationMarkers/{uid}`
 * còn sót, KHÔNG có hồ sơ users/{uid}, quá 10 phút). KHÔNG đụng tới tài khoản Auth không có dấu (có thể thuộc ứng dụng khác).
 * MẶC ĐỊNH LÀ DRY-RUN.
 *   npm run auth:cleanup-orphans
 *   npm run auth:cleanup-orphans:apply
 */
require("dotenv").config();
const { cleanupOrphans } = require("../src/services/orphanAuth");

const APPLY = process.argv.includes("--apply");

cleanupOrphans({ apply: APPLY })
  .then((r) => {
    console.log(`Đã quét ${r.scanned} dấu đăng ký; mồ côi: ${r.orphans.length}; dấu thừa (đăng ký đã xong): ${r.staleMarkers}.`);
    r.orphans.forEach((o) => console.log(`  - ${o.uid} <${o.email}> ${o.ageMin} phút trước${o.authExists ? "" : " (tài khoản Auth đã không còn)"}`));
    console.log(APPLY ? `Đã xoá ${r.deleted} tài khoản mồ côi.` : "DRY-RUN — thêm --apply để xoá thật.");
    process.exit(0);
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
