#!/usr/bin/env node
/**
 * purge-ghost-profiles.js  (v2.2.1 — báo cáo bảo mật 2.2.0, A-02 / T-220-01)
 * Quét và (tuỳ chọn) xoá:
 *   • "hồ sơ ma" users/{uid}: chỉ có điểm số, không có status/email/tagName/displayName/uid và không còn tài khoản Firebase Auth;
 *   • userPrivate/{uid} (tên thật) mồ côi: không có hồ sơ users/{uid} và không còn tài khoản Auth.
 * Hồ sơ có `status` hoặc có tài khoản Auth KHÔNG BAO GIỜ bị đụng tới. MẶC ĐỊNH LÀ DRY-RUN.
 *   npm run ghosts:purge
 *   npm run ghosts:purge:apply
 */
require("dotenv").config();
const { purgeGhosts } = require("../src/services/ghostCleanup");

const APPLY = process.argv.includes("--apply");

purgeGhosts({ apply: APPLY })
  .then((r) => {
    console.log(`Hồ sơ ma: ${r.ghostProfiles.length}; userPrivate mồ côi: ${r.strayPrivate.length}.`);
    r.ghostProfiles.forEach((g) => console.log(`  - users/${g.uid} (positiveScore=${g.positiveScore}, accountScore=${g.accountScore})`));
    r.strayPrivate.forEach((s) => console.log(`  - userPrivate/${s.uid}`));
    console.log(APPLY ? `Đã xoá ${r.deleted} mục.` : "DRY-RUN — thêm --apply để xoá thật.");
    process.exit(0);
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
