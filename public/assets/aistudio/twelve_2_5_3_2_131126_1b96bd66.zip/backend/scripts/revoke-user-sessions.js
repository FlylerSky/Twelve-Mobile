#!/usr/bin/env node
/**
 * revoke-user-sessions.js  (v2.5.3 — TW-05: tài khoản thử nghiệm đã giao cho bên khác / nghi lộ phiên)
 * Thu hồi MỌI phiên đăng nhập của các tài khoản được nêu (ID token cũ bị từ chối trong ≤ 1 phút — middleware kiểm thu hồi có cache 60 giây), tuỳ chọn hạ về RA/user và/hoặc vô hiệu hoá.
 * MẶC ĐỊNH LÀ DRY-RUN (chỉ in tình trạng hiện tại và việc SẼ làm). Không bao giờ nhận/in mật khẩu — đổi mật khẩu ở Firebase Console > Authentication.
 *   npm run sessions:revoke -- --uid=UID1,UID2 [--email=a@x.com,b@y.com] [--demote] [--disable]
 *   npm run sessions:revoke:apply -- --uid=UID1 --demote --disable
 */
require("dotenv").config();

const argv = process.argv.slice(2);
const listArg = (name) => {
  const a = argv.find((x) => x.startsWith(`--${name}=`));
  return a ? a.slice(name.length + 3).split(",").map((s) => s.trim()).filter(Boolean) : [];
};
const APPLY = argv.includes("--apply");
const uids = listArg("uid");
const emails = listArg("email");

if (!uids.length && !emails.length) {
  console.error("Thiếu đối tượng. Ví dụ: npm run sessions:revoke -- --uid=UID1,UID2 [--email=a@x.com] [--demote] [--disable]");
  process.exit(2);
}

// Nạp service SAU khi kiểm tra tham số: thiếu đối tượng thì thoát ngay, không khởi tạo Firebase.
const { revokeUserSessions } = require("../src/services/revokeSessions");

revokeUserSessions({ uids, emails, apply: APPLY, disable: argv.includes("--disable"), demote: argv.includes("--demote") })
  .then(({ results }) => {
    let failed = 0;
    for (const r of results) {
      if (!r.ok) { failed++; console.log(`  ✖ ${r.uid || "(email)"}: ${r.error}`); continue; }
      const b = r.before;
      console.log(`  • ${r.uid}: nhóm ${b.group}/${b.role}, trạng thái ${b.status}, ${b.disabled ? "ĐÃ vô hiệu hoá" : "đang bật"}, token hợp lệ từ ${b.tokensValidAfter || "?"} → ${APPLY ? "ĐÃ" : "SẼ"}: ${r.actions.join(" + ")}`);
    }
    console.log(APPLY ? `Xong: ${results.length - failed} tài khoản đã xử lý, ${failed} lỗi. Nhớ đổi mật khẩu ở Firebase Console.` : "DRY-RUN — thêm --apply để thực hiện thật.");
    process.exit(failed ? 1 : 0);
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
