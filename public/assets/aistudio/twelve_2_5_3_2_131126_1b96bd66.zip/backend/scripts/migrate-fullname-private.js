#!/usr/bin/env node
/**
 * migrate-fullname-private.js  (v2.2.0)
 * Chuyển tên thật (`fullName`) từ `users/{uid}` sang `userPrivate/{uid}` cho các tài khoản tạo TRƯỚC v2.2.0.
 * Lý do: chủ tài khoản đọc thẳng được `users/{uid}` bằng Client SDK nên tên thật trong đó đi tới trình duyệt, làm yêu cầu
 * "xem/đổi tên thật phải nhập lại mật khẩu" thành hình thức (xem services/userPrivate.js).
 *
 * KHÔNG bắt buộc chạy ngay: backend tự chuyển lười từng tài khoản khi chủ tài khoản xem/đổi tên thật, và không bao giờ trả `fullName`
 * trong GET /users/me. Chạy script này để dọn dứt điểm phần còn lại.
 * An toàn chạy lại nhiều lần: GHI `userPrivate` trước, XOÁ field cũ sau; tài khoản đã có `userPrivate` chỉ bị dọn field cũ.
 * MẶC ĐỊNH LÀ DRY-RUN.
 *   npm run realname:migrate
 *   npm run realname:migrate:apply
 */
require("dotenv").config();
const { db, admin } = require("../src/config/firebase");
const { COLLECTIONS } = require("../src/utils/constants");
const { moveLegacyFullName } = require("../src/services/userPrivate");

async function migrate({ apply = false, pageSize = 300 } = {}) {
  const result = { scanned: 0, legacy: 0, moved: 0 };
  let last = null;
  for (;;) {
    let q = db.collection(COLLECTIONS.USERS).orderBy("__name__").limit(pageSize);
    if (last) q = q.startAfter(last);
    const snap = await q.get();
    if (snap.empty) break;
    for (const doc of snap.docs) {
      result.scanned++;
      const fullName = doc.data().fullName;
      if (fullName === undefined) continue;
      result.legacy++;
      if (!apply) continue;
      if (typeof fullName === "string" && fullName) {
        await moveLegacyFullName(doc.id, fullName);
      } else {
        await doc.ref.update({ fullName: admin.firestore.FieldValue.delete() }); // field rỗng/sai kiểu: chỉ dọn
      }
      result.moved++;
    }
    last = snap.docs[snap.docs.length - 1];
    if (snap.docs.length < pageSize) break;
  }
  return result;
}

module.exports = { migrate };

if (require.main === module) {
  const APPLY = process.argv.includes("--apply");
  migrate({ apply: APPLY })
    .then((r) => {
      console.log(`Đã quét ${r.scanned} hồ sơ; còn tên thật ở kiểu cũ: ${r.legacy}.`);
      console.log(APPLY ? `Đã chuyển ${r.moved} hồ sơ sang userPrivate.` : "DRY-RUN — thêm --apply để chuyển thật.");
      process.exit(0);
    })
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}
