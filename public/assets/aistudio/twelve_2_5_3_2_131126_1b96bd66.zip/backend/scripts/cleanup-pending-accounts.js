#!/usr/bin/env node
/**
 * cleanup-pending-accounts.js  (v2.2.1 — báo cáo bảo mật 2.2.0, A-04)
 * Dọn tài khoản `pending` (chưa xác minh email) QUÁ HẠN — giải phóng Tag Name Search và email bị chiếm vĩnh viễn. Bỏ qua tài khoản đã xác minh email
 * (Firebase Auth `emailVerified`) và hồ sơ thiếu `createdAt`. Việc xoá được XẾP HÀNG vào quy trình xoá bền vững (server tự xử lý trong ≤1 phút).
 * MẶC ĐỊNH LÀ DRY-RUN. Mặc định quá hạn 7 ngày (v2.5.3; env PENDING_MAX_AGE_DAYS); đổi bằng --days=N.
 * Từ v2.5.3 server TỰ dọn định kỳ (services/pendingCleanup.js#startPendingSweeper) — script này còn để chạy thử/dry-run hoặc dọn ngay.
 *   npm run pending:cleanup
 *   npm run pending:cleanup:apply
 */
require("dotenv").config();
const { cleanupExpiredPending, pendingMaxAgeDays } = require("../src/services/pendingCleanup");

const APPLY = process.argv.includes("--apply");
const daysArg = process.argv.find((a) => a.startsWith("--days="));
const DAYS = daysArg ? Math.max(1, parseInt(daysArg.split("=")[1], 10) || pendingMaxAgeDays()) : pendingMaxAgeDays();

cleanupExpiredPending({ apply: APPLY, maxAgeDays: DAYS })
  .then((r) => {
    console.log(`Đã quét ${r.scanned} tài khoản pending; quá ${DAYS} ngày & chưa xác minh: ${r.expired.length}; bỏ qua: ${r.skippedVerified} đã xác minh email, ${r.skippedYoung} còn mới, ${r.skippedNoDate} thiếu ngày tạo.`);
    r.expired.forEach((e) => console.log(`  - ${e.uid} <${e.email}> @${e.tagName} (${e.ageDays} ngày)`));
    if (r.truncated) console.log("(Đã chạm giới hạn quét — còn tài khoản chưa xét; chạy lại.)");
    if (APPLY && r.skippedLate) console.log(`Bỏ qua ${r.skippedLate} tài khoản vừa xác minh/kích hoạt trong lúc chạy (kiểm lại ngay trước khi xoá).`);
    console.log(APPLY ? `Đã xếp hàng xoá ${r.queued} tài khoản (server sẽ xử lý trong ≤1 phút; xem: npm run deletions:list).` : "DRY-RUN — thêm --apply để xếp hàng xoá thật.");
    process.exit(0);
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
