#!/usr/bin/env node
/**
 * account-deletions.js  (v2.2.0)
 * Xem hàng chờ xoá tài khoản (`accountDeletions`) và đặt lại các việc đã bị đánh dấu `failed`.
 * Bình thường không cần dùng: server tự nhặt việc dang dở (sau khi khởi động và mỗi phút) và tự thử lại với backoff. Một việc chỉ thành
 * `failed` sau nhiều lần lỗi liên tiếp (thường do Cloudinary/Firebase sự cố kéo dài) — sửa nguyên nhân rồi chạy `--retry-failed`.
 *   npm run deletions:list
 *   npm run deletions:retry-failed
 */
require("dotenv").config();
const { db } = require("../src/config/firebase");
const { COLLECTIONS } = require("../src/utils/constants");

async function listDeletions({ retryFailed = false, now = Date.now() } = {}) {
  const snap = await db.collection(COLLECTIONS.ACCOUNT_DELETIONS).limit(500).get();
  const rows = snap.docs
    .map((d) => d.data())
    .sort((a, b) => (a.requestedAtMs || 0) - (b.requestedAtMs || 0))
    .map((e) => ({
      uid: e.uid,
      status: e.status,
      step: e.step,
      failures: e.failures || 0,
      ageMin: Math.round((now - (e.requestedAtMs || now)) / 60000),
      lastError: e.lastError || null,
    }));
  let requeued = 0;
  if (retryFailed) {
    for (const e of rows.filter((r) => r.status === "failed")) {
      await db.collection(COLLECTIONS.ACCOUNT_DELETIONS).doc(e.uid).update({
        status: "queued", failures: 0, nextAttemptAtMs: 0, leaseOwner: null, leaseUntilMs: 0,
      });
      requeued++;
    }
  }
  return { rows, requeued };
}

module.exports = { listDeletions };

if (require.main === module) {
  const RETRY = process.argv.includes("--retry-failed");
  listDeletions({ retryFailed: RETRY })
    .then(({ rows, requeued }) => {
      if (!rows.length) console.log("Hàng chờ trống — không có tài khoản nào đang xoá dở.");
      rows.forEach((r) => console.log(`  - ${r.uid} [${r.status}] bước=${r.step} lỗi=${r.failures} ${r.ageMin} phút trước${r.lastError ? ` — ${r.lastError}` : ""}`));
      if (RETRY) console.log(`Đã đặt lại ${requeued} việc 'failed' vào hàng chờ (server sẽ nhặt trong ≤1 phút).`);
      process.exit(0);
    })
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}
