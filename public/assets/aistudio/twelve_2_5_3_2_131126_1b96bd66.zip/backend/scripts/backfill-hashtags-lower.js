#!/usr/bin/env node
/**
 * backfill-hashtags-lower.js  (v2.0.5)
 * Điền `hashtagsLower` (hashtag chữ thường) cho posts/blogs tạo TRƯỚC bản vá. Mặc định DRY-RUN.
 *   npm run hashtags:backfill            # chỉ đếm
 *   npm run hashtags:backfill:apply      # ghi thật (theo lô 400, an toàn chạy lại nhiều lần)
 */
require("dotenv").config();
const { db, admin } = require("../src/config/firebase");
const { COLLECTIONS } = require("../src/utils/constants");
const { toHashtagsLower } = require("../src/utils/helpers");

const APPLY = process.argv.includes("--apply");

async function backfill(collectionName) {
  let last = null;
  let scanned = 0;
  let needs = 0;
  for (;;) {
    let q = db.collection(collectionName).orderBy(admin.firestore.FieldPath.documentId()).limit(400);
    if (last) q = q.startAfter(last);
    const snap = await q.get();
    if (snap.empty) break;
    const batch = db.batch();
    let inBatch = 0;
    for (const doc of snap.docs) {
      scanned += 1;
      const tags = doc.get("hashtags");
      if (!Array.isArray(tags)) continue;
      const lower = toHashtagsLower(tags);
      const cur = doc.get("hashtagsLower");
      if (Array.isArray(cur) && cur.length === lower.length && cur.every((v, i) => v === lower[i])) continue;
      needs += 1;
      if (APPLY) {
        batch.update(doc.ref, { hashtagsLower: lower });
        inBatch += 1;
      }
    }
    if (APPLY && inBatch) await batch.commit();
    last = snap.docs[snap.docs.length - 1];
    if (snap.size < 400) break;
  }
  console.log(`${collectionName}: quét ${scanned}, cần cập nhật ${needs}${APPLY ? " (đã ghi)" : " (dry-run)"}`);
}

(async () => {
  await backfill(COLLECTIONS.POSTS);
  await backfill(COLLECTIONS.BLOGS);
  if (!APPLY) console.log("DRY-RUN — thêm --apply để ghi.");
})().then(() => process.exit(0), (e) => { console.error(e); process.exit(1); });
