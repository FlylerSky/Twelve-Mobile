require("dotenv").config();
const { db } = require("../config/firebase");
const { COLLECTIONS } = require("../utils/constants");
const pkg = require("../../package.json");

async function run() {
  // v2.2.1: mặc định lấy từ package.json (trước đây cứng "2.0.3.011026" nên quên đặt BACKEND_VERSION là nhãn phiên bản trong UI lệch với /health).
  const version = process.env.BACKEND_VERSION || pkg.version;
  await db.collection(COLLECTIONS.CONFIG).doc("version").set({ backend: version });
  console.log(`✅ Đã set phiên bản backend = ${version} trong Firestore (config/version).`);
  process.exit(0);
}

run().catch((err) => {
  console.error("Seed version thất bại:", err);
  process.exit(1);
});
