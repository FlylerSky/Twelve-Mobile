/**
 * Chuẩn hoá Firestore Timestamp / Date / object {_seconds|seconds} thành ISO
 * string. Tránh lỗi EJS in ra "[object Object]" khi SSR.
 *
 * v2.0.0: MỘT bản duy nhất — trước đây chép nguyên văn ở posts.controller,
 * blog.controller và (biến thể `toIsoStringLocal`) trending.controller.
 */
function toIsoString(value) {
  if (!value) return null;
  if (typeof value === "string") return value;
  if (value instanceof Date) return value.toISOString();
  if (typeof value.toDate === "function") {
    try {
      return value.toDate().toISOString();
    } catch (_) {
      /* fall through */
    }
  }
  if (typeof value._seconds === "number") {
    return new Date(value._seconds * 1000).toISOString();
  }
  if (typeof value.seconds === "number") {
    return new Date(value.seconds * 1000).toISOString();
  }
  return null;
}

module.exports = { toIsoString };
