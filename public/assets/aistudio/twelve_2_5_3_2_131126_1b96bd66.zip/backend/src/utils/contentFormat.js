const { htmlToExcerpt } = require("../services/sanitize.service");
const { computePostScore } = require("./helpers");
const { toIsoString } = require("./time");

/**
 * ==== v2.0.0 — Định dạng response bài viết/blog (dùng chung Post + Blog + SSR) ====
 * Trước đây `formatCardPost`/`formatFullPost` nằm trong posts.controller còn
 * blog.controller tự viết lại danh sách field của card (và thiếu fallback
 * excerpt cho bài cũ). Cả hai cùng dùng các hàm này.
 */

/** Dữ liệu cho card trên trang INDEX/BLOG (không cần full content). */
function formatCardContent(p) {
  return {
    id: p.id,
    author: p.author,
    title: p.title,
    excerpt: p.excerpt || htmlToExcerpt(p.contentHtml),
    coverImageUrl: p.coverImageUrl,
    // v0.9.7 — hashtag bài viết
    hashtags: p.hashtags || [],
    likeCount: p.likeCount,
    dislikeCount: p.dislikeCount,
    commentCount: p.commentCount,
    // Card chỉ HIỂN THỊ view/share, không làm tăng (chỉ trang chi tiết mới tăng)
    viewCount: p.viewCount || 0,
    aiViewCount: p.aiViewCount || 0,
    shareCount: p.shareCount || 0,
    // Điểm bài viết — LUÔN tính lại từ 5 thông số gốc ở trên, không lưu
    // riêng (xem utils/helpers.js#computePostScore).
    postScore: computePostScore(p),
    createdAt: toIsoString(p.createdAt),
  };
}

function formatFullContent(p) {
  return {
    id: p.id,
    author: p.author,
    title: p.title,
    contentHtml: p.contentHtml,
    // Luôn có excerpt cho meta description / OG (kể cả bài cũ chưa lưu excerpt)
    excerpt: p.excerpt || htmlToExcerpt(p.contentHtml),
    coverImageUrl: p.coverImageUrl,
    // v0.9.7 — hashtag bài viết
    hashtags: p.hashtags || [],
    likeCount: p.likeCount || 0,
    dislikeCount: p.dislikeCount || 0,
    commentCount: p.commentCount || 0,
    viewCount: p.viewCount || 0,
    aiViewCount: p.aiViewCount || 0,
    shareCount: p.shareCount || 0,
    postScore: computePostScore(p),
    createdAt: toIsoString(p.createdAt),
    updatedAt: toIsoString(p.updatedAt),
  };
}

module.exports = { formatCardContent, formatFullContent };
