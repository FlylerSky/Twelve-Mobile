const { db } = require("../config/firebase");
const { COLLECTIONS } = require("./constants");
const { toPublicUser, isLiveProfile } = require("./helpers");
const { isSafeDocId } = require("./input");

/**
 * Gắn `author` (hồ sơ công khai) vào danh sách bài viết/blog theo `authorUid`.
 * v2.0.0: chuyển từ posts.controller về utils (blog/trending/SSR cùng dùng —
 * trước đây blog.controller phải `require("./posts.controller")` chỉ để lấy hàm này).
 */
async function attachAuthors(items) {
  // v2.5.3 [TW-14]: `authorUid` có thể là null/số/chuỗi có "/" (dữ liệu di trú `scripts/migrate-legacy-data.js` gán `d.uid || null`). `.doc(null)` ném lỗi đồng bộ ⇒ trước đây
  // cả trang feed/blog/trending/SSR chứa MỘT phần tử như vậy trả 500. Nay chỉ tra cứu uid hợp lệ; phần tử còn lại nhận `author: null` (giao diện đã xử lý "tác giả ẩn").
  const uids = [...new Set(items.map((p) => p.authorUid).filter(isSafeDocId))];
  const authorDocs = await Promise.all(uids.map((uid) => db.collection(COLLECTIONS.USERS).doc(uid).get()));
  const authorMap = {};
  authorDocs.forEach((d) => {
    if (d.exists && isLiveProfile(d.data())) authorMap[d.id] = toPublicUser(d.data()); // v2.2.1: bỏ hồ sơ ma (không có status)
  });
  return items.map((p) => ({ ...p, author: (isSafeDocId(p.authorUid) && authorMap[p.authorUid]) || null }));
}

module.exports = { attachAuthors };
