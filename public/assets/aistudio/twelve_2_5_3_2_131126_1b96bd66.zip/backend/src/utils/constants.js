// ==== Nhóm & vai trò tài khoản ====
const ACCOUNT_GROUP = {
  SA: "SA", // Senior Account: quyền hạn cao
  RA: "RA", // Regular Account: người dùng sở hữu tài khoản
  LLA: "LLA", // Low Level Account: tài khoản thử nghiệm, không có quyền sở hữu
};

const ACCOUNT_ROLE = {
  // SA
  ADMIN: "admin",
  DEV: "dev",
  MODERATOR: "moderator",
  // RA
  PRO_USER: "pro_user",
  USER: "user",
  // LLA
  TEST: "test",
};

// Vai trò nào thuộc nhóm nào (dùng để suy ra accountGroup từ accountRole khi cần)
const ROLE_TO_GROUP = {
  [ACCOUNT_ROLE.ADMIN]: ACCOUNT_GROUP.SA,
  [ACCOUNT_ROLE.DEV]: ACCOUNT_GROUP.SA,
  [ACCOUNT_ROLE.MODERATOR]: ACCOUNT_GROUP.SA,
  [ACCOUNT_ROLE.PRO_USER]: ACCOUNT_GROUP.RA,
  [ACCOUNT_ROLE.USER]: ACCOUNT_GROUP.RA,
  [ACCOUNT_ROLE.TEST]: ACCOUNT_GROUP.LLA,
};

const ACCOUNT_STATUS = {
  PENDING: "pending", // Chưa kích hoạt
  ACTIVE: "active",
  SUSPENDED: "suspended", // Dùng cho LLA có thể bị tước quyền bất cứ lúc nào
  // v2.2.0 — tài khoản đang trong quy trình xoá (xem services/accountDeletion.js). KHÔNG đăng nhập/thao tác được nữa,
  // hồ sơ công khai trả 404 như chưa tồn tại; hồ sơ bị xoá SAU CÙNG nên trạng thái này còn lại là dấu vết nếu server sập giữa chừng.
  DELETING: "deleting",
};

const REACTION_TYPE = {
  LIKE: "like",
  DISLIKE: "dislike",
};

// ==== v0.9.6 [MEDIUM] — Giới hạn độ dài nội dung do người dùng nhập ====
// Trước đây `title` (bài viết/blog) chỉ được kiểm tra "có tồn tại", không có
// độ dài tối đa/tối thiểu — tiêu đề dài bất thường có thể gây vấn đề hiển
// thị, phình document Firestore, và ảnh hưởng SEO/OG tags. `editComment`
// cũng thiếu giới hạn độ dài (trong khi `addComment` đã có sẵn 2000 ký tự),
// cho phép lách giới hạn ban đầu bằng cách tạo comment ngắn rồi sửa dài ra.
// Xem CHANGELOG-v0.9.6.md.
const CONTENT_LIMITS = {
  TITLE_MIN: 5,
  TITLE_MAX: 200,
  COMMENT_MAX: 2000,
  COVER_IMAGE_URL_MAX: 2000,
  // v0.9.7 — hashtag bài viết/blog
  HASHTAG_MAX_COUNT: 20,
  HASHTAG_MAX_LENGTH: 30, // số ký tự tối đa SAU dấu #
  // v0.10.17 — phân trang danh sách bình luận (xem comments.controller.js#listComments)
  COMMENTS_PAGE_SIZE: 20,
  COMMENTS_PAGE_SIZE_MAX: 50,
  // v2.0.10 [BẢO MẬT F1] — giới hạn đầu vào của `contentHtml` TRƯỚC khi sanitize (xem services/contentPipeline.js).
  // Đã đo: bài thật 118 KB ≈ 0,5 giây; thẻ lạ/`<table>` bị DOMPurify "gỡ vỏ" tốn thời gian siêu tuyến tính
  // (2.000 thẻ ≈ 1 giây, 6.000 phần tử bảng ≈ 3,6 giây); `<div>` lồng sâu tốn bậc hai.
  HTML_MAX_CHARS: 250000,
  HTML_MAX_ELEMENTS: 5000,
  HTML_MAX_DEPTH: 100,
  HTML_MAX_DISALLOWED: 300,
  HTML_MAX_MEDIA: 200, // img/video/audio/source/iframe — mỗi phần tử phải kiểm tra URL nên đắt hơn (5.000 ảnh ≈ 3,4 giây)
  SANITIZE_TIMEOUT_MS: 3000,
};

// ==== Tên collection Firestore ====
const COLLECTIONS = {
  USERS: "users",
  TAGNAMES: "tagNames", // dùng để đảm bảo Tag Name Search là duy nhất: doc id = tagName (không có @)
  POSTS: "posts",
  BLOGS: "blogs",
  COUNTRIES: "countries",
  CONFIG: "config", // doc "version" chứa { backend: "0.1.0" }
  ACTIVATIONS: "activations", // mã kích hoạt tài khoản, tách riêng khỏi users để dễ quản lý TTL
  // v0.10.0 — trang Xu hướng (Trending)
  WEEKLY_LEADERBOARDS: "weeklyLeaderboards", // doc id = mã tuần "N.K.MM.YYYY", lưu VĨNH VIỄN top 10 đã chốt của tuần đó
  // v0.10.8 — tab Hashtag của trang Xu hướng
  HASHTAGS: "hashtags", // doc id = hashtag đã chuẩn hoá (chữ thường, không có "#") — chỉ lưu mốc weeklySnapshot để tính tăng trưởng tuần, KHÔNG lưu tổng điểm hiện tại (luôn quét lại từ posts/blogs, xem trending.controller.js)
  HASHTAG_WEEKLY_LEADERBOARDS: "hashtagWeeklyLeaderboards", // doc id = "{mãTuầnCũ}_{classic|advanced}", lưu VĨNH VIỄN top 10 Hashtag tăng trưởng mạnh nhất tuần đã chốt
  HASHTAG_EXPLORE_SNAPSHOTS: "hashtagExploreSnapshots", // doc id = "{mãTuầnCũ}_{classic|advanced}", lưu top 10 Hashtag toàn thời gian (tab Khám phá) tại thời điểm chốt tuần — phục vụ thành tích/vinh danh sau này
};

// (ASSETS được thêm bên dưới, ngay sau object COLLECTIONS, để khỏi làm rối khối comment dài phía trên)
COLLECTIONS.REGISTRATION_MARKERS = "registrationMarkers"; // v2.0.12 [N3] — dấu "đang đăng ký dở" của luồng /auth/register (doc id = uid Firebase Auth), xem services/orphanAuth.js
COLLECTIONS.ACCOUNT_DELETIONS = "accountDeletions"; // v2.2.0 — hàng chờ/sổ theo dõi xoá tài khoản (doc id = uid), xem services/accountDeletion.js
COLLECTIONS.USER_PRIVATE = "userPrivate"; // v2.2.0 — dữ liệu riêng của user mà Client SDK KHÔNG được đọc (hiện: tên thật `fullName`), doc id = uid; rules chặn hoàn toàn
COLLECTIONS.DEBUG_RUNS = "debugRuns"; // v2.3.0 — kết quả TÓM TẮT lần chạy gần nhất của từng module "Gỡ lỗi" (doc id = id module; KHÔNG lưu log). rules chặn hoàn toàn (khác `config` là đọc công khai!)
COLLECTIONS.ASSETS = "assets"; // v0.10.20 — sổ đăng ký MỌI file người dùng upload lên Cloudinary (doc id = publicId, "/" đổi thành "__"), xem services/assets.service.js
COLLECTIONS.PROFILE_VISITORS = "profileVisitors"; // v2.5.2 — lịch sử KHÁCH GHÉ THĂM hồ sơ: doc id = uid CHỦ hồ sơ, `{ visitors: [{ uid, at }] }` (≤ PROFILE.VISITORS_MAX, mới nhất đứng đầu). rules chặn hoàn toàn Client SDK — chỉ chủ hồ sơ xem được, qua GET /users/me/visitors
COLLECTIONS.CONFIG_AUDIT = "configAudit"; // v2.5.3 [TW-09] — nhật ký THÊM-CHỈ các thay đổi cấu hình của SA (domain nhúng, font, đặt lại báo cáo CSP): ai, lúc nào, diff. rules chặn hoàn toàn Client SDK; xem services/configAudit.js

// Sub-collection names (đặt trong doc bài viết / blog)
const SUBCOLLECTIONS = {
  COMMENTS: "comments",
  REACTIONS: "reactions", // mỗi doc id = uid, field type: like/dislike
  SHARES: "shares", // mỗi doc = 1 lượt share được TÍNH (đã có người click link), field sharerUid có thể null
  VIEWS: "views", // mỗi doc id = viewerKey (uid/session/ip), chống đếm trùng view trong 1 khoảng thời gian (v0.8.3)
  POSITIVE_SCORE_LOGS: "positiveScoreLogs", // audit log: mỗi lần cộng/trừ positiveScore đều ghi 1 doc ở đây
};

// v0.10.0 — trang Xu hướng (Trending): giới hạn/tầng hiển thị bảng xếp hạng.
// "Đại sảnh" = top 1-3, "Top 4-10", "Top 11-100". RANKING_LIMIT là tổng số
// user tối đa trả về cho mỗi bảng xếp hạng (Tuần qua / Toàn thời gian).
const TRENDING = {
  RANKING_LIMIT: 100,
  HALL_OF_FAME_SIZE: 3,
  TOP_TIER_SIZE: 10,
  // v0.10.8 — tab Hashtag: số bài viết tối đa hiển thị khi click vào 1 Hashtag,
  // và số kết quả tối đa cho mỗi loại ở tab Tìm kiếm.
  HASHTAG_POST_LIMIT: 100,
  SEARCH_RESULT_LIMIT: 50,
};

// v0.10.8 — 2 "chế độ" xếp hạng dùng chung cho tab Hashtag (Cổ điển/Nâng cao)
// và tab Tìm kiếm (sắp xếp theo "thịnh hành"). CLASSIC dùng postScore (đã bao
// gồm cả tự tương tác), ADVANCED dùng externalPostScore (chỉ tính tương tác
// từ người khác — chống farm điểm, xem utils/helpers.js#computePostScore).
const SCORE_MODE = {
  CLASSIC: "classic",
  ADVANCED: "advanced",
};

// ==== v0.10.20 — Quản lý tài nguyên Cloudinary do người dùng upload ====
// Mọi thứ liên quan tới "được upload gì, bao lớn, để ở đâu" gom về đây để khi
// mở rộng upload (ảnh bài viết, video...) chỉ cần THÊM 1 mục vào ASSET_KIND +
// ASSET_LIMITS, không phải rải hằng số khắp nơi như trước.
const ASSET_ROOT_FOLDER = "twelve"; // mọi public_id do Twelve tạo đều bắt đầu bằng "twelve/"

const ASSET_KIND = {
  AVATAR: "avatar", // 1 ảnh/user, GHI ĐÈ khi đổi (public_id cố định theo uid)
  COVER: "cover", // v2.4.0 — ảnh bìa hồ sơ: 1 ảnh/user, GHI ĐÈ khi đổi (public_id cố định theo uid, thư mục `twelve/covers/<uid>/`)
};

const ASSET_LIMITS = {
  [ASSET_KIND.AVATAR]: {
    // Frontend luôn cắt 512x512 JPEG (~100-300KB, xem AvatarCropper.jsx) nên 2MB
    // đã là dư nhiều; trước v0.10.20 là 10MB (chỉ để chừa chỗ cho ảnh gốc, nhưng
    // ảnh gốc không bao giờ được gửi lên server).
    MAX_BYTES: 2 * 1024 * 1024,
    // Chỉ định dạng ảnh tĩnh phổ biến. Bỏ GIF (ảnh động phình dung lượng) và AVIF.
    ALLOWED_MIMES: ["image/jpeg", "image/png", "image/webp"],
    // Số asset tối đa 1 user được giữ cho loại này (cơ sở để mở rộng quota sau này).
    MAX_PER_USER: 1,
  },
  // v2.4.0 — ảnh bìa hồ sơ. Frontend cắt sẵn tỉ lệ 3:1 và xuất 1500x500 JPEG (~100–400 KB) nên 3 MB là dư;
  // vẫn chặn ở backend vì client không đáng tin. Cùng định dạng cho phép như avatar (không GIF/AVIF).
  [ASSET_KIND.COVER]: {
    MAX_BYTES: 3 * 1024 * 1024,
    ALLOWED_MIMES: ["image/jpeg", "image/png", "image/webp"],
    MAX_PER_USER: 1,
  },
};

// ==== v2.4.0 — Trang Profile ====
// PINNED_POSTS_MAX: số bài tối đa một người được ghim lên Trang chủ hồ sơ. Đổi ở đây là đủ — backend (pinPost) và
// frontend (nhận lỗi PIN_LIMIT_REACHED từ API) không hard-code số này ở chỗ nào khác.
// USER_POSTS_PAGE_*: phân trang danh sách bài ở tab "Bài viết" (GET /api/users/:uid/posts).
const PROFILE = {
  PINNED_POSTS_MAX: 3,
  USER_POSTS_PAGE_SIZE: 10,
  USER_POSTS_PAGE_SIZE_MAX: 30,
  COVER_URL_MAX: 2000,
  // v2.4.1 — khung hiển thị ảnh bìa (vùng người dùng chọn khi kéo/thu phóng), tính theo % kích thước ảnh gốc.
  // Chiều rộng tối thiểu 10% (≈ phóng tối đa 10 lần) — chặn giá trị phi lý làm ảnh phóng khổng lồ trong CSS.
  COVER_CROP_MIN_PERCENT: 10,
  // ==== v2.5.2 — Tiểu sử, khách ghé thăm, tab Blog ====
  // BIO_MAX: số code point tối đa của Tiểu sử (emoji đơn tính 1, emoji ghép ZWJ tính nhiều); BIO_MAX_LINES: số DÒNG tối đa (chặn "xuống dòng liên tục" làm đầu hồ sơ dài vô hạn).
  BIO_MAX: 300,
  BIO_MAX_LINES: 6,
  // VISITORS_MAX: chỉ nhớ chừng này người ghé thăm gần nhất (không trùng; ai vào lại thì được đưa lên đầu). Đổi ở đây là đủ.
  // VISIT_REFRESH_MS: người đang đứng ĐẦU danh sách mà vào lại trong khoảng này thì KHÔNG ghi lại (chống ghi Firestore mỗi lần F5/chuyển tab).
  VISITORS_MAX: 50,
  VISIT_REFRESH_MS: 5 * 60 * 1000,
  // Thành tích tuần: số tuần gần nhất liệt kê trong hộp "Xem thêm" (các con số tổng vẫn tính trên MỌI tuần đã chốt).
  ACHIEVEMENT_RECENT_WEEKS: 10,
};

// ==== v2.2.0 — Xoá tài khoản & xác nhận lại mật khẩu ====
// Mọi hằng số vận hành của quy trình xoá gom về đây (có thể chỉnh bằng biến môi trường, xem services/accountDeletion.js).
const ACCOUNT_DELETION = {
  // Một bước xoá phải "gia hạn hợp đồng" (lease) trong thời gian này; hết hạn mà chưa gia hạn = tiến trình đã chết, instance khác được nhận lại.
  LEASE_MS: 3 * 60 * 1000,
  // Số tài khoản xử lý SONG SONG trong một instance (phần còn lại nằm chờ trong hàng đợi Firestore).
  MAX_CONCURRENT: 2,
  // Quét hàng đợi định kỳ (và 1 lần ngay sau khi khởi động) để nhặt việc dang dở.
  SWEEP_INTERVAL_MS: 60 * 1000,
  BOOT_DELAY_MS: 5 * 1000,
  // Số bài/blog xoá mỗi vòng.
  CONTENT_BATCH: 20,
  // Lỗi liên tiếp quá ngưỡng này thì đánh dấu "failed" (cần người xử lý, xem scripts/account-deletions.js).
  MAX_FAILURES: 10,
  BACKOFF_BASE_MS: 15 * 1000,
  BACKOFF_MAX_MS: 30 * 60 * 1000,
  // Số lần được "quay lại bước xoá nội dung" khi bước kiểm cuối phát hiện còn bài sót.
  MAX_REWINDS: 3,
  // v2.2.1 [A-02]: bước "verify" chạy lại sau khi hồ sơ đã xoá một khoảng ngắn — đủ dài hơn một request bị kẹt (Render cắt request ở ~100 giây)
  // để dọn mọi thứ bị dựng lại muộn (userPrivate, hồ sơ "ma", bài mồ côi). Đặt 0 để verify chạy ngay (dùng trong test).
  VERIFY_DELAY_MS: 2 * 60 * 1000,
};

// Thao tác nhạy cảm (đổi mật khẩu/tên thật, xoá tài khoản) chỉ được chấp nhận nếu người dùng vừa nhập lại mật khẩu trong chừng này giây
// (so với `auth_time` của ID token — Firebase cập nhật khi reauthenticateWithCredential).
const RECENT_AUTH_MAX_AGE_SEC = 5 * 60;

module.exports = {
  PROFILE,
  ACCOUNT_DELETION,
  RECENT_AUTH_MAX_AGE_SEC,
  ACCOUNT_GROUP,
  ACCOUNT_ROLE,
  ROLE_TO_GROUP,
  ACCOUNT_STATUS,
  REACTION_TYPE,
  COLLECTIONS,
  SUBCOLLECTIONS,
  CONTENT_LIMITS,
  TRENDING,
  SCORE_MODE,
  ASSET_ROOT_FOLDER,
  ASSET_KIND,
  ASSET_LIMITS,
};
