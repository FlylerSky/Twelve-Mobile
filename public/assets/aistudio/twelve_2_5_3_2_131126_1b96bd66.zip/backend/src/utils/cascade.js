const { SUBCOLLECTIONS } = require("./constants");

/**
 * ==== v2.0.5 [DỌN DỮ LIỆU] Xoá subcollection của bài viết/blog sau khi xoá document cha ====
 *
 * Firestore KHÔNG tự xoá subcollection khi xoá document cha. Trước đây deletePost/deleteBlog để lại
 * `comments`, `views`, `reactions` mồ côi; vì rules cho đọc công khai `posts/{id}/comments/*`, nội
 * bình luận của bài đã xoá vẫn đọc được qua SDK. Nay xoá đệ quy NỀN (không chặn response; có thể lâu
 * khi bài có nhiều view). Lỗi chỉ ghi log — `scripts/purge-orphan-subcollections.js` dọn phần sót.
 *
 * ==== v2.2.0 — tách phần xoá thật ra `deleteContentTree` (NÉM LỖI) ====
 * Quy trình xoá tài khoản (services/accountDeletion.js) cũng cần đúng thao tác này nhưng PHẢI biết khi nó thất bại để
 * thử lại — nên logic nằm ở một chỗ (`deleteContentTree`, ném lỗi), còn `purgeContentSubcollections` chỉ là vỏ "nuốt lỗi + log"
 * cho đường xoá bài thường ngày. Sửa cách xoá ở đây là áp dụng cho cả hai.
 */
async function deleteContentTree(db, parentRef) {
  if (typeof db.recursiveDelete === "function") {
    await db.recursiveDelete(parentRef);
    return;
  }
  // Fallback (SDK cũ / test): xoá từng subcollection đã biết theo lô 400.
  for (const name of Object.values(SUBCOLLECTIONS)) {
    for (;;) {
      const snap = await parentRef.collection(name).limit(400).get();
      if (snap.empty) break;
      const batch = db.batch();
      snap.docs.forEach((d) => batch.delete(d.ref));
      await batch.commit();
    }
  }
}

async function purgeContentSubcollections(db, parentRef) {
  try {
    await deleteContentTree(db, parentRef);
  } catch (err) {
    console.error(`purgeContentSubcollections(${parentRef.path || parentRef.id}) lỗi:`, err.message);
  }
}

module.exports = { purgeContentSubcollections, deleteContentTree };
