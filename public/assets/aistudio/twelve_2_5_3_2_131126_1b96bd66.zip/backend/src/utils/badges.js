const { ACCOUNT_GROUP, ACCOUNT_ROLE, ROLE_TO_GROUP } = require("./constants");

/**
 * ==== v2.4.0 — Hệ thống HUY HIỆU (nguồn sự thật duy nhất) ====
 *
 * TRƯỚC ĐÂY (≤ 2.3.0) có hai thứ gọi là "huy hiệu" nhưng chưa được định nghĩa thành một hệ thống:
 *   • nhãn nhóm tài khoản (SA/RA/LLA) — chỉ hiện ở thẻ hồ sơ trong Menu của CHÍNH chủ, dạng chữ;
 *   • "Đến từ Twelve cũ" (isLegacyMember) — chỉ hiện ở trang hồ sơ công khai, dạng chữ dài tốn chỗ.
 * Bài viết, bình luận, bảng xếp hạng… đều không hiện gì.
 *
 * TỪ 2.4.0:
 *   1. Huy hiệu là DỮ LIỆU SUY RA từ hồ sơ (không lưu thêm trường nào): cấp bậc tài khoản (accountGroup + accountRole) + thành viên
 *      Twelve cũ (isLegacyMember). Đổi nhóm/vai trò/đánh dấu thành viên cũ thì huy hiệu đổi theo ngay, không có chỗ nào lệch.
 *
 *      v2.4.1 — NHÓM (accountGroup) LÀ CĂN CỨ CHÍNH, vai trò (accountRole) chỉ làm rõ thêm TRONG nhóm. Lý do: mọi quyền hạn của Twelve
 *      (requireSA, isSA, xoá bài/bình luận…) đều dựa vào accountGroup; còn accountRole chỉ được ghi lúc đăng ký (= "user") và lúc di chuyển
 *      dữ liệu cũ. Tài khoản SA do quản trị đặt tay (chỉ đổi accountGroup) vẫn mang accountRole "user" → bản 2.4.0 (chỉ nhìn accountRole)
 *      KHÔNG hiện huy hiệu cho họ. Huy hiệu phải khớp quyền thật, nên nay đi theo nhóm:
 *        SA  → admin / dev / moderator nếu accountRole nói rõ, KHÔNG thì huy hiệu chung "sa" (Tài khoản cấp cao);
 *        LLA → "tester";   RA → "pro" nếu accountRole = pro_user, còn lại không có;
 *        thiếu accountGroup (hồ sơ rất cũ) → suy nhóm từ accountRole như trước.
 *   2. Backend chỉ trả DANH SÁCH ID (`badges: ["admin", "legacy"]`) trong mọi hồ sơ công khai (toPublicUser) — nên huy hiệu có mặt
 *      ở MỌI nơi hiện người dùng (bài viết, bình luận, xếp hạng, hồ sơ…). Hình/tên/mô tả hiển thị nằm ở frontend
 *      (frontend/src/utils/badges.js), giao diện chỉ vẽ ICON; tên + mô tả chỉ hiện khi bấm vào huy hiệu.
 *   3. Thứ tự cố định: cấp bậc tài khoản trước, rồi các huy hiệu thành tích (hiện chỉ có "legacy").
 *
 * THÊM HUY HIỆU MỚI: thêm id vào BADGE_ID, thêm luật vào badgeIdsForUser, rồi khai báo hình/tên/mô tả ở frontend/src/utils/badges.js.
 * Hai bảng ở test (backend/test/profile-240.test.js và frontend/tests/badges.test.js) kiểm cùng một bộ ca để hai phía không lệch nhau.
 */
const BADGE_ID = Object.freeze({
  SA: "sa",
  ADMIN: "admin",
  DEV: "dev",
  MODERATOR: "moderator",
  PRO: "pro",
  TESTER: "tester",
  LEGACY: "legacy",
});

// Vai trò NHÂN VIÊN (nhóm SA) → huy hiệu cụ thể. Vai trò khác trong nhóm SA (hoặc không ghi) → huy hiệu chung BADGE_ID.SA.
const STAFF_BADGE_BY_ROLE = Object.freeze({
  [ACCOUNT_ROLE.ADMIN]: BADGE_ID.ADMIN,
  [ACCOUNT_ROLE.DEV]: BADGE_ID.DEV,
  [ACCOUNT_ROLE.MODERATOR]: BADGE_ID.MODERATOR,
});

/** Huy hiệu cấp bậc của một hồ sơ, hoặc null. Nhóm quyết định; người thường (RA, vai trò user) CỐ Ý không có huy hiệu. */
function tierBadgeId(user) {
  const group = user.accountGroup || ROLE_TO_GROUP[user.accountRole] || null;
  if (group === ACCOUNT_GROUP.SA) return STAFF_BADGE_BY_ROLE[user.accountRole] || BADGE_ID.SA;
  if (group === ACCOUNT_GROUP.LLA) return BADGE_ID.TESTER;
  if (group === ACCOUNT_GROUP.RA && user.accountRole === ACCOUNT_ROLE.PRO_USER) return BADGE_ID.PRO;
  return null;
}

/**
 * Danh sách id huy hiệu của một hồ sơ (document `users/{uid}` hoặc đối tượng có accountGroup/accountRole/isLegacyMember).
 * Luôn trả mảng (có thể rỗng), không trùng, đúng thứ tự hiển thị.
 */
function badgeIdsForUser(user) {
  if (!user || typeof user !== "object") return [];
  const ids = [];
  const tier = tierBadgeId(user);
  if (tier) ids.push(tier);
  if (user.isLegacyMember === true) ids.push(BADGE_ID.LEGACY);
  return ids;
}

module.exports = { BADGE_ID, STAFF_BADGE_BY_ROLE, tierBadgeId, badgeIdsForUser };
