const { db } = require("../config/firebase");
const { COLLECTIONS, SUBCOLLECTIONS, ACCOUNT_STATUS } = require("./constants");
const { toIsoString } = require("./time");
const { isSafeDocId } = require("./input");

/**
 * ==== v2.5.0 [SEO] — Thành phần nội dung riêng cho trang SSR ====
 *
 * Cẩm nang SEO của Google (mục "Thêm hình ảnh... và tối ưu hoá"): mọi ảnh cần văn bản thay thế (alt) mang tính mô tả để
 * công cụ tìm kiếm hiểu ảnh và quan hệ của ảnh với trang. Trình soạn thảo Quill KHÔNG tạo `alt` cho ảnh người dùng chèn,
 * nên trước 2.5.0 mọi ảnh trong thân bài ở bản SSR đều không có alt. Hàm dưới đây điền alt dự phòng từ tiêu đề bài —
 * CHỈ ở lúc render SSR (không sửa dữ liệu đã lưu, không đụng bộ lọc DOMPurify).
 */

const ALT_TITLE_MAX = 100;

function escapeAttr(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function shortTitle(title) {
  const s = String(title == null ? "" : title).replace(/\s+/g, " ").trim();
  return s.length <= ALT_TITLE_MAX ? s : `${s.slice(0, ALT_TITLE_MAX - 1).trimEnd()}…`;
}

/**
 * Điền `alt` cho thẻ <img> chưa có alt (hoặc alt rỗng) trong HTML đã sanitize. Ảnh đã có alt mô tả giữ nguyên.
 * Ảnh thứ n (đếm mọi ảnh trong thân bài, bắt đầu từ 1) nhận alt "<tiêu đề> — hình n" để các ảnh trong cùng bài không trùng nhau.
 */
function ensureImageAlts(html, title) {
  if (!html || typeof html !== "string") return html || "";
  const base = shortTitle(title);
  if (!base) return html;
  let index = 0;
  return html.replace(/<img\b[^>]*>/gi, (tag) => {
    index += 1;
    const existing = tag.match(/\salt\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))/i);
    const current = existing ? (existing[2] ?? existing[3] ?? existing[4] ?? "") : "";
    if (existing && current.trim()) return tag; // đã có alt mô tả
    const alt = ` alt="${escapeAttr(`${base} — hình ${index}`)}"`;
    if (existing) return tag.replace(existing[0], alt); // alt rỗng -> thay
    return tag.replace(/^<img\b/i, `<img${alt}`);
  });
}

/**
 * Bình luận hiển thị ở bản SSR: tối đa `limit` bình luận CŨ NHẤT (đúng thứ tự trang người dùng thấy) của tác giả ACTIVE.
 * Bình luận của hồ sơ "ma"/đang xoá/chưa kích hoạt/bị khoá KHÔNG được đưa ra cho bot (nội dung đó không nên được lập chỉ mục).
 * Không có bình luận (commentCount = 0) thì không tốn lượt đọc Firestore nào. Mọi lỗi => mảng rỗng (SSR không được hỏng vì phần phụ).
 *
 * `content` là văn bản THUẦN (xem comments.controller.js) — view phải dùng <%= %> (tự escape), không bao giờ <%- %>.
 */
async function loadSsrComments(parentCollection, parentId, commentCount, { limit = 10 } = {}) {
  if (!commentCount || commentCount < 1) return [];
  try {
    const snap = await db
      .collection(parentCollection)
      .doc(parentId)
      .collection(SUBCOLLECTIONS.COMMENTS)
      .orderBy("createdAt", "asc")
      .limit(limit)
      .get();
    const rows = snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((c) => isSafeDocId(c.authorUid) && typeof c.content === "string" && c.content.trim()); // v2.5.3 [TW-14]: không chỉ "có giá trị" mà phải là id tài liệu hợp lệ (.doc("a/b") ném lỗi đồng bộ)
    if (!rows.length) return [];
    const uids = [...new Set(rows.map((c) => c.authorUid))];
    const authorDocs = await Promise.all(uids.map((uid) => db.collection(COLLECTIONS.USERS).doc(uid).get()));
    const authors = {};
    authorDocs.forEach((d) => {
      if (d.exists && d.data().status === ACCOUNT_STATUS.ACTIVE) authors[d.id] = { uid: d.id, ...d.data() };
    });
    return rows
      .filter((c) => authors[c.authorUid])
      .map((c) => ({
        id: c.id,
        content: c.content,
        createdAt: toIsoString(c.createdAt),
        isEdited: !!c.isEdited,
        updatedAt: c.isEdited ? toIsoString(c.updatedAt) : null,
        author: authors[c.authorUid],
      }));
  } catch (err) {
    console.error("SSR loadSsrComments error:", err.message);
    return [];
  }
}

/**
 * ==== v2.5.3 [TW-20] — Lớp sanitize THỨ HAI khi SSR đọc bài ====
 * `views/content.ejs` in `post.contentHtml` THÔ (`<%- … %>`) — chỗ duy nhất tin hoàn toàn HTML đã lưu. HTML được làm sạch lúc GHI, nhưng bài cũ chỉ sạch theo bộ lọc LÚC ĐÓ
 * (đổi bộ lọc phải chạy `npm run content:resanitize`). Đây là lưới an toàn rẻ: một "dây vấp" bằng regex trên chuỗi đã lưu; chỉ khi thấy dấu hiệu mà bộ lọc hiện hành chắc chắn
 * không cho phép (thẻ nguy hiểm, trình xử lý sự kiện on*, URL javascript:/vbscript:/data:text/html, srcdoc) mới chạy lại DOMPurify (qua worker) — nội dung bình thường KHÔNG tốn thêm gì.
 * Lỗi khi làm sạch ⇒ trả chuỗi rỗng (đóng an toàn) chứ không in HTML chưa làm sạch. Có thay đổi ⇒ log id bài (kèm số ký tự) để biết kho dữ liệu còn HTML cũ cần re-sanitize.
 */
const SSR_TRIPWIRE = /<\s*\/?\s*(?:script|object|embed|applet|link|meta|base|form|style|svg|math|template|noscript)\b|[\s"'\/]on[a-z]{3,}\s*=|(?:java|vb)script\s*:|data\s*:\s*text\/html|\bsrcdoc\s*=/i;

/**
 * v2.5.3 (rà soát độc lập): `SSR_TRIPWIRE` chạy trên chuỗi THÔ nên bị lách bằng thứ mà TRÌNH DUYỆT giải mã trước khi phân tích URL/thuộc tính:
 *   • thực thể HTML: `&#106;avascript:`, `&#x6A;avascript:`, `javascript&colon;` (thuộc tính được giải mã thực thể);
 *   • TAB/LF/CR nằm giữa chữ của scheme (`java&#9;script:`, `java<TAB>script:`) — trình duyệt xoá chúng khỏi URL.
 * Nay kiểm ba dạng của cùng một chuỗi: (A) thô, (B) đã giải mã thực thể, (C) B + bỏ \t\n\r\f\0. B và C tách riêng vì bỏ khoảng trắng làm dính `x\nonerror=` thành `xonerror=` (mất tiền tố
 * `\s` của mẫu on*=), còn B giữ nguyên. Cố ý KHÔNG giải mã `&lt; &gt; &#60; &#62;` (chỉ có thể là CHỮ, không bao giờ tạo thẻ) để `<pre>&lt;script&gt;…` của bài hướng dẫn lập trình không bị bắt oan.
 * Bắt oan chỉ tốn một lượt DOMPurify (và trang SSR được CDN giữ ~40 phút); bắt thiếu mới là lỗ hổng — nên mọi nghi ngờ đều nghiêng về "làm sạch lại".
 */
const NAMED_ENTITIES = { colon: ":", tab: "\t", newline: "\n", lpar: "(", rpar: ")", sol: "/", bsol: "\\", num: "#", equals: "=", quot: '"', apos: "'", amp: "&", semi: ";", period: ".", comma: ",", excl: "!" };
function decodeEntitiesLoose(str) {
  return str.replace(/&(?:#(\d{1,7})|#x([0-9a-f]{1,6})|([a-z][a-z0-9]{1,9}));?/gi, (m, dec, hex, name) => {
    if (dec !== undefined || hex !== undefined) {
      const cp = dec !== undefined ? parseInt(dec, 10) : parseInt(hex, 16);
      if (!(cp > 0 && cp <= 0x10ffff) || cp === 60 || cp === 62) return cp === 60 || cp === 62 ? m : "";
      return String.fromCodePoint(cp);
    }
    const v = NAMED_ENTITIES[name.toLowerCase()];
    return v === undefined ? m : v;
  });
}

function ssrTripwireHit(html) {
  if (typeof html !== "string" || !html) return false;
  if (SSR_TRIPWIRE.test(html)) return true;
  if (html.indexOf("&") === -1 && !/[\t\n\r\f\0]/.test(html)) return false; // không có gì để giải mã/bỏ ⇒ dạng thô là đủ
  const decoded = decodeEntitiesLoose(html);
  return SSR_TRIPWIRE.test(decoded) || SSR_TRIPWIRE.test(decoded.replace(/[\t\n\r\f\0]/g, ""));
}

async function sanitizeAgainForSsr(html, { id = "?", processContentHtml } = {}) {
  if (typeof html !== "string" || !html || !ssrTripwireHit(html)) return html;
  try {
    const run = processContentHtml || require("../services/contentPipeline").processContentHtml;
    const { html: clean } = await run(html);
    if (clean !== html) console.warn(`[ssr-tripwire] bài ${String(id).slice(0, 40)}: HTML đã lưu còn phần bộ lọc hiện hành sẽ bỏ (${html.length} → ${clean.length} ký tự) — chạy \`npm run content:resanitize\`.`);
    return clean;
  } catch (err) {
    console.error(`[ssr-tripwire] bài ${String(id).slice(0, 40)}: làm sạch lại thất bại, không hiển thị nội dung:`, err && err.message);
    return "";
  }
}

module.exports = { ensureImageAlts, loadSsrComments, escapeAttr, sanitizeAgainForSsr, SSR_TRIPWIRE, ssrTripwireHit };
