const { db, admin } = require("../config/firebase");
const { COLLECTIONS } = require("./constants");
const { attachAuthors } = require("./authors");
const { getMyReactionsById } = require("./myReactions");
const { formatCardContent } = require("./contentFormat");
const { syncPostScoresBatch } = require("./helpers");

/**
 * ==== v2.4.0 — Dựng danh sách thẻ bài cho trang Profile (tab Bài viết + bài ghim) ====
 * Cùng đường đi với feed Trang chủ (posts.controller#listPosts): gắn tác giả, myReaction của người đang xem,
 * định dạng thẻ, đồng bộ cache điểm — để thẻ ở Profile giống hệt thẻ ở Trang chủ. Thêm `isPinned` cho từng bài.
 *
 * v2.5.2: dùng được cho cả BLOG (tab "Blog" của hồ sơ SA) qua `collection: COLLECTIONS.BLOGS` — thẻ blog KHÔNG có `isPinned` (chỉ bài viết thường mới ghim được).
 *
 * @param {object[]} rawPosts dữ liệu document `posts` (hoặc `blogs`) (đã có `id`)
 * @param {{ viewerUid?: string|null, pinnedIds?: string[], collection?: string }} opts
 */
async function buildProfileCards(rawPosts, { viewerUid = null, pinnedIds = [], collection = COLLECTIONS.POSTS } = {}) {
  if (!rawPosts.length) return [];
  const withAuthors = await attachAuthors(rawPosts);
  const myReactionById = await getMyReactionsById(collection, withAuthors.map((p) => p.id), viewerUid);
  const pinned = new Set(pinnedIds);
  const isPostCollection = collection === COLLECTIONS.POSTS;
  const cards = withAuthors.map((p) => ({
    ...formatCardContent(p),
    myReaction: myReactionById[p.id] || null,
    ...(isPostCollection ? { isPinned: pinned.has(p.id) } : {}),
  }));
  syncPostScoresBatch(
    db,
    admin,
    collection,
    withAuthors.map((p, i) => ({ id: p.id, score: cards[i].postScore, storedScore: p.postScore, authorUid: p.authorUid }))
  );
  return cards;
}

module.exports = { buildProfileCards };
