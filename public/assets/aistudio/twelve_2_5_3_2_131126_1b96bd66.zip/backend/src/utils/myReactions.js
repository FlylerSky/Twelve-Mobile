const { db } = require("../config/firebase");
const { SUBCOLLECTIONS } = require("./constants");

// Firestore giới hạn số tài liệu mỗi lần getAll — chia lô cho an toàn.
const GET_ALL_CHUNK = 450;

/**
 * ==== v2.0.0 — Đọc reaction (like/dislike) của người đang xem ====
 * Trước đây logic này bị chép ở posts.controller (list + detail),
 * blog.controller (chỉ list) và trending.controller. Hệ quả: `getBlog` KHÔNG
 * trả `myReaction` (trang chi tiết Blog luôn hiện "chưa bấm" sau khi tải lại)
 * dù `getPost` đã đúng — nay cả hai cùng gọi các hàm dưới đây.
 */

/** myReaction ("like" | "dislike" | null) của `authUid` trên 1 bài. */
async function getMyReaction(collectionName, id, authUid) {
  if (!authUid) return null;
  const snap = await db
    .collection(collectionName)
    .doc(id)
    .collection(SUBCOLLECTIONS.REACTIONS)
    .doc(authUid)
    .get();
  return snap.exists ? snap.data().type : null;
}

/**
 * Nhiều bài cùng lúc (db.getAll gộp thành ít round-trip).
 * @param {{key: string, collection: string, id: string}[]} entries
 * @returns {Promise<Record<string, string>>} key → type (chỉ những bài đã có reaction)
 */
async function getMyReactions(entries, authUid) {
  const out = {};
  if (!authUid || !entries.length) return out;
  const refs = entries.map((e) =>
    db.collection(e.collection).doc(e.id).collection(SUBCOLLECTIONS.REACTIONS).doc(authUid)
  );
  for (let i = 0; i < refs.length; i += GET_ALL_CHUNK) {
    const snaps = await db.getAll(...refs.slice(i, i + GET_ALL_CHUNK));
    snaps.forEach((s, j) => {
      if (s.exists) out[entries[i + j].key] = s.data().type;
    });
  }
  return out;
}

/** Tiện ích cho danh sách cùng 1 collection: id → type. */
function getMyReactionsById(collectionName, ids, authUid) {
  return getMyReactions(
    ids.map((id) => ({ key: id, collection: collectionName, id })),
    authUid
  );
}

module.exports = { getMyReaction, getMyReactions, getMyReactionsById };
