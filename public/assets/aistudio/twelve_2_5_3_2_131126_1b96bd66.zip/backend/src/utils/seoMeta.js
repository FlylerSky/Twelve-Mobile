const { frontendOrigin, profilePath } = require("./helpers");
const { toIsoString } = require("./time");

/**
 * ==== v2.0.4 [SEO — tái sử dụng] Dựng metadata/JSON-LD cho mọi trang SSR ở MỘT chỗ ====
 *
 * Trước đây post.ejs và blog.ejs giống nhau 100% (chỉ khác 1 dòng <title>) và
 * JSON-LD được viết thẳng trong EJS ở 4 template. Nay route dựng đối tượng `meta`
 * bằng các hàm dưới đây, view chỉ việc hiển thị (xem views/partials/top.ejs).
 */

const ROBOTS_INDEX = "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1";
const ROBOTS_NOINDEX_FOLLOW = "noindex, follow";
const ROBOTS_NOINDEX = "noindex, nofollow";

const HEADLINE_MAX = 110; // Google khuyến nghị headline Article <= 110 ký tự
const DESCRIPTION_MAX = 160;
// v2.5.0: mô tả/ảnh dự phòng thống nhất giữa bản SSR (bot) và SPA (người dùng) — hai bản phải khớp nhau (cẩm nang SEO: mỗi trang một
// tiêu đề/mô tả riêng, mô tả đúng nội dung; kết xuất động chỉ hợp lệ khi bot và người dùng thấy nội dung tương đương).
const SITE_NAME = "Twelve";
const HOME_TITLE = "Twelve — Nền tảng mạng xã hội chia sẻ bài viết";
const HOME_DESCRIPTION =
  "Twelve là nền tảng mạng xã hội chia sẻ bài viết, bình luận và xếp hạng nội dung theo tuần. Khám phá bài viết mới, blog và bảng xu hướng.";
const BLOG_TITLE = "Blog | Twelve";
const BLOG_DESCRIPTION = "Danh sách bài viết blog trên Twelve, cập nhật mới nhất.";
const DEFAULT_IMAGE_ALT = "Twelve — nền tảng mạng xã hội chia sẻ bài viết";

function truncate(str, max) {
  const s = String(str == null ? "" : str).replace(/\s+/g, " ").trim();
  if (s.length <= max) return s;
  return s.slice(0, Math.max(0, max - 1)).trimEnd() + "…";
}

/** Ảnh OG mặc định (dùng khi trang không có ảnh bìa/avatar) — xem frontend/public/og-default.png. */
function defaultOgImage() {
  if (process.env.SITE_OG_IMAGE_URL) return process.env.SITE_OG_IMAGE_URL;
  const base = frontendOrigin();
  return base ? `${base}/og-default.png` : null;
}

/** Link "Mở bản đầy đủ": thêm ?spa=1 để middleware Vercel trả SPA thay vì SSR lần nữa (tránh vòng lặp). */
function withSpaFlag(url) {
  return `${url}${url.includes("?") ? "&" : "?"}spa=1`;
}

function breadcrumbJsonLd(frontendBase, items) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: it.url,
    })),
  };
}

function itemListJsonLd(name, cards, frontendBase) {
  return {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name,
    itemListElement: cards.map((p, i) => ({
      "@type": "ListItem",
      position: i + 1,
      url: frontendBase + p.url,
      name: p.title,
    })),
  };
}

/** Một bình luận -> JSON-LD `Comment` (chỉ dùng cho blog; bài viết thường dùng Microdata trong content.ejs). */
function commentJsonLd(c, frontendBase, canonicalUrl) {
  const a = c.author || {};
  return {
    "@type": "Comment",
    text: c.content,
    author: {
      "@type": "Person",
      name: a.displayName,
      url: frontendBase ? `${frontendBase}${profilePath(a)}` : undefined,
    },
    datePublished: c.createdAt || undefined,
    dateModified: c.updatedAt || undefined,
    url: `${canonicalUrl}#comment-${c.id}`,
  };
}

/**
 * Metadata cho trang chi tiết bài viết / blog.
 *
 * v2.5.0 — chọn loại dữ liệu có cấu trúc đúng theo hướng dẫn của Google:
 *  - `kind: "post"` (bài viết của người dùng trên mạng xã hội): `DiscussionForumPosting` — Google yêu cầu MỌI thuộc tính văn bản/bình luận phải
 *    khớp nội dung hiển thị và khuyến nghị dùng MICRODATA cho loại này (tránh nhân đôi khối văn bản lớn trong JSON-LD), nên phần đó nằm ở
 *    views/content.ejs; ở đây chỉ còn BreadcrumbList. (Trước đây dùng `Article` — loại dành cho nội dung do chính nhà xuất bản viết.)
 *  - `kind: "blog"`: `BlogPosting` (loại con của Article), kèm `commentCount` + `comment` (các bình luận đang hiển thị ở trang).
 */
function buildContentMeta({ post, canonicalUrl, frontendBase, section, titleSuffix, kind = "post", comments = [] }) {
  const description = truncate(post.excerpt || post.title, DESCRIPTION_MAX);
  const image = post.coverImageUrl || defaultOgImage();
  const authorName = post.author ? post.author.displayName : SITE_NAME;
  const authorUrl = post.author && frontendBase ? `${frontendBase}${profilePath(post.author)}` : undefined;

  const extra = [];
  if (post.createdAt) extra.push({ property: "article:published_time", content: post.createdAt });
  if (post.updatedAt) extra.push({ property: "article:modified_time", content: post.updatedAt });
  extra.push({ property: "article:author", content: authorName });
  extra.push({ property: "article:section", content: section.name });
  (Array.isArray(post.hashtags) ? post.hashtags : []).forEach((tag) => extra.push({ property: "article:tag", content: tag }));

  const breadcrumb = breadcrumbJsonLd(frontendBase, [
    { name: "Trang chủ", url: `${frontendBase}/` },
    { name: section.name, url: `${frontendBase}${section.path}` },
    { name: post.title, url: canonicalUrl },
  ]);

  const jsonLd = [];
  if (kind === "blog") {
    const stats = [
      ["ViewAction", post.viewCount],
      ["LikeAction", post.likeCount],
      ["CommentAction", post.commentCount],
      ["ShareAction", post.shareCount],
    ].map(([type, n]) => ({ "@type": "InteractionCounter", interactionType: `https://schema.org/${type}`, userInteractionCount: n || 0 }));
    jsonLd.push({
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      headline: truncate(post.title, HEADLINE_MAX),
      description,
      // Chỉ khai báo ảnh THẬT của bài; ảnh OG mặc định của site không phải ảnh của bài (không đưa vào dữ liệu có cấu trúc).
      image: post.coverImageUrl || undefined,
      author: { "@type": "Person", name: authorName, url: authorUrl },
      publisher: process.env.SITE_LOGO_URL
        ? { "@type": "Organization", name: SITE_NAME, logo: { "@type": "ImageObject", url: process.env.SITE_LOGO_URL } }
        : undefined,
      datePublished: post.createdAt || undefined,
      dateModified: post.updatedAt || post.createdAt || undefined,
      mainEntityOfPage: { "@type": "WebPage", "@id": canonicalUrl },
      inLanguage: "vi",
      keywords: Array.isArray(post.hashtags) && post.hashtags.length ? post.hashtags.join(", ") : undefined,
      commentCount: post.commentCount || 0,
      comment: comments.length ? comments.map((c) => commentJsonLd(c, frontendBase, canonicalUrl)) : undefined,
      interactionStatistic: stats,
    });
  }
  jsonLd.push(breadcrumb);

  return {
    title: `${post.title} | ${titleSuffix}`,
    description,
    robots: ROBOTS_INDEX,
    ogType: "article",
    image,
    imageAlt: post.coverImageUrl ? post.title : DEFAULT_IMAGE_ALT,
    canonicalUrl,
    schemaKind: kind, // content.ejs: kind === "post" => Microdata DiscussionForumPosting
    extra,
    jsonLd,
  };
}

/**
 * Metadata cho trang hồ sơ /u/:ref (v2.4.2.1: URL dùng Tag Name Search).
 * v2.5.2: Tiểu sử (`user.bio`) làm đầu mô tả + `Person.description`; bài Blog (tài khoản SA) có ItemList riêng. `user.createdAt` là null khi chủ hồ sơ đã TẮT
 * hiển thị ngày tham gia (xem utils/profileExtras.js) — khi đó không có `dateCreated`.
 */
function buildProfileMeta({ user, posts, blogs = [], canonicalUrl, frontendBase, robots }) {
  // v2.5.0: mô tả RIÊNG cho từng hồ sơ (kèm tiêu đề bài gần đây) thay cho một câu chung cho mọi hồ sơ.
  const recent = [...posts, ...blogs]
    .slice(0, 3)
    .map((p) => p.title)
    .join("; ");
  const bio = String(user.bio || "").replace(/\s+/g, " ").trim();
  const description = truncate(
    `Hồ sơ ${user.displayName} (${user.tagName}) trên Twelve.${bio ? ` ${bio}` : ""}${recent ? ` Bài viết gần đây: ${recent}.` : bio ? "" : " Xem bài viết, điểm số và thành tích."}`,
    DESCRIPTION_MAX
  );
  const created = toIsoString(user.createdAt);
  const profileImage = user.avatarUrl || undefined;
  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "ProfilePage",
      url: canonicalUrl,
      dateCreated: created || undefined,
      mainEntity: {
        "@type": "Person",
        name: user.displayName,
        alternateName: user.tagName,
        url: canonicalUrl,
        image: profileImage,
        identifier: user.tagName,
        description: bio || undefined,
      },
    },
    breadcrumbJsonLd(frontendBase, [
      { name: "Trang chủ", url: `${frontendBase}/` },
      { name: user.displayName, url: canonicalUrl },
    ]),
  ];
  if (posts.length) jsonLd.push(itemListJsonLd(`Bài viết gần đây của ${user.displayName}`, posts, frontendBase));
  if (blogs.length) jsonLd.push(itemListJsonLd(`Bài Blog của ${user.displayName}`, blogs, frontendBase));
  const hasCover = !!user.coverUrl;
  return {
    title: `${user.displayName} (${user.tagName}) | Twelve`,
    description,
    robots,
    ogType: "profile",
    // v2.4.0: ảnh bìa hồ sơ (nếu có) làm og:image — khổ ngang hợp với thẻ chia sẻ hơn avatar vuông.
    image: user.coverUrl || user.avatarUrl || defaultOgImage(),
    imageAlt: hasCover || user.avatarUrl ? `Ảnh hồ sơ của ${user.displayName}` : DEFAULT_IMAGE_ALT,
    canonicalUrl,
    extra: [{ property: "profile:username", content: user.tagName }],
    jsonLd,
  };
}

/** Metadata cho trang hashtag / xu hướng. */
function buildHashtagMeta({ tag, posts, canonicalUrl, frontendBase, robots }) {
  const title = tag ? `${tag} — Xu hướng | Twelve` : "Xu hướng | Twelve";
  // v2.5.0: mô tả hashtag nêu số bài + tiêu đề tiêu biểu (riêng cho từng hashtag, đúng nội dung trang) thay cho một câu khuôn mẫu.
  const description = tag
    ? truncate(
        posts.length
          ? `${posts.length} bài viết và blog mới nhất với hashtag ${tag} trên Twelve: ${posts
              .slice(0, 3)
              .map((p) => p.title)
              .join("; ")}.`
          : `Bài viết và blog với hashtag ${tag} trên Twelve.`,
        DESCRIPTION_MAX
      )
    : "Bảng xếp hạng người dùng, bài viết và hashtag thịnh hành trên Twelve.";
  const jsonLd = [];
  if (tag && posts.length) {
    jsonLd.push({
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      name: `Hashtag ${tag}`,
      url: canonicalUrl,
      mainEntity: itemListJsonLd(`Nội dung với ${tag}`, posts, frontendBase),
    });
  }
  jsonLd.push(
    breadcrumbJsonLd(
      frontendBase,
      tag
        ? [
            { name: "Trang chủ", url: `${frontendBase}/` },
            { name: "Xu hướng", url: `${frontendBase}/trending` },
            { name: tag, url: canonicalUrl },
          ]
        : [
            { name: "Trang chủ", url: `${frontendBase}/` },
            { name: "Xu hướng", url: canonicalUrl },
          ]
    )
  );
  return { title, description, robots, ogType: "website", image: defaultOgImage(), imageAlt: DEFAULT_IMAGE_ALT, canonicalUrl, extra: [], jsonLd };
}

/** Metadata cho trang danh sách (Trang chủ / Blog). */
function buildListMeta({ kind, cards, canonicalUrl, frontendBase }) {
  const isBlog = kind === "blog";
  // v2.5.0: tiêu đề/mô tả KHỚP CHỮ với bản SPA (IndexPage/BlogPage) — trước đây bot và người dùng thấy hai tiêu đề khác nhau cho cùng một URL.
  const title = isBlog ? BLOG_TITLE : HOME_TITLE;
  const description = isBlog ? BLOG_DESCRIPTION : HOME_DESCRIPTION;
  const jsonLd = [itemListJsonLd(isBlog ? "Blog mới nhất" : "Bài viết mới nhất", cards, frontendBase)];
  if (!isBlog) {
    jsonLd.unshift(
      {
        "@context": "https://schema.org",
        "@type": "WebSite",
        name: SITE_NAME, // tên trang web (Google "Tên trang web"): chuẩn hoá một giá trị duy nhất
        alternateName: "Twelve — mạng xã hội chia sẻ bài viết",
        url: `${frontendBase}/`,
        inLanguage: "vi",
      },
      {
        "@context": "https://schema.org",
        "@type": "Organization",
        name: SITE_NAME,
        url: `${frontendBase}/`,
        logo: process.env.SITE_LOGO_URL || undefined,
      }
    );
  } else {
    jsonLd.push(
      breadcrumbJsonLd(frontendBase, [
        { name: "Trang chủ", url: `${frontendBase}/` },
        { name: "Blog", url: canonicalUrl },
      ])
    );
  }
  return {
    title,
    description,
    robots: cards.length ? ROBOTS_INDEX : ROBOTS_NOINDEX_FOLLOW,
    ogType: "website",
    image: defaultOgImage(),
    imageAlt: DEFAULT_IMAGE_ALT,
    canonicalUrl,
    extra: [],
    jsonLd,
  };
}

module.exports = {
  ROBOTS_INDEX,
  ROBOTS_NOINDEX_FOLLOW,
  ROBOTS_NOINDEX,
  SITE_NAME,
  truncate,
  defaultOgImage,
  withSpaFlag,
  buildContentMeta,
  buildProfileMeta,
  buildHashtagMeta,
  buildListMeta,
};
