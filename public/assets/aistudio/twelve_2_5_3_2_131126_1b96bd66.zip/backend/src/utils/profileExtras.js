const { toIsoString } = require("./time");

/**
 * ==== v2.5.2 — "THÔNG TIN MỞ RỘNG" của hồ sơ (hộp "Xem thêm" ở trang Profile) ====
 *
 * Chủ tài khoản bật/tắt TỪNG mục ở Cài đặt > Tài khoản > Thông tin > "Thông tin mở rộng". Cờ lưu ở `users/{uid}.profileExtras`
 * (map `{ <khoá>: boolean }`; khoá vắng mặt = dùng MẶC ĐỊNH dưới đây).
 *
 * QUY TẮC QUAN TRỌNG: việc ẩn/hiện được ÁP DỤNG Ở BACKEND (buildExtraFields) — dữ liệu của mục đang TẮT không bao giờ rời máy chủ tới người khác.
 * Ẩn ở giao diện thôi thì ai mở DevTools vẫn thấy ngày sinh/giới tính. Ngày sinh và giới tính trước 2.5.2 hoàn toàn riêng tư (xem toPublicUser);
 * từ nay chúng chỉ ra công khai khi chính chủ BẬT.
 *
 * MẶC ĐỊNH (chọn để nâng cấp không làm lộ thêm gì so với trước):
 *   BẬT  — những gì vốn đã công khai ở nơi khác: tên hiển thị, nhóm/vai trò tài khoản (huy hiệu), ngày tham gia (đã có ở hồ sơ SSR), thành tích
 *          (top 10 tuần vốn đã công khai ở trang Xu hướng);
 *   TẮT  — những gì trước nay luôn riêng tư hoặc chủ đích không lộ: ngày sinh, giới tính, trạng thái tài khoản, UID (2.4.2.1 cố ý bỏ UID khỏi URL).
 *
 * File này là NGUỒN SỰ THẬT về danh sách khoá + mặc định; frontend/src/utils/profileExtras.js phản chiếu nó (test ở hai phía kiểm cùng một bảng).
 * Thuần (không đụng Firebase) để frontend test có thể nạp trực tiếp.
 *
 * THÊM MỤC MỚI: thêm khoá vào EXTRA_KEYS + EXTRA_DEFAULTS, thêm luật vào buildExtraFields, rồi khai báo nhãn ở frontend/src/utils/profileExtras.js.
 */
const EXTRA_KEYS = Object.freeze(["displayName", "accountGroup", "accountRole", "birthday", "createdAt", "gender", "status", "uid", "achievements"]);

const EXTRA_DEFAULTS = Object.freeze({
  displayName: true,
  accountGroup: true,
  accountRole: true,
  birthday: false,
  createdAt: true,
  gender: false,
  status: false,
  uid: false,
  achievements: true,
});

const KEY_SET = new Set(EXTRA_KEYS);

/** Cờ ĐÃ PHÂN GIẢI (đủ mọi khoá, đều boolean) từ giá trị lưu trong hồ sơ. Giá trị lạ/không phải boolean → quay về mặc định (dữ liệu hỏng không bao giờ "bật" nhầm). */
function resolveExtras(stored) {
  const src = stored && typeof stored === "object" && !Array.isArray(stored) ? stored : {};
  const out = {};
  for (const key of EXTRA_KEYS) out[key] = typeof src[key] === "boolean" ? src[key] : EXTRA_DEFAULTS[key];
  return out;
}

/**
 * Kiểm tra phần cập nhật từ người dùng: `{ <khoá>: boolean }`, ít nhất 1 khoá, CHỈ khoá đã biết, giá trị PHẢI là boolean.
 * Khoá lạ bị từ chối (không âm thầm bỏ qua) để lỗi gõ sai không đi qua mà người dùng tưởng đã lưu.
 * @returns {{ ok: true, value: Object<string, boolean> } | { ok: false, error: string }}
 */
function parseExtrasUpdate(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return { ok: false, error: "Dữ liệu thông tin mở rộng không hợp lệ." };
  const keys = Object.keys(input);
  if (keys.length === 0) return { ok: false, error: "Không có mục nào để cập nhật." };
  const value = {};
  for (const key of keys) {
    if (!KEY_SET.has(key)) return { ok: false, error: `Mục thông tin mở rộng không tồn tại: ${key.slice(0, 40)}.` };
    if (typeof input[key] !== "boolean") return { ok: false, error: "Mỗi mục chỉ nhận giá trị bật hoặc tắt." };
    value[key] = input[key];
  }
  return { ok: true, value };
}

/**
 * Các trường VÔ HƯỚNG (không kể "thành tích") của một hồ sơ mà chủ đã cho phép hiện. Chỉ chứa mục ĐANG BẬT và CÓ GIÁ TRỊ.
 * Giá trị trả nguyên bản (frontend lo nhãn/định dạng): birthday "YYYY-MM-DD", createdAt ISO, còn lại chuỗi như trong hồ sơ.
 * @param {object} userDoc document `users/{uid}` (có thể kèm `uid`)
 * @param {object} flags kết quả resolveExtras()
 * @param {string[]} [only] giới hạn trong các khoá này (SSR chỉ lấy tập không nhạy cảm — xem SSR_EXTRA_KEYS)
 */
function buildExtraFields(userDoc, flags, only) {
  const out = {};
  if (!userDoc || typeof userDoc !== "object") return out;
  const allowed = only ? new Set(only) : null;
  const on = (key) => flags[key] === true && (!allowed || allowed.has(key));
  const text = (v) => (typeof v === "string" && v.trim() ? v : null);

  if (on("displayName") && text(userDoc.displayName)) out.displayName = userDoc.displayName;
  if (on("accountGroup") && text(userDoc.accountGroup)) out.accountGroup = userDoc.accountGroup;
  if (on("accountRole") && text(userDoc.accountRole)) out.accountRole = userDoc.accountRole;
  if (on("birthday") && /^\d{4}-\d{2}-\d{2}$/.test(userDoc.birthday || "")) out.birthday = userDoc.birthday;
  if (on("createdAt")) {
    const iso = toIsoString(userDoc.createdAt);
    if (iso) out.createdAt = iso;
  }
  if (on("gender") && ["male", "female", "other"].includes(userDoc.gender)) out.gender = userDoc.gender;
  if (on("status") && text(userDoc.status)) out.status = userDoc.status;
  if (on("uid") && text(userDoc.uid)) out.uid = userDoc.uid;
  return out;
}

/**
 * Tập khoá SSR (trang cho bot/công cụ tìm kiếm) được phép in ra. KHÔNG gồm birthday / gender / status / uid dù chủ đã bật:
 * trang SSR được CDN giữ tới ~40 phút (s-maxage + stale-while-revalidate) và công cụ tìm kiếm lưu bản chụp lâu hơn nữa — chủ hồ sơ vừa TẮT mục
 * nhạy cảm mà bản SSR vẫn còn lộ thì phản tác dụng. Những mục này cũng không có giá trị SEO. Người dùng thật vẫn thấy đủ qua hộp "Xem thêm" (API, không cache).
 */
const SSR_EXTRA_KEYS = Object.freeze(["displayName", "accountGroup", "accountRole", "createdAt"]);

/**
 * Nhãn tiếng Việt cho trang SSR (bot không chạy frontend nên cần bản riêng). Phản chiếu frontend/src/utils/profileExtras.js — test ở frontend kiểm hai bảng KHỚP.
 * Giá trị lạ (vai trò/nhóm mới thêm sau) hiện nguyên mã thay vì mất.
 */
const GROUP_LABELS = Object.freeze({ SA: "Tài khoản cấp cao (SA)", RA: "Tài khoản thường (RA)", LLA: "Tài khoản thử nghiệm (LLA)" });
const ROLE_LABELS = Object.freeze({
  admin: "Quản trị viên",
  dev: "Lập trình viên",
  moderator: "Điều hành viên",
  pro_user: "Người dùng Pro",
  user: "Người dùng",
  test: "Tài khoản thử nghiệm",
});

/**
 * Các dòng "nhãn: giá trị" của phần Thông tin mở rộng trên trang SSR (đã lọc theo SSR_EXTRA_KEYS ở buildExtraFields), kèm tóm tắt thành tích nếu chủ cho phép và có gì để nói.
 * @param {object} fields kết quả buildExtraFields
 * @param {object|null} achievements kết quả getUserAchievements (hoặc null nếu chủ tắt/không tải được)
 * Ngày tham gia KHÔNG nằm ở đây: nó đã có dòng "Tham gia từ" ngay dưới tên (views/profile.ejs), cũng theo công tắc `createdAt`.
 */
function describeSsrExtras(fields, achievements) {
  const rows = [];
  if (fields.displayName) rows.push({ label: "Tên hiển thị", value: fields.displayName });
  if (fields.accountGroup) rows.push({ label: "Nhóm tài khoản", value: GROUP_LABELS[fields.accountGroup] || fields.accountGroup });
  if (fields.accountRole) rows.push({ label: "Vai trò", value: ROLE_LABELS[fields.accountRole] || fields.accountRole });
  if (achievements) {
    const w = achievements.weekly || {};
    if (achievements.accountScore > 0) rows.push({ label: "Điểm tài khoản", value: String(achievements.accountScore) });
    if (w.top10Count > 0) {
      const detail = [w.firstPlaceCount > 0 ? `${w.firstPlaceCount} lần hạng 1` : null, w.top3Count > 0 ? `${w.top3Count} lần trong top 3` : null].filter(Boolean).join(", ");
      rows.push({ label: "Thành tích tuần", value: `Vào top 10 tăng điểm ${w.top10Count} tuần${detail ? ` (${detail})` : ""}` });
      if (w.best) rows.push({ label: "Hạng tuần cao nhất", value: `Hạng ${w.best.rank} — tuần ${w.best.weekCode}` });
    }
  }
  return rows;
}

module.exports = { EXTRA_KEYS, EXTRA_DEFAULTS, SSR_EXTRA_KEYS, GROUP_LABELS, ROLE_LABELS, resolveExtras, parseExtrasUpdate, buildExtraFields, describeSsrExtras };
