// Lỗi A-01 (Cao) — ghi nhận ở 2.2.0, vá ở 2.2.1.
const CASES = [
  ["hồ sơ: id chứa %2F", "/api/users/a%2Fb"],
  ["hồ sơ: nhiều %2F", "/api/users/a%2Fb%2Fc"],
  ["hồ sơ: trỏ vào tài liệu lồng (uid/positiveScoreLogs/x)", "/api/users/uU%2FpositiveScoreLogs%2Fx"],
  ["hồ sơ: id dành riêng __x__", "/api/users/__x__"],
  ["hồ sơ: id \"..\"", "/api/users/.."],
  ["hồ sơ: id \"%2e%2e\"", "/api/users/%2e%2e"],
  ["hồ sơ: ký tự null %00", "/api/users/a%00b"],
  ["hồ sơ: id dài 5000 ký tự", `/api/users/${"a".repeat(5000)}`],
  ["hồ sơ: ký tự điều khiển hướng chữ (bidi)", "/api/users/%E2%80%AEabc"],
  ["bài viết: id chứa %2F", "/api/posts/a%2Fb"],
  ["bài viết: id dành riêng", "/api/posts/__x__"],
  ["blog: id chứa %2F", "/api/blogs/a%2Fb"],
  ["bình luận: id bài chứa %2F", "/api/posts/a%2Fb/comments"],
  ["SSR bài viết: id chứa %2F", "/post/a%2Fb"],
  ["SSR blog: id chứa %2F", "/blog/a%2Fb"],
  ["SSR hồ sơ: id chứa %2F", "/u/a%2Fb"],
  ["font: tên tệp chứa %2F", "/api/fonts/files/a%2Fb"],
  ["hashtag: chứa %2F", "/api/trending/hashtags/a%2Fb/posts"],
];
const OK_STATUS = [200, 400, 404];

module.exports = {
  id: "a01-uid-crash",
  ref: "A-01",
  title: "Sập tiến trình bằng id lạ trên đường dẫn",
  severity: "high",
  recordedIn: "2.2.0",
  fixedIn: "2.2.1",
  mode: "isolated",
  timeoutMs: 45000,
  description:
    "Từng có: GET /api/users/a%2Fb (không cần đăng nhập) làm SDK Firestore ném lỗi trong handler async không có try/catch; Express 4 không bắt nên thành unhandledRejection và server.js gọi process.exit(1) — một request đủ làm sập cả dịch vụ. " +
    "Module khởi chạy server.js THẬT trong tiến trình con (Firestore giả mô phỏng đúng lỗi của SDK), gửi các id lạ tới nhiều route và kiểm tra: mỗi request trả 200/400/404 (không sập, không 500) và tiến trình con vẫn sống. " +
    "KHÔNG gửi payload này vào server đang phục vụ — vì vậy chạy cô lập.",
  async run(ctx) {
    const srv = await ctx.spawnServer();
    ctx.log(`Server con đã sẵn sàng (cổng ${srv.port}).`);
    const base = await srv.request("/api/users/abc");
    ctx.check("Đối chứng: hồ sơ không tồn tại trả 404", base.status === 404, `HTTP ${base.status ?? base.error}`);
    for (const [label, p] of CASES) {
      const r = await srv.request(p);
      const alive = srv.alive();
      const ok = alive && OK_STATUS.includes(r.status);
      ctx.check(label, ok, alive ? `HTTP ${r.status ?? r.error}` : `TIẾN TRÌNH CON ĐÃ SẬP (mã ${srv.exitInfo() && srv.exitInfo().code})`);
      if (!alive) break;
    }
    const health = await srv.request("/health");
    ctx.check("Sau tất cả, /health vẫn trả 200", srv.alive() && health.status === 200, `HTTP ${health.status ?? health.error}`);
    ctx.metric("Số tình huống đã thử", CASES.length + 2, "ca");
  },
};
