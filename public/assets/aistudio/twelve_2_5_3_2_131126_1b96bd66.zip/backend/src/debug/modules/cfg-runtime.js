const pkg = require("../../../package.json");
// Cấu hình chạy thật — chủ yếu là các lỗi do CẤU HÌNH chứ không do mã. Chỉ báo có/không, KHÔNG bao giờ in giá trị biến bí mật.
module.exports = {
  id: "cfg-runtime",
  ref: "CFG",
  title: "Cấu hình chạy thật của máy chủ này",
  severity: "medium",
  recordedIn: "2.2.0",
  fixedIn: null,
  mode: "static",
  description:
    "Nhiều lỗi nghiêm trọng đến từ cấu hình chứ không phải mã: NODE_ENV không phải production (tắt các kiểm tra bắt buộc), thiếu SSR_PROXY_SECRET (bảng CSP và đếm view SSR hỏng), thiếu SHARE_LINK_SECRET/Turnstile/khoá Firebase web… " +
    "Module đọc cấu hình của CHÍNH tiến trình đang chạy và các lưới an toàn của bản vá A-01 (lớp chuyển lỗi async của Express, bộ bắt unhandledRejection/uncaughtException). " +
    "Chỉ trả có/không cho biến bí mật, không in giá trị. Mục \"cảnh báo\" là khuyến nghị cấu hình, mục \"không đạt\" là lưới an toàn bị mất.",
  async run(ctx) {
    const env = process.env;
    const isProd = env.NODE_ENV === "production";
    ctx.check("NODE_ENV = production", isProd, `NODE_ENV=${env.NODE_ENV || "(chưa đặt)"}${isProd ? "" : " — môi trường khác production tắt các kiểm tra fail-fast (CORS, CAPTCHA, SHARE_LINK_SECRET) và cho đếm view SSR không cần secret"}`, { level: "warn" });
    for (const [name, why] of [
      ["SSR_PROXY_SECRET", "thiếu thì Render không tin IP/view do Vercel chuyển tới; CSP và đếm view SSR coi mọi người là một nguồn"],
      ["SHARE_LINK_SECRET", "thiếu thì link chia sẻ không ký được (chống bơm điểm share)"],
      ["TURNSTILE_SECRET_KEY", "thiếu thì CAPTCHA đăng ký/quên mật khẩu không có hiệu lực"],
      ["FIREBASE_WEB_API_KEY", "thiếu thì \"Quên mật khẩu\" không gửi được thư"],
      ["CORS_ORIGIN", "thiếu thì CORS không giới hạn đúng nguồn"],
      ["FRONTEND_URL", "thiếu thì SSR/sitemap/OG dùng địa chỉ mặc định"],
    ]) ctx.check(`${name} đã đặt`, ctx.hasEnv(name), ctx.hasEnv(name) ? "" : why, { level: "warn" });
    ctx.check("BACKEND_VERSION (nếu đặt) khớp package.json", !env.BACKEND_VERSION || env.BACKEND_VERSION === pkg.version, env.BACKEND_VERSION ? `env=${env.BACKEND_VERSION}, package=${pkg.version}` : "không đặt — dùng package.json", { level: "warn" });
    // v2.5.3 [TW-03]: mặc định đã đảo sang BẬT — chỉ cảnh báo khi ai đó chủ động đặt "off".
    const viewOnceOff = ["off", "0", "false"].includes(String(env.VIEW_SCORE_ONCE_PER_PAIR || "").trim().toLowerCase());
    ctx.check("Chống cày điểm xem (VIEW_SCORE_ONCE_PER_PAIR) đang BẬT", !viewOnceOff, "đang bị đặt \"off\" — một tài khoản cày được ~48 điểm/ngày/bài (TW-03); xoá biến hoặc đặt \"on\"", { level: "warn" });
    // v2.5.3 [TW-01]: IP client — số hop proxy phải được ĐO rồi mới đặt (xem utils/clientIp.js).
    ctx.check("TRUST_PROXY_HOPS đã được đặt sau khi đo topology", env.TRUST_PROXY_HOPS !== undefined && env.TRUST_PROXY_HOPS !== "", env.TRUST_PROXY_HOPS ? `= ${env.TRUST_PROXY_HOPS}` : "chưa đặt — đang dùng mặc định 1 (như 2.5.2); bật DEBUG_IP_TOPOLOGY=on, gọi /api/version vài lần từ máy bạn rồi đối chiếu log [IP-TOPO] (TW-01)", { level: "warn" });
    ctx.check("Sweeper dọn tài khoản pending đang bật (TW-08)", String(env.PENDING_SWEEPER || "").trim().toLowerCase() !== "off", "PENDING_SWEEPER=off — tài khoản pending quá hạn sẽ giữ Tag Name/email cho tới khi bạn chạy `npm run pending:cleanup:apply` bằng tay", { level: "warn" });
    ctx.check("DEBUG_IP_TOPOLOGY đã tắt", env.DEBUG_IP_TOPOLOGY !== "on", "log chẩn đoán IP đang bật — chỉ bật tạm khi đo, rồi gỡ biến", { level: "warn" });

    const major = parseInt(require("express/package.json").version, 10);
    const patched = major >= 5 || (require("express/lib/router/layer").prototype.__twelveAsyncPatched === true);
    ctx.check("Lỗi của handler async được chuyển vào error handler (không thành unhandledRejection)", patched, `Express ${major}.x${major >= 5 ? " tự làm việc này" : patched ? " + lớp vá của Twelve" : " — LỚP VÁ A-01 KHÔNG CÓ"}`);
    ctx.check("Có bộ bắt unhandledRejection", process.listenerCount("unhandledRejection") >= 1);
    ctx.check("Có bộ bắt uncaughtException", process.listenerCount("uncaughtException") >= 1);
    ctx.check("Node.js ≥ 18", parseInt(process.versions.node, 10) >= 18, `Node ${process.versions.node}`, { level: "warn" });
    ctx.metric("Thời gian chạy của tiến trình", Math.round(process.uptime()), "giây");
    ctx.metric("Bộ nhớ RSS", Math.round(process.memoryUsage().rss / 1048576), "MB");
  },
};
