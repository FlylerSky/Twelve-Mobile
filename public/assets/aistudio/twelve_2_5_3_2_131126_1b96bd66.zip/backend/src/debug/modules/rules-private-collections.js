// Kiểm firestore.rules ĐÃ DEPLOY thật chưa: Client SDK không được đọc dữ liệu riêng. Gọi REST Firestore KHÔNG kèm token từ chính server này.
// v2.5.3 [TW-07]: thêm `config` vào danh sách phải bị chặn (rules không còn cho đọc công khai `config/*` — chứa UID của SA) và ĐỔI đối chứng "cho đọc công khai" từ
// `config/` sang `countries/` (rules vẫn cho đọc công khai: firestore.rules). Nếu để nguyên đối chứng `config/` thì sau khi khoá nó trả 403 và module sẽ tự "bỏ qua" mãi.
const PROBES = ["userPrivate", "accountDeletions", "assets", "debugRuns", "profileVisitors", "users", "config"]; // đều phải bị rules chặn đọc khi không đăng nhập
const CONTROL = "countries"; // collection công khai: tài liệu thử không tồn tại ⇒ 404 (không phải 403)
const fs = require("fs");
const path = require("path");

/**
 * v2.5.3 [TW-13]: kiểm BẢN TRONG MÃ NGUỒN của firestore.rules cho đường dẫn `matchPath` (vd. `/users/{uid}/positiveScoreLogs/{logId}`): không có khối riêng
 * (rơi vào `{document=**}` = chặn) hoặc khối đó chỉ có `allow read[, write]: if false`. Vì sao cần: probe không đăng nhập KHÔNG phân biệt được "chính chủ đọc được"
 * với "khoá hẳn" (cả hai 403) nên không thể chứng minh khoá `positiveScoreLogs` bằng REST — chỉ kiểm được file nguồn (chưa chứng minh đã deploy).
 */
function sourceDeniesRead(rulesText, matchPath) {
  const code = String(rulesText).replace(/\/\/[^\n]*/g, "");
  const header = `match ${matchPath} {`;
  const start = code.indexOf(header);
  if (start === -1) return true;
  const bodyStart = start + header.length; // bỏ qua dấu "}" nằm TRONG đường dẫn (vd. {uid})
  const end = code.indexOf("}", bodyStart);
  const block = code.slice(bodyStart, end === -1 ? undefined : end);
  const reads = block.match(/allow\s+[a-z, ]*\bread\b[^;]*;/g) || block.match(/allow\s+(?:get|list)[^;]*;/g) || [];
  return reads.length > 0 && reads.every((r) => /:\s*if\s+false\s*;$/.test(r));
}
function projectId(env) {
  if (env.FIREBASE_PROJECT_ID) return env.FIREBASE_PROJECT_ID;
  try {
    return JSON.parse(env.FIREBASE_SERVICE_ACCOUNT || "{}").project_id || "";
  } catch (_e) {
    return "";
  }
}

module.exports = {
  __test: { sourceDeniesRead },
  id: "rules-private-collections",
  ref: "RULES",
  title: "Firestore rules đã chặn đọc dữ liệu riêng (tên thật, sổ xoá, tài nguyên…)",
  severity: "high",
  recordedIn: "2.2.0",
  fixedIn: null,
  mode: "live-safe",
  timeoutMs: 40000,
  description:
    "Tên thật được chuyển sang collection userPrivate với giả định rules chặn hoàn toàn Client SDK. Nếu quên deploy firestore.rules thì giả định đó sai và ai cũng đọc được. " +
    "Module gọi REST Firestore (chỉ GET, không kèm token) tới tài liệu thử trong userPrivate, accountDeletions, assets, debugRuns, profileVisitors, users, config: phải bị từ chối (403). Đối chứng: countries/ (rules cho đọc công khai) phải trả 404 chứ không 403 — nếu cả hai cùng 403 thì phép thử không phân biệt được (vd. API cần khoá) và module báo bỏ qua thay vì \"đạt\" giả. " +
    "Thêm (v2.5.3): đọc file firestore.rules đi kèm mã nguồn để kiểm positiveScoreLogs đã khoá (probe không đăng nhập không chứng minh được điều này). " +
    "Chỉ đọc, không ghi, chỉ tới firestore.googleapis.com.",
  async run(ctx) {
    const pid = projectId(process.env);
    if (!pid) return ctx.skip("Không xác định được project id Firebase (FIREBASE_PROJECT_ID hoặc FIREBASE_SERVICE_ACCOUNT).");
    const url = (col) => `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(pid)}/databases/(default)/documents/${col}/debug-probe`;
    const control = await ctx.httpsGet(url(CONTROL));
    if (control.error) return ctx.skip(`Không gọi được Firestore REST từ máy chủ này (${control.error}).`);
    if (control.status !== 404) {
      return ctx.skip(`Phép thử đối chứng không phân biệt được cho/chặn (${CONTROL}/ trả HTTP ${control.status}, mong đợi 404) — kiểm tay bằng Firebase Console → Rules Playground.`);
    }
    ctx.check(`Đối chứng: collection công khai (${CONTROL}) trả 404 — phép thử phân biệt được cho/chặn`, true, "HTTP 404");
    for (const col of PROBES) {
      const r = await ctx.httpsGet(url(col));
      if (r.error) {
        ctx.check(`${col}: bị rules chặn đọc khi không đăng nhập`, false, `không gọi được (${r.error})`);
        continue;
      }
      ctx.check(`${col}: bị rules chặn đọc khi không đăng nhập`, r.status === 403, `HTTP ${r.status}${r.status === 404 ? " — rules CHO ĐỌC (tài liệu thử không tồn tại nên 404)" : ""}`);
    }
    // v2.5.3 [TW-13]: positiveScoreLogs — kiểm file nguồn (xem sourceDeniesRead). Không tìm thấy file thì chỉ cảnh báo, không làm module thất bại.
    let rulesText = null;
    try {
      rulesText = fs.readFileSync(path.join(__dirname, "../../../firestore.rules"), "utf8");
    } catch (_e) {
      /* chạy ở môi trường không có file rules — bỏ qua phép kiểm này */
    }
    if (rulesText === null) ctx.check("firestore.rules (nguồn) khoá users/*/positiveScoreLogs", false, "không đọc được firestore.rules đi kèm mã nguồn", { level: "warn" });
    else ctx.check("firestore.rules (nguồn) khoá users/*/positiveScoreLogs và config/*", sourceDeniesRead(rulesText, "/users/{uid}/positiveScoreLogs/{logId}") && sourceDeniesRead(rulesText, "/config/{docId}"), "file nguồn; đã deploy chưa thì kiểm bằng Rules Playground (probe không đăng nhập không phân biệt được)");
  },
};
