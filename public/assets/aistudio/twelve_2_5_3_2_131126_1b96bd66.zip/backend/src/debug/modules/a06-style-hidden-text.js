const { sanitizeHtml } = require("../../services/sanitize.service");
// Lỗi A-06 + R-01 (Thấp) — ghi nhận ở 2.2.0, vá ở 2.2.1; màu/ngưỡng alpha siết ở 2.2.2 và 2.3.0.
const html = (style) => `<p style="${style}">kiem-tra</p>`;
const stripped = (style) => !/style=/.test(sanitizeHtml(html(style)));
const kept = (style) => /style=/.test(sanitizeHtml(html(style)));

// Phải BỊ LOẠI: chữ vô hình / phá bố cục
const MUST_STRIP = [
  "font-size:0px", "font-size:7px", "font-size:0.1em", "font-size:1000px",
  "margin-left:-9999px", "margin-right:-5px", "padding-left:99999px", "padding-right:201px",
  "line-height:0",
  "color:transparent", "color:TRANSPARENT", "color:#fff0", "color:#ffffff00", "color:#00000000", "color:#0001", "color:#fff2", "color:#ffffff1a",
  "color:rgba(0,0,0,0)", "color:rgba(255,255,255,0.1)", "color:rgba(255,255,255,.49)", "color:hsla(0,0%,0%,0)",
  "color:canvas", "color:field", "color:window", "color:buttonface",
  "color:var(--x)", "color:color-mix(in srgb, red, transparent)", "color:light-dark(red, transparent)",
  "position:fixed", "background-color:url(https://evil.example/x.png)", "z-index:9999",
];
// Phải ĐƯỢC GIỮ: định dạng bình thường mà Quill/người dùng hay tạo
const MUST_KEEP = [
  "color:red", "color:#e60000", "color:#fff", "color:rgb(230, 0, 0)", "color:rgba(10,20,30,0.8)", "color:hsl(120, 100%, 50%)", "color:currentcolor",
  "font-size:14px", "font-size:1.2em", "font-size:large", "text-align:center", "line-height:1.5", "padding-left:30px", "margin-left:auto", "background-color:#ff0",
];
// Vector XSS cơ bản — dù đã vá từ trước cũng giữ trong hồi quy
const XSS = [
  ['<a href="javascript:alert(1)">x</a>', "javascript:"],
  ['<img src="https://evil.example/x.png" onerror="alert(1)">', "onerror"],
  ["<svg><script>alert(1)</script></svg>", "<script"],
  ['<iframe src="https://evil.example/x"></iframe>', "<iframe"],
  ['<p onclick="alert(1)">x</p>', "onclick"],
];

module.exports = {
  id: "a06-style-hidden-text",
  ref: "A-06",
  title: "Chữ vô hình / phá bố cục qua thuộc tính style của bài viết",
  severity: "low",
  recordedIn: "2.2.0",
  fixedIn: "2.3.0",
  mode: "unit",
  description:
    "Từng có: bộ lọc style giữ mọi giá trị số nên font-size:0, color:transparent, hex-alpha (#fff0), margin âm hay padding khổng lồ làm chữ vô hình (spam SEO; SSR dựng riêng cho bot/AI nên còn là kênh giấu chỉ dẫn cho AI) hoặc phá bố cục. " +
    "Module chạy sanitizeHtml() thật với các payload PHẢI bị loại và các định dạng bình thường PHẢI được giữ, cộng vài vector XSS cơ bản. Hàm thuần — chạy an toàn trong tiến trình chính. " +
    "Giới hạn cố hữu: chữ trùng màu nền (vd. #fff trên nền trắng) không phát hiện được bằng danh sách trắng nên module này không (và không thể) cam đoan loại bỏ hoàn toàn.",
  async run(ctx) {
    const leaked = MUST_STRIP.filter((s) => !stripped(s));
    ctx.check(`${MUST_STRIP.length} kiểu style gây chữ vô hình/phá bố cục đều bị loại`, leaked.length === 0, leaked.length ? `CÒN LỌT: ${leaked.join(" | ")}` : "");
    const lost = MUST_KEEP.filter((s) => !kept(s));
    ctx.check(`${MUST_KEEP.length} định dạng bình thường vẫn được giữ`, lost.length === 0, lost.length ? `BỊ LOẠI NHẦM: ${lost.join(" | ")}` : "");
    const xssLeft = XSS.filter(([input, marker]) => sanitizeHtml(input).toLowerCase().includes(marker));
    ctx.check(`${XSS.length} vector XSS cơ bản đều bị loại`, xssLeft.length === 0, xssLeft.length ? `CÒN LỌT: ${xssLeft.map((x) => x[1]).join(", ")}` : "");
    ctx.check("Nội dung chữ vẫn còn khi style bị loại", sanitizeHtml(html("font-size:0px")).includes("kiem-tra"));
    ctx.metric("Payload style PHẢI loại", MUST_STRIP.length, "mẫu");
    ctx.metric("Định dạng PHẢI giữ", MUST_KEEP.length, "mẫu");
  },
};
