const { applyChildResult } = require("../support/childResult");
// Lỗi A-03 / T-220-02 (Thấp) — ghi nhận ở 2.2.0, vá ở 2.2.1.
module.exports = {
  id: "a03-forgot-timing",
  ref: "A-03",
  title: "Quên mật khẩu lộ email nào có tài khoản (thời gian / mã lỗi)",
  severity: "low",
  recordedIn: "2.2.0",
  fixedIn: "2.2.1",
  mode: "isolated",
  timeoutMs: 40000,
  description:
    "Từng có: POST /api/auth/forgot-password trả lời chậm hơn ~300 ms cho email CÓ tài khoản (phải gọi Firebase) và trả 502/429 khi Firebase lỗi, nên dò được email nào đã đăng ký dù nội dung phản hồi giống nhau. " +
    "Module dựng server tại chỗ (Firebase giả, gọi Firebase REST bị giả lập chậm 300 ms), đo median thời gian phản hồi 10 cặp xen kẽ sau khi làm nóng và so sánh. Bản vá trả lời ngay rồi gửi thư ở nền nên hai median xấp xỉ nhau. " +
    "Phép đo nhạy với tải CPU của máy chủ: nếu chỉ đỏ ở mục thời gian, chạy lại khi máy rảnh.",
  async run(ctx) {
    applyChildResult(ctx, await ctx.runChild("forgot-timing-probe.js", [], { timeoutMs: 35000 }), "quên mật khẩu");
  },
};
