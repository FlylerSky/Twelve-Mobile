const { applyChildResult } = require("../support/childResult");
// Lỗi A-02 / T-220-01 (Thấp–Trung bình) — ghi nhận ở 2.2.0, vá ở 2.2.1.
module.exports = {
  id: "a02-delete-race",
  ref: "A-02",
  title: "Race khi xoá tài khoản (dữ liệu dựng lại sau khi xoá)",
  severity: "medium",
  recordedIn: "2.2.0",
  fixedIn: "2.2.1",
  mode: "isolated",
  timeoutMs: 30000,
  description:
    "Từng có: request đã qua middleware nhưng bị kẹt (PUT tên thật, POST bài viết) vẫn ghi dữ liệu SAU khi tài khoản bị xoá xong — dựng lại userPrivate/{uid}, bài mồ côi, hồ sơ \"ma\" users/{uid} (do tx.set với merge tạo document). " +
    "Module dựng đúng tình huống đó trong tiến trình con với dữ liệu giả: giữ request lại → xoá tài khoản xong → thả request, rồi kiểm tra request bị từ chối (403) và không còn dữ liệu sót.",
  async run(ctx) {
    applyChildResult(ctx, await ctx.runChild("race-probe.js", [], { timeoutMs: 25000 }), "race xoá tài khoản");
  },
};
