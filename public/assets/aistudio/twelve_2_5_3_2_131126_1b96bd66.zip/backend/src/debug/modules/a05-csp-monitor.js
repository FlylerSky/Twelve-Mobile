const { applyChildResult } = require("../support/childResult");
// Lỗi A-05 + R-02 (Thấp) — ghi nhận ở 2.2.0, vá ở 2.2.1; giới hạn theo nguồn thêm ở 2.2.2.
module.exports = {
  id: "a05-csp-monitor",
  ref: "A-05",
  title: "Đầu độc bảng theo dõi báo cáo CSP",
  severity: "low",
  recordedIn: "2.2.0",
  fixedIn: "2.2.2",
  mode: "isolated",
  timeoutMs: 20000,
  description:
    "Từng có: endpoint /api/csp-report công khai; kẻ tấn công gửi vài trăm báo cáo giả làm bảng 300 khoá đầy và đẩy báo cáo hợp lệ ra (làm sai dữ liệu quyết định bật script-src thật). " +
    "Bản vá: không loại khoá cũ, mỗi nguồn chỉ tạo tối đa 10 khoá mới, có khoản dự trữ cho script-src, đếm phần bị bỏ ở throttled/overflow. " +
    "Module chạy cô lập (bảng thống kê là trạng thái toàn cục trong RAM — chạy ở tiến trình thật sẽ xoá dữ liệu quan sát của bạn) và kiểm: một nguồn không lấp được bảng, báo cáo thật từ nhiều người được gom đúng, " +
    "và giới hạn đã biết (kẻ tấn công ~35 nguồn vẫn lấp được nhưng bị đếm ở overflow).",
  async run(ctx) {
    applyChildResult(ctx, await ctx.runChild("csp-probe.js", [], { timeoutMs: 15000 }), "giám sát CSP");
  },
};
