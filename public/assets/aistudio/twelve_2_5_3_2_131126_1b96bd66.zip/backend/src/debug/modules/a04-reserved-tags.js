const { isReservedTagName } = require("../../utils/helpers");
// Lỗi A-04 + R-03 (Thấp) — ghi nhận ở 2.2.0, vá ở 2.2.1; sót ranh giới chữ lặp vá nốt ở 2.3.0.
const MUST_BLOCK = [
  "admin", "Admin_", "admin2", "_admin", "administrator", "twelve", "twelve_support", "support", "official", "moderator", "security",
  "adm1n", "tw3lve", "twe1ve", "suppport", "the_twelve", "twelvehelp", "twelve_vn", "realtwelve", "official_twelve",
  "support_team", "supportteam", "admin_news", "adminnews", "official_support_team_vn", "support_the",
];
const MUST_ALLOW = [
  "helpful", "model", "supporter", "teammate", "twelvefan_vn", "alice", "bob_2000", "nguyen_van_a", "minh_support_me", "supportive", "modern",
  "botanist", "newsletter", "information", "global_traveler", "the_best", "real_madrid", "team_alpha", "vn_news", "admin_fan", "hq_media", "app_dev",
  "care_bear", "service_dog", "contact_lens", "account_book", "verified_user", "the_real", "info_hub", "bots", "mods", "staffing", "teams", "staff_fan",
];

module.exports = {
  id: "a04-reserved-tags",
  ref: "A-04",
  title: "Tag Name dành riêng (chống mạo danh admin/twelve/support…)",
  severity: "low",
  recordedIn: "2.2.0",
  fixedIn: "2.3.0",
  mode: "unit",
  description:
    "Từng có: admin, twelve, support, moderator… đăng ký được để mạo danh quản trị/hỗ trợ; bản vá đầu chặn biến thể gạch dưới/số đuôi/lookalike nhưng gập chữ lặp làm hỏng việc ghép từ ở chỗ nối (support_team, admin_news lọt). " +
    "Module gọi thẳng isReservedTagName() với danh sách tên PHẢI bị chặn và danh sách tag bình thường PHẢI được dùng (phát hiện cả chặn nhầm). Hàm thuần, chỉ đọc — chạy trong tiến trình chính an toàn. " +
    "Lưu ý: tag chỉ bị chặn với tài khoản MỚI; muốn biết ai đang giữ tag dành riêng từ trước hãy chạy `npm run tags:reserved`.",
  async run(ctx) {
    const leaked = MUST_BLOCK.filter((n) => !isReservedTagName(n));
    ctx.check(`${MUST_BLOCK.length} tên mạo danh đều bị chặn`, leaked.length === 0, leaked.length ? `LỌT: ${leaked.join(", ")}` : "");
    const blocked = MUST_ALLOW.filter((n) => isReservedTagName(n));
    ctx.check(`${MUST_ALLOW.length} tag bình thường đều dùng được (không chặn nhầm)`, blocked.length === 0, blocked.length ? `BỊ CHẶN NHẦM: ${blocked.join(", ")}` : "");
    ctx.metric("Tên mạo danh đã thử", MUST_BLOCK.length, "tên");
    ctx.metric("Tag bình thường đã thử", MUST_ALLOW.length, "tên");
  },
};
