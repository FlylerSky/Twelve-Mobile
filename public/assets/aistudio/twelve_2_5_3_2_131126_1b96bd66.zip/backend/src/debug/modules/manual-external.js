// Những thứ nằm NGOÀI tiến trình này nên không tự kiểm được — hiển thị trung thực là "cần kiểm tay" thay vì xanh giả.
module.exports = {
  id: "manual-external",
  ref: "MANUAL",
  title: "Việc cần kiểm tay (ngoài tầm nhìn của máy chủ)",
  severity: "info",
  recordedIn: "2.2.0",
  fixedIn: null,
  mode: "manual",
  description:
    "Các mục dưới đây phụ thuộc Firebase Console, Render, Vercel hoặc hành vi trình duyệt nên mã chạy trong máy chủ không tự xác nhận được. Module liệt kê cách kiểm từng mục để không bị bỏ sót khi nâng phiên bản.",
  async run(ctx) {
    return ctx.manual([
      { title: "Email enumeration protection (Firebase)", how: "Firebase Console → Authentication → Settings → User actions: bật \"Email enumeration protection\". Kiểm tra tác động lên luồng đăng ký/đăng nhập trước khi bật." },
      { title: "Nhập lại mật khẩu cấp auth_time mới", how: "Đăng nhập, đợi > 5 phút, mở Cài đặt → Tài khoản → Tên thật: phải hiện hộp mật khẩu; nhập đúng thì xem được. Thử lại sau khi đã xem để chắc cửa sổ 5 phút hoạt động." },
      { title: "SSR_PROXY_SECRET khớp giữa Vercel và Render", how: "Mở một bài viết bằng curl (không phải trình duyệt) tới Vercel và xem header phản hồi X-Twelve-Ssr-Trusted: 1. Nếu 0 thì secret chưa khớp." },
      { title: "Giới hạn tần suất với IPv6", how: "Kiểm backend nhận req.ip dạng IPv4 hay IPv6 qua Render; nếu IPv6, một khối /64 có thể xoay IP để né limiter theo IP." },
      { title: "firestore.rules đã deploy", how: "Chạy module \"rules-private-collections\" ở trên; nếu bị bỏ qua, dùng Rules Playground trong Firebase Console để thử đọc userPrivate không đăng nhập." },
      { title: "Lockfile và dependency", how: "Repo thật có package-lock.json ở backend/ và frontend/ chưa; Render/Vercel dùng npm ci. Chạy npm audit định kỳ và nâng theo từng đợt có hồi quy." },
      { title: "Mật khẩu tài khoản thử nghiệm đã chia sẻ", how: "Đổi mật khẩu của mọi tài khoản test đã đưa cho công cụ/AI bên ngoài (và bất kỳ dịch vụ nào dùng chung mật khẩu đó)." },
      { title: "Sau khi triển khai bản có đổi bộ lọc style", how: "Chạy resanitizeContent.js (sao lưu trước) để áp bộ lọc mới cho bài cũ; chạy npm run tags:reserved để biết ai đang giữ tag dành riêng." },
    ]);
  },
};
