/** Chuyển kết quả JSON do tiến trình con in ra (xem child.js) thành các phép kiểm tra/số đo của ctx. Dùng chung cho mọi module chế độ "isolated". */
function applyChildResult(ctx, res, label) {
  if (!res.ok || !res.json) {
    const why = res.timedOut ? "quá thời gian" : res.spawnError ? res.spawnError : `mã thoát ${res.code}${res.signal ? `, tín hiệu ${res.signal}` : ""}`;
    ctx.check(`Tiến trình kiểm tra "${label}" chạy xong`, false, `${why}. ${String(res.stderrTail || "").trim().slice(-200)}`);
    return;
  }
  for (const c of res.json.checks || []) ctx.check(c.name, c.ok, c.detail);
  for (const m of res.json.metrics || []) ctx.metric(m.name, m.value, m.unit);
  if (res.json.error) ctx.check(`Tiến trình kiểm tra "${label}" không báo lỗi nội bộ`, false, res.json.error);
}
module.exports = { applyChildResult };
