/**
 * Tiến trình con cho module a03-forgot-timing: đo qua HTTP thật (server dựng tại chỗ, Firebase giả, gọi Firebase REST bị giả lập 300 ms)
 * thời gian nhận phản hồi của POST /api/auth/forgot-password với email CÓ tài khoản và email LẠ, xen kẽ, có làm nóng, lấy median.
 * Bản đã vá trả lời NGAY rồi mới gửi thư ở nền ⇒ hai median xấp xỉ nhau; bản lỗi (≤ 2.2.0) chênh ≈ 300 ms.
 */
const http = require("http");
const express = require("express");
const { install } = require("../support/fakeFirebase");
const { RESULT_MARK } = require("../child");

const fb = install({ tokens: {}, authTimes: {} });
const S = fb.store;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
process.env.FIREBASE_WEB_API_KEY = "demo-key";

const app = express();
app.set("trust proxy", 1);
app.use(express.json());
app.use("/api/auth", require("../../routes/auth.routes"));

const med = (a) => a.slice().sort((x, y) => x - y)[Math.floor(a.length / 2)];
const checks = [];
const metrics = [];
const add = (name, ok, detail) => checks.push({ name, ok: !!ok, detail: detail || "" });

(async () => {
  const server = http.createServer(app);
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const realFetch = global.fetch;
  let outbound = 0;
  global.fetch = async (url, o) => {
    if (String(url).includes("identitytoolkit")) { outbound++; await sleep(300); return { ok: true, status: 200, json: async () => ({}) }; }
    return realFetch(url, o);
  };
  let n = 0;
  const hit = async (email) => {
    const ip = `10.7.${Math.floor(n / 250)}.${(n++ % 250) + 1}`; // mỗi lần một IP khác để không dính giới hạn 5 lần/giờ/IP
    const t0 = process.hrtime.bigint();
    const r = await realFetch(`${base}/api/auth/forgot-password`, { method: "POST", headers: { "Content-Type": "application/json", "X-Forwarded-For": ip }, body: JSON.stringify({ email, captchaToken: "x" }) });
    const b = await r.json();
    return { ms: Number(process.hrtime.bigint() - t0) / 1e6, status: r.status, msg: b.message || b.error };
  };
  for (let i = 0; i < 3; i++) await hit(`warm${i}@example.org`);
  const K = []; const U = []; let last = {};
  for (let i = 0; i < 10; i++) {
    fb.authUsers.set(`uF${i}`, { uid: `uF${i}`, email: `real${i}@example.org` });
    S[`users/uF${i}`] = { uid: `uF${i}`, status: "active" };
    const k = await hit(`real${i}@example.org`);
    const u = await hit(`nobody${i}@example.org`);
    K.push(k.ms); U.push(u.ms); last = { k, u };
  }
  await sleep(500);
  const mk = med(K); const mu = med(U); const delta = mk - mu;
  metrics.push({ name: "Median phản hồi — email CÓ tài khoản", value: Math.round(mk * 10) / 10, unit: "ms" });
  metrics.push({ name: "Median phản hồi — email LẠ", value: Math.round(mu * 10) / 10, unit: "ms" });
  metrics.push({ name: "Chênh lệch median", value: Math.round(delta * 10) / 10, unit: "ms" });
  add("Cả hai trả HTTP 200", last.k.status === 200 && last.u.status === 200, `${last.k.status} / ${last.u.status}`);
  add("Cùng nội dung phản hồi", last.k.msg === last.u.msg);
  add("Chênh lệch thời gian phản hồi nhỏ (< 80 ms; bản lỗi chênh ≈ 300 ms)", Math.abs(delta) < 80, `${delta.toFixed(1)} ms`);
  add("Thư đặt lại vẫn được gửi (ở nền) cho email thật", outbound >= 10, `${outbound} lượt gọi Firebase`);
  global.fetch = realFetch;
  console.log(RESULT_MARK + JSON.stringify({ checks, metrics }));
  process.exit(0);
})().catch((e) => {
  console.log(RESULT_MARK + JSON.stringify({ checks, metrics, error: String(e && e.message ? e.message : e) }));
  process.exit(0);
});
