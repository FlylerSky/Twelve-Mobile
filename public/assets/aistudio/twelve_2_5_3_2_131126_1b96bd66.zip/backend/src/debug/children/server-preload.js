// Nạp bằng `node -r` TRƯỚC server.js trong tiến trình con (xem child.js → spawnServer): thay Firestore/Auth bằng bản GIẢ
// (mô phỏng cả việc SDK thật ném lỗi với id chứa "/"), để chạy server.js THẬT mà không cần khoá Firebase.
const { install } = require("../support/fakeFirebase");
install({ tokens: {} });
