/**
 * Tiến trình con cho module a05-csp-monitor. Chạy trong tiến trình RIÊNG vì bảng thống kê CSP là trạng thái toàn cục trong RAM —
 * chạy ở tiến trình thật sẽ xoá/ghi đè dữ liệu quan sát của quản trị viên.
 * Kiểm: (1) một nguồn không lấp được bảng/khoản dự trữ script-src, (2) báo cáo thật từ nhiều người được gom đúng, (3) giới hạn đã biết: kẻ tấn công ~35 nguồn vẫn lấp được nhưng bị đếm ở `overflow`.
 */
process.env.SSR_PROXY_SECRET = "debug-probe-secret";
const { RESULT_MARK } = require("../child");
const csp = require("../../controllers/csp.controller");

const checks = [];
const metrics = [];
const add = (name, ok, detail) => checks.push({ name, ok: !!ok, detail: detail || "" });
const res = { status() { return { end() {} }; } };
const origWarn = console.warn;
console.warn = () => {};
const mk = (ip, directive, blocked) => ({
  headers: { "x-twelve-ssr-secret": "debug-probe-secret", "x-twelve-client-ip": ip },
  ip,
  body: { "csp-report": { "document-uri": "https://twelve.test/", "effective-directive": directive, "blocked-uri": blocked } },
});
const send = (ip, d, b) => csp.receiveCspReport(mk(ip, d, b), res);
const reset = () => csp.__test.reset({}, { json() {} });
// Muối băm nguồn là NGẪU NHIÊN theo tiến trình => hai IP có thể (hiếm) trùng ô. Chọn IP có ô KHÁC NHAU để kết quả xác định (không "đỏ" ngẫu nhiên).
let seq = 0;
const distinctIps = (n) => {
  const out = []; const used = new Set();
  while (out.length < n) {
    const ip = `100.64.${Math.floor(seq / 250)}.${(seq++ % 250) + 1}`;
    const b = csp.__test.reporterBucket(ip);
    if (!used.has(b)) { used.add(b); out.push(ip); }
  }
  return out;
};
const hasKey = (s) => [...csp.__test.entries.keys()].some((k) => k.includes(s));

try {
  // (1) MỘT nguồn
  reset();
  const [attacker, honest1, honest2] = distinctIps(3);
  for (let i = 0; i < 300; i++) send(attacker, "img-src", `https://n${i}.example/a.png`);
  for (let i = 0; i < 50; i++) send(attacker, "script-src", `https://evil${i}.example/x.js`);
  send(honest1, "script-src", "https://real-xss.example/payload.js");
  add("Một nguồn gửi 350 báo cáo khác nhau không lấp được bảng", csp.__test.entries.size <= 20, `${csp.__test.entries.size} khoá`);
  add("Vi phạm script-src THẬT từ người khác vẫn được ghi", hasKey("real-xss"));
  add("Phần vượt bị đếm ở `throttled`", csp.__test.state.throttled > 0, `throttled = ${csp.__test.state.throttled}`);

  // (2) Gom nhiều người báo cùng một vi phạm
  reset();
  send(honest1, "script-src", "https://real-xss.example/p.js");
  send(honest2, "script-src", "https://real-xss.example/p.js");
  const out = []; csp.getCspReports({}, { json: (b) => out.push(b) });
  const e = (out[0].entries || []).find((x) => String(x.blocked).includes("real-xss"));
  add("Hai người báo cùng một vi phạm được gom thành 1 dòng, 2 nguồn", !!e && e.count === 2 && e.reporters === 2, e ? `count=${e.count}, reporters=${e.reporters}` : "không thấy");

  // (3) Giới hạn đã biết — kẻ tấn công ~35 nguồn
  reset();
  const swarm = distinctIps(36); // 30 nguồn lấp bảng chung + 5 lấp khoản dự trữ script-src + 1 người dùng thật
  for (let s = 0; s < 30; s++) for (let i = 0; i < 10; i++) send(swarm[s], "img-src", `https://n${s}-${i}.example/a.png`);
  for (let s = 30; s < 35; s++) for (let i = 0; i < 10; i++) send(swarm[s], "script-src", `https://e${s}-${i}.example/a.js`);
  send(swarm[35], "script-src", "https://real-xss.example/p.js");
  metrics.push({ name: "Khoá trong bảng sau khi ~35 nguồn tấn công", value: csp.__test.entries.size, unit: "khoá" });
  metrics.push({ name: "Báo cáo bị bỏ vì bảng đầy (overflow)", value: csp.__test.state.overflow, unit: "báo cáo" });
  add("Giới hạn đã biết: ~35 nguồn vẫn lấp được bảng — nhưng PHẢI bị đếm ở overflow để quản trị viên thấy", csp.__test.state.overflow >= 1, `overflow = ${csp.__test.state.overflow}`);
} catch (e) {
  add("Chạy probe CSP", false, String(e && e.message ? e.message : e));
}
console.warn = origWarn;
console.log(RESULT_MARK + JSON.stringify({ checks, metrics }));
process.exit(0);
