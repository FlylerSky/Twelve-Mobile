/**
 * Tiến trình con cho module a02-delete-race: dựng lại hai request "đã qua middleware nhưng bị kẹt" rồi cho tài khoản bị xoá XONG, sau đó thả request.
 * Bản đã vá: request kẹt bị từ chối (403) và không để lại dữ liệu (userPrivate / bài mồ côi / hồ sơ "ma").
 * Chạy với Firestore/Auth/Cloudinary GIẢ; in kết quả JSON ra stdout sau dấu @@RESULT@@.
 */
const http = require("http");
const path = require("path");
const express = require("express");
const { install } = require("../support/fakeFirebase");
const { RESULT_MARK } = require("../child");

const nowSec = () => Math.floor(Date.now() / 1000);
const fb = install({ tokens: { tA: "uA" }, authTimes: { tA: nowSec() - 10 } });
const S = fb.store;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const cloudinaryPath = require.resolve(path.join(__dirname, "../../config/cloudinary.js"));
require.cache[cloudinaryPath] = { id: cloudinaryPath, filename: cloudinaryPath, loaded: true, exports: {
  config: () => ({ cloud_name: "demo", api_key: "k", api_secret: "s" }),
  uploader: { destroy: async () => ({}) },
  api: { delete_resources_by_prefix: async () => ({}), delete_resources: async () => ({}) },
} };

// "Giữ chân" request giữa middleware và bước ghi (mô phỏng request đã qua requireAuth nhưng chậm)
let gate = Promise.resolve();
const userPrivate = require("../../services/userPrivate");
const origWrite = userPrivate.writeRealName;
userPrivate.writeRealName = async (...a) => { await gate; return origWrite(...a); };
const cp = require("../../services/contentPipeline");
cp.processContentHtml = async () => { await gate; return { html: "<p>x</p>", excerpt: "x" }; };
const deletion = require("../../services/accountDeletion");
const D = deletion.__test;

const app = express();
app.use(express.json());
app.use("/api/users", require("../../routes/users.routes"));
app.use("/api/posts", require("../../routes/posts.routes"));

const checks = [];
const add = (name, ok, detail) => checks.push({ name, ok: !!ok, detail: detail || "" });

const seed = () => {
  Object.keys(S).forEach((k) => delete S[k]);
  fb.authUsers.clear();
  S["users/uA"] = { uid: "uA", displayName: "A", tagName: "tag_a", status: "active", accountGroup: "RA", accountRole: "user", country: "VN" };
  S["tagNames/tag_a"] = { uid: "uA" };
  S["userPrivate/uA"] = { fullName: "Nguyễn Văn A" };
  fb.authUsers.set("uA", { uid: "uA", email: "a@x.com" });
  require("../../middleware/auth").__test.clearRevokeCache();
  D.reset();
};

(async () => {
  const server = http.createServer(app);
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, url, token, body) => {
    const res = await fetch(base + url, { method, headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
    let json = null; try { json = await res.json(); } catch (_e) { /* không có thân */ }
    return { status: res.status, body: json };
  };
  const deleteFully = async () => { await deletion.requestDeletion("uA"); await D.processOne("uA"); };

  // Kịch bản 1 — T-220-01: PUT tên thật đã qua middleware, tài khoản xoá xong rồi mới ghi
  seed();
  let release; gate = new Promise((r) => (release = r));
  const p1 = call("PUT", "/api/users/me/real-name", "tA", { fullName: "TEN-MUON" });
  await sleep(80);
  await deleteFully();
  add("Tài khoản đã bị xoá trước khi request kẹt được thả", S["users/uA"] === undefined && S["userPrivate/uA"] === undefined);
  release(); gate = Promise.resolve();
  const r1 = await p1;
  add("PUT tên thật đến muộn bị từ chối (403)", r1.status === 403, `HTTP ${r1.status}`);
  add("Không dựng lại userPrivate/{uid}", S["userPrivate/uA"] === undefined);

  // Kịch bản 2 — A-02: POST bài đã qua middleware, tài khoản xoá xong rồi mới ghi
  seed();
  gate = new Promise((r) => (release = r));
  const p2 = call("POST", "/api/posts", "tA", { title: "Bài đăng muộn", contentHtml: "<p>x</p>" });
  await sleep(80);
  await deleteFully();
  release(); gate = Promise.resolve();
  const r2 = await p2;
  const posts = Object.keys(S).filter((k) => /^posts\/[^/]+$/.test(k));
  add("POST bài đến muộn bị từ chối (403)", r2.status === 403, `HTTP ${r2.status}`);
  add("Không còn bài mồ côi của tài khoản đã xoá", posts.length === 0, `${posts.length} bài`);
  add("Không dựng lại hồ sơ \"ma\" users/{uid}", S["users/uA"] === undefined);
  const pub = await call("GET", "/api/users/uA", null);
  add("Trang hồ sơ công khai của tài khoản đã xoá trả 404", pub.status === 404, `HTTP ${pub.status}`);

  console.log(RESULT_MARK + JSON.stringify({ checks }));
  process.exit(0);
})().catch((e) => {
  console.log(RESULT_MARK + JSON.stringify({ checks, error: String(e && e.message ? e.message : e) }));
  process.exit(0);
});
