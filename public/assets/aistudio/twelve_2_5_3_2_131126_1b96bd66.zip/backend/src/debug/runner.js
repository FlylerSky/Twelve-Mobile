/**
 * ==== v2.3.0 — Bộ chạy module "Gỡ lỗi" ====
 * Một chỗ duy nhất chạy mọi module, nên các rào an toàn áp dụng đồng loạt (module không tự lo):
 *  - MỘT module chạy tại một thời điểm (đang chạy mà gọi thêm → 409 DEBUG_BUSY) — máy Render miễn phí không chịu nổi nhiều tiến trình con cùng lúc.
 *  - Timeout cứng (mặc định 30 giây, tối đa 60) → trạng thái "timeout"; mọi tiến trình con do module mở bị kill.
 *  - Che bí mật: giá trị của biến môi trường trông như bí mật (SECRET/TOKEN/PASSWORD/KEY/PRIVATE/SERVICE_ACCOUNT…), khoá riêng PEM và JWT bị thay bằng [đã ẩn]
 *    ở MỌI chuỗi trong kết quả (log, chi tiết kiểm tra, tên số đo) trước khi rời khỏi server.
 *  - Giới hạn dung lượng: số dòng log, độ dài dòng, tổng ký tự, số kiểm tra/số đo — vượt thì cắt và đánh dấu `truncated`.
 *  - Module không có cách nào nhận mã/tham số từ client: API chỉ nhận `id` và id phải có trong sổ đăng ký (registry.js).
 *  - Chỉ lưu BẢN TÓM TẮT (không log) vào collection `debugRuns` (rules chặn hoàn toàn; không dùng `config` vì `config` đọc công khai).
 */
const http = require("http");
const pkg = require("../../package.json");
const { getRegistry, describe, MAX_TIMEOUT_MS } = require("./registry");
const child = require("./child");
const { COLLECTIONS } = require("../utils/constants");

const DEFAULT_TIMEOUT_MS = 30 * 1000;
const LIMITS = { LOG_LINES: 300, LINE_CHARS: 500, TOTAL_CHARS: 60000, CHECKS: 200, METRICS: 100 };
const HTTPS_ALLOW_HOSTS = ["firestore.googleapis.com"]; // module "live-safe" chỉ được GET tới các host này
const REDACTED = "[đã ẩn]";
const STATUSES = ["pass", "fail", "warn", "skip", "manual", "error", "timeout"];

const deps = { fetch: (...a) => globalThis.fetch(...a) }; // tách ra để test thay được

let running = null; // { id, startedAt }
const lastResults = new Map(); // id -> kết quả đầy đủ gần nhất (mất khi khởi động lại; bản tóm tắt thì nằm ở Firestore)

function isEnabled() {
  return !/^(off|false|0|no)$/i.test(String(process.env.DEBUG_PANEL_ENABLED || "on").trim());
}

// ---------- che bí mật ----------
const SECRET_KEY_RE = /SECRET|TOKEN|PASSWORD|PRIVATE|API_KEY|SERVICE_ACCOUNT|_KEY$/i;
function collectSecrets() {
  const out = new Set();
  for (const [k, v] of Object.entries(process.env)) {
    if (!v || v.length < 6 || !SECRET_KEY_RE.test(k)) continue;
    out.add(v);
    if (k === "FIREBASE_SERVICE_ACCOUNT") {
      try {
        const j = JSON.parse(v);
        for (const f of ["private_key", "private_key_id"]) if (typeof j[f] === "string" && j[f].length >= 6) out.add(j[f]);
      } catch (_e) { /* không phải JSON: đã che nguyên chuỗi ở trên */ }
    }
  }
  return [...out].sort((a, b) => b.length - a.length);
}
const PEM_RE = /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g;
const JWT_RE = /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g;
function redact(value, secrets) {
  let s = String(value ?? "");
  for (const sec of secrets) if (s.includes(sec)) s = s.split(sec).join(REDACTED);
  return s.replace(PEM_RE, REDACTED).replace(JWT_RE, REDACTED);
}

// ---------- ngữ cảnh đưa cho module ----------
function createContext({ mod, secrets, cleanups }) {
  const logs = [];
  const checks = [];
  const metrics = [];
  let chars = 0;
  let truncated = false;
  let closed = false;
  const t0 = Date.now();

  const clip = (v, n) => {
    const s = redact(v, secrets);
    return s.length > n ? `${s.slice(0, n)}…` : s;
  };
  const push = (level, msg) => {
    if (closed) return;
    if (logs.length >= LIMITS.LOG_LINES || chars >= LIMITS.TOTAL_CHARS) {
      truncated = true;
      return;
    }
    const line = clip(msg, LIMITS.LINE_CHARS);
    chars += line.length;
    logs.push({ t: Date.now() - t0, level, msg: line });
  };

  const ctx = {
    appVersion: pkg.version,
    log: (m) => push("info", m),
    warn: (m) => push("warn", m),
    error: (m) => push("error", m),
    /** Ghi một phép kiểm tra. `opts.level:"warn"` ⇒ nếu không đạt chỉ làm trạng thái thành "warn" (cấu hình khuyến nghị) chứ không "fail". */
    check(name, ok, detail, opts = {}) {
      const pass = !!ok;
      const level = pass ? "ok" : opts.level === "warn" ? "warn" : "fail";
      if (!closed) {
        if (checks.length >= LIMITS.CHECKS) truncated = true;
        else checks.push({ name: clip(name, 200), ok: pass, level, detail: detail === undefined || detail === null ? "" : clip(detail, 300) });
      }
      push(level, `${pass ? "✔" : level === "warn" ? "⚠" : "✖"} ${name}${detail ? ` — ${detail}` : ""}`);
      return pass;
    },
    metric(name, value, unit = "") {
      if (closed || !Number.isFinite(Number(value))) return;
      if (metrics.length >= LIMITS.METRICS) {
        truncated = true;
        return;
      }
      metrics.push({ name: clip(name, 120), value: Number(value), unit: clip(unit, 20) });
      push("info", `# ${name} = ${value}${unit ? ` ${unit}` : ""}`);
    },
    skip: (reason) => ({ __status: "skip", reason: String(reason || "") }),
    manual: (steps) => ({ __status: "manual", steps: Array.isArray(steps) ? steps.slice(0, 30).map((s) => ({ title: String(s.title || ""), how: String(s.how || "") })) : [] }),
    sleep: (ms) => new Promise((r) => setTimeout(r, Math.min(Math.max(0, ms | 0), 10000))),
    hasEnv: (name) => !!process.env[name], // chỉ trả có/không — module không nên đọc giá trị bí mật
    onCleanup: (fn) => cleanups.push(fn),
    runChild: (script, args, opts) => child.runChildScript(script, args, { ...opts, onCleanup: (fn) => cleanups.push(fn) }),
    spawnServer: (opts) => child.spawnServer({ ...opts, onCleanup: (fn) => cleanups.push(fn) }),
    /** GET tới CHÍNH server này qua loopback (chỉ GET/đường dẫn tương đối). KHÔNG dùng để gửi payload có thể làm sập server — dùng spawnServer cho việc đó. */
    http: {
      get: (reqPath, { timeoutMs = 8000 } = {}) =>
        new Promise((resolve) => {
          if (typeof reqPath !== "string" || !reqPath.startsWith("/") || reqPath.length > 2000) return resolve({ error: "ĐƯỜNG DẪN KHÔNG HỢP LỆ" });
          const r = http.request({ host: "127.0.0.1", port: process.env.PORT || 8080, path: reqPath, method: "GET" }, (res) => {
            let body = "";
            res.on("data", (d) => { if (body.length < 2000) body += d; });
            res.on("end", () => resolve({ status: res.statusCode, body }));
          });
          r.on("error", (e) => resolve({ error: e.code || e.message }));
          r.setTimeout(timeoutMs, () => { r.destroy(); resolve({ error: "TIMEOUT" }); });
          r.end();
        }),
    },
    /** GET tới URL https của một host trong HTTPS_ALLOW_HOSTS (chỉ GET, không gửi header xác thực). Dùng cho module "live-safe". */
    async httpsGet(url, { timeoutMs = 8000 } = {}) {
      let u;
      try { u = new URL(url); } catch (_e) { return { error: "URL KHÔNG HỢP LỆ" }; }
      if (u.protocol !== "https:" || !HTTPS_ALLOW_HOSTS.includes(u.hostname)) return { error: `HOST KHÔNG ĐƯỢC PHÉP: ${u.hostname}` };
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(), timeoutMs);
      try {
        const res = await deps.fetch(u.toString(), { method: "GET", signal: ac.signal, redirect: "manual" });
        const body = (await res.text()).slice(0, 1000);
        return { status: res.status, body };
      } catch (e) {
        return { error: e.name === "AbortError" ? "TIMEOUT" : e.code || e.message };
      } finally {
        clearTimeout(timer);
      }
    },
  };
  return { ctx, snapshot: () => ({ logs, checks, metrics, truncated }), close: () => { closed = true; } };
}

function deepRedact(value, secrets) {
  if (typeof value === "string") return redact(value, secrets);
  if (Array.isArray(value)) return value.map((x) => deepRedact(x, secrets));
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, deepRedact(v, secrets)]));
  return value;
}

function summarize(status, checks, extra) {
  const failed = checks.filter((c) => c.level === "fail").length;
  const warned = checks.filter((c) => c.level === "warn").length;
  const total = checks.length;
  switch (status) {
    case "pass": return `${total}/${total} kiểm tra đạt`;
    case "fail": return `${failed} kiểm tra KHÔNG đạt / ${total}`;
    case "warn": return `${total - warned}/${total} đạt, ${warned} cảnh báo`;
    case "skip": return extra || "Bỏ qua";
    case "manual": return "Cần kiểm tay";
    case "timeout": return "Quá thời gian chạy";
    default: return extra || "Lỗi khi chạy";
  }
}

/**
 * Chạy một module theo id. Ném lỗi có `.status`/`.code` khi: không tồn tại (404), đang bận (409), bị tắt (403).
 * Kết quả — kể cả "fail" — là DỮ LIỆU, không phải lỗi HTTP: module không đạt nghĩa là lỗi cũ có thể đã tái xuất.
 */
async function runModule(id, { actorUid = null } = {}) {
  if (!isEnabled()) throw Object.assign(new Error("Panel Gỡ lỗi đang bị tắt (DEBUG_PANEL_ENABLED=off)."), { status: 403, code: "DEBUG_DISABLED" });
  const mod = getRegistry().byId.get(String(id));
  if (!mod) throw Object.assign(new Error("Không có module này."), { status: 404, code: "DEBUG_NOT_FOUND" });
  if (running) throw Object.assign(new Error(`Đang chạy module "${running.id}". Đợi xong rồi thử lại.`), { status: 409, code: "DEBUG_BUSY" });

  running = { id: mod.id, startedAt: Date.now() };
  const secrets = collectSecrets();
  const cleanups = [];
  const { ctx, snapshot, close } = createContext({ mod, secrets, cleanups });
  const startedAt = Date.now();
  const timeoutMs = Math.min(mod.timeoutMs || DEFAULT_TIMEOUT_MS, MAX_TIMEOUT_MS);
  let status = "pass";
  let returned = null;
  let errorMsg = "";
  let timer;
  try {
    const timeout = new Promise((_, rej) => { timer = setTimeout(() => rej(Object.assign(new Error("TIMEOUT"), { __timeout: true })), timeoutMs); });
    returned = await Promise.race([Promise.resolve().then(() => mod.run(ctx)), timeout]);
  } catch (e) {
    if (e && e.__timeout) status = "timeout";
    else {
      status = "error";
      errorMsg = redact(e && e.message ? e.message : String(e), secrets).slice(0, 300);
      ctx.error(`Lỗi khi chạy: ${errorMsg}`);
    }
  } finally {
    clearTimeout(timer);
    for (const fn of cleanups.splice(0)) {
      try { await fn(); } catch (_e) { /* dọn dẹp cố gắng hết sức */ }
    }
    running = null; // nhả khoá NGAY trong finally — dù phần xử lý kết quả bên dưới có lỗi, khoá cũng không kẹt
  }
  close();
  const { logs, checks, metrics, truncated } = snapshot();
  let extra = errorMsg;
  let steps;
  if (status === "pass") {
    if (returned && returned.__status === "skip") { status = "skip"; extra = returned.reason; }
    else if (returned && returned.__status === "manual") { status = "manual"; steps = returned.steps; }
    else if (checks.some((c) => c.level === "fail")) status = "fail";
    else if (checks.some((c) => c.level === "warn")) status = "warn";
    else if (checks.length === 0) { status = "error"; extra = "Module không ghi phép kiểm tra nào"; }
  }
  const finishedAt = Date.now();
  const result = deepRedact({
    id: mod.id,
    ...describe(mod),
    status,
    summary: summarize(status, checks, extra),
    startedAt,
    finishedAt,
    durationMs: finishedAt - startedAt,
    appVersion: pkg.version,
    checks,
    metrics,
    logs,
    steps: steps || undefined,
    reason: status === "skip" ? extra : undefined,
    truncated,
  }, secrets);
  lastResults.set(mod.id, result);
  await persist(result, actorUid);
  return result;
}

async function persist(result, actorUid) {
  try {
    const { db } = require("../config/firebase");
    await db.collection(COLLECTIONS.DEBUG_RUNS).doc(result.id).set({
      id: result.id,
      status: result.status,
      summary: result.summary,
      appVersion: result.appVersion,
      startedAt: result.startedAt,
      durationMs: result.durationMs,
      checksTotal: result.checks.length,
      checksFailed: result.checks.filter((c) => c.level === "fail").length,
      actorUid: actorUid || null,
    });
  } catch (e) {
    console.warn("[debug] không lưu được tóm tắt lần chạy:", e.message); // cố gắng hết sức — mất lịch sử không được làm hỏng kết quả
  }
}

/** Tóm tắt lần chạy gần nhất của mọi module: ưu tiên Firestore (sống qua khởi động lại), bổ sung bằng bộ nhớ. */
async function loadLastRuns() {
  const out = {};
  try {
    const { db } = require("../config/firebase");
    const snap = await db.collection(COLLECTIONS.DEBUG_RUNS).get();
    snap.docs.forEach((d) => { out[d.id] = d.data(); });
  } catch (e) {
    console.warn("[debug] không đọc được lịch sử chạy:", e.message);
  }
  for (const [id, r] of lastResults) {
    if (!out[id] || (out[id].startedAt || 0) <= r.startedAt) {
      out[id] = { id, status: r.status, summary: r.summary, appVersion: r.appVersion, startedAt: r.startedAt, durationMs: r.durationMs, checksTotal: r.checks.length, checksFailed: r.checks.filter((c) => c.level === "fail").length };
    }
  }
  return out;
}

async function listModules() {
  const reg = getRegistry();
  const last = await loadLastRuns();
  return {
    appVersion: pkg.version,
    enabled: isEnabled(),
    busy: running ? running.id : null,
    loadErrors: reg.errors.length,
    modules: reg.list.map((m) => ({ ...describe(m), lastRun: last[m.id] || null })),
  };
}

module.exports = { runModule, listModules, isEnabled, redact, collectSecrets, LIMITS, STATUSES, HTTPS_ALLOW_HOSTS, __test: { deps, lastResults, getRunning: () => running, reset: () => { running = null; lastResults.clear(); }, createContext } };
