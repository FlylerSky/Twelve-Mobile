/**
 * ==== v2.3.0 — Sổ đăng ký module "Gỡ lỗi" (hồi quy các lỗi bảo mật đã từng gặp) ====
 * Mỗi lỗi từng được ghi nhận = MỘT tệp trong `src/debug/modules/`. Thêm lỗi mới = thêm một tệp; không phải sửa chỗ nào khác (sổ này tự quét thư mục).
 * Quy ước: module chỉ được THÊM, không xoá — để mọi bản sau vẫn kiểm tra lại được lỗi cũ có tái xuất không (có test giữ quy ước, xem test/debug-230.test.js).
 *
 * Hình dạng một module:
 *   {
 *     id:          "a01-uid-crash"           chữ thường/số, nối bằng gạch ngang (là một đoạn URL của API)
 *     ref?:        "A-01"                    mã lỗi trong báo cáo kiểm tra (để đối chiếu)
 *     title:       "Tên lỗi"
 *     severity:    "high" | "medium" | "low" | "info"
 *     recordedIn:  "2.2.0"                   phiên bản ghi nhận lỗi
 *     fixedIn?:    "2.2.1" | null            phiên bản đã vá (null/thiếu = chưa vá)
 *     knownOpen?:  true                      lỗi CÒN MỞ có chủ đích — được phép không đạt (test CI bỏ qua)
 *     description: "Mô tả lỗi và cách kiểm tra"
 *     mode:        "static" | "unit" | "isolated" | "live-safe" | "manual"   (xem runner.js)
 *     timeoutMs?:  số ms, tối đa 60000
 *     run(ctx):    async — dùng ctx.check / ctx.metric / ctx.log; trả ctx.skip(lý do) hoặc ctx.manual([...]) khi không tự kiểm được
 *   }
 */
const fs = require("fs");
const path = require("path");

const MODULES_DIR = path.join(__dirname, "modules");
const ID_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const VERSION_RE = /^\d+\.\d+\.\d+(?:\.\d+)?$/;
const SEVERITIES = ["high", "medium", "low", "info"];
const MODES = ["static", "unit", "isolated", "live-safe", "manual"];
const MAX_TIMEOUT_MS = 60 * 1000;

/** So sánh hai chuỗi phiên bản theo ba số đầu (bỏ đoạn thứ tư kiểu 171026). -1 | 0 | 1. */
function compareVersions(a, b) {
  const pa = String(a).split(".").slice(0, 3).map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split(".").slice(0, 3).map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i++) {
    if (pa[i] !== pb[i]) return pa[i] < pb[i] ? -1 : 1;
  }
  return 0;
}

/** Trả về danh sách lỗi khai báo của một module (rỗng = hợp lệ). */
function validateModule(m) {
  const errs = [];
  if (!m || typeof m !== "object") return ["không phải object"];
  if (typeof m.id !== "string" || !ID_RE.test(m.id) || m.id.length > 64) errs.push("id phải là chữ thường/số nối bằng gạch ngang (≤ 64 ký tự)");
  if (m.ref !== undefined && (typeof m.ref !== "string" || m.ref.length > 20)) errs.push("ref phải là chuỗi ≤ 20 ký tự");
  if (typeof m.title !== "string" || !m.title.trim()) errs.push("thiếu title");
  if (!SEVERITIES.includes(m.severity)) errs.push(`severity phải thuộc ${SEVERITIES.join("|")}`);
  if (typeof m.recordedIn !== "string" || !VERSION_RE.test(m.recordedIn)) errs.push("recordedIn phải là số phiên bản (vd. 2.2.0)");
  if (m.fixedIn != null && (typeof m.fixedIn !== "string" || !VERSION_RE.test(m.fixedIn))) errs.push("fixedIn phải là số phiên bản hoặc null");
  if (typeof m.description !== "string" || m.description.trim().length < 20) errs.push("description quá ngắn (≥ 20 ký tự)");
  if (!MODES.includes(m.mode)) errs.push(`mode phải thuộc ${MODES.join("|")}`);
  if (typeof m.run !== "function") errs.push("run phải là hàm");
  if (m.timeoutMs !== undefined && !(Number.isFinite(m.timeoutMs) && m.timeoutMs > 0 && m.timeoutMs <= MAX_TIMEOUT_MS)) errs.push(`timeoutMs phải trong (0, ${MAX_TIMEOUT_MS}]`);
  return errs;
}

function loadFrom(dir) {
  const modules = [];
  const errors = [];
  let files = [];
  try {
    files = fs.readdirSync(dir).filter((f) => f.endsWith(".js")).sort();
  } catch (e) {
    return { modules, errors: [{ file: dir, errors: [`không đọc được thư mục: ${e.message}`] }] };
  }
  const seen = new Set();
  for (const file of files) {
    try {
      const m = require(path.join(dir, file));
      const errs = validateModule(m);
      if (!errs.length && seen.has(m.id)) errs.push(`trùng id "${m.id}"`);
      if (errs.length) {
        errors.push({ file, errors: errs });
        continue;
      }
      seen.add(m.id);
      modules.push(m);
    } catch (e) {
      errors.push({ file, errors: [`lỗi khi nạp: ${e.message}`] });
    }
  }
  return { modules, errors };
}

let cache = null;

/** Nạp lười, một lần. Module hỏng bị bỏ qua (và báo trong `errors`) — một tệp sai KHÔNG được làm hỏng cả server hay cả panel. */
function getRegistry() {
  if (!cache) {
    const { modules, errors } = loadFrom(MODULES_DIR);
    cache = { list: modules, byId: new Map(modules.map((m) => [m.id, m])), errors };
    if (errors.length) console.error("[debug] module hỏng bị bỏ qua:", JSON.stringify(errors));
  }
  return cache;
}

/** Siêu dữ liệu công khai của module (KHÔNG có hàm run). */
function describe(m) {
  return {
    id: m.id,
    ref: m.ref || null,
    title: m.title,
    severity: m.severity,
    recordedIn: m.recordedIn,
    fixedIn: m.fixedIn || null,
    knownOpen: m.knownOpen === true,
    description: m.description,
    mode: m.mode,
  };
}

module.exports = { getRegistry, describe, validateModule, loadFrom, compareVersions, ID_RE, MODES, SEVERITIES, MAX_TIMEOUT_MS, __test: { reset: () => { cache = null; }, set: (c) => { cache = c; } } };
