# Mục "Gỡ lỗi" — hồi quy các lỗi bảo mật đã từng gặp (v2.3.0)

Mỗi lỗi từng được ghi nhận = **một tệp** trong `modules/`. Panel (Cài đặt → Quản trị → Gỡ lỗi) và API tự nhận module mới — không phải sửa chỗ nào khác.

## Thêm một lỗi mới (4 bước)
1. Tạo `modules/<id>.js` (id chữ thường nối gạch ngang, vd. `a07-ten-loi`). Mẫu bên dưới.
2. Nếu cần chạy cô lập: thêm script vào `children/` (in kết quả JSON sau dấu `@@RESULT@@ `), rồi gọi `ctx.runChild("ten.js")` trong module. Có thể dùng `support/childResult.js` để chuyển kết quả thành các phép kiểm tra.
3. Thêm id vào `REQUIRED_IDS` trong `backend/test/debug-230.test.js` (từ giờ **không được xoá** module — test giữ quy ước "chỉ thêm").
4. Chạy `npm test`. Lỗi đã vá: module phải ĐẠT. Lỗi còn mở: đặt `knownOpen: true`.

```js
module.exports = {
  id: "a07-ten-loi",
  ref: "A-07",                 // mã trong báo cáo kiểm tra (tuỳ chọn)
  title: "Tên lỗi hiển thị trên panel",
  severity: "medium",          // high | medium | low | info
  recordedIn: "2.3.0",         // phiên bản GHI NHẬN lỗi
  fixedIn: "2.3.1",            // phiên bản đã vá (null nếu chưa)
  mode: "unit",                // static | unit | isolated | live-safe | manual
  description: "Mô tả lỗi và cách module kiểm tra (≥ 20 ký tự).",
  async run(ctx) {
    ctx.check("Điều phải đúng", ketQua === true, "chi tiết hiện ra khi xem");
    ctx.check("Khuyến nghị cấu hình", ok, "vì sao", { level: "warn" }); // không đạt ⇒ chỉ "Cảnh báo"
    ctx.metric("Số đo", 12.3, "ms");
    // return ctx.skip("lý do không kiểm được");        // bỏ qua (không phải "đạt")
    // return ctx.manual([{ title: "Việc", how: "Cách kiểm" }]);
  },
};
```

## Chọn `mode` thế nào
| mode | Chạy ở đâu | Dùng khi |
|---|---|---|
| `static` | tiến trình chính, chỉ đọc cấu hình | kiểm biến môi trường, lưới an toàn của tiến trình |
| `unit` | tiến trình chính, gọi **hàm thuần** | bộ lọc, hàm kiểm tra chuỗi… (không ghi dữ liệu, không đổi trạng thái toàn cục) |
| `isolated` | **tiến trình con**, Firestore/Auth giả | lỗi làm sập tiến trình, cần ghi dữ liệu thử, hoặc đụng trạng thái toàn cục trong RAM |
| `live-safe` | tiến trình chính, `ctx.httpsGet` (chỉ GET, chỉ host cho phép) | kiểm thứ nằm ngoài máy chủ (vd. rules Firestore đã deploy) |
| `manual` | không chạy gì | việc phải kiểm tay (Firebase Console, Render, trình duyệt) |

## Quy tắc an toàn (bộ chạy ép sẵn — module không phải tự lo)
- Một module chạy một lúc (409), timeout cứng (mặc định 30 s, tối đa 60 s) → kill tiến trình con.
- Log/kết quả bị che bí mật (biến môi trường kiểu SECRET/TOKEN/KEY…, khoá PEM, JWT) và cắt dung lượng.
- Tiến trình con **không thừa kế** biến môi trường của server (không có khoá Firebase/Cloudinary).
- **Không** gửi payload có thể làm sập server vào `ctx.http` (server đang phục vụ). Dùng `ctx.spawnServer()` (server.js thật trong tiến trình con) cho việc đó.
- Module không nhận mã/tham số từ client; API chỉ nhận `id`.
