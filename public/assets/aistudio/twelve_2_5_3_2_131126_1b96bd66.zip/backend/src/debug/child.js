/**
 * ==== v2.3.0 — Chạy mã kiểm tra trong TIẾN TRÌNH CON (chế độ "isolated") ====
 * Vì sao cần: nhiều lỗi cũ chỉ lộ khi nó làm CHẾT tiến trình (A-01) hoặc cần ghi dữ liệu thử (A-02) / đặt lại trạng thái toàn cục (A-05).
 * Chạy những kiểm tra đó trong tiến trình đang phục vụ người dùng là tự bắn vào chân. Ở đây mã kiểm tra chạy trong tiến trình CON với Firestore/Auth GIẢ
 * (support/fakeFirebase.js); con chết thì server cha vẫn sống.
 *
 * An toàn:
 *  - Chỉ chạy được các tệp nằm trong `src/debug/children/` (tên khớp SCRIPT_RE, tồn tại thật) — không có đường nào chạy mã/ lệnh tuỳ ý từ bên ngoài.
 *  - Tiến trình con KHÔNG thừa kế biến môi trường của server: chỉ PATH/HOME/… cho Node chạy được, `NODE_ENV=development` và vài biến do module chọn.
 *    Nên khoá Firebase/Cloudinary/secret thật không bao giờ vào tiến trình con (và không thể lọt vào log).
 *  - Có timeout cứng (SIGKILL) và giới hạn dung lượng đầu ra.
 */
const { spawn } = require("child_process");
const fs = require("fs");
const http = require("http");
const net = require("net");
const path = require("path");

const BACKEND_ROOT = path.join(__dirname, "..", "..");
const CHILDREN_DIR = path.join(__dirname, "children");
const SCRIPT_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*\.js$/;
const RESULT_MARK = "@@RESULT@@ ";
const ENV_ALLOW = ["PATH", "HOME", "TMPDIR", "TEMP", "TMP", "LANG", "LC_ALL", "SystemRoot"];
const OUT_CAP = 200 * 1024;

function buildChildEnv(extra = {}) {
  const env = {};
  for (const k of ENV_ALLOW) if (process.env[k] !== undefined) env[k] = process.env[k];
  env.NODE_ENV = "development"; // cố ý KHÔNG phải production: con dùng dữ liệu giả, không cần (và không được có) cấu hình bí mật
  env.TWELVE_DEBUG_CHILD = "1";
  for (const [k, v] of Object.entries(extra)) env[k] = String(v);
  return env;
}

function killer(cp) {
  return () => {
    try { cp.kill("SIGKILL"); } catch (_e) { /* đã chết */ }
  };
}

/**
 * Chạy một script trong children/ và đọc kết quả JSON nó in ra sau dấu `@@RESULT@@ ` (dòng cuối cùng có dấu đó).
 * @returns {Promise<{ok:boolean, timedOut:boolean, json:any, code?:number, signal?:string, stdoutTail:string, stderrTail:string}>}
 */
function runChildScript(name, args = [], { timeoutMs = 20000, env = {}, onCleanup } = {}) {
  if (typeof name !== "string" || !SCRIPT_RE.test(name)) throw new Error("tên script không hợp lệ");
  const file = path.join(CHILDREN_DIR, name);
  if (!fs.existsSync(file)) throw new Error(`không có script ${name}`);
  if (!Array.isArray(args) || args.length > 10 || args.some((a) => typeof a !== "string" || a.length > 200)) throw new Error("args không hợp lệ");

  return new Promise((resolve) => {
    const cp = spawn(process.execPath, [file, ...args], { cwd: BACKEND_ROOT, env: buildChildEnv(env), stdio: ["ignore", "pipe", "pipe"] });
    const kill = killer(cp);
    if (onCleanup) onCleanup(kill);
    let out = "";
    let err = "";
    let timedOut = false;
    let done = false;
    const timer = setTimeout(() => {
      timedOut = true;
      kill();
    }, timeoutMs);
    cp.stdout.on("data", (d) => { if (out.length < OUT_CAP) out += d; });
    cp.stderr.on("data", (d) => { if (err.length < OUT_CAP) err += d; });
    const finish = (extra) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      let json = null;
      const line = out.split("\n").reverse().find((l) => l.startsWith(RESULT_MARK));
      if (line) {
        try { json = JSON.parse(line.slice(RESULT_MARK.length)); } catch (_e) { json = null; }
      }
      resolve({ ok: !timedOut && extra.code === 0 && json !== null, timedOut, json, stdoutTail: out.slice(-2000), stderrTail: err.slice(-2000), ...extra });
    };
    cp.on("error", (e) => finish({ code: -1, spawnError: e.message }));
    cp.on("close", (code, signal) => finish({ code, signal }));
  });
}

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.on("error", reject);
    s.listen(0, "127.0.0.1", () => {
      const { port } = s.address();
      s.close(() => resolve(port));
    });
  });
}

/**
 * Khởi chạy server.js THẬT trong tiến trình con với Firestore/Auth giả (children/server-preload.js), chờ /health sẵn sàng.
 * Dùng để kiểm hành vi cấp tiến trình (sống/chết) mà không đụng dữ liệu thật. Trả về công cụ gửi request GET thô (đường dẫn không bị chuẩn hoá).
 */
async function spawnServer({ onCleanup, startupTimeoutMs = 15000, env = {} } = {}) {
  const port = await freePort();
  const cp = spawn(process.execPath, ["-r", path.join(CHILDREN_DIR, "server-preload.js"), path.join(BACKEND_ROOT, "server.js")], {
    cwd: BACKEND_ROOT,
    env: buildChildEnv({ PORT: port, SANITIZE_WORKER: "off", ...env }),
    stdio: ["ignore", "pipe", "pipe"],
  });
  const kill = killer(cp);
  if (onCleanup) onCleanup(kill);
  let log = "";
  let exit = null;
  const add = (d) => { log = (log + d).slice(-4000); };
  cp.stdout.on("data", add);
  cp.stderr.on("data", add);
  cp.on("exit", (code, signal) => { exit = { code, signal }; });

  const request = (reqPath, { timeoutMs = 4000 } = {}) =>
    new Promise((resolve) => {
      const r = http.request({ host: "127.0.0.1", port, path: reqPath, method: "GET" }, (res) => {
        res.resume();
        res.on("end", () => resolve({ status: res.statusCode }));
      });
      r.on("error", (e) => resolve({ error: e.code || e.message }));
      r.setTimeout(timeoutMs, () => {
        r.destroy();
        resolve({ error: "TIMEOUT" });
      });
      r.end();
    });

  const t0 = Date.now();
  for (;;) {
    if (exit) {
      kill();
      throw new Error(`server con thoát sớm (code ${exit.code}): ${log.slice(-300)}`);
    }
    const r = await request("/health", { timeoutMs: 800 });
    if (r.status === 200) break;
    if (Date.now() - t0 > startupTimeoutMs) {
      kill();
      throw new Error("server con không khởi động kịp");
    }
    await new Promise((res) => setTimeout(res, 150));
  }
  return { port, request, alive: () => exit === null, exitInfo: () => exit, logTail: () => log, stop: kill };
}

module.exports = { runChildScript, spawnServer, buildChildEnv, RESULT_MARK, SCRIPT_RE, __test: { CHILDREN_DIR, ENV_ALLOW } };
