const express = require("express");
const router = express.Router();
const { db, admin } = require("../config/firebase");
const { COLLECTIONS, ACCOUNT_STATUS } = require("../utils/constants");
const { attachAuthors, formatFullPost } = require("../controllers/posts.controller");
const { formatCardContent } = require("../utils/contentFormat");
const {
  registerView,
  viewerKeyFromRequest,
  computePostScore,
  syncPostScore,
  safeJsonForScript,
  canonicalUrl,
  frontendOrigin,
  lazyLoadImages,
  formatDateVi,
  toPublicProfile,
  profilePath,
  classifyProfileRef,
  isValidTagName,
} = require("../utils/helpers");
const { viewLimiter } = require("../middleware/rateLimiters");
const { canCountSsrView, isTrustedSsrProxy } = require("../utils/clientIp");
const { isHiddenDraft } = require("../utils/visibility");
const { isSafeDocId } = require("../utils/input");
const seo = require("../utils/seoMeta");
const { ensureImageAlts, loadSsrComments, sanitizeAgainForSsr } = require("../utils/ssrContent");
const { loadLivePublicUser, loadLivePublicUserByTag } = require("../services/profileLookup");
const { getUserAchievements } = require("../services/achievements");
const { resolveExtras, buildExtraFields, describeSsrExtras, SSR_EXTRA_KEYS } = require("../utils/profileExtras");

/**
 * ==== SSR cho bot/AI (SEO) ====
 *
 * v2.0.4 — vá + tái cấu trúc:
 *  - Blog NHÁP không bao giờ được render (404 như không tồn tại), kể cả ở danh sách hashtag.
 *  - View/AI-view chỉ được cộng khi request ĐÃ XÁC THỰC là từ middleware Vercel của dự án
 *    (header bí mật, xem utils/clientIp.js). Gọi thẳng backend + UA giả không còn bơm được view.
 *  - Field trạng thái tài khoản đúng là `status` (trước đây đọc nhầm `accountStatus`).
 *  - "N bài mới nhất" nay thật sự là N bài mới nhất (orderBy createdAt, có fallback khi thiếu index).
 *  - Post/Blog dùng chung 1 handler + 1 template; head/nav/CSS/danh sách tách thành partials.
 */

const LIST_SIZE = 20;
const FALLBACK_SCAN = 100;

const CONTENT_CONFIG = {
  post: {
    collection: COLLECTIONS.POSTS,
    base: "/post",
    section: { name: "Bài viết", path: "/" },
    titleSuffix: "Twelve",
    notFound: "Không tìm thấy bài viết.",
  },
  blog: {
    collection: COLLECTIONS.BLOGS,
    base: "/blog",
    section: { name: "Blog", path: "/blog" },
    titleSuffix: "Twelve Blog",
    notFound: "Không tìm thấy bài blog.",
  },
};

// ---------------------------------------------------------------- tiện ích

/** Header chẩn đoán: cho biết backend có nhận ra secret từ middleware Vercel không (không lộ secret). */
function ssrTrustHeader(req, res, next) {
  if (process.env.SSR_PROXY_SECRET) {
    res.set("X-Twelve-Ssr-Trusted", isTrustedSsrProxy(req) ? "1" : "0");
  }
  next();
}

function sendNotFound(res, message) {
  res.set("X-Robots-Tag", "noindex");
  res.set("Cache-Control", "public, max-age=60, s-maxage=60");
  return res.status(404).type("text/plain; charset=utf-8").send(message);
}

// v2.2.1 [A-01]: id có "/" (%2F) hoặc lạ không bao giờ tới Firestore — 404 như không tồn tại (HTML/text như các 404 khác của SSR).
router.param("id", (req, res, next, value) => (isSafeDocId(value) ? next() : sendNotFound(res, "Không tìm thấy nội dung.")));
// v2.4.2.1: `/u/:ref` — `ref` là "@<tag>" (Tag Name Search) hoặc (link CŨ) UID; chuỗi lạ/có "/" không bao giờ tới Firestore.
router.param("ref", (req, res, next, value) =>
  classifyProfileRef(value).kind === "tag" || isSafeDocId(value) ? next() : sendNotFound(res, "Không tìm thấy người dùng.")
);

function toMillis(ts) {
  return ts && typeof ts.toMillis === "function" ? ts.toMillis() : 0;
}

function isMissingIndexError(err) {
  return !!err && (err.code === 9 || /FAILED_PRECONDITION|requires an index/i.test(String(err.message || "")));
}

/**
 * Lấy `size` tài liệu MỚI NHẤT của một truy vấn lọc (authorUid / hashtag / isPublished…).
 * Dùng orderBy("createdAt","desc") (cần composite index — xem firestore.indexes.json). Nếu index
 * chưa được deploy: ghi cảnh báo và lùi về quét FALLBACK_SCAN tài liệu rồi sort trong bộ nhớ.
 */
async function fetchNewest(buildQuery, size = LIST_SIZE) {
  try {
    const snap = await buildQuery().orderBy("createdAt", "desc").limit(size).get();
    return snap.docs;
  } catch (err) {
    if (!isMissingIndexError(err)) throw err;
    console.warn(
      "SSR: thiếu composite index cho truy vấn 'mới nhất' — hãy `firebase deploy --only firestore:indexes`. " +
        "Tạm dùng fallback quét " + FALLBACK_SCAN + " tài liệu. Chi tiết:",
      err.message
    );
    const snap = await buildQuery().limit(FALLBACK_SCAN).get();
    return snap.docs.sort((a, b) => toMillis(b.get("createdAt")) - toMillis(a.get("createdAt"))).slice(0, size);
  }
}

/**
 * Bài/blog theo hashtag, KHÔNG phân biệt hoa/thường (v2.0.5): truy vấn `hashtagsLower` (chữ thường). Dữ liệu
 * cũ chưa backfill (`npm run hashtags:backfill:apply`) thì lùi về truy vấn khớp đúng chữ hoa/thường gốc.
 */
async function docsForHashtag(baseQuery, tag, size = LIST_SIZE) {
  const docs = await fetchNewest(() => baseQuery().where("hashtagsLower", "array-contains", tag.toLowerCase()), size);
  if (docs.length) return docs;
  return fetchNewest(() => baseQuery().where("hashtags", "array-contains", tag), size);
}

/** Query blog CHỈ lấy bài đã xuất bản. */
function publishedBlogs() {
  return db.collection(COLLECTIONS.BLOGS).where("isPublished", "==", true);
}

function toCard(item, kind) {
  const card = formatCardContent(item);
  card.url = `${CONTENT_CONFIG[kind].base}/${item.id}`;
  return card;
}

function baseLocals(res) {
  return {
    frontendBase: frontendOrigin() || "",
    formatDate: formatDateVi,
    profilePath, // v2.4.2.1: link tác giả trong view = /u/@<tag> (không còn /u/<UID>)
    safeJsonForScript,
    cspNonce: res.locals.cspNonce,
  };
}

function appLinkFor(canonical, label) {
  return { href: seo.withSpaFlag(canonical), label };
}

function sendServerError(res, label, err) {
  console.error(`SSR ${label} error:`, err);
  res.status(500).type("text/plain; charset=utf-8").send("Đã có lỗi xảy ra.");
}

// v2.5.0 [SEO] — liên kết nội bộ có anchor mô tả: mỗi trang chi tiết dẫn tới (a) bài CÙNG HASHTAG đầu tiên và (b) bài khác của TÁC GIẢ.
// Trước 2.5.0 trang SSR chỉ link tới tác giả + hashtag + 3 mục nav => bài cũ chỉ được khám phá qua sitemap. Mỗi khối ≤ RELATED_SIZE bài,
// ≤ RELATED_SIZE+1 lượt đọc Firestore (không đọc thêm hồ sơ tác giả). Lỗi/thiếu index => bỏ khối đó, KHÔNG làm hỏng trang.
const RELATED_SIZE = 5;

async function relatedByHashtag(kind, cfg, post) {
  const tag = Array.isArray(post.hashtags) && post.hashtags.length ? String(post.hashtags[0]) : null;
  if (!tag) return null;
  try {
    const base = kind === "blog" ? publishedBlogs : () => db.collection(cfg.collection);
    const docs = await docsForHashtag(base, tag, RELATED_SIZE + 1);
    const items = docs
      .filter((d) => d.id !== post.id)
      .slice(0, RELATED_SIZE)
      .map((d) => toCard({ id: d.id, ...d.data() }, kind));
    return items.length ? { heading: `Cùng chủ đề ${tag}`, items } : null;
  } catch (err) {
    console.error("SSR relatedByHashtag error:", err.message);
    return null;
  }
}

async function relatedByAuthor(kind, cfg, post, authorUid) {
  if (!authorUid || !post.author) return null;
  try {
    const base = kind === "blog" ? () => publishedBlogs().where("authorUid", "==", authorUid) : () => db.collection(cfg.collection).where("authorUid", "==", authorUid);
    const docs = await fetchNewest(base, RELATED_SIZE + 1);
    const items = docs
      .filter((d) => d.id !== post.id)
      .slice(0, RELATED_SIZE)
      .map((d) => toCard({ id: d.id, ...d.data(), author: post.author }, kind));
    return items.length ? { heading: `Bài khác của ${post.author.displayName}`, items } : null;
  } catch (err) {
    console.error("SSR relatedByAuthor error:", err.message);
    return null;
  }
}

// ------------------------------------------------- /post/:id và /blog/:id

function contentHandler(kind) {
  const cfg = CONTENT_CONFIG[kind];
  return async (req, res) => {
    try {
      const snap = await db.collection(cfg.collection).doc(req.params.id).get();
      // Blog nháp => 404 y hệt không tồn tại.
      if (!snap.exists || isHiddenDraft(cfg.collection, snap.data())) return sendNotFound(res, cfg.notFound);

      const data = snap.data();
      const [full] = await attachAuthors([data]);
      const post = formatFullPost(full);
      // v2.5.3 [TW-20]: lớp sanitize thứ hai (chỉ chạy khi HTML đã lưu có dấu hiệu nguy hiểm) — `content.ejs` in HTML thô.
      post.contentHtml = await sanitizeAgainForSsr(post.contentHtml, { id: post.id });
      // v2.5.0: ảnh trong thân bài chưa có alt => điền alt dự phòng từ tiêu đề (chỉ lúc render, không sửa dữ liệu lưu).
      post.contentHtml = ensureImageAlts(lazyLoadImages(post.contentHtml), post.title);
      const path = `${cfg.base}/${post.id}`;
      const canonical = canonicalUrl(path);

      // Chỉ cộng view/AI-view khi request đến từ middleware Vercel đã xác thực (hoặc môi trường dev).
      // registerView chạy nền (không chặn TTFB); dedup 30 phút theo IP thật vẫn áp dụng.
      const countView = canCountSsrView(req);
      if (countView) {
        registerView(db, admin, cfg.collection, req.params.id, {
          viewerKey: viewerKeyFromRequest(req),
          isAi: true,
        }).catch((err) => console.error("SSR registerView (bg) error:", err.message));
      }

      post.viewCount = data.viewCount || 0;
      post.aiViewCount = data.aiViewCount || 0;
      post.shareCount = data.shareCount || 0;
      post.postScore = computePostScore(post);
      if (countView) {
        syncPostScore(db, admin, cfg.collection, req.params.id, post.postScore, data.postScore, data.authorUid);
      }

      // v2.5.0: bình luận (≤10, chỉ tác giả active) + liên kết nội bộ chạy SONG SONG; mọi lỗi phần phụ đều bị nuốt (xem từng hàm).
      const [comments, byTag, byAuthor] = await Promise.all([
        loadSsrComments(cfg.collection, req.params.id, data.commentCount || 0),
        relatedByHashtag(kind, cfg, post),
        relatedByAuthor(kind, cfg, post, data.authorUid),
      ]);

      const locals = baseLocals(res);
      const meta = seo.buildContentMeta({
        post,
        canonicalUrl: canonical,
        frontendBase: locals.frontendBase,
        section: cfg.section,
        titleSuffix: cfg.titleSuffix,
        kind,
        comments,
      });

      res.set("Cache-Control", "public, max-age=60, s-maxage=300, stale-while-revalidate=600");
      res.render("content", {
        ...locals,
        post,
        comments,
        related: [byTag, byAuthor].filter(Boolean),
        meta,
        hashtagBaseUrl: `${canonicalUrl("/trending")}?tab=hashtag&hashtag=`,
        appLink: appLinkFor(canonical, "Mở trên Twelve (bản đầy đủ)"),
      });
    } catch (err) {
      sendServerError(res, `${cfg.base}/:id`, err);
    }
  };
}

router.get("/post/:id", ssrTrustHeader, viewLimiter, contentHandler("post"));
router.get("/blog/:id", ssrTrustHeader, viewLimiter, contentHandler("blog"));

// --------------------------------- Trang danh sách: Trang chủ và Blog

function listHandler(kind) {
  return async (req, res) => {
    try {
      const docs = await fetchNewest(
        kind === "blog" ? publishedBlogs : () => db.collection(COLLECTIONS.POSTS)
      );
      const items = await attachAuthors(docs.map((d) => ({ id: d.id, ...d.data() })));
      const cards = items.map((p) => toCard(p, kind));

      const canonical = canonicalUrl(kind === "blog" ? "/blog" : "/");
      const locals = baseLocals(res);
      const meta = seo.buildListMeta({ kind, cards, canonicalUrl: canonical, frontendBase: locals.frontendBase });

      res.set("Cache-Control", "public, max-age=120, s-maxage=300, stale-while-revalidate=900");
      res.render("list", {
        ...locals,
        meta,
        heading: kind === "blog" ? "Blog" : "Bài viết mới nhất",
        intro: meta.description,
        items: cards,
        appLink: appLinkFor(canonical, "Mở trên Twelve (bản đầy đủ)"),
      });
    } catch (err) {
      sendServerError(res, `/__ssr/${kind}`, err);
    }
  };
}

// Middleware Vercel rewrite "/" -> "/__ssr/home" và "/blog" -> "/__ssr/blog" cho bot/AI.
router.get("/__ssr/home", ssrTrustHeader, viewLimiter, listHandler("post"));
router.get("/__ssr/blog", ssrTrustHeader, viewLimiter, listHandler("blog"));

// ------------------------------------------------------------ /u/:ref
// v2.4.2.1: URL hồ sơ là /u/@<tag> (không còn /u/<UID> — dài và làm lộ UID tài khoản). "@" là bắt buộc: nó phân định tag với `/u/myProfile` và mọi route phụ về sau.
//  • `ref` = "@<tag hợp lệ>" => render hồ sơ; canonical LUÔN là /u/@<tag> chữ thường (/u/@Abc và /u/@abc cùng một trang => 301 về dạng chuẩn);
//  • `ref` = UID (link cũ đã lan truyền) => 301 sang /u/@<tag> để bot gom về URL mới; hồ sơ không có tag hợp lệ thì không có đích chuyển hướng => 404;
//  • `ref` = `myProfile` (hồ sơ của người đang đăng nhập — chỉ có nghĩa ở frontend), "@" + tag sai định dạng, hoặc tag KHÔNG có "@" (không phải URL hồ sơ) => 404.

router.get("/u/:ref", ssrTrustHeader, viewLimiter, async (req, res) => {
  try {
    const ref = classifyProfileRef(req.params.ref);
    if (ref.kind === "self" || ref.kind === "invalid") return sendNotFound(res, "Không tìm thấy người dùng.");
    let uid;
    let rawUser;

    if (ref.kind === "tag") {
      const live = await loadLivePublicUserByTag(ref.tag);
      if (!live) return sendNotFound(res, "Không tìm thấy người dùng.");
      uid = live.uid;
      rawUser = { uid, ...live.data };
      // Tên đúng nhưng viết khác (chữ hoa) => chuyển về dạng chuẩn để mỗi hồ sơ chỉ có MỘT URL.
      if (req.params.ref !== `@${ref.tag}`) {
        res.set("Cache-Control", "public, max-age=300, s-maxage=600");
        return res.redirect(301, canonicalUrl(profilePath(rawUser)));
      }
    } else {
      // Link cũ /u/<UID>: tìm hồ sơ rồi chuyển hướng vĩnh viễn sang URL tag.
      const live = await loadLivePublicUser(ref.uid);
      if (!live) return sendNotFound(res, "Không tìm thấy người dùng.");
      rawUser = { uid: ref.uid, ...live.data };
      if (!isValidTagName(rawUser.tagName)) return sendNotFound(res, "Không tìm thấy người dùng.");
      res.set("Cache-Control", "public, max-age=300, s-maxage=600");
      return res.redirect(301, canonicalUrl(profilePath(rawUser)));
    }

    // Tài khoản chưa kích hoạt / hồ sơ "ma" / đang xoá đã bị loadLivePublicUserByTag loại (404) — cùng quy tắc với API công khai.

    // v2.4.0: toPublicProfile (= toPublicUser + ảnh bìa) — ảnh bìa dùng làm og:image của hồ sơ.
    const user = toPublicProfile(rawUser); // v2.5.2: kèm `bio` (Tiểu sử)
    const isSuspended = rawUser.status === ACCOUNT_STATUS.SUSPENDED;

    // v2.5.2 — THÔNG TIN MỞ RỘNG trên SSR: chỉ các mục chủ hồ sơ BẬT và chỉ tập không nhạy cảm (SSR_EXTRA_KEYS — không có ngày sinh/giới tính/trạng thái/UID,
    // vì trang SSR được CDN/công cụ tìm kiếm giữ bản chụp lâu sau khi chủ tắt mục). Ngày tham gia cũng theo công tắc: tắt thì không in "Tham gia từ" và không có dateCreated.
    const flags = resolveExtras(rawUser.profileExtras);
    const extraFields = buildExtraFields(rawUser, flags, SSR_EXTRA_KEYS);
    user.createdAt = extraFields.createdAt || null; // v2.5.0: đã chuẩn hoá ISO (Timestamp thô in "[object Object]"); v2.5.2: null nếu chủ tắt
    let achievements = null;
    if (flags.achievements) {
      try {
        achievements = await getUserAchievements(uid, rawUser);
      } catch (err) {
        console.error("SSR /u/:ref đọc thành tích lỗi:", err.message); // không làm hỏng trang vì phần phụ
      }
    }
    const extraRows = describeSsrExtras(extraFields, achievements);

    let posts = [];
    let blogs = [];
    if (!isSuspended) {
      try {
        const docs = await fetchNewest(() =>
          db.collection(COLLECTIONS.POSTS).where("authorUid", "==", uid)
        );
        posts = docs.map((d) => toCard({ id: d.id, ...d.data(), author: user }, "post"));
      } catch (err) {
        console.error("SSR /u/:ref đọc posts lỗi:", err.message);
      }
      // v2.5.2 — tab "Blog" của hồ sơ chỉ có với tài khoản SA (nhóm quyết định, như huy hiệu — xem utils/badges.js): liệt kê Blog ĐÃ XUẤT BẢN của họ (index blogs(isPublished, authorUid, createdAt ↓)).
      if (rawUser.accountGroup === "SA") {
        try {
          const docs = await fetchNewest(() => publishedBlogs().where("authorUid", "==", uid));
          blogs = docs.map((d) => toCard({ id: d.id, ...d.data(), author: user }, "blog"));
        } catch (err) {
          console.error("SSR /u/:ref đọc blogs lỗi:", err.message);
        }
      }
    }

    // Suspended: noindex,nofollow. Hồ sơ chưa có bài/blog: noindex (tránh index hàng loạt hồ sơ rỗng), vẫn follow.
    const hasContent = posts.length > 0 || blogs.length > 0;
    const robots = isSuspended ? seo.ROBOTS_NOINDEX : hasContent ? seo.ROBOTS_INDEX : seo.ROBOTS_NOINDEX_FOLLOW;
    const canonical = canonicalUrl(profilePath(user));
    const locals = baseLocals(res);
    const meta = seo.buildProfileMeta({ user, posts, blogs, canonicalUrl: canonical, frontendBase: locals.frontendBase, robots });

    res.set("Cache-Control", "public, max-age=300, s-maxage=600, stale-while-revalidate=1800");
    res.render("profile", {
      ...locals,
      user,
      posts,
      blogs,
      extraRows,
      meta,
      appLink: appLinkFor(canonical, "Mở hồ sơ trên Twelve (bản đầy đủ)"),
    });
  } catch (err) {
    sendServerError(res, "/u/:ref", err);
  }
});

// ---------------------------------------------------------- /trending

router.get("/trending", ssrTrustHeader, viewLimiter, async (req, res) => {
  try {
    let tag = null;
    if (req.query.tab === "hashtag" && req.query.hashtag) {
      let t = String(req.query.hashtag).trim();
      if (t && !t.startsWith("#")) t = "#" + t;
      // Chuẩn hoá chữ thường: #Việt và #việt dùng CHUNG một URL canonical (trước đây là 2 URL trùng nội dung).
      if (/^#[\p{L}\p{N}_]{1,30}$/u.test(t)) tag = t.toLowerCase();
    }

    let posts = [];
    if (tag) {
      try {
        const [pDocs, bDocs] = await Promise.all([
          docsForHashtag(() => db.collection(COLLECTIONS.POSTS), tag),
          // Blog nháp KHÔNG được xuất hiện ở trang hashtag.
          docsForHashtag(publishedBlogs, tag),
        ]);
        const items = [
          ...pDocs.map((d) => ({ id: d.id, __kind: "post", ...d.data() })),
          ...bDocs.map((d) => ({ id: d.id, __kind: "blog", ...d.data() })),
        ];
        const withAuthors = items.length ? await attachAuthors(items) : [];
        withAuthors.sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
        posts = withAuthors.slice(0, LIST_SIZE).map((p) => toCard(p, p.__kind));
      } catch (err) {
        console.error("SSR /trending hashtag lỗi:", err.message);
      }
    }

    // Hashtag không có bài nào => noindex (tránh soft-404 / không gian URL vô hạn từ ?hashtag=bất-kỳ).
    const robots = tag && posts.length === 0 ? seo.ROBOTS_NOINDEX_FOLLOW : seo.ROBOTS_INDEX;
    const canonical = tag
      ? canonicalUrl(`/trending?tab=hashtag&hashtag=${encodeURIComponent(tag)}`)
      : canonicalUrl("/trending");
    const locals = baseLocals(res);
    const meta = seo.buildHashtagMeta({ tag, posts, canonicalUrl: canonical, frontendBase: locals.frontendBase, robots });

    // Hashtag không có bài: 404 thật (không chỉ noindex) để crawler không lập lại chỉ mục vô hạn URL ?hashtag=bất-kỳ.
    if (tag && posts.length === 0) res.status(404);
    res.set(
      "Cache-Control",
      tag && posts.length === 0
        ? "public, max-age=60, s-maxage=120"
        : "public, max-age=300, s-maxage=600, stale-while-revalidate=1800"
    );
    res.render("hashtag", {
      ...locals,
      tag,
      posts,
      meta,
      appLink: appLinkFor(canonical, "Mở trên Twelve (bản đầy đủ)"),
    });
  } catch (err) {
    sendServerError(res, "/trending", err);
  }
});

module.exports = router;
