const express = require("express");
const router = express.Router();
const { getRobotsTxt, getSitemapIndex, getSitemapChunk } = require("../controllers/seo.controller");

router.get("/robots.txt", getRobotsTxt);
router.get("/sitemap.xml", getSitemapIndex);
router.get(/^\/sitemap-(\d+)\.xml$/, (req, res, next) => {
  req.params.n = req.params[0];
  return getSitemapChunk(req, res, next);
});

module.exports = router;
