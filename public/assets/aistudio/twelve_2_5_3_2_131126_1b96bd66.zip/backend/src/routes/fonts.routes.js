const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/fonts.controller");

// v2.0.8 — công khai (không cần đăng nhập): danh sách font server + file font SA đã thêm.
router.get("/", ctrl.listPublicFonts);
router.get("/files/:name", ctrl.serveFontFile);

module.exports = router;
