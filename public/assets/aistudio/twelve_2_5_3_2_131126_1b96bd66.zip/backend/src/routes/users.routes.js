const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/users.controller");
const account = require("../controllers/account.controller");
const { requireAuth, requireAuthAllowPending, requireRecentAuth, optionalAuth } = require("../middleware/auth");
const upload = require("../middleware/upload");
const { updateMeValidators, realNameValidators, handleValidation } = require("../middleware/validators");
const {
  profileWriteLimiter,
  avatarUploadLimiter,
  profileReadLimiter,
  sensitiveAccountLimiter,
  accountDeleteLimiter,
  coverUploadLimiter,
  userPostsLimiter,
  visitRecordLimiter,
  profileExtrasWriteLimiter,
} = require("../middleware/rateLimiters");
const { ASSET_KIND, ASSET_LIMITS } = require("../utils/constants");
const { idParam } = require("../middleware/idParams");

// v2.2.1 [A-01]: `:uid` chỉ nhận id hợp lệ — id có "/" (%2F) trước đây làm sập tiến trình. Xem middleware/idParams.js.
router.param("uid", idParam("Không tìm thấy người dùng."));

// GET /me là endpoint DUY NHẤT còn lại (ngoài /auth/activation/sync) được phép
// dùng requireAuthAllowPending: tài khoản pending cần đọc được chính hồ sơ của
// mình (biết status pending/active) thì mới có thể tự hoàn tất kích hoạt.
// Đây là thao tác ĐỌC dữ liệu của chính chủ, không ảnh hưởng người khác.
router.get("/me", requireAuthAllowPending, ctrl.getMe);

// Mọi thao tác GHI hồ sơ (đổi tên, avatar...) đều bắt buộc tài khoản active —
// requireAuth mặc định giờ đã enforce điều đó.
// v0.9.6 [HIGH]: thêm profileWriteLimiter — xem middleware/rateLimiters.js.
router.patch("/me", requireAuth, profileWriteLimiter, updateMeValidators, handleValidation, ctrl.updateMe);

// Wrapper để bắt lỗi multer (file quá lớn / sai MIME) và trả JSON rõ ràng
function avatarUpload(req, res, next) {
  upload.single("avatar")(req, res, (err) => {
    if (err) {
      console.error("Multer avatar error:", err);
      if (err.code === "LIMIT_FILE_SIZE") {
        const maxMb = ASSET_LIMITS[ASSET_KIND.AVATAR].MAX_BYTES / (1024 * 1024);
        return res.status(400).json({ error: `Ảnh quá lớn (tối đa ${maxMb}MB).` });
      }
      if (["LIMIT_FIELD_COUNT", "LIMIT_FIELD_KEY", "LIMIT_FIELD_VALUE", "LIMIT_PART_COUNT", "LIMIT_FILE_COUNT", "LIMIT_UNEXPECTED_FILE"].includes(err.code)) {
        return res.status(400).json({ error: "Yêu cầu tải ảnh không hợp lệ." });
      }
      return res.status(400).json({ error: err.message || "File ảnh không hợp lệ." });
    }
    next();
  });
}

// v0.10.20: avatarUploadLimiter đặt TRƯỚC multer để request bị chặn không tốn RAM parse file.
router.post("/me/avatar", requireAuth, profileWriteLimiter, avatarUploadLimiter, avatarUpload, ctrl.uploadAvatar);

// ==== v2.4.0 — Ảnh bìa hồ sơ (Cài đặt > Tài khoản > Thông tin) ====
// Cùng khuôn với avatar: limiter đặt TRƯỚC multer để request bị chặn không tốn RAM parse file.
function coverUpload(req, res, next) {
  upload.cover.single("cover")(req, res, (err) => {
    if (err) {
      console.error("Multer cover error:", err);
      if (err.code === "LIMIT_FILE_SIZE") {
        const maxMb = ASSET_LIMITS[ASSET_KIND.COVER].MAX_BYTES / (1024 * 1024);
        return res.status(400).json({ error: `Ảnh quá lớn (tối đa ${maxMb}MB).` });
      }
      if (["LIMIT_FIELD_COUNT", "LIMIT_FIELD_KEY", "LIMIT_FIELD_VALUE", "LIMIT_PART_COUNT", "LIMIT_FILE_COUNT", "LIMIT_UNEXPECTED_FILE"].includes(err.code)) {
        return res.status(400).json({ error: "Yêu cầu tải ảnh không hợp lệ." });
      }
      return res.status(400).json({ error: err.message || "File ảnh không hợp lệ." });
    }
    next();
  });
}
router.post("/me/cover", requireAuth, profileWriteLimiter, coverUploadLimiter, coverUpload, ctrl.uploadCover);
router.put("/me/cover", requireAuth, profileWriteLimiter, ctrl.setCoverUrl);
// v2.4.1 — chỉnh lại khung hiển thị (kéo/thu phóng) của ảnh bìa đang có, không tải lại ảnh.
router.put("/me/cover/crop", requireAuth, profileWriteLimiter, ctrl.setCoverCrop);
router.delete("/me/cover", requireAuth, profileWriteLimiter, ctrl.removeCover);
// ==== v2.5.2 — Thông tin mở rộng (hộp "Xem thêm") + Khách ghé thăm. Đặt TRƯỚC "/:uid" để "me" không bị coi là uid. ====
// Bật/tắt từng mục hiển thị trong hộp "Xem thêm" (Cài đặt > Tài khoản > Thông tin > Thông tin mở rộng). Việc ẩn/hiện được áp dụng ở BACKEND (GET /:uid/extra-info).
router.put("/me/extras", requireAuth, profileExtrasWriteLimiter, ctrl.updateExtras);
// Khách ghé thăm hồ sơ CỦA MÌNH (chỉ chính chủ: uid lấy từ token, không nhận uid từ client).
router.get("/me/visitors", requireAuth, profileReadLimiter, ctrl.listMyVisitors);
// ==== v2.2.0 — Cài đặt > Tài khoản (đặt TRƯỚC "/:uid" để "me" không bị coi là uid) ====
// Tên thật: xem và đổi đều phải vừa nhập lại mật khẩu (requireRecentAuth — xem middleware/auth.js).
router.get("/me/real-name", requireAuth, requireRecentAuth(), sensitiveAccountLimiter, account.getRealName);
router.put("/me/real-name", requireAuth, requireRecentAuth(), sensitiveAccountLimiter, realNameValidators, handleValidation, account.updateRealName);
// Tag Name Search: đổi trong 1 transaction (khoá duy nhất). Không cần nhập lại mật khẩu.
router.put("/me/tag-name", requireAuth, sensitiveAccountLimiter, account.updateTagName);
// Xoá tài khoản: bắt buộc vừa nhập lại mật khẩu; trả 202, việc xoá chạy nền bền vững (services/accountDeletion.js).
router.post("/me/deletion", requireAuth, requireRecentAuth(), accountDeleteLimiter, account.requestAccountDeletion);

// v2.4.2.1 — hồ sơ theo Tag Name Search (URL hồ sơ là /u/@<tag>). Đặt TRƯỚC "/:uid" và "/:uid/posts" để "by-tag" không bị coi là uid.
// `:tag` được kiểm định dạng ngay trong controller (không đi qua router.param("uid")); tag sai định dạng => 404 như tag không tồn tại.
router.get("/by-tag/:tag", profileReadLimiter, ctrl.getPublicProfileByTag);
// Link cũ /u/<UID> vẫn tra được hồ sơ (frontend dùng để CHUYỂN HƯỚNG sang /u/@<tag>); các endpoint con (/posts, /pinned) vẫn theo uid vì không hiện trên thanh địa chỉ.
router.get("/:uid", profileReadLimiter, ctrl.getPublicProfile);
// v2.4.0 — tab "Bài viết" và khu "Đã ghim" của trang Profile. optionalAuth: để gắn đúng myReaction cho người đang xem (khách vẫn xem được).
router.get("/:uid/posts", optionalAuth, userPostsLimiter, ctrl.listUserPosts);
router.get("/:uid/pinned", optionalAuth, userPostsLimiter, ctrl.listPinnedPosts);
// v2.5.2 — tab "Blog" của hồ sơ (bài Blog đã xuất bản của người này) và nội dung hộp "Xem thêm".
router.get("/:uid/blogs", optionalAuth, userPostsLimiter, ctrl.listUserBlogs);
router.get("/:uid/extra-info", profileReadLimiter, ctrl.getExtraInfo);
// v2.5.2 — ghi nhận lượt ghé thăm (chỉ người đã đăng nhập; không ghi chính chủ). POST riêng, không gộp vào GET hồ sơ.
router.post("/:uid/visit", requireAuth, visitRecordLimiter, ctrl.recordProfileVisit);

module.exports = router;
