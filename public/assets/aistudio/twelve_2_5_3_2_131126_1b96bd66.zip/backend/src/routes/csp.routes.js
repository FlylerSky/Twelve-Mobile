const express = require("express");
const rateLimit = require("express-rate-limit");
const router = express.Router();
const ctrl = require("../controllers/csp.controller");
const { getClientKey } = require("../utils/clientIp");

// Báo cáo CSP: công khai nên giới hạn chặt. Khoá theo IP thật (Vercel middleware chuyển tiếp IP qua header tin cậy).
const cspReportLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 60,
  keyGenerator: (req) => `csp:${getClientKey(req)}`,
  standardHeaders: false,
  legacyHeaders: false,
  handler: (req, res) => res.status(204).end(), // không phản hồi lỗi cho trình duyệt (tránh vòng lặp báo cáo)
});

// Trình duyệt gửi `application/csp-report` (report-uri) hoặc `application/reports+json` (Reporting API).
router.post(
  "/",
  cspReportLimiter,
  express.json({ type: ["application/csp-report", "application/reports+json", "application/json"], limit: "16kb" }),
  ctrl.receiveCspReport
);

// Body sai định dạng / quá lớn: vẫn trả 204 (không lộ thông tin, không gây vòng lặp báo cáo).
router.use((err, req, res, next) => res.status(204).end());

module.exports = router;
