const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/embedDomains.controller");
const assetsCtrl = require("../controllers/assets.controller");
const fontsCtrl = require("../controllers/fonts.controller");
const cspCtrl = require("../controllers/csp.controller");
const debugCtrl = require("../controllers/debug.controller");
const configAuditCtrl = require("../controllers/configAudit.controller");
const ipTopologyCtrl = require("../controllers/ipTopology.controller");
const { requireAuth, requireActive, requireRecentAuth } = require("../middleware/auth");
const { debugRunLimiter, ipTopologyLimiter } = require("../middleware/rateLimiters");
const { requireSA } = require("../middleware/roles");

// v0.10.15 — tab "Quản trị" (Settings, chỉ SA). Mọi route trong file này bắt
// buộc SA — áp router.use() để route thêm sau này không lỡ quên gắn quyền.
router.use(requireAuth, requireActive, requireSA);

router.get("/embed-domains", ctrl.getEmbedDomainsSettings);
// v2.5.3 [TW-09]: 3 route GHI của SA (embed-domains, fonts, csp-reports) đòi nhập lại mật khẩu gần đây (requireRecentAuth → 403 REAUTH_REQUIRED) như tên thật/debug — một phiên SA bị lấy
// (máy dùng chung, token lộ) không đủ để mở rộng allowlist iframe/ảnh, thêm font ngoài hay xoá bằng chứng CSP. Mọi thay đổi còn được ghi vào nhật ký (services/configAudit.js).
router.put("/embed-domains", requireRecentAuth(), ctrl.updateEmbedDomainsSettings);
router.get("/embed-domains/rescan", ctrl.getEmbedDomainsRescanStatus);

// v0.10.20 — giám sát tài nguyên Cloudinary do người dùng upload.
router.get("/csp-reports", cspCtrl.getCspReports);
router.delete("/csp-reports", requireRecentAuth(), cspCtrl.resetCspReportsAudited);

router.get("/fonts", fontsCtrl.getFontsSettings);
router.put("/fonts", requireRecentAuth(), fontsCtrl.updateFontsSettings);

// v2.5.3 [TW-09] — nhật ký thay đổi cấu hình (chỉ đọc; chỉ SA do router.use ở trên).
router.get("/config-audit", configAuditCtrl.getConfigAudit);

// v2.5.3.2 [TW-01] — đo nhận diện IP client (chỉ đọc; chỉ SA do router.use ở trên). Xem controllers/ipTopology.controller.js.
router.get("/ip-topology", ipTopologyLimiter, ipTopologyCtrl.getIpTopology);

router.get("/assets/stats", assetsCtrl.getAssetStats);

// v2.3.0 — mục "Gỡ lỗi": hồi quy các lỗi bảo mật đã từng gặp (xem src/debug/). Chạy module đòi nhập lại mật khẩu gần đây + giới hạn tần suất.
router.get("/debug/modules", debugCtrl.getModules);
router.post("/debug/modules/:id/run", requireRecentAuth(), debugRunLimiter, debugCtrl.runOne);

module.exports = router;
