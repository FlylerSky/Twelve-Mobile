const { db } = require("../config/firebase");
const { COLLECTIONS } = require("../utils/constants");
const pkg = require("../../package.json");

/**
 * GET /api/version
 * Trả về phiên bản Backend lấy từ Firestore (config/version).
 * Phiên bản Frontend được lấy trực tiếp từ file version.json của chính frontend
 * (không qua API này) như yêu cầu trong thiết kế Menu ở trang INDEX.
 */
async function getVersion(req, res) {
  try {
    // v2.2.1 (A-07): ưu tiên biến môi trường BACKEND_VERSION — cùng nguồn với /health — để nhãn trong UI không còn lệch khi quên chạy `npm run seed:version`.
    // Không có biến thì giữ hành vi cũ (document Firestore `config/version`), cuối cùng mới tới package.json.
    let backendVersion = process.env.BACKEND_VERSION;
    if (!backendVersion) {
      const snap = await db.collection(COLLECTIONS.CONFIG).doc("version").get();
      backendVersion = snap.exists && snap.data().backend ? snap.data().backend : pkg.version || "0.1.0";
    }
    return res.json({ backend: backendVersion });
  } catch (err) {
    console.error("getVersion error:", err);
    return res.status(500).json({ error: "Không lấy được phiên bản backend." });
  }
}

module.exports = { getVersion };
