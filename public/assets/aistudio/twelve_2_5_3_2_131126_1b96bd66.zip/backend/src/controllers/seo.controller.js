const crypto = require("crypto");
const { db } = require("../config/firebase");
const { COLLECTIONS, ACCOUNT_STATUS } = require("../utils/constants");
const { isSafeDocId } = require("../utils/input");
const { frontendOrigin, canonicalUrl, profilePath, isValidTagName } = require("../utils/helpers");

/**
 * ==== robots.txt + sitemap (v2.0.4 — vá + mở rộng) ====
 *
 * Trước đây:
 *  - `/sitemap.xml?refresh=1` không cần đăng nhập, không rate-limit: mỗi lần gọi đọc tới ~20k
 *    document Firestore => ai cũng đốt được chi phí.
 *  - Cắt cứng 10.000 bài/loại, không sắp xếp (mất bài MỚI mà không báo), thiếu hồ sơ và hashtag,
 *    `lastmod` của trang tĩnh luôn là "hôm nay" (Google dần bỏ qua lastmod nếu nó sai).
 *
 * Nay:
 *  - `/sitemap.xml` là sitemap INDEX trỏ tới `/sitemap-<n>.xml` (mỗi file <= 5.000 URL, giới hạn
 *    giao thức là 50.000). Dữ liệu dựng 1 lần/giờ, "single-flight" (nhiều request đồng thời chỉ
 *    dựng 1 lần) và dùng bản cũ trong lúc dựng lại.
 *  - Ép dựng lại CHỈ khi cấu hình SITEMAP_REFRESH_TOKEN và gửi header `x-sitemap-token` khớp;
 *    tối thiểu 60 giây giữa hai lần ép. Thiếu biến môi trường = tắt hẳn.
 *  - Duyệt từ mới đến cũ (orderBy createdAt desc) với trần MAX_DOCS_PER_TYPE; vượt trần thì ghi log.
 *  - Có hồ sơ tác giả (chỉ tài khoản active có bài) và hashtag dùng >= MIN_HASHTAG_USAGE lần.
 *  - `lastmod` trang tĩnh = thời điểm nội dung mới nhất, không phải "hôm nay".
 */

const SITEMAP_TTL_MS = 60 * 60 * 1000;
const FORCED_REBUILD_MIN_GAP_MS = 60 * 1000;
const URLS_PER_SITEMAP = 5000;
const MAX_DOCS_PER_TYPE = 45000;
const MIN_HASHTAG_USAGE = 2;
const MAX_HASHTAG_URLS = 2000;
const USER_STATUS_BATCH = 300;

let cache = { chunks: null, builtAt: 0, generatedIso: null };
let building = null;
let lastForcedAt = 0;

function toMs(ts) {
  if (!ts) return 0;
  try {
    if (typeof ts.toMillis === "function") return ts.toMillis();
    const d = new Date(ts);
    return Number.isNaN(d.getTime()) ? 0 : d.getTime();
  } catch (_) {
    return 0;
  }
}
const iso = (ms) => (ms ? new Date(ms).toISOString() : null);

function escapeXml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

// v2.5.0 [SEO]: sơ đồ trang web cho HÌNH ẢNH (cẩm nang SEO — "Thêm hình ảnh... và tối ưu hoá"; Google chỉ còn dùng <image:loc>).
// Ảnh bìa bài viết/blog là URL https do người dùng dán (đã qua allowlist domain lúc lưu) — vẫn kiểm lại ở đây vì dữ liệu cũ có thể lọt qua.
function safeImageUrl(url) {
  if (typeof url !== "string") return null;
  const u = url.trim();
  if (!u || u.length > 2048 || !/^https:\/\//i.test(u) || /[\s\u0000-\u001f<>"]/.test(u)) return null;
  return u;
}

function urlEntry(loc, lastmod, imageUrl) {
  const lm = lastmod ? `<lastmod>${escapeXml(lastmod)}</lastmod>` : "";
  const img = safeImageUrl(imageUrl);
  const imgXml = img ? `<image:image><image:loc>${escapeXml(img)}</image:loc></image:image>` : "";
  return `  <url><loc>${escapeXml(loc)}</loc>${lm}${imgXml}</url>`;
}

/** Đọc tối đa MAX_DOCS_PER_TYPE tài liệu MỚI NHẤT với các field cần dùng. */
async function readNewest(query, fields, label) {
  const snap = await query.orderBy("createdAt", "desc").select(...fields).limit(MAX_DOCS_PER_TYPE).get();
  if (snap.size >= MAX_DOCS_PER_TYPE) {
    console.warn(`sitemap: ${label} đạt trần ${MAX_DOCS_PER_TYPE} — các mục cũ nhất sẽ không có trong sitemap.`);
  }
  return snap.docs;
}

// v2.4.2.1: trả Map uid -> tagName (chỉ tác giả ACTIVE) thay cho Set uid — URL hồ sơ trong sitemap là /u/@<tag>, không còn /u/<UID>.
async function activeAuthorSet(allUids) {
  const active = new Map();
  const uids = allUids.filter(isSafeDocId); // v2.5.3 [TW-14]: authorUid di trú có thể là rác — `.doc()` ném lỗi đồng bộ làm hỏng cả sitemap
  for (let i = 0; i < uids.length; i += USER_STATUS_BATCH) {
    const refs = uids.slice(i, i + USER_STATUS_BATCH).map((uid) => db.collection(COLLECTIONS.USERS).doc(uid));
    const docs = await db.getAll(...refs, { fieldMask: ["status", "tagName"] });
    docs.forEach((d) => {
      if (d.exists && d.get("status") === ACCOUNT_STATUS.ACTIVE) active.set(d.id, d.get("tagName") || "");
    });
  }
  return active;
}

async function buildChunks() {
  const entries = [];
  let newestPostMs = 0;
  let newestBlogMs = 0;
  const authors = new Map(); // uid -> lastmod ms (bài mới nhất)
  const tags = new Map(); // key(lowercase) -> { tag, count, lastMs }

  const noteTags = (list, ms) => {
    (Array.isArray(list) ? list : []).forEach((tag) => {
      if (typeof tag !== "string" || !tag) return;
      const key = tag.toLowerCase();
      const e = tags.get(key) || { tag, count: 0, lastMs: 0 };
      e.count += 1;
      if (ms > e.lastMs) e.lastMs = ms;
      tags.set(key, e);
    });
  };

  try {
    const docs = await readNewest(
      db.collection(COLLECTIONS.POSTS),
      ["updatedAt", "createdAt", "authorUid", "hashtags", "coverImageUrl"],
      "posts"
    );
    docs.forEach((doc) => {
      const d = doc.data();
      const ms = toMs(d.updatedAt) || toMs(d.createdAt);
      if (ms > newestPostMs) newestPostMs = ms;
      entries.push(urlEntry(canonicalUrl(`/post/${doc.id}`), iso(ms), d.coverImageUrl));
      if (d.authorUid && ms > (authors.get(d.authorUid) || 0)) authors.set(d.authorUid, ms);
      noteTags(d.hashtags, ms);
    });
  } catch (err) {
    console.error("sitemap: đọc posts lỗi:", err.message);
  }

  try {
    // Chỉ blog ĐÃ XUẤT BẢN (index isPublished + createdAt đã có trong firestore.indexes.json).
    const docs = await readNewest(
      db.collection(COLLECTIONS.BLOGS).where("isPublished", "==", true),
      ["updatedAt", "createdAt", "hashtags", "coverImageUrl"],
      "blogs"
    );
    docs.forEach((doc) => {
      const d = doc.data();
      const ms = toMs(d.updatedAt) || toMs(d.createdAt);
      if (ms > newestBlogMs) newestBlogMs = ms;
      entries.push(urlEntry(canonicalUrl(`/blog/${doc.id}`), iso(ms), d.coverImageUrl));
      noteTags(d.hashtags, ms);
    });
  } catch (err) {
    console.error("sitemap: đọc blogs lỗi:", err.message);
  }

  try {
    const active = await activeAuthorSet([...authors.keys()]);
    for (const [uid, ms] of authors) {
      if (!active.has(uid)) continue;
      // Tác giả không có Tag Name hợp lệ thì KHÔNG đưa vào sitemap: URL /u/<UID> chỉ còn là link chuyển hướng cũ và là thứ không được quảng bá nữa.
      if (!isValidTagName(active.get(uid))) continue;
      entries.push(urlEntry(canonicalUrl(profilePath({ uid, tagName: active.get(uid) })), iso(ms)));
    }
  } catch (err) {
    console.error("sitemap: đọc hồ sơ tác giả lỗi:", err.message);
  }

  [...tags.values()]
    .filter((t) => t.count >= MIN_HASHTAG_USAGE)
    .sort((a, b) => b.count - a.count || b.lastMs - a.lastMs)
    .slice(0, MAX_HASHTAG_URLS)
    .forEach((t) => {
      // URL canonical dùng hashtag CHỮ THƯỜNG (khớp canonical của SSR).
      const path = `/trending?tab=hashtag&hashtag=${encodeURIComponent(t.tag.toLowerCase())}`;
      entries.push(urlEntry(canonicalUrl(path), iso(t.lastMs)));
    });

  // Trang tĩnh: lastmod = lúc có nội dung mới nhất (không phải "hôm nay").
  const newestAny = Math.max(newestPostMs, newestBlogMs);
  const staticEntries = [
    urlEntry(canonicalUrl("/"), iso(newestPostMs || newestAny)),
    urlEntry(canonicalUrl("/blog"), iso(newestBlogMs || newestAny)),
    urlEntry(canonicalUrl("/trending"), iso(newestAny)),
  ];

  const all = [...staticEntries, ...entries];
  const chunks = [];
  for (let i = 0; i < all.length; i += URLS_PER_SITEMAP) {
    const body = all.slice(i, i + URLS_PER_SITEMAP).join("\n");
    chunks.push(
      '<?xml version="1.0" encoding="UTF-8"?>\n' +
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n' +
        body +
        "\n</urlset>\n"
    );
  }
  return chunks;
}

function startBuild() {
  if (!building) {
    building = buildChunks()
      .then((chunks) => {
        cache = { chunks, builtAt: Date.now(), generatedIso: new Date().toISOString() };
        return cache;
      })
      .finally(() => {
        building = null;
      });
  }
  return building;
}

function refreshAllowed(req) {
  const secret = process.env.SITEMAP_REFRESH_TOKEN;
  const provided = req.headers["x-sitemap-token"];
  if (!secret || typeof provided !== "string" || !provided) return false;
  const h = (v) => crypto.createHash("sha256").update(String(v)).digest();
  return crypto.timingSafeEqual(h(provided), h(secret));
}

async function getSitemapData(req) {
  const now = Date.now();
  if (req.query.refresh === "1" && refreshAllowed(req) && now - lastForcedAt >= FORCED_REBUILD_MIN_GAP_MS) {
    lastForcedAt = now;
    return startBuild();
  }
  if (!cache.chunks) return startBuild();
  if (now - cache.builtAt > SITEMAP_TTL_MS) {
    startBuild().catch((err) => console.error("sitemap: dựng lại nền lỗi:", err.message)); // trả bản cũ ngay
  }
  return cache;
}

async function getSitemapIndex(req, res) {
  try {
    const data = await getSitemapData(req);
    const base = frontendOrigin() || "";
    const items = data.chunks
      .map((_, i) => `  <sitemap><loc>${escapeXml(`${base}/sitemap-${i + 1}.xml`)}</loc><lastmod>${data.generatedIso}</lastmod></sitemap>`)
      .join("\n");
    res.set("Content-Type", "application/xml; charset=utf-8");
    res.set("Cache-Control", "public, max-age=600, s-maxage=3600");
    return res.send(
      '<?xml version="1.0" encoding="UTF-8"?>\n' +
        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
        items +
        "\n</sitemapindex>\n"
    );
  } catch (err) {
    console.error("getSitemapIndex error:", err);
    return res.status(500).type("text/plain").send("Sitemap temporarily unavailable.");
  }
}

async function getSitemapChunk(req, res) {
  try {
    const n = Number.parseInt(req.params.n, 10);
    const data = await getSitemapData(req);
    if (!Number.isInteger(n) || n < 1 || n > data.chunks.length) {
      return res.status(404).type("text/plain").send("Not found.");
    }
    res.set("Content-Type", "application/xml; charset=utf-8");
    res.set("Cache-Control", "public, max-age=600, s-maxage=3600");
    return res.send(data.chunks[n - 1]);
  } catch (err) {
    console.error("getSitemapChunk error:", err);
    return res.status(500).type("text/plain").send("Sitemap temporarily unavailable.");
  }
}

// v2.5.0 [SEO]: các đường dẫn KHÔNG có giá trị tìm kiếm, tránh bot tốn ngân sách thu thập:
//  - /settings, /u/myProfile: trang riêng của người đang đăng nhập (SPA, không có nội dung công khai);
//  - /csp-report: điểm nhận báo cáo CSP (POST), không phải trang.
// KHÔNG chặn /login, /register (đã noindex bằng thẻ meta — chặn robots.txt sẽ khiến Google không thấy thẻ noindex),
// KHÔNG chặn các URL chia sẻ có tham số (?idu=…, ?spa=1): chúng cần thu thập được để Google đọc rel="canonical" gom về URL chuẩn.
const ROBOTS_DISALLOW = ["/settings", "/u/myProfile", "/csp-report"];

function getRobotsTxt(req, res) {
  const base = frontendOrigin();
  const sitemapLine = base ? `Sitemap: ${base}/sitemap.xml\n` : "";
  const body =
    "User-agent: *\n" + "Allow: /\n" + ROBOTS_DISALLOW.map((p) => `Disallow: ${p}\n`).join("") + "\n" + sitemapLine;
  res.set("Content-Type", "text/plain; charset=utf-8");
  res.set("Cache-Control", "public, max-age=3600, s-maxage=86400");
  return res.send(body);
}

module.exports = { getRobotsTxt, getSitemapIndex, getSitemapChunk, __test: { buildChunks, toMs, safeImageUrl, ROBOTS_DISALLOW } };
