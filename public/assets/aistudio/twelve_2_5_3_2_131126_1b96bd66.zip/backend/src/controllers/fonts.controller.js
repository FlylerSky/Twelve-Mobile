const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { db, admin } = require("../config/firebase");
const { COLLECTIONS } = require("../utils/constants");
const configAudit = require("../services/configAudit");

/**
 * ==== v2.0.8 — Font chữ server (#1.1) ====
 *
 * SA quản lý danh sách font "chính thức" do server cung cấp (Settings > Quản trị > Font chữ trên server).
 * Mỗi font là MỘT trong hai loại nguồn:
 *   - kind "url" : link https trực tiếp tới file font ở máy chủ khác (CDN…). Trình duyệt tải thẳng từ đó.
 *   - kind "file": file font nằm trong thư mục `backend/fonts/` (được deploy cùng mã nguồn); backend phục vụ
 *                  tại GET /api/fonts/files/:name — CHỈ các file SA đã thêm vào danh sách.
 * Danh sách lưu ở Firestore: config/fonts = { fonts: [...], updatedAt }.
 * Người dùng lấy danh sách qua GET /api/fonts (công khai, cache 60 giây trong RAM + Cache-Control).
 */

const CONFIG_DOC_ID = "fonts";
const FONTS_DIR = process.env.FONTS_DIR || path.join(__dirname, "../../fonts");
const MAX_FONTS = 20;
const MAX_LABEL = 40;
const MAX_NOTE = 160;
const MAX_URL = 500;
const CACHE_MS = 60 * 1000;

const EXT_INFO = {
  woff2: { format: "woff2", mime: "font/woff2" },
  woff: { format: "woff", mime: "font/woff" },
  ttf: { format: "truetype", mime: "font/ttf" },
  otf: { format: "opentype", mime: "font/otf" },
};
const FILE_NAME_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/;
const ID_RE = /^srv-[a-z0-9-]{1,36}$/;
const WEIGHT_RE = /^[1-9]00( [1-9]00)?$/; // "400" hoặc khoảng "100 900"

function extOf(name) {
  const m = /\.([A-Za-z0-9]+)$/.exec(name || "");
  return m ? m[1].toLowerCase() : "";
}

function cleanText(value, max) {
  // eslint-disable-next-line no-control-regex
  return String(value == null ? "" : value).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
}

function isIpLiteral(host) {
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(":") || host.startsWith("[");
}

/** Kiểm tra link font trực tiếp. Trả { url, format } hoặc { error }. */
function validateFontUrl(raw) {
  const text = String(raw == null ? "" : raw).trim();
  if (!text) return { error: "Thiếu link font." };
  if (text.length > MAX_URL) return { error: `Link font dài quá ${MAX_URL} ký tự.` };
  let u;
  try {
    u = new URL(text);
  } catch (_) {
    return { error: "Link font không hợp lệ." };
  }
  if (u.protocol !== "https:") return { error: "Link font phải bắt đầu bằng https://." };
  if (u.username || u.password) return { error: "Link font không được chứa tên đăng nhập/mật khẩu." };
  const host = u.hostname.toLowerCase();
  if (!host.includes(".") || host === "localhost" || host.endsWith(".local") || host.endsWith(".internal") || isIpLiteral(host)) {
    return { error: "Link font phải dùng tên miền công khai (không dùng localhost hoặc địa chỉ IP)." };
  }
  const ext = extOf(u.pathname);
  if (host === "fonts.googleapis.com" || ext === "css") {
    return { error: "Đây là link CSS. Hãy dùng link trực tiếp tới FILE font (.woff2/.woff/.ttf/.otf), ví dụ file trên fonts.gstatic.com." };
  }
  if (ext && !EXT_INFO[ext] && /^[a-z0-9]{2,5}$/.test(ext)) {
    return { error: "Định dạng không được hỗ trợ. Dùng .woff2, .woff, .ttf hoặc .otf." };
  }
  return { url: u.toString(), format: EXT_INFO[ext] ? EXT_INFO[ext].format : null };
}

function fileExists(name) {
  try {
    return fs.statSync(path.join(FONTS_DIR, name)).isFile();
  } catch (_) {
    return false;
  }
}

function listAvailableFiles() {
  try {
    return fs
      .readdirSync(FONTS_DIR)
      .filter((n) => FILE_NAME_RE.test(n) && EXT_INFO[extOf(n)])
      .filter((n) => fileExists(n))
      .sort()
      .map((n) => ({ name: n, size: fs.statSync(path.join(FONTS_DIR, n)).size }));
  } catch (_) {
    return [];
  }
}

/** Chuẩn hoá + kiểm tra danh sách font SA gửi lên. Trả { fonts } hoặc { error }. */
function normalizeFontsInput(raw) {
  if (!Array.isArray(raw)) return { error: "Danh sách font không hợp lệ." };
  if (raw.length > MAX_FONTS) return { error: `Tối đa ${MAX_FONTS} font.` };
  const out = [];
  const ids = new Set();
  const keys = new Set();
  for (let i = 0; i < raw.length; i++) {
    const r = raw[i] || {};
    const row = `Font #${i + 1}`;
    const label = cleanText(r.label, MAX_LABEL);
    if (!label) return { error: `${row}: thiếu tên hiển thị.` };

    const kind = r.kind === "file" ? "file" : r.kind === "url" ? "url" : null;
    if (!kind) return { error: `${row}: loại nguồn phải là "url" hoặc "file".` };

    const entry = { id: "", label, kind };
    if (kind === "url") {
      const v = validateFontUrl(r.url);
      if (v.error) return { error: `${row} (${label}): ${v.error}` };
      entry.url = v.url;
      if (keys.has("u:" + v.url)) return { error: `${row} (${label}): link bị trùng với font khác.` };
      keys.add("u:" + v.url);
    } else {
      const file = String(r.file == null ? "" : r.file);
      if (!FILE_NAME_RE.test(file) || !EXT_INFO[extOf(file)]) {
        return { error: `${row} (${label}): tên file không hợp lệ (chỉ chữ/số . _ - và đuôi .woff2/.woff/.ttf/.otf).` };
      }
      if (!fileExists(file)) return { error: `${row} (${label}): file "${file}" không có trong thư mục backend/fonts trên server.` };
      entry.file = file;
      if (keys.has("f:" + file)) return { error: `${row} (${label}): file bị trùng với font khác.` };
      keys.add("f:" + file);
    }

    const weight = r.weight == null || r.weight === "" ? "100 900" : String(r.weight).trim();
    if (!WEIGHT_RE.test(weight)) return { error: `${row} (${label}): độ đậm phải dạng "400" hoặc "100 900".` };
    entry.weight = weight;

    const note = cleanText(r.note, MAX_NOTE);
    if (note) entry.note = note;

    let id = r.id == null || r.id === "" ? "" : String(r.id);
    if (id) {
      if (!ID_RE.test(id)) return { error: `${row} (${label}): mã font không hợp lệ.` };
    } else {
      do {
        id = "srv-" + crypto.randomBytes(4).toString("hex");
      } while (ids.has(id));
    }
    if (ids.has(id)) return { error: `${row} (${label}): mã font bị trùng.` };
    ids.add(id);
    entry.id = id;
    out.push(entry);
  }
  return { fonts: out };
}

/** Dạng công khai gửi cho client. File không còn trên đĩa => trả null (bị bỏ qua). */
function toPublicFont(entry) {
  if (entry.kind === "file") {
    if (!fileExists(entry.file)) return null;
    return {
      id: entry.id,
      label: entry.label,
      url: `/fonts/files/${entry.file}`, // tương đối so với API base (client ghép origin)
      relative: true,
      format: EXT_INFO[extOf(entry.file)].format,
      weight: entry.weight || "100 900",
      note: entry.note || "",
    };
  }
  const v = validateFontUrl(entry.url);
  if (v.error) return null; // dữ liệu hỏng/cũ: không bao giờ đẩy URL không hợp lệ xuống client
  return {
    id: entry.id,
    label: entry.label,
    url: v.url,
    relative: false,
    format: v.format,
    weight: entry.weight || "100 900",
    note: entry.note || "",
  };
}

let cache = { at: 0, entries: null };
function invalidateCache() {
  cache = { at: 0, entries: null };
}

async function loadEntries() {
  const now = Date.now();
  if (cache.entries && now - cache.at < CACHE_MS) return cache.entries;
  const snap = await db.collection(COLLECTIONS.CONFIG).doc(CONFIG_DOC_ID).get();
  const entries = snap.exists && Array.isArray(snap.data().fonts) ? snap.data().fonts : [];
  cache = { at: now, entries };
  return entries;
}

/** GET /api/fonts — công khai. */
async function listPublicFonts(req, res) {
  try {
    const entries = await loadEntries();
    const fonts = entries.map(toPublicFont).filter(Boolean);
    // v2.0.9: trước đây "max-age=60" khiến trình duyệt dùng lại danh sách CŨ tới 60 giây (SA vừa lưu mà
    // vẫn thấy rỗng). `no-cache` = luôn hỏi lại server (có ETag nên rất rẻ: 304 nếu không đổi); server đã tự
    // cache RAM 60 giây và vô hiệu ngay khi SA lưu.
    res.set("Cache-Control", "no-cache");
    return res.json({ fonts });
  } catch (err) {
    console.error("listPublicFonts error:", err);
    return res.status(500).json({ error: "Không tải được danh sách font." });
  }
}

/** GET /api/fonts/files/:name — chỉ phục vụ file SA đã thêm vào danh sách. */
async function serveFontFile(req, res) {
  try {
    const name = String(req.params.name || "");
    const ext = extOf(name);
    if (!FILE_NAME_RE.test(name) || !EXT_INFO[ext]) return res.status(404).end();
    const entries = await loadEntries();
    if (!entries.some((e) => e.kind === "file" && e.file === name)) return res.status(404).end();
    const abs = path.resolve(FONTS_DIR, name);
    if (path.dirname(abs) !== path.resolve(FONTS_DIR) || !fileExists(name)) return res.status(404).end();

    // Font tải bằng CORS từ origin của frontend (khác origin của backend).
    res.set("Access-Control-Allow-Origin", "*");
    res.removeHeader("Access-Control-Allow-Credentials");
    res.set("Cross-Origin-Resource-Policy", "cross-origin");
    res.set("Cache-Control", "public, max-age=86400");
    res.set("X-Content-Type-Options", "nosniff");
    res.type(EXT_INFO[ext].mime);
    return res.sendFile(abs, { dotfiles: "deny" });
  } catch (err) {
    console.error("serveFontFile error:", err);
    return res.status(500).end();
  }
}

async function adminPayload() {
  const snap = await db.collection(COLLECTIONS.CONFIG).doc(CONFIG_DOC_ID).get();
  const entries = snap.exists && Array.isArray(snap.data().fonts) ? snap.data().fonts : [];
  // v2.0.9: cho SA biết font nào ĐANG BỊ ẨN với người dùng và vì sao (trước đây ẩn im lặng).
  const rows = entries.map((e) => {
    const missing = e.kind === "file" ? !fileExists(e.file) : false;
    const visible = !!toPublicFont(e);
    let hiddenReason = null;
    if (!visible) hiddenReason = missing ? "Không tìm thấy file trong thư mục backend/fonts trên server (đã commit và deploy chưa?)." : "Dữ liệu font không hợp lệ.";
    return { ...e, fileMissing: missing, visible, hiddenReason };
  });
  return {
    fonts: rows,
    availableFiles: listAvailableFiles(),
    visibleCount: rows.filter((r) => r.visible).length,
    limits: { maxFonts: MAX_FONTS },
  };
}

/** GET /api/admin/fonts (SA) */
async function getFontsSettings(req, res) {
  try {
    return res.json(await adminPayload());
  } catch (err) {
    console.error("getFontsSettings error:", err);
    return res.status(500).json({ error: "Không tải được cấu hình font." });
  }
}

/** PUT /api/admin/fonts (SA) — thay thế toàn bộ danh sách. */
async function updateFontsSettings(req, res) {
  try {
    const { fonts, error } = normalizeFontsInput(req.body && req.body.fonts);
    if (error) return res.status(400).json({ error });
    // v2.5.3 [TW-09]: nhật ký thay đổi (ai, lúc nào, font nào thêm/bỏ/đổi nguồn) ghi CÙNG MỘT batch với cấu hình.
    const configRef = db.collection(COLLECTIONS.CONFIG).doc(CONFIG_DOC_ID);
    const beforeSnap = await configRef.get();
    const beforeFonts = beforeSnap.exists && Array.isArray(beforeSnap.data().fonts) ? beforeSnap.data().fonts : [];
    const batch = db.batch();
    batch.set(configRef, {
      fonts,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedBy: req.authUid || null,
    });
    batch.set(configAudit.newAuditRef(), configAudit.buildEntry({ action: "fonts.update", uid: req.authUid, diff: configAudit.diffFonts(beforeFonts, fonts) }));
    await batch.commit();
    invalidateCache();
    return res.json(await adminPayload());
  } catch (err) {
    console.error("updateFontsSettings error:", err);
    return res.status(500).json({ error: "Không lưu được cấu hình font." });
  }
}

module.exports = {
  listPublicFonts,
  serveFontFile,
  getFontsSettings,
  updateFontsSettings,
  __test: { validateFontUrl, normalizeFontsInput, toPublicFont, invalidateCache, FONTS_DIR },
};
