const { db } = require("../config/firebase");
const { COLLECTIONS, ACCOUNT_STATUS, ACCOUNT_GROUP } = require("../utils/constants");
const { normalizeTagName, isValidTagName, isReservedTagName, ACCOUNT_NOT_ACTIVE_BODY } = require("../utils/helpers");
const { readRealName, writeRealName } = require("../services/userPrivate");
const accountDeletion = require("../services/accountDeletion");

/**
 * ==== v2.2.0 — Cài đặt > Tài khoản ====
 * Các thao tác nhạy cảm của CHÍNH CHỦ. Route (users.routes.js) gắn: requireAuth → [requireRecentAuth] → limiter → validator → handler.
 */

// GET /api/users/me/real-name — yêu cầu vừa nhập lại mật khẩu (requireRecentAuth).
async function getRealName(req, res) {
  try {
    const fullName = await readRealName(req.authUid);
    return res.json({ fullName });
  } catch (err) {
    if (err.code === "ACCOUNT_NOT_ACTIVE") return res.status(403).json(ACCOUNT_NOT_ACTIVE_BODY);
    console.error("getRealName error:", err);
    return res.status(500).json({ error: "Không đọc được tên thật." });
  }
}

// PUT /api/users/me/real-name  body: { fullName } — yêu cầu vừa nhập lại mật khẩu.
async function updateRealName(req, res) {
  try {
    await writeRealName(req.authUid, req.body.fullName); // validator đã làm sạch + kiểm độ dài
    return res.json({ message: "Đã cập nhật tên thật." });
  } catch (err) {
    if (err.code === "ACCOUNT_NOT_ACTIVE") return res.status(403).json(ACCOUNT_NOT_ACTIVE_BODY);
    console.error("updateRealName error:", err);
    return res.status(500).json({ error: "Cập nhật tên thật thất bại." });
  }
}

/**
 * PUT /api/users/me/tag-name  body: { tagName }
 * Đổi Tag Name Search. Tag là khoá duy nhất (collection `tagNames`, doc id = tag): đặt tag mới + trả tag cũ + cập nhật hồ sơ trong
 * MỘT transaction nên không có thời điểm nào 2 người cùng giữ một tag, hay một người mất tag mà chưa có tag mới.
 * Hồ sơ/bài viết tham chiếu theo uid chứ không theo tag nên đổi tag không làm gãy liên kết nào.
 */
async function updateTagName(req, res) {
  const raw = req.body && req.body.tagName;
  if (typeof raw !== "string" || !isValidTagName(raw)) {
    return res.status(400).json({ error: "Tag Name Search không hợp lệ. Chỉ dùng chữ thường, số, gạch dưới, 3-20 ký tự." });
  }
  const next = normalizeTagName(raw);
  const uid = req.authUid;
  const prev = req.authUser.tagName || null;
  if (next === prev) return res.json({ tagName: `@${next}`, message: "Tag Name Search không thay đổi." });
  // v2.2.1 [A-04]: tag dành riêng chỉ SA được đặt (xem helpers.js#isReservedTagName).
  if (isReservedTagName(next) && req.authUser.accountGroup !== ACCOUNT_GROUP.SA) {
    return res.status(409).json({ error: "Tag Name Search này được dành riêng, vui lòng chọn tên khác." });
  }

  try {
    await db.runTransaction(async (tx) => {
      const userRef = db.collection(COLLECTIONS.USERS).doc(uid);
      const nextRef = db.collection(COLLECTIONS.TAGNAMES).doc(next);
      const prevRef = prev ? db.collection(COLLECTIONS.TAGNAMES).doc(prev) : null;
      const [userSnap, nextSnap, prevSnap] = await Promise.all([tx.get(userRef), tx.get(nextRef), prevRef ? tx.get(prevRef) : null]);

      // Đọc lại ngay trong transaction: tài khoản có thể vừa bị khoá/xoá giữa lúc requireAuth chạy và lúc này.
      if (!userSnap.exists || userSnap.data().status !== ACCOUNT_STATUS.ACTIVE) {
        throw Object.assign(new Error("ACCOUNT_NOT_ACTIVE"), { code: "ACCOUNT_NOT_ACTIVE" });
      }
      // Tag đã có người giữ (trừ khi chính uid này giữ — dữ liệu cũ lệch — thì cho dùng lại).
      if (nextSnap.exists && nextSnap.data().uid !== uid) {
        throw Object.assign(new Error("TAGNAME_TAKEN"), { code: "TAGNAME_TAKEN" });
      }
      tx.set(nextRef, { uid });
      tx.update(userRef, { tagName: next });
      if (prevSnap && prevSnap.exists && prevSnap.data().uid === uid) tx.delete(prevRef);
    });
    return res.json({ tagName: `@${next}`, message: "Đã đổi Tag Name Search." });
  } catch (err) {
    if (err.code === "TAGNAME_TAKEN") return res.status(409).json({ error: "Tag Name Search này đã có người dùng." });
    if (err.code === "ACCOUNT_NOT_ACTIVE") return res.status(403).json({ error: "Tài khoản không ở trạng thái hoạt động.", code: "ACCOUNT_NOT_ACTIVE" });
    console.error("updateTagName error:", err);
    return res.status(500).json({ error: "Đổi Tag Name Search thất bại." });
  }
}

/**
 * POST /api/users/me/deletion  body: { confirm: true }
 * Mật khẩu đã được xác nhận ở bước trước (requireRecentAuth). Ghi nhớ yêu cầu + khoá tài khoản rồi trả 202 NGAY; việc xoá chạy nền
 * (services/accountDeletion.js) — người dùng đóng trình duyệt hay mất mạng sau điểm này cũng không ảnh hưởng.
 */
async function requestAccountDeletion(req, res) {
  if (!req.body || req.body.confirm !== true) {
    return res.status(400).json({ error: "Thiếu xác nhận xoá tài khoản." });
  }
  // Chặn tài khoản quản trị tự xoá: xoá nhầm tài khoản SA cuối cùng sẽ làm mất khả năng quản trị (font, domain nhúng, CSP…).
  if (req.authUser.accountGroup === ACCOUNT_GROUP.SA) {
    return res.status(403).json({
      error: "Tài khoản quản trị (SA) không thể tự xoá. Hãy hạ quyền tài khoản này trước.",
      code: "SA_CANNOT_SELF_DELETE",
    });
  }
  try {
    await accountDeletion.requestDeletion(req.authUid);
    return res.status(202).json({
      status: "accepted",
      message: "Đã tiếp nhận yêu cầu xoá tài khoản. Dữ liệu của bạn đang được xoá và bạn sẽ bị đăng xuất.",
    });
  } catch (err) {
    if (err instanceof accountDeletion.DeletionRequestError) return res.status(err.status).json({ error: err.message, code: err.code });
    console.error("requestAccountDeletion error:", err);
    return res.status(500).json({ error: "Không gửi được yêu cầu xoá tài khoản. Vui lòng thử lại." });
  }
}

module.exports = { getRealName, updateRealName, updateTagName, requestAccountDeletion };
