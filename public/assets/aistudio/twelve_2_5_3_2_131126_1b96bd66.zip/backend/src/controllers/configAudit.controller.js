const configAudit = require("../services/configAudit");

/** GET /api/admin/config-audit (SA) — nhật ký thay đổi cấu hình, mới nhất trước (?limit=1..200, mặc định 50). v2.5.3 [TW-09]. */
async function getConfigAudit(req, res) {
  try {
    const entries = await configAudit.listRecent(req.query && req.query.limit);
    return res.json({ entries });
  } catch (err) {
    console.error("getConfigAudit error:", err && err.message);
    return res.status(500).json({ error: "Không tải được nhật ký thay đổi cấu hình." });
  }
}

module.exports = { getConfigAudit };
