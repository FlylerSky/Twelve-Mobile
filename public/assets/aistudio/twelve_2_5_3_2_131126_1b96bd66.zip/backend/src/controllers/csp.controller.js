/**
 * ==== v2.0.11 [Báo cáo bảo mật Phiên 2 — G1] Thu báo cáo vi phạm CSP của SPA ====
 *
 * SPA (Vercel) đang chạy CSP ở chế độ Report-Only. Trước đây policy KHÔNG có `report-uri` nên chẳng ai biết policy có
 * đang hoạt động đúng hay không ⇒ không có cơ sở để chuyển sang enforcing. Nay trình duyệt gửi báo cáo tới
 * `/csp-report` (Vercel middleware chuyển sang POST /api/csp-report ở đây).
 *
 * Quyết định thiết kế:
 *  - KHÔNG ghi Firestore (tránh chi phí + tránh bị bơm dữ liệu); gom thống kê trong RAM + log, đủ cho cửa sổ quan sát
 *    vài ngày. Khởi động lại server = bắt đầu lại thống kê (SA xem ở Cài đặt > Quản trị > Báo cáo CSP).
 *  - Endpoint công khai nên luôn trả 204, chặn kích thước, giới hạn tần suất theo IP, tối đa 20 báo cáo/request.
 *  - Quyền riêng tư: chỉ giữ origin + path (bỏ query/hash), blocked-uri chỉ giữ origin; không lưu IP.
 *  - Báo cáo do tiện ích trình duyệt (chrome-extension://…) sinh ra được đếm riêng, không lẫn vào danh sách cần xử lý.
 */

const crypto = require("crypto");
const { getClientKey } = require("../utils/clientIp");

const MAX_KEYS = 300;
// v2.2.1 [A-05]: chỗ dự trữ riêng cho họ `script-src`/`default-src` — chính các chỉ thị này quyết định việc bật `script-src` thật (SECURITY-STATUS G1),
// nên báo cáo nhiễu ở chỉ thị khác (img-src…) không được làm đầy bảng và che mất vi phạm script thật.
const SCRIPT_RESERVE = 50;
const SCRIPT_FAMILY = /^(script-src|script-src-elem|script-src-attr|default-src)$/;
// v2.2.2 [R-02]: `blocked-uri` do người gửi tự khai nên 50 khoá giả vẫn lấp đầy khoản dự trữ. Mỗi NGUỒN GỬI (IP, chỉ giữ dạng băm) chỉ được tạo tối đa
// MAX_NEW_KEYS_PER_REPORTER khoá MỚI trong một cửa sổ quan sát: một người gửi không thể tự mình lấp đầy bảng hay khoản dự trữ (cần ≥5 nguồn để lấp 50 chỗ,
// ≥30 nguồn để lấp 300 chỗ), và vi phạm thật — vốn đến từ NHIỀU người dùng khác nhau — được ghi nhận kèm số nguồn (`reporters`) để SA phân biệt
// với nhiễu một nguồn. Không lưu IP: chỉ băm có muối ngẫu nhiên theo tiến trình vào REPORTER_BUCKETS ô cố định (bộ nhớ không phình).
const REPORTER_BUCKETS = 4096; // 8 KB; hai nguồn trùng ô chỉ chia chung hạn mức khoá mới (vô hại)
const MAX_NEW_KEYS_PER_REPORTER = 10;
const MAX_REPORTERS_TRACKED = 20;
const MAX_REPORTS_PER_REQUEST = 20;
const MAX_LOG_PER_MINUTE = 30;

const EXTENSION_SCHEMES = /^(chrome-extension|moz-extension|safari-extension|safari-web-extension|webkit-masked-url|ms-browser-extension):/i;
const KEYWORD_BLOCKED = new Set(["inline", "eval", "data", "blob", "self", "wasm-eval", "trusted-types-policy", "trusted-types-sink", "url", "unsafe-eval", "unsafe-inline"]);

const state = { startedAt: Date.now(), total: 0, ignored: 0, dropped: 0, overflow: 0, throttled: 0 };
const reporterSalt = crypto.randomBytes(16);
const newKeysByReporter = new Uint16Array(REPORTER_BUCKETS);

function reporterBucket(ip) {
  return crypto.createHash("sha256").update(reporterSalt).update(String(ip || "")).digest().readUInt16BE(0) % REPORTER_BUCKETS;
}
const entries = new Map(); // key -> entry
let logWindowStart = 0;
let logCount = 0;

function clean(value, max) {
  // eslint-disable-next-line no-control-regex
  return String(value == null ? "" : value).replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, max);
}

/** URL tài liệu -> "origin/path" đã chuẩn hoá (id động -> :id), bỏ query/hash. */
function normalizeDocument(raw) {
  try {
    const u = new URL(String(raw));
    const parts = u.pathname.split("/").filter(Boolean);
    if (["post", "blog", "u"].includes(parts[0]) && parts.length > 1) parts[1] = ":id";
    return `${u.origin}/${parts.slice(0, 3).join("/")}`.slice(0, 200);
  } catch (_) {
    return clean(raw, 100) || "(không rõ)";
  }
}

/** blocked-uri -> từ khoá (inline/eval/…) hoặc CHỈ origin của URL bị chặn. */
function normalizeBlocked(raw) {
  const text = clean(raw, 300);
  if (!text) return { label: "(trống)", extension: false };
  if (EXTENSION_SCHEMES.test(text)) return { label: text.split("://")[0] + "://", extension: true };
  if (KEYWORD_BLOCKED.has(text.toLowerCase())) return { label: text.toLowerCase(), extension: false };
  try {
    const u = new URL(text);
    if (u.protocol === "data:" || u.protocol === "blob:") return { label: u.protocol.replace(":", ""), extension: false };
    return { label: u.origin, extension: false };
  } catch (_) {
    return { label: text.slice(0, 60), extension: false };
  }
}

/** Chuẩn hoá một báo cáo (cả định dạng report-uri lẫn Reporting API). Trả null nếu không dùng được. */
function normalizeReport(raw) {
  if (!raw || typeof raw !== "object") return null;
  let body;
  if (raw["csp-report"] && typeof raw["csp-report"] === "object") {
    const r = raw["csp-report"];
    body = {
      documentURL: r["document-uri"],
      effectiveDirective: r["effective-directive"] || r["violated-directive"],
      blockedURL: r["blocked-uri"],
      disposition: r["disposition"],
      sourceFile: r["source-file"],
      sample: r["script-sample"],
    };
  } else if (raw.type === "csp-violation" && raw.body && typeof raw.body === "object") {
    const r = raw.body;
    body = {
      documentURL: r.documentURL || raw.url,
      effectiveDirective: r.effectiveDirective || r.violatedDirective,
      blockedURL: r.blockedURL,
      disposition: r.disposition,
      sourceFile: r.sourceFile,
      sample: r.sample,
    };
  } else {
    return null;
  }
  const directive = clean(body.effectiveDirective, 40).split(" ")[0].toLowerCase();
  if (!directive || !/^[a-z-]+$/.test(directive)) return null;
  const blocked = normalizeBlocked(body.blockedURL);
  return {
    directive,
    blocked: blocked.label,
    extension: blocked.extension || EXTENSION_SCHEMES.test(clean(body.sourceFile, 200)),
    document: normalizeDocument(body.documentURL),
    disposition: clean(body.disposition, 10).toLowerCase() === "enforce" ? "enforce" : "report",
    sourceFile: body.sourceFile ? normalizeBlocked(body.sourceFile).label : "",
    sample: clean(body.sample, 80),
  };
}

function maybeLog(report, isNew) {
  if (!isNew) return;
  const now = Date.now();
  if (now - logWindowStart > 60000) {
    logWindowStart = now;
    logCount = 0;
  }
  if (logCount >= MAX_LOG_PER_MINUTE) return;
  logCount++;
  console.warn(`[CSP] ${report.directive} chặn ${report.blocked} tại ${report.document}${report.sample ? ` mẫu="${report.sample}"` : ""}`);
}

function record(report, reporter = 0) {
  state.total++;
  if (report.extension) {
    state.ignored++;
    return;
  }
  // v2.2.1 [A-05]: khoá gom theo `chỉ thị | nguồn bị chặn` (KHÔNG còn kèm đường dẫn tài liệu — giá trị đó do người gửi tự khai nên là cách rẻ nhất để
  // sinh vô hạn khoá). Trang cụ thể vẫn được ghi: `document` = trang thấy đầu tiên, `otherDocuments` = số lần thấy ở trang khác.
  const key = `${report.directive}|${report.blocked}`;
  const now = Date.now();
  let e = entries.get(key);
  if (!e) {
    // v2.2.2 [R-02]: mỗi nguồn gửi chỉ tạo được một số khoá mới nhất định (xem chú thích ở đầu tệp).
    if (newKeysByReporter[reporter] >= MAX_NEW_KEYS_PER_REPORTER) {
      state.dropped++;
      state.throttled++;
      return;
    }
    const cap = SCRIPT_FAMILY.test(report.directive) ? MAX_KEYS + SCRIPT_RESERVE : MAX_KEYS;
    if (entries.size >= cap) {
      // v2.2.1 [A-05]: bảng đầy ⇒ KHÔNG loại khoá cũ nữa (trước đây khoá lâu không thấy nhất bị đẩy ra, nên 300+ báo cáo nhiễu xoá được vi phạm thật đã ghi).
      // Báo cáo mới chỉ được cộng vào bộ đếm tràn; SA thấy `droppedKeys`/`overflow` > 0 và có thể bắt đầu lại cửa sổ quan sát.
      state.dropped++;
      state.overflow++;
      return;
    }
    newKeysByReporter[reporter]++;
    e = { directive: report.directive, blocked: report.blocked, document: report.document, otherDocuments: 0, disposition: report.disposition, sourceFile: report.sourceFile, sample: report.sample, count: 0, firstSeen: now, lastSeen: now, reporterSet: new Set() };
    entries.set(key, e);
    maybeLog(report, true);
  } else if (e.document !== report.document) {
    e.otherDocuments = (e.otherDocuments || 0) + 1;
  }
  e.count++;
  e.lastSeen = now;
  if (e.reporterSet.size < MAX_REPORTERS_TRACKED) e.reporterSet.add(reporter); // số nguồn gửi khác nhau (xấp xỉ, tối đa 20)
}

/** POST /api/csp-report — công khai, luôn 204. */
function receiveCspReport(req, res) {
  try {
    const body = req.body;
    const list = Array.isArray(body) ? body : body ? [body] : [];
    // IP thật của người gửi: request đi qua middleware Vercel mang IP thật trong `x-twelve-client-ip` (chỉ tin khi có SSR_PROXY_SECRET khớp) — cùng nguồn
    // với `cspReportLimiter`. Nếu SSR_PROXY_SECRET CHƯA cấu hình ở production thì mọi báo cáo từ Vercel nhìn như một nguồn duy nhất và hạn mức khoá mới
    // (MAX_NEW_KEYS_PER_REPORTER) bị dùng chung — hãy đặt SSR_PROXY_SECRET (cùng giá trị ở Render và Vercel).
    const reporter = reporterBucket(getClientKey(req.headers ? req : { ...req, headers: {} }));
    for (const raw of list.slice(0, MAX_REPORTS_PER_REQUEST)) {
      const report = normalizeReport(raw);
      if (report) record(report, reporter);
    }
  } catch (err) {
    console.error("receiveCspReport error:", err.message);
  }
  return res.status(204).end();
}

/** GET /api/admin/csp-reports (SA) */
function getCspReports(req, res) {
  const list = [...entries.values()]
    .sort((a, b) => b.count - a.count || b.lastSeen - a.lastSeen)
    .slice(0, 100)
    .map(({ reporterSet, ...rest }) => ({ ...rest, reporters: reporterSet ? reporterSet.size : 0 })); // reporters = số nguồn gửi khác nhau (nhiễu thường chỉ 1)
  return res.json({
    startedAt: state.startedAt,
    total: state.total,
    ignoredExtensions: state.ignored,
    droppedKeys: state.dropped,
    overflow: state.overflow, // báo cáo bị bỏ vì bảng đầy (v2.2.1) — > 0 nghĩa là có thể đang bị bơm nhiễu hoặc cần bắt đầu lại cửa sổ quan sát
    throttled: state.throttled, // báo cáo bị bỏ vì MỘT nguồn gửi tạo quá nhiều khoá mới (v2.2.2) — dấu hiệu bơm nhiễu từ một nguồn
    uniqueViolations: entries.size,
    entries: list,
  });
}

/** DELETE /api/admin/csp-reports (SA) — bắt đầu lại cửa sổ quan sát. */
function resetCspReports(req, res) {
  entries.clear();
  state.startedAt = Date.now();
  state.total = 0;
  state.ignored = 0;
  state.dropped = 0;
  state.overflow = 0;
  state.throttled = 0;
  newKeysByReporter.fill(0);
  return res.json({ ok: true });
}

/**
 * v2.5.3 [TW-09]: DELETE /api/admin/csp-reports — xoá bảng báo cáo CSP = xoá "bằng chứng", nên ghi nhật ký (ai, lúc nào, đã xoá bao nhiêu) TRƯỚC khi xoá;
 * ghi nhật ký thất bại ⇒ 500 và KHÔNG xoá. `resetCspReports` (đồng bộ) giữ nguyên cho test/nội bộ.
 */
async function resetCspReportsAudited(req, res) {
  try {
    // Nạp muộn: controller này được nhiều test nạp mà không cần Firestore.
    await require("../services/configAudit").record({ action: "csp-reports.reset", uid: req.authUid, diff: { clearedTotal: state.total, clearedKeys: entries.size, since: state.startedAt } });
  } catch (err) {
    console.error("resetCspReportsAudited: không ghi được nhật ký:", err && err.message);
    return res.status(500).json({ error: "Không ghi được nhật ký thay đổi nên chưa đặt lại. Vui lòng thử lại." });
  }
  return resetCspReports(req, res);
}

module.exports = { receiveCspReport, getCspReports, resetCspReports, resetCspReportsAudited, __test: { normalizeReport, entries, state, reset: resetCspReports, reporterBucket } };
