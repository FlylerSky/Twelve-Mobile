const { db, admin } = require("../config/firebase");
const { COLLECTIONS } = require("../utils/constants");
const { processContentHtml, sendContentError } = require("../services/contentPipeline");
const { attachAuthors } = require("../utils/authors");
const { isHiddenDraft, canViewDraft } = require("../utils/visibility");
const { purgeContentSubcollections } = require("../utils/cascade");
const { parseLimit, parseCursor, stripBidiAndInvisible } = require("../utils/input");
const { toHashtagsLower } = require("../utils/helpers");
const { formatCardContent } = require("../utils/contentFormat");
const { getMyReaction, getMyReactionsById } = require("../utils/myReactions");
const { registerView, parseShareQuery, registerShare, viewerKeyFromRequest, computePostScore, syncPostScore, syncPostScoresBatch, postsScoreSumWrite, reconcilePostsScoreSum, positiveScoreWrite, positiveScoreLogWrite, validateTitle, validateCoverImageUrl, validateHashtags, assertActorActive, ACCOUNT_NOT_ACTIVE_BODY } = require("../utils/helpers");

const FieldValue = admin.firestore.FieldValue;

/**
 * POST /api/blogs  (chỉ SA)
 */
async function createBlog(req, res) {
  try {
    const { title, contentHtml, coverImageUrl, hashtags } = req.body;
    if (!title || !contentHtml) {
      return res.status(400).json({ error: "Cần có tiêu đề và nội dung bài blog." });
    }
    // v0.9.6 [MEDIUM]: title trước đây không giới hạn độ dài tối đa.
    const titleErr = validateTitle(title);
    if (titleErr) return res.status(400).json({ error: titleErr });
    const coverErr = validateCoverImageUrl(coverImageUrl);
    if (coverErr) return res.status(400).json({ error: coverErr });
    // v0.9.7 — hashtag bài blog
    const { error: hashtagErr, hashtags: cleanHashtags } = validateHashtags(hashtags);
    if (hashtagErr) return res.status(400).json({ error: hashtagErr });

    // v2.0.10 [BẢO MẬT F1]: kiểm tra giới hạn + sanitize ở worker có timeout (không chặn event loop).
    const { html: cleanHtml, excerpt: cleanExcerpt } = await processContentHtml(contentHtml);
    const ref = db.collection(COLLECTIONS.BLOGS).doc();

    const blogData = {
      id: ref.id,
      authorUid: req.authUid,
      title: stripBidiAndInvisible(title).trim(),
      contentHtml: cleanHtml,
      excerpt: cleanExcerpt,
      coverImageUrl: coverImageUrl || null,
      // v0.9.7 — hashtag bài blog, dạng ["#tag1", "#tag2"], tối đa 20 tag.
      hashtags: cleanHashtags,
      hashtagsLower: toHashtagsLower(cleanHashtags),
      likeCount: 0,
      dislikeCount: 0,
      commentCount: 0,
      viewCount: 0,
      aiViewCount: 0,
      shareCount: 0,
      postScore: 0,
      // ==== v0.8.25 [CRITICAL] ====
      // externalPostScore: chỉ tính điểm từ tương tác của NGƯỜI KHÁC tác giả.
      externalPostScore: 0,
      isPublished: true,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    };

    // ĐIỂM TÍCH CỰC (v0.8.17): +1 cho tác giả (SA) khi đăng blog — cùng quy
    // tắc "đăng bài" áp dụng cho posts, ghi atomic bằng batch — xem giải
    // thích chi tiết ở posts.controller.js#createPost.
    // v2.2.1 [A-02]: batch -> transaction có kiểm tra tác giả còn active (xem posts.controller.js#createPost).
    const pw = positiveScoreWrite(db, admin, req.authUid, 1);
    // AUDIT LOG (v0.8.25): ghi lại chi tiết lần cộng điểm khi đăng blog
    const lw = positiveScoreLogWrite(db, admin, req.authUid, 1, "create_blog", {
      collection: COLLECTIONS.BLOGS,
      docId: ref.id,
    });
    await db.runTransaction(async (tx) => {
      await assertActorActive(tx, db, req.authUid);
      tx.set(ref, blogData);
      if (pw) tx.set(pw.ref, pw.data, { merge: true });
      if (lw) tx.set(lw.ref, lw.data);
    });

    return res.status(201).json({ message: "Đăng bài blog thành công.", blogId: ref.id });
  } catch (err) {
    if (err && err.code === "ACCOUNT_NOT_ACTIVE") return res.status(403).json(ACCOUNT_NOT_ACTIVE_BODY);
    if (sendContentError(res, err)) return;
    console.error("createBlog error:", err);
    return res.status(500).json({ error: "Đăng bài blog thất bại." });
  }
}

/**
 * GET /api/blogs?cursor=&limit=
 * Công khai — ai cũng xem được danh sách blog (chỉ SA mới đăng/sửa/xóa được).
 */
async function listBlogs(req, res) {
  try {
    // v2.0.10 [F8]: limit/cursor sai kiểu (âm, mảng, chứa "/") trước đây làm Firestore ném lỗi => 500.
    const limit = parseLimit(req.query.limit, 10, 30);
    const cursorParsed = parseCursor(req.query.cursor);
    if (!cursorParsed.ok) return res.status(400).json({ error: "Tham số cursor không hợp lệ." });
    let query = db
      .collection(COLLECTIONS.BLOGS)
      .where("isPublished", "==", true)
      .orderBy("createdAt", "desc")
      .limit(limit);

    if (cursorParsed.value) {
      const cursorSnap = await db.collection(COLLECTIONS.BLOGS).doc(cursorParsed.value).get();
      if (cursorSnap.exists) query = query.startAfter(cursorSnap);
    }

    const snap = await query.get();
    const blogs = await attachAuthors(snap.docs.map((d) => d.data()));

    // v0.8.18: xem giải thích chi tiết ở posts.controller.js#listPosts —
    // cùng lỗi/cùng cách vá, chỉ khác collection.
    const myReactionByBlogId = await getMyReactionsById(COLLECTIONS.BLOGS, blogs.map((b) => b.id), req.authUid);

    const formatted = blogs.map((b) => ({
      ...formatCardContent(b),
      myReaction: myReactionByBlogId[b.id] || null,
    }));

    // Đồng bộ cache postScore (song song, không chặn response) — xem
    // utils/helpers.js#syncPostScoresBatch.
    syncPostScoresBatch(
      db,
      admin,
      COLLECTIONS.BLOGS,
      blogs.map((b, i) => ({ id: b.id, score: formatted[i].postScore, storedScore: b.postScore, authorUid: b.authorUid }))
    );

    return res.json({
      blogs: formatted,
      nextCursor: snap.docs.length ? snap.docs[snap.docs.length - 1].id : null,
    });
  } catch (err) {
    console.error("listBlogs error:", err);
    return res.status(500).json({ error: "Không tải được danh sách blog." });
  }
}

/**
 * GET /api/blogs/:id  -> dùng chung trang POST để hiển thị (SSR ở route riêng, xem views/post.ejs)
 */
async function getBlog(req, res) {
  try {
    const snap = await db.collection(COLLECTIONS.BLOGS).doc(req.params.id).get();
    if (!snap.exists) return res.status(404).json({ error: "Không tìm thấy bài blog." });

    const blogData = snap.data();

    // v2.0.4 [BẢO MẬT]: blog nháp chỉ tác giả/SA xem được; người khác nhận 404
    // y hệt blog không tồn tại (không lộ việc id này có thật).
    const isDraft = isHiddenDraft(COLLECTIONS.BLOGS, blogData);
    if (isDraft && !canViewDraft(req, blogData)) {
      return res.status(404).json({ error: "Không tìm thấy bài blog." });
    }

    const [full] = await attachAuthors([blogData]);

    // Tính VIEW: chỉ khi xem trang blog chi tiết mới tính, giống cơ chế ở
    // posts.controller.getPost — mọi đối tượng xem đều được tính (kể cả khách
    // chưa đăng nhập, route dùng optionalAuth). Chống bơm view ảo (vá báo cáo
    // bảo mật #5) bằng dedupe theo viewerKey, xem utils/helpers.js#registerView.
    // Bản nháp (chỉ tác giả/SA xem trước) KHÔNG được cộng view/share.
    const viewCounted = isDraft
      ? false
      : await registerView(db, admin, COLLECTIONS.BLOGS, req.params.id, {
          viewerKey: viewerKeyFromRequest(req),
          isAi: false,
          viewerUid: req.authUid || null,
          authorUid: blogData.authorUid,
        });

    // Tính SHARE: xem giải thích chi tiết ở posts.controller.js#getPost.
    const { isShareLink, rawSharerUid, signature } = parseShareQuery(req.query);
    let shareCounted = false;
    if (isShareLink && !isDraft) {
      const shareResult = await registerShare(db, admin, COLLECTIONS.BLOGS, req.params.id, {
        rawSharerUid,
        signature,
        authorUid: blogData.authorUid,
        source: "web",
        viewerKey: viewerKeyFromRequest(req),
        viewerUid: req.authUid || null,
      });
      shareCounted = shareResult.counted;
    }

    const finalBlog = {
      ...full,
      viewCount: (blogData.viewCount || 0) + (viewCounted ? 1 : 0),
      aiViewCount: blogData.aiViewCount || 0,
      shareCount: (blogData.shareCount || 0) + (shareCounted ? 1 : 0),
    };
    // postScore PHẢI tính SAU khi đã gán view/share mới nhất ở trên — xem
    // giải thích chi tiết ở posts.controller.js#getPost.
    finalBlog.postScore = computePostScore(finalBlog);
    // Đồng bộ cache trong Firestore (song song, không chặn response).
    syncPostScore(db, admin, COLLECTIONS.BLOGS, req.params.id, finalBlog.postScore, blogData.postScore, blogData.authorUid);

    // v2.0.0: trước đây getBlog KHÔNG trả myReaction (khác getPost) nên trang chi
    // tiết Blog luôn hiện nút Like/Dislike "chưa bấm" sau khi tải lại.
    const myReaction = await getMyReaction(COLLECTIONS.BLOGS, req.params.id, req.authUid);

    return res.json({ blog: finalBlog, myReaction });
  } catch (err) {
    console.error("getBlog error:", err);
    return res.status(500).json({ error: "Không tải được bài blog." });
  }
}

/**
 * PATCH /api/blogs/:id (chỉ SA)
 */
async function updateBlog(req, res) {
  try {
    const ref = db.collection(COLLECTIONS.BLOGS).doc(req.params.id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ error: "Không tìm thấy bài blog." });

    const updates = { updatedAt: FieldValue.serverTimestamp() };
    if (req.body.title) {
      const titleErr = validateTitle(req.body.title);
      if (titleErr) return res.status(400).json({ error: titleErr });
      updates.title = stripBidiAndInvisible(req.body.title).trim();
    }
    if (req.body.contentHtml) {
      const processed = await processContentHtml(req.body.contentHtml);
      updates.contentHtml = processed.html;
      updates.excerpt = processed.excerpt;
    }
    if (req.body.coverImageUrl !== undefined) {
      const coverErr = validateCoverImageUrl(req.body.coverImageUrl, snap.data().coverImageUrl || null);
      if (coverErr) return res.status(400).json({ error: coverErr });
      updates.coverImageUrl = req.body.coverImageUrl || null;
    }
    if (req.body.hashtags !== undefined) {
      const { error: hashtagErr, hashtags: cleanHashtags } = validateHashtags(req.body.hashtags);
      if (hashtagErr) return res.status(400).json({ error: hashtagErr });
      updates.hashtags = cleanHashtags;
      updates.hashtagsLower = toHashtagsLower(cleanHashtags);
    }
    if (req.body.isPublished !== undefined) updates.isPublished = !!req.body.isPublished;

    await ref.update(updates);
    return res.json({ message: "Cập nhật bài blog thành công." });
  } catch (err) {
    if (sendContentError(res, err)) return;
    console.error("updateBlog error:", err);
    return res.status(500).json({ error: "Cập nhật thất bại." });
  }
}

/**
 * DELETE /api/blogs/:id (chỉ SA)
 */
async function deleteBlog(req, res) {
  try {
    const ref = db.collection(COLLECTIONS.BLOGS).doc(req.params.id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ error: "Không tìm thấy bài blog." });

    // Xoá bài + trừ đúng phần đóng góp khỏi postsScoreSum của tác giả — xem
    // giải thích chi tiết ở posts.controller.js#deletePost.
    let deletedAuthorUid = null;
    await db.runTransaction(async (tx) => {
      const freshSnap = await tx.get(ref);
      if (!freshSnap.exists) return;

      const freshData = freshSnap.data();
      const currentScore = computePostScore(freshData);
      // ==== VÁ v0.8.25 [CRITICAL] — Chống farm điểm qua postsScoreSum ====
      // Khi xoá blog, trừ đúng `externalPostScore` (chỉ điểm từ người khác)
      // khỏi postsScoreSum.
      const externalScoreToRemove = freshData.externalPostScore || 0;

      tx.delete(ref);

      const w = postsScoreSumWrite(db, admin, freshData.authorUid, -externalScoreToRemove);
      if (w) tx.set(w.ref, w.data, { merge: true });
      deletedAuthorUid = freshData.authorUid;

      // ĐIỂM TÍCH CỰC (v0.8.17): -1 cho tác giả khi xoá blog — xem
      // posts.controller.js#deletePost.
      const pw = positiveScoreWrite(db, admin, freshData.authorUid, -1);
      if (pw) tx.set(pw.ref, pw.data, { merge: true });
      // AUDIT LOG (v0.8.25): ghi lại chi tiết lần trừ điểm khi xoá blog
      const lw = positiveScoreLogWrite(db, admin, freshData.authorUid, -1, "delete_blog", {
        collection: COLLECTIONS.BLOGS,
        docId: req.params.id,
      });
      if (lw) tx.set(lw.ref, lw.data);
    });

    // v0.8.14: đối soát lại bằng aggregation query — xem
    // posts.controller.js#deletePost.
    if (deletedAuthorUid) {
      reconcilePostsScoreSum(db, admin, deletedAuthorUid).catch(() => {});
      purgeContentSubcollections(db, ref); // v2.0.5: dọn comments/views/reactions (nền)
    }

    return res.json({ message: "Đã xóa bài blog." });
  } catch (err) {
    console.error("deleteBlog error:", err);
    return res.status(500).json({ error: "Xóa thất bại." });
  }
}

module.exports = { createBlog, listBlogs, getBlog, updateBlog, deleteBlog };
