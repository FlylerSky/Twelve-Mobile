const { db, admin } = require("../config/firebase");
const { COLLECTIONS } = require("../utils/constants");
const {
  setEmbedDomainsConfig,
  getEmbedDomainsConfig,
  DEFAULT_EMBED_DOMAINS,
} = require("../services/sanitize.service");
const { processContentHtml } = require("../services/contentPipeline");
const configAudit = require("../services/configAudit");

const FieldValue = admin.firestore.FieldValue;
const CONFIG_DOC_ID = "embedDomains";

/**
 * ==== v0.10.15 — tab "Quản trị" (Settings, chỉ SA) — quản lý domain nhúng
 * media của bài viết/blog ====
 *
 * Doc Firestore `config/embedDomains`:
 *   { enabled: boolean, domains: [{ domain, path, label }], updatedAt, updatedByUid }
 *
 * `enabled: false` = chặn TOÀN BỘ media có domain-allowlist — không có
 * ngoại lệ, bất kể `domains` còn gì.
 *
 * ==== v0.10.16 — thêm `path` (tuỳ chọn) cho mỗi domain, áp dụng cho TẤT CẢ
 * media (không riêng iframe nữa — xem docblock "VÁ v0.10.16" trong
 * sanitize.service.js) ====
 * SA có thể nhập "domain/path" (vd. "res.cloudinary.com/dk7xohrrk") để CHỈ
 * cho phép đúng 1 thư mục/cloud cụ thể dưới domain đó — không phải toàn bộ
 * domain. `path` rỗng (chỉ nhập domain thuần) = không giới hạn, hành vi y
 * hệt trước bản vá.
 */

const MAX_DOMAINS = 50;
const DOMAIN_RE = /^(?!-)[a-z0-9-]{1,63}(?:\.[a-z0-9-]{1,63})+$/; // ví dụ hợp lệ: "youtube.com", "player.vimeo.com" — không cho phép scheme/khoảng trắng
const MAX_PATH_LEN = 200;
// Mỗi SEGMENT của path chỉ chấp nhận ký tự an toàn thường gặp trong URL
// (không "?", "#", "*", khoảng trắng, hay ký tự đặc biệt khác) — path phân
// biệt hoa/thường (khác domain), giữ NGUYÊN chữ hoa/thường SA nhập.
const PATH_SEGMENT_RE = /^[a-zA-Z0-9._~%-]+$/;

// ==== VÁ v0.10.18 [LOW — báo cáo bảo mật L-7] chặn "suffix công cộng" ====
// `hostnameMatchesDomain()` chấp nhận MỌI subdomain của 1 domain trong danh
// sách. Nếu SA lỡ thêm 1 suffix dùng chung (`github.io`, `vercel.app`,
// `com.vn`...) thì MỌI người dùng của dịch vụ đó (mỗi người 1 subdomain
// riêng) đều trở thành nguồn được tin cậy — kể cả kẻ tấn công tự đăng ký 1
// subdomain. Path-scoping KHÔNG cứu được trường hợp này (path áp cho mọi
// subdomain). Từ chối luôn ở bước lưu; SA phải nhập subdomain cụ thể
// (vd. `ten-ban.github.io`). Danh sách dưới đây là các dịch vụ hosting
// nhiều-người-dùng phổ biến (không thể đầy đủ tuyệt đối) + heuristic ccSLD.
const PUBLIC_SUFFIXES = new Set([
  "github.io", "githubusercontent.com", "gitlab.io", "bitbucket.io",
  "vercel.app", "now.sh", "netlify.app", "pages.dev", "workers.dev",
  "web.app", "firebaseapp.com", "appspot.com", "herokuapp.com", "onrender.com",
  "fly.dev", "railway.app", "glitch.me", "repl.co", "replit.app", "replit.dev",
  "blogspot.com", "wordpress.com", "wixsite.com", "weebly.com", "webflow.io",
  "notion.site", "carrd.co", "neocities.org", "itch.io", "surge.sh",
  "azurewebsites.net", "azurestaticapps.net", "cloudfront.net", "amazonaws.com",
  "s3.amazonaws.com", "ngrok.io", "ngrok-free.app", "trycloudflare.com",
  "duckdns.org", "no-ip.org", "ddns.net", "000webhostapp.com", "supabase.co",
]);
const GENERIC_SLD_LABELS = new Set([
  "co", "com", "net", "org", "gov", "edu", "ac", "or", "ne", "go", "gr", "ltd", "plc", "sch", "mil", "info",
]);

function isPublicSuffix(domain) {
  if (PUBLIC_SUFFIXES.has(domain)) return true;
  const labels = domain.split(".");
  // ccSLD kiểu "com.vn", "co.uk", "com.au", "co.jp", "ne.jp"...
  return labels.length === 2 && GENERIC_SLD_LABELS.has(labels[0]) && labels[1].length === 2;
}

function splitDomainAndPath(withoutScheme) {
  const slashIdx = withoutScheme.indexOf("/");
  if (slashIdx === -1) return { domainPart: withoutScheme, pathPart: "" };
  return { domainPart: withoutScheme.slice(0, slashIdx), pathPart: withoutScheme.slice(slashIdx + 1) };
}

function normalizeDomainsInput(rawDomains) {
  if (!Array.isArray(rawDomains)) return { error: "Danh sách domain phải là 1 mảng." };
  if (rawDomains.length > MAX_DOMAINS) return { error: `Tối đa ${MAX_DOMAINS} domain.` };

  const seen = new Set();
  const domains = [];
  for (const raw of rawDomains) {
    const inputRaw = typeof raw === "string" ? raw : raw && raw.domain;
    if (typeof inputRaw !== "string") return { error: "Mỗi domain phải là chuỗi ký tự." };

    // Tách domain/path TRÊN CHUỖI GỐC (chưa lowercase) — path cần giữ đúng
    // chữ hoa/thường, chỉ domain mới hạ về chữ thường.
    const withoutScheme = inputRaw.trim().replace(/^https?:\/\//i, "");
    const { domainPart, pathPart } = splitDomainAndPath(withoutScheme);
    const domain = domainPart.toLowerCase();

    if (!DOMAIN_RE.test(domain)) {
      return {
        error: `Domain không hợp lệ: "${inputRaw}". Chỉ nhập tên miền thuần, có thể kèm đường dẫn (vd. "youtube.com" hoặc "res.cloudinary.com/ten-cloud"), không kèm "https://".`,
      };
    }

    // Chuẩn hoá path: bỏ "/" đầu/cuối thừa, gộp "//" liên tiếp, loại segment rỗng.
    const pathSegments = pathPart.split("/").map((s) => s.trim()).filter(Boolean);
    const path = pathSegments.join("/");
    if (path) {
      if (path.length > MAX_PATH_LEN) {
        return { error: `Đường dẫn quá dài ở "${inputRaw}" (tối đa ${MAX_PATH_LEN} ký tự).` };
      }
      if (!pathSegments.every((seg) => PATH_SEGMENT_RE.test(seg))) {
        return {
          error: `Đường dẫn không hợp lệ ở "${inputRaw}" — mỗi phần chỉ chấp nhận chữ/số và . _ ~ % -, không khoảng trắng hay ký tự đặc biệt khác.`,
        };
      }
    }

    if (isPublicSuffix(domain)) {
      return {
        error: `"${domain}" là tên miền DÙNG CHUNG (mỗi người dùng có 1 subdomain riêng) — cho phép nó nghĩa là tin cậy mọi người dùng của dịch vụ đó. Hãy nhập subdomain cụ thể (vd. "ten-ban.${domain}").`,
      };
    }

    const key = `${domain}/${path}`;
    if (seen.has(key)) continue; // bỏ qua trùng lặp thay vì báo lỗi — thân thiện hơn
    seen.add(key);
    const labelRaw = typeof raw === "object" && raw && typeof raw.label === "string" ? raw.label.trim() : "";
    const defaultLabel = path ? `${domain}/${path}` : domain;
    domains.push({ domain, path, label: labelRaw ? labelRaw.slice(0, 60) : defaultLabel });
  }
  return { domains };
}

/**
 * GET /api/admin/embed-domains (chỉ SA)
 * Trả về cấu hình đang lưu ở Firestore — KHÔNG đọc từ state trong bộ nhớ
 * (`getEmbedDomainsConfig()`) vì state đó chỉ có domain thô (không có
 * `label`, đã rút gọn để sanitize dùng) — Firestore mới là nguồn đầy đủ cho
 * UI hiển thị.
 */
async function getEmbedDomainsSettings(req, res) {
  try {
    const snap = await db.collection(COLLECTIONS.CONFIG).doc(CONFIG_DOC_ID).get();
    if (!snap.exists) {
      // Chưa từng được ghi (lý thuyết không xảy ra vì server.js đã seed lúc
      // khởi động — phòng hờ trường hợp gọi API trước khi job seed kịp chạy).
      return res.json({ enabled: true, domains: DEFAULT_EMBED_DOMAINS });
    }
    const data = snap.data();
    return res.json({ enabled: data.enabled !== false, domains: Array.isArray(data.domains) ? data.domains : [] });
  } catch (err) {
    console.error("getEmbedDomainsSettings error:", err);
    return res.status(500).json({ error: "Không tải được cấu hình domain nhúng." });
  }
}

/**
 * PUT /api/admin/embed-domains (chỉ SA)
 * Body: { enabled: boolean, domains: [{ domain, label? }] }
 *
 * Sau khi ghi, LUÔN:
 *   1. Gọi `setEmbedDomainsConfig()` để áp dụng NGAY cho các request kế tiếp
 *      (không cần khởi động lại server).
 *   2. Quét lại TOÀN BỘ posts + blogs, sanitize lại `contentHtml` bằng cấu
 *      hình MỚI — loại bỏ mọi iframe từ domain không còn trong danh sách
 *      (hoặc mọi iframe nếu `enabled: false`). Đây chính là yêu cầu "quét
 *      sạch bài viết đang có một cách an toàn": chỉ GHI LẠI những doc thực
 *      sự thay đổi (so sánh HTML trước/sau), không đụng vào doc không liên
 *      quan; chạy theo lô (batch) để không vượt giới hạn ghi Firestore.
 */
async function updateEmbedDomainsSettings(req, res) {
  try {
    const enabled = req.body.enabled !== false; // mặc định true nếu thiếu/không hợp lệ, chỉ false khi CHỦ ĐỘNG gửi false
    const { domains, error } = normalizeDomainsInput(req.body.domains);
    if (error) return res.status(400).json({ error });

    const configRef = db.collection(COLLECTIONS.CONFIG).doc(CONFIG_DOC_ID);
    // v2.5.3 [TW-09]: ghi nhật ký thay đổi (ai, lúc nào, thêm/bỏ domain nào, bật/tắt) CÙNG MỘT batch với việc ghi cấu hình — hoặc có cả hai hoặc không có gì.
    const beforeSnap = await configRef.get();
    const before = beforeSnap.exists ? beforeSnap.data() : { enabled: true, domains: DEFAULT_EMBED_DOMAINS };
    const batch = db.batch();
    batch.set(
      configRef,
      { enabled, domains, updatedAt: FieldValue.serverTimestamp(), updatedByUid: req.authUid },
      { merge: false } // ghi đè toàn bộ — đây là cấu hình "trạng thái hiện tại", không phải log cộng dồn
    );
    batch.set(configAudit.newAuditRef(), configAudit.buildEntry({ action: "embed-domains.update", uid: req.authUid, diff: configAudit.diffEmbedDomains(before, { enabled, domains }) }));
    await batch.commit();

    // Áp dụng ngay cho các request /api/posts, /api/blogs... kế tiếp.
    setEmbedDomainsConfig({ enabled, domains: domains.map((d) => ({ domain: d.domain, path: d.path })) });
    lastAppliedUpdatedAtMs = null; // buộc lần đồng bộ kế tiếp lấy lại mốc thời gian chuẩn từ Firestore

    // v2.0.5: quét lại bài cũ chạy NỀN (trước đây chạy đồng bộ trong request PUT: đọc toàn bộ posts+blogs
    // kèm contentHtml rồi sanitize bằng JSDOM ngay trên event loop => dễ treo server/timeout trên Render).
    // PUT trả về NGAY `rescan: { running: true }`; giao diện hỏi tiến độ qua GET /embed-domains/rescan.
    startRescanInBackground();
    const rescan = { running: true };

    return res.json({ enabled, domains, rescan });
  } catch (err) {
    console.error("updateEmbedDomainsSettings error:", err);
    return res.status(500).json({ error: "Không lưu được cấu hình domain nhúng." });
  }
}

/**
 * Quét lại TOÀN BỘ posts + blogs (kể cả blog nháp — nội dung của nó vẫn có
 * thể chứa media không còn hợp lệ, và sẽ được publish sau này), sanitize
 * lại `contentHtml` bằng cấu hình domain HIỆN TẠI (đã được
 * `setEmbedDomainsConfig()` áp dụng ngay trước khi hàm này được gọi), CHỈ
 * ghi lại những doc có nội dung thực sự thay đổi.
 *
 * v0.10.16: `sanitizeHtml()` giờ domain-gate CẢ iframe LẪN img/video/audio/
 * source trực tiếp (xem sanitize.service.js) — nên lần quét này giờ dọn
 * sạch MỌI loại nhúng từ 1 domain SA vừa gỡ/thu hẹp path, không riêng
 * iframe như trước v0.10.16 nữa.
 *
 * ==== LƯU Ý HIỆU NĂNG ====
 * Đọc TOÀN BỘ contentHtml của mọi post/blog (không dùng `.select()` giảm
 * tải như các chỗ khác trong code — ở đây bắt buộc cần full nội dung để
 * sanitize lại) — cùng triết lý "chấp nhận quét toàn bộ ở quy mô nhỏ" đã
 * dùng cho trending.controller.js. Thao tác này CHỈ chạy khi SA chủ động
 * lưu thay đổi domain (hiếm, không phải trên đường request thông thường của
 * người dùng) nên chấp nhận được dù có thể mất vài giây ở dữ liệu lớn.
 */
const RESCAN_STATUS_DOC = "embedDomainsRescan";
const RESCAN_PAGE = 100;
const yieldToEventLoop = () => new Promise((resolve) => setImmediate(resolve));

let rescanRunning = false;
let rescanQueued = false;

async function writeRescanStatus(patch) {
  try {
    await db.collection(COLLECTIONS.CONFIG).doc(RESCAN_STATUS_DOC).set(patch, { merge: true });
  } catch (err) {
    console.error("writeRescanStatus lỗi:", err.message);
  }
}

/**
 * Chạy quét nền; nếu SA lưu thêm lần nữa trong lúc đang quét thì xếp hàng đúng 1 lần quét lại sau đó
 * (cấu hình đã đổi nên kết quả quét đang chạy có thể lỗi thời). Trạng thái ghi vào config/embedDomainsRescan
 * để giao diện (và các instance khác) đọc được.
 */
function startRescanInBackground() {
  if (rescanRunning) {
    rescanQueued = true;
    return;
  }
  rescanRunning = true;
  (async () => {
    do {
      rescanQueued = false;
      await writeRescanStatus({ status: "running", startedAtMs: Date.now(), finishedAtMs: null, error: false });
      let result;
      try {
        result = await rescanContentForEmbedDomains();
      } catch (err) {
        console.error("rescanContentForEmbedDomains error:", err);
        result = { scanned: 0, modified: 0, skipped: 0, failed: 0, error: true };
      }
      await writeRescanStatus({ status: "done", finishedAtMs: Date.now(), ...result });
    } while (rescanQueued);
  })()
    .catch((err) => console.error("startRescanInBackground lỗi:", err))
    .finally(() => {
      rescanRunning = false;
    });
}

/** GET /api/admin/embed-domains/rescan — tiến độ / kết quả lần quét gần nhất (chỉ SA). */
async function getEmbedDomainsRescanStatus(req, res) {
  try {
    const snap = await db.collection(COLLECTIONS.CONFIG).doc(RESCAN_STATUS_DOC).get();
    const d = snap.exists ? snap.data() : null;
    if (!d) return res.json({ running: false, rescan: null });
    // Trạng thái "running" bị treo (instance chết giữa chừng) quá 15 phút thì coi như đã dừng.
    const stale = d.status === "running" && Date.now() - (d.startedAtMs || 0) > 15 * 60 * 1000;
    const running = d.status === "running" && !stale;
    return res.json({
      running,
      rescan: {
        scanned: d.scanned || 0,
        modified: d.modified || 0,
        skipped: d.skipped || 0,
        failed: d.failed || 0,
        error: !!d.error || stale,
      },
    });
  } catch (err) {
    console.error("getEmbedDomainsRescanStatus error:", err);
    return res.status(500).json({ error: "Không đọc được trạng thái quét." });
  }
}

/** Duyệt 1 collection theo trang (documentId) để không nạp toàn bộ nội dung vào RAM cùng lúc. */
async function* pagedDocs(collectionName) {
  let last = null;
  for (;;) {
    let q = db.collection(collectionName).orderBy(admin.firestore.FieldPath.documentId()).limit(RESCAN_PAGE);
    if (last) q = q.startAfter(last);
    const snap = await q.get();
    if (snap.empty) return;
    for (const doc of snap.docs) yield doc;
    last = snap.docs[snap.docs.length - 1];
    if (snap.size < RESCAN_PAGE) return;
  }
}

/**
 * Quét lại TOÀN BỘ posts + blogs (kể cả blog nháp), sanitize lại `contentHtml` bằng cấu hình domain
 * HIỆN TẠI, CHỈ ghi lại doc có nội dung thực sự đổi (mỗi doc 1 transaction riêng, đọc lại bản mới nhất
 * để không ghi đè chỉnh sửa đồng thời — xem VÁ v0.10.18 L-6). v2.0.5: duyệt theo trang + nhường event
 * loop giữa các doc (request khác vẫn được phục vụ), và cập nhật lại `excerpt` cho khớp nội dung mới.
 */
async function rescanContentForEmbedDomains() {
  let scanned = 0;
  let modified = 0;
  let skipped = 0;
  let failed = 0;

  for (const collectionName of [COLLECTIONS.POSTS, COLLECTIONS.BLOGS]) {
    for await (const doc of pagedDocs(collectionName)) {
      scanned++;
      await yieldToEventLoop();
      const data = doc.data();
      if (!data.contentHtml) continue;

      try {
        // v2.0.10 [BẢO MẬT F1/F10]: sanitize chạy ở worker có timeout (không chặn event loop) và NẰM TRONG try/catch —
        // một tài liệu cũ chứa payload bệnh lý chỉ bị tính là "failed", không làm treo/huỷ cả đợt quét.
        const { html: clean, excerpt } = await processContentHtml(data.contentHtml);
        if (clean === data.contentHtml) continue; // không cần sửa (đa số)

        const outcome = await db.runTransaction(async (tx) => {
          const fresh = await tx.get(doc.ref);
          if (!fresh.exists) return "skipped";
          // Nếu nội dung đã bị sửa trong lúc quét thì bỏ qua: đường sửa bài đã sanitize bằng cấu hình HIỆN TẠI (VÁ v0.10.18 L-6).
          if (fresh.data().contentHtml !== data.contentHtml) return "skipped";
          tx.update(doc.ref, { contentHtml: clean, excerpt });
          return "modified";
        });
        if (outcome === "modified") modified++;
        else skipped++;
      } catch (err) {
        failed++;
        console.error(`rescanContentForEmbedDomains: lỗi khi xử lý ${doc.ref.path}:`, err.message);
      }
    }
  }
  return { scanned, modified, skipped, failed };
}

/**
 * v2.0.5 — đồng bộ cấu hình domain nhúng giữa NHIỀU instance. Cấu hình nằm trong RAM mỗi instance; trước
 * đây chỉ instance nhận PUT được cập nhật, instance khác giữ bản cũ tới khi khởi động lại. Nay mỗi
 * instance đọc doc cấu hình định kỳ (1 lượt đọc / 60 giây / instance) và áp dụng khi `updatedAt` đổi.
 */
let lastAppliedUpdatedAtMs = null;
function startEmbedConfigSync(intervalMs = 60 * 1000) {
  const tick = async () => {
    try {
      const snap = await db.collection(COLLECTIONS.CONFIG).doc(CONFIG_DOC_ID).get();
      if (!snap.exists) return;
      const data = snap.data();
      const ms = data.updatedAt && typeof data.updatedAt.toMillis === "function" ? data.updatedAt.toMillis() : 0;
      if (lastAppliedUpdatedAtMs === null) {
        lastAppliedUpdatedAtMs = ms; // lần đầu: cấu hình đã được nạp lúc khởi động
        return;
      }
      if (ms !== lastAppliedUpdatedAtMs) {
        setEmbedDomainsConfig(data);
        lastAppliedUpdatedAtMs = ms;
      }
    } catch (err) {
      console.error("startEmbedConfigSync lỗi:", err.message);
    }
  };
  const timer = setInterval(tick, intervalMs);
  if (timer.unref) timer.unref();
  return timer;
}

module.exports = {
  getEmbedDomainsSettings,
  updateEmbedDomainsSettings,
  getEmbedDomainsRescanStatus,
  startEmbedConfigSync,
  __test: { rescanContentForEmbedDomains },
};
