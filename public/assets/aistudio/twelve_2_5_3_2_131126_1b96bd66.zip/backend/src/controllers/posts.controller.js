const { db, admin } = require("../config/firebase");
const { COLLECTIONS } = require("../utils/constants");
const { processContentHtml, sendContentError } = require("../services/contentPipeline");
const { registerView, parseShareQuery, registerShare, viewerKeyFromRequest, computePostScore, syncPostScore, syncPostScoresBatch, postsScoreSumWrite, reconcilePostsScoreSum, positiveScoreWrite, positiveScoreLogWrite, validateTitle, validateCoverImageUrl, validateHashtags, assertActorActive, ACCOUNT_NOT_ACTIVE_BODY } = require("../utils/helpers");

const { attachAuthors } = require("../utils/authors");
const { purgeContentSubcollections } = require("../utils/cascade");
const { parseLimit, parseCursor, stripBidiAndInvisible } = require("../utils/input");
const { toHashtagsLower } = require("../utils/helpers");
const { formatCardContent, formatFullContent } = require("../utils/contentFormat");
const { getMyReaction, getMyReactionsById } = require("../utils/myReactions");
const pins = require("../services/pins");

const FieldValue = admin.firestore.FieldValue;

/**
 * POST /api/posts
 * body: { title, contentHtml, coverImageUrl? }
 * contentHtml: HTML do Quill.js render ra ở frontend (đã gồm ảnh/video/media chèn qua URL)
 * coverImageUrl: URL do người dùng dán vào (không upload trực tiếp)
 */
async function createPost(req, res) {
  try {
    const { title, contentHtml, coverImageUrl, hashtags } = req.body;
    if (!title || !contentHtml) {
      return res.status(400).json({ error: "Cần có tiêu đề và nội dung bài viết." });
    }
    // v0.9.6 [MEDIUM]: title trước đây không giới hạn độ dài tối đa.
    const titleErr = validateTitle(title);
    if (titleErr) return res.status(400).json({ error: titleErr });
    const coverErr = validateCoverImageUrl(coverImageUrl);
    if (coverErr) return res.status(400).json({ error: coverErr });
    // v0.9.7 — hashtag bài viết
    const { error: hashtagErr, hashtags: cleanHashtags } = validateHashtags(hashtags);
    if (hashtagErr) return res.status(400).json({ error: hashtagErr });

    // v2.0.10 [BẢO MẬT F1]: kiểm tra giới hạn + sanitize ở worker có timeout (không chặn event loop).
    const { html: cleanHtml, excerpt: cleanExcerpt } = await processContentHtml(contentHtml);
    const postRef = db.collection(COLLECTIONS.POSTS).doc();

    const postData = {
      id: postRef.id,
      authorUid: req.authUid,
      title: stripBidiAndInvisible(title).trim(),
      contentHtml: cleanHtml,
      excerpt: cleanExcerpt,
      coverImageUrl: coverImageUrl || null,
      // v0.9.7 — hashtag bài viết, dạng ["#tag1", "#tag2"], tối đa 20 tag.
      hashtags: cleanHashtags,
      hashtagsLower: toHashtagsLower(cleanHashtags),
      likeCount: 0,
      dislikeCount: 0,
      commentCount: 0,
      viewCount: 0,
      aiViewCount: 0,
      shareCount: 0,
      // postScore chỉ là CACHE (xem utils/helpers.js#syncPostScore) — khởi tạo
      // 0 cho nhất quán với các counter khác, không phải nguồn sự thật.
      postScore: 0,
      // ==== v0.8.25 [CRITICAL] ====
      // externalPostScore: chỉ tính điểm từ tương tác của NGƯỜI KHÁC tác giả.
      // Dùng để tính postsScoreSum/accountScore, chống farm điểm qua tự tương tác.
      externalPostScore: 0,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    };

    // ĐIỂM TÍCH CỰC (v0.8.17): +1 cho tác giả khi đăng bài thành công. Ghi
    // BẰNG BATCH cùng lúc với việc tạo bài (không phải 2 lệnh `await` rời
    // nhau) để atomic — tránh trường hợp tạo bài xong nhưng crash/lỗi mạng
    // ngay trước khi cộng điểm, khiến bài đã tồn tại mà tác giả không được
    // cộng đúng điểm cho hành động "đăng bài" đó.
    //
    // v2.2.1 [A-02]: batch -> TRANSACTION có đọc hồ sơ tác giả (assertActorActive). `batch.set(..., {merge:true})` TẠO LẠI `users/{uid}` và
    // vẫn ghi bài mồ côi nếu request đã qua middleware nhưng tài khoản bị xoá xong trước lúc commit (hồ sơ "ma" + bài của tài khoản đã xoá).
    // Transaction bị tuần tự hoá với `requestDeletion` nên không còn khe hở đó.
    const pw = positiveScoreWrite(db, admin, req.authUid, 1);
    // AUDIT LOG (v0.8.25): ghi lại chi tiết lần cộng điểm khi đăng bài
    const lw = positiveScoreLogWrite(db, admin, req.authUid, 1, "create_post", {
      collection: COLLECTIONS.POSTS,
      docId: postRef.id,
    });
    await db.runTransaction(async (tx) => {
      await assertActorActive(tx, db, req.authUid);
      tx.set(postRef, postData);
      if (pw) tx.set(pw.ref, pw.data, { merge: true });
      if (lw) tx.set(lw.ref, lw.data);
    });

    return res.status(201).json({ message: "Đăng bài thành công.", postId: postRef.id });
  } catch (err) {
    if (err && err.code === "ACCOUNT_NOT_ACTIVE") return res.status(403).json(ACCOUNT_NOT_ACTIVE_BODY);
    if (sendContentError(res, err)) return;
    console.error("createPost error:", err);
    return res.status(500).json({ error: "Đăng bài thất bại." });
  }
}

/**
 * GET /api/posts?cursor=<postId>&limit=10
 * Feed cho trang INDEX, sắp xếp mới nhất trước, phân trang kiểu cursor.
 */
async function listPosts(req, res) {
  try {
    // v2.0.10 [F8]: limit/cursor sai kiểu (âm, mảng, chứa "/") trước đây làm Firestore ném lỗi => 500.
    const limit = parseLimit(req.query.limit, 10, 30);
    const cursorParsed = parseCursor(req.query.cursor);
    if (!cursorParsed.ok) return res.status(400).json({ error: "Tham số cursor không hợp lệ." });
    let query = db.collection(COLLECTIONS.POSTS).orderBy("createdAt", "desc").limit(limit);

    if (cursorParsed.value) {
      const cursorSnap = await db.collection(COLLECTIONS.POSTS).doc(cursorParsed.value).get();
      if (cursorSnap.exists) query = query.startAfter(cursorSnap);
    }

    const snap = await query.get();
    const posts = await attachAuthors(snap.docs.map((d) => d.data()));

    // ==== VÁ v0.8.18 ====
    // TRƯỚC ĐÂY endpoint danh sách này KHÔNG bao giờ trả `myReaction` cho
    // từng bài, khác hẳn `getPost` (trang chi tiết) đã làm đúng — khiến
    // PostCard trên trang INDEX/BLOG luôn hiển thị nút Like/Dislike ở trạng
    // thái "chưa bấm" sau mỗi lần tải lại trang, dù Firestore đã có sẵn
    // reaction thật của người dùng. Hậu quả: người dùng tưởng đang bấm Like
    // MỚI nhưng thực chất đang GỠ 1 like đã có từ trước — backend xử lý hoàn
    // toàn đúng (toggle-off, đúng thiết kế) nhưng trải nghiệm gây hiểu lầm
    // nghiêm trọng (đặc biệt sau khi có positiveScore v0.8.17: gỡ nhầm 1 like
    // tưởng là thêm mới sẽ thấy điểm bị TRỪ thay vì CỘNG).
    // Route này trước đây cũng thiếu `optionalAuth` nên `req.authUid` không
    // tồn tại — đã thêm ở posts.routes.js.
    const myReactionByPostId = await getMyReactionsById(COLLECTIONS.POSTS, posts.map((p) => p.id), req.authUid);

    const formatted = posts.map((p) => ({
      ...formatCardPost(p),
      myReaction: myReactionByPostId[p.id] || null,
    }));

    // Đồng bộ cache postScore trong Firestore cho các bài mà điểm vừa tính
    // ra khác với giá trị đang lưu — chạy song song, KHÔNG chặn response
    // (xem utils/helpers.js#syncPostScoresBatch).
    syncPostScoresBatch(
      db,
      admin,
      COLLECTIONS.POSTS,
      posts.map((p, i) => ({ id: p.id, score: formatted[i].postScore, storedScore: p.postScore, authorUid: p.authorUid }))
    );

    return res.json({
      posts: formatted,
      nextCursor: snap.docs.length ? snap.docs[snap.docs.length - 1].id : null,
    });
  } catch (err) {
    console.error("listPosts error:", err);
    return res.status(500).json({ error: "Không tải được danh sách bài viết." });
  }
}

/**
 * GET /api/posts/:id
 * Dùng cho trang POST (chi tiết, SSR). Trả về đầy đủ nội dung + reaction của user hiện tại (nếu có).
 */
async function getPost(req, res) {
  try {
    const snap = await db.collection(COLLECTIONS.POSTS).doc(req.params.id).get();
    if (!snap.exists) return res.status(404).json({ error: "Không tìm thấy bài viết." });

    const post = snap.data();
    const [author] = await attachAuthors([post]);

    const myReaction = await getMyReaction(COLLECTIONS.POSTS, req.params.id, req.authUid);

    const viewCounted = await registerView(db, admin, COLLECTIONS.POSTS, req.params.id, {
      viewerKey: viewerKeyFromRequest(req),
      isAi: false,
      viewerUid: req.authUid || null,
      authorUid: post.authorUid,
    });

    // Tính SHARE: nếu URL đang mở có ?idu=uid hoặc ?shared=1 (link do
    // POST /api/posts/:id/share tạo ra) thì đây chính là lượt "có người click
    // vào link chia sẻ" — ghi nhận 1 share (xem utils/helpers.js).
    const { isShareLink, rawSharerUid, signature } = parseShareQuery(req.query);
    let shareCounted = false;
    if (isShareLink) {
      const shareResult = await registerShare(db, admin, COLLECTIONS.POSTS, req.params.id, {
        rawSharerUid,
        signature,
        authorUid: post.authorUid,
        source: "web",
        viewerKey: viewerKeyFromRequest(req),
        viewerUid: req.authUid || null,
      });
      shareCounted = shareResult.counted;
    }

    const formatted = formatFullPost(author);
    // Phản ánh ngay lượt xem / lượt share vừa tính vào response để client
    // không cần chờ round-trip khác mới thấy số cập nhật. Chỉ +1 viewCount
    // nếu registerView xác nhận đây thực sự là 1 view mới (chưa trùng).
    formatted.viewCount = (post.viewCount || 0) + (viewCounted ? 1 : 0);
    formatted.shareCount = (post.shareCount || 0) + (shareCounted ? 1 : 0);
    // postScore PHẢI tính lại SAU khi đã cộng view/share ở trên — nếu tính
    // trong formatFullPost (dùng viewCount/shareCount cũ) thì sẽ bị lệch 1
    // nhịp so với số vừa cập nhật.
    formatted.postScore = computePostScore(formatted);
    // Đồng bộ cache trong Firestore (song song, không chặn response) — xem
    // utils/helpers.js#syncPostScore.
    syncPostScore(db, admin, COLLECTIONS.POSTS, req.params.id, formatted.postScore, post.postScore, post.authorUid);

    return res.json({ post: formatted, myReaction });
  } catch (err) {
    console.error("getPost error:", err);
    return res.status(500).json({ error: "Không tải được bài viết." });
  }
}

/**
 * PATCH /api/posts/:id  (chỉ chủ bài viết hoặc SA)
 */
async function updatePost(req, res) {
  try {
    const ref = db.collection(COLLECTIONS.POSTS).doc(req.params.id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ error: "Không tìm thấy bài viết." });

    const post = snap.data();
    const isOwner = post.authorUid === req.authUid;
    const isSA = req.authUser.accountGroup === "SA";
    if (!isOwner && !isSA) return res.status(403).json({ error: "Bạn không có quyền sửa bài viết này." });

    const updates = { updatedAt: FieldValue.serverTimestamp() };
    if (req.body.title) {
      const titleErr = validateTitle(req.body.title);
      if (titleErr) return res.status(400).json({ error: titleErr });
      updates.title = stripBidiAndInvisible(req.body.title).trim();
    }
    if (req.body.contentHtml) {
      const processed = await processContentHtml(req.body.contentHtml);
      updates.contentHtml = processed.html;
      updates.excerpt = processed.excerpt;
    }
    if (req.body.coverImageUrl !== undefined) {
      const coverErr = validateCoverImageUrl(req.body.coverImageUrl, post.coverImageUrl || null);
      if (coverErr) return res.status(400).json({ error: coverErr });
      updates.coverImageUrl = req.body.coverImageUrl || null;
    }
    if (req.body.hashtags !== undefined) {
      const { error: hashtagErr, hashtags: cleanHashtags } = validateHashtags(req.body.hashtags);
      if (hashtagErr) return res.status(400).json({ error: hashtagErr });
      updates.hashtags = cleanHashtags;
      updates.hashtagsLower = toHashtagsLower(cleanHashtags);
    }

    await ref.update(updates);
    return res.json({ message: "Cập nhật bài viết thành công." });
  } catch (err) {
    if (sendContentError(res, err)) return;
    console.error("updatePost error:", err);
    return res.status(500).json({ error: "Cập nhật thất bại." });
  }
}

/**
 * DELETE /api/posts/:id (chỉ chủ bài viết hoặc SA)
 */
async function deletePost(req, res) {
  try {
    const ref = db.collection(COLLECTIONS.POSTS).doc(req.params.id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ error: "Không tìm thấy bài viết." });

    const post = snap.data();
    const isOwner = post.authorUid === req.authUid;
    const isSA = req.authUser.accountGroup === "SA";
    if (!isOwner && !isSA) return res.status(403).json({ error: "Bạn không có quyền xóa bài viết này." });

    // Xoá bài + trừ đúng phần đóng góp (postScore hiện tại) của bài này khỏi
    // postsScoreSum của tác giả — trong CÙNG 1 transaction (atomic), vì bài
    // không còn tồn tại nữa thì không được tính vào tổng điểm tài khoản. Tính
    // điểm MỚI NHẤT ngay tại thời điểm xoá (không dùng field postScore cache
    // có thể hơi cũ) để đảm bảo trừ đúng số đã từng cộng.
    let deletedAuthorUid = null;
    await db.runTransaction(async (tx) => {
      const freshSnap = await tx.get(ref);
      if (!freshSnap.exists) return; // đã bị xoá bởi request khác, bỏ qua

      const freshData = freshSnap.data();
      const currentScore = computePostScore(freshData);
      // ==== VÁ v0.8.25 [CRITICAL] — Chống farm điểm qua postsScoreSum ====
      // Khi xoá bài, trừ đúng `externalPostScore` (chỉ điểm từ người khác)
      // khỏi postsScoreSum, thay vì trừ `postScore` (bao gồm cả tự tương tác
      // chưa từng được cộng vào postsScoreSum).
      const externalScoreToRemove = freshData.externalPostScore || 0;

      tx.delete(ref);

      const w = postsScoreSumWrite(db, admin, freshData.authorUid, -externalScoreToRemove);
      if (w) tx.set(w.ref, w.data, { merge: true });
      deletedAuthorUid = freshData.authorUid;

      // ĐIỂM TÍCH CỰC (v0.8.17): -1 cho tác giả khi xoá bài — đảo ngược
      // đúng +1 lúc đăng bài (createPost), atomic trong CÙNG transaction xoá.
      const pw = positiveScoreWrite(db, admin, freshData.authorUid, -1);
      if (pw) tx.set(pw.ref, pw.data, { merge: true });
      // AUDIT LOG (v0.8.25): ghi lại chi tiết lần trừ điểm khi xoá bài
      const lw = positiveScoreLogWrite(db, admin, freshData.authorUid, -1, "delete_post", {
        collection: COLLECTIONS.POSTS,
        docId: req.params.id,
      });
      if (lw) tx.set(lw.ref, lw.data);
    });

    // v0.8.14: đối soát lại bằng aggregation query SAU KHI transaction xoá +
    // trừ delta đã commit — chốt lại đúng giá trị thật (bài vừa xoá chắc
    // chắn không còn được tính nữa vì query aggregate chỉ quét document đang
    // tồn tại). Xem giải thích ở utils/helpers.js#reconcilePostsScoreSum.
    if (deletedAuthorUid) {
      reconcilePostsScoreSum(db, admin, deletedAuthorUid).catch(() => {});
      // v2.4.0: bài bị xoá (bởi chủ bài hoặc SA) không còn được ghim — gỡ id khỏi hồ sơ tác giả (nền; lần đọc bài ghim sau cũng tự dọn).
      pins.removePinsBestEffort(deletedAuthorUid, [req.params.id]);
      // v2.0.5: dọn comments/views/reactions của bài (nền, không chặn response).
      purgeContentSubcollections(db, ref);
    }

    return res.json({ message: "Đã xóa bài viết." });
  } catch (err) {
    console.error("deletePost error:", err);
    return res.status(500).json({ error: "Xóa thất bại." });
  }
}

/**
 * PUT /api/posts/:id/pin — ghim bài của CHÍNH MÌNH lên Trang chủ hồ sơ (tối đa PROFILE.PINNED_POSTS_MAX bài). Idempotent.
 * Trả `{ pinnedPostIds }` (danh sách mới, bài vừa ghim đứng đầu) để frontend cập nhật ngay không cần chờ realtime.
 */
async function pinPost(req, res) {
  return runPinAction(req, res, pins.pinPost, "Đã ghim bài viết lên trang cá nhân.", "Ghim bài thất bại.", "pinPost");
}

/** DELETE /api/posts/:id/pin — gỡ ghim (bài đã bị xoá vẫn gỡ được). Idempotent. */
async function unpinPost(req, res) {
  return runPinAction(req, res, pins.unpinPost, "Đã gỡ ghim bài viết.", "Gỡ ghim thất bại.", "unpinPost");
}

async function runPinAction(req, res, action, okMessage, failMessage, label) {
  try {
    const result = await action(req.authUid, req.params.id);
    return res.json({ message: okMessage, pinnedPostIds: result.pinnedPostIds, changed: result.changed });
  } catch (err) {
    if (err && err.code === "ACCOUNT_NOT_ACTIVE") return res.status(403).json(ACCOUNT_NOT_ACTIVE_BODY);
    if (err instanceof pins.PinError) return res.status(err.status).json({ error: err.userMessage, code: err.code });
    console.error(`${label} error:`, err);
    return res.status(500).json({ error: failMessage });
  }
}

// ==== Helpers dùng chung ====

// v2.0.0: định dạng card/full chuyển sang utils/contentFormat (dùng chung với Blog); giữ tên cũ để route SSR không đổi.
const formatCardPost = formatCardContent;
const formatFullPost = formatFullContent;

module.exports = {
  createPost,
  listPosts,
  getPost,
  updatePost,
  deletePost,
  pinPost,
  unpinPost,
  attachAuthors,
  formatFullPost,
  formatCardPost,
};
