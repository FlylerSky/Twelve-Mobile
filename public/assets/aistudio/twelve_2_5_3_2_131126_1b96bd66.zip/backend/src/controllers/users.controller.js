const { db } = require("../config/firebase");
const cloudinary = require("../config/cloudinary");
const assets = require("../services/assets.service");
const { COLLECTIONS, ASSET_KIND, ASSET_LIMITS, PROFILE, ACCOUNT_STATUS } = require("../utils/constants");
const { avatarPublicId, coverPublicId, parseCloudinaryUrl } = require("../utils/cloudinaryUrl");
const { toPublicProfile, syncAccountScore, validateProfileCoverUrl, parseCoverCrop, ACCOUNT_NOT_ACTIVE_BODY } = require("../utils/helpers");
const { sniffImageMime, parseLimit, parseCursor } = require("../utils/input");
const { withoutRealName } = require("../services/userPrivate");
const { badgeIdsForUser } = require("../utils/badges");
const { normalizePinnedIds, removePinsBestEffort } = require("../services/pins");
const { buildProfileCards } = require("../utils/profilePosts");
const { loadLivePublicUser, loadLivePublicUserByTag } = require("../services/profileLookup");
const profileVisitors = require("../services/profileVisitors");
const { getUserAchievements } = require("../services/achievements");
const { resolveExtras, parseExtrasUpdate, buildExtraFields } = require("../utils/profileExtras");

// GET /api/users/me
async function getMe(req, res) {
  try {
    // v0.8.23: đối soát accountScore = postsScoreSum + positiveScore mỗi khi
    // user truy cập/tải hồ sơ của chính mình — đúng điều kiện trigger "đăng
    // nhập/truy cập Twelve" (xem utils/helpers.js#syncAccountScore).
    const user = syncAccountScore(db, req.authUid, req.authUser);
    // v2.2.0: tên thật KHÔNG bao giờ đi theo /users/me — chỉ lấy được qua GET /users/me/real-name sau khi nhập lại mật khẩu.
    // v2.4.0: kèm `badges` (danh sách id huy hiệu, xem utils/badges.js) như mọi hồ sơ công khai. Hồ sơ của chính chủ còn có
    // `coverUrl` và `pinnedPostIds` (cả hai nằm sẵn trong document `users/{uid}` — frontend cũng nghe realtime document này).
    return res.json({ user: { ...withoutRealName(user), badges: badgeIdsForUser(user) } });
  } catch (err) {
    // v2.2.1 [A-01]: mọi handler async đều phải tự bắt lỗi (xem utils/asyncErrors.js — lớp lưới an toàn cuối).
    console.error("getMe error:", err);
    return res.status(500).json({ error: "Không tải được hồ sơ." });
  }
}

const NOT_FOUND_USER = { error: "Không tìm thấy người dùng." };

// GET /api/users/:uid  (thông tin công khai)
async function getPublicProfile(req, res) {
  try {
    const live = await loadLivePublicUser(req.params.uid);
    if (!live) return res.status(404).json(NOT_FOUND_USER);
    // v2.4.0: toPublicProfile = toPublicUser (+ huy hiệu) + ảnh bìa.
    return res.json({ user: toPublicProfile(live.data) });
  } catch (err) {
    console.error("getPublicProfile error:", err);
    return res.status(500).json({ error: "Không tải được hồ sơ." });
  }
}

// GET /api/users/by-tag/:tag  (v2.4.2.1 — hồ sơ công khai theo Tag Name Search; `:tag` nhận cả "abc" lẫn "@abc", không phân biệt hoa/thường)
async function getPublicProfileByTag(req, res) {
  try {
    const live = await loadLivePublicUserByTag(req.params.tag);
    if (!live) return res.status(404).json(NOT_FOUND_USER);
    return res.json({ user: toPublicProfile({ uid: live.uid, ...live.data }) });
  } catch (err) {
    console.error("getPublicProfileByTag error:", err);
    return res.status(500).json({ error: "Không tải được hồ sơ." });
  }
}

/**
 * GET /api/users/:uid/posts?cursor=<postId>&limit=10 — tab "Bài viết" của hồ sơ: bài của người này, mới nhất trước.
 * Dùng chỉ mục có sẵn (posts: authorUid + createdAt DESC). Bài đang ghim vẫn nằm trong danh sách (kèm isPinned=true).
 */
async function listUserPosts(req, res) {
  try {
    const live = await loadLivePublicUser(req.params.uid);
    if (!live) return res.status(404).json(NOT_FOUND_USER);
    const limit = parseLimit(req.query.limit, PROFILE.USER_POSTS_PAGE_SIZE, PROFILE.USER_POSTS_PAGE_SIZE_MAX);
    const cursorParsed = parseCursor(req.query.cursor);
    if (!cursorParsed.ok) return res.status(400).json({ error: "Tham số cursor không hợp lệ." });

    let query = db
      .collection(COLLECTIONS.POSTS)
      .where("authorUid", "==", req.params.uid)
      .orderBy("createdAt", "desc")
      .limit(limit);
    if (cursorParsed.value) {
      const cursorSnap = await db.collection(COLLECTIONS.POSTS).doc(cursorParsed.value).get();
      // Cursor phải là bài của CHÍNH người này — id của bài người khác sẽ làm trang kế tiếp lệch thứ tự.
      if (cursorSnap.exists && cursorSnap.data().authorUid === req.params.uid) query = query.startAfter(cursorSnap);
    }
    const snap = await query.get();
    const raw = snap.docs.map((d) => ({ ...d.data(), id: d.id }));
    const posts = await buildProfileCards(raw, {
      viewerUid: req.authUid || null,
      pinnedIds: normalizePinnedIds(live.data.pinnedPostIds),
    });
    return res.json({ posts, nextCursor: snap.docs.length ? snap.docs[snap.docs.length - 1].id : null });
  } catch (err) {
    console.error("listUserPosts error:", err);
    return res.status(500).json({ error: "Không tải được bài viết của người dùng." });
  }
}

/**
 * GET /api/users/:uid/pinned — các bài người này ghim lên Trang chủ hồ sơ, theo thứ tự đã ghim.
 * Tự loại bài không còn / không còn là của người này và gỡ id đó khỏi danh sách ghim (xem services/pins.js).
 */
async function listPinnedPosts(req, res) {
  try {
    const live = await loadLivePublicUser(req.params.uid);
    if (!live) return res.status(404).json(NOT_FOUND_USER);
    const uid = req.params.uid;
    const ids = normalizePinnedIds(live.data.pinnedPostIds).slice(0, PROFILE.PINNED_POSTS_MAX);
    if (ids.length === 0) return res.json({ posts: [] });

    const snaps = await db.getAll(...ids.map((id) => db.collection(COLLECTIONS.POSTS).doc(id)));
    const alive = [];
    const dead = [];
    snaps.forEach((s, i) => {
      if (s.exists && s.data().authorUid === uid) alive.push({ ...s.data(), id: ids[i] });
      else dead.push(ids[i]);
    });
    if (dead.length) removePinsBestEffort(uid, dead); // nền, không chặn response

    const posts = await buildProfileCards(alive, { viewerUid: req.authUid || null, pinnedIds: ids });
    return res.json({ posts });
  } catch (err) {
    console.error("listPinnedPosts error:", err);
    return res.status(500).json({ error: "Không tải được bài viết đã ghim." });
  }
}

/**
 * GET /api/users/:uid/blogs?cursor=<blogId>&limit=10 — tab "Blog" của hồ sơ (v2.5.2): các bài Blog ĐÃ XUẤT BẢN do người này đăng, mới nhất trước.
 * Cùng khuôn với listUserPosts và cùng dạng thẻ với GET /api/blogs (formatCardContent + myReaction của người xem). Dùng chỉ mục có sẵn
 * blogs(isPublished, authorUid, createdAt ↓). Bản NHÁP không bao giờ có ở đây (kể cả khi người xem là chính tác giả — bản nháp xem ở trang Blog/soạn thảo).
 * Backend KHÔNG tự lọc theo bậc tài khoản: ai từng đăng Blog thì bài vẫn có thể liệt kê; việc chỉ hiện tab cho tài khoản SA là của frontend (profileTabs.jsx).
 */
async function listUserBlogs(req, res) {
  try {
    const live = await loadLivePublicUser(req.params.uid);
    if (!live) return res.status(404).json(NOT_FOUND_USER);
    const limit = parseLimit(req.query.limit, PROFILE.USER_POSTS_PAGE_SIZE, PROFILE.USER_POSTS_PAGE_SIZE_MAX);
    const cursorParsed = parseCursor(req.query.cursor);
    if (!cursorParsed.ok) return res.status(400).json({ error: "Tham số cursor không hợp lệ." });

    let query = db
      .collection(COLLECTIONS.BLOGS)
      .where("isPublished", "==", true)
      .where("authorUid", "==", req.params.uid)
      .orderBy("createdAt", "desc")
      .limit(limit);
    if (cursorParsed.value) {
      const cursorSnap = await db.collection(COLLECTIONS.BLOGS).doc(cursorParsed.value).get();
      // Cursor phải là blog ĐÃ XUẤT BẢN của CHÍNH người này — id lạ làm trang kế tiếp lệch thứ tự (và không được dùng để dò bản nháp).
      if (cursorSnap.exists && cursorSnap.data().authorUid === req.params.uid && cursorSnap.data().isPublished === true) query = query.startAfter(cursorSnap);
    }
    const snap = await query.get();
    const raw = snap.docs.map((d) => ({ ...d.data(), id: d.id }));
    const blogs = await buildProfileCards(raw, { viewerUid: req.authUid || null, collection: COLLECTIONS.BLOGS });
    return res.json({ blogs, nextCursor: snap.docs.length ? snap.docs[snap.docs.length - 1].id : null });
  } catch (err) {
    console.error("listUserBlogs error:", err);
    return res.status(500).json({ error: "Không tải được bài Blog của người dùng." });
  }
}

/**
 * GET /api/users/:uid/extra-info — nội dung hộp "Xem thêm" (v2.5.2). Chỉ gồm các mục CHỦ HỒ SƠ đang BẬT (xem utils/profileExtras.js) — mục tắt không rời máy chủ.
 * Trả `{ fields, achievements }`: `fields` = các trường vô hướng đang bật và có giá trị; `achievements` = thành tích (hoặc null nếu chủ tắt).
 * Tải khi mở hộp (không nằm trong GET hồ sơ) để mỗi lần xem hồ sơ không phải trả giá cho việc đọc bảng thành tích. Không cache phía CDN: tắt mục là có hiệu lực ngay.
 */
async function getExtraInfo(req, res) {
  try {
    const live = await loadLivePublicUser(req.params.uid);
    if (!live) return res.status(404).json(NOT_FOUND_USER);
    const flags = resolveExtras(live.data.profileExtras);
    const fields = buildExtraFields({ uid: req.params.uid, ...live.data }, flags);
    const achievements = flags.achievements ? await getUserAchievements(req.params.uid, live.data) : null;
    res.set("Cache-Control", "no-store");
    return res.json({ fields, achievements });
  } catch (err) {
    console.error("getExtraInfo error:", err);
    return res.status(500).json({ error: "Không tải được thông tin mở rộng." });
  }
}

/**
 * PUT /api/users/me/extras  body: { extras: { <khoá>: boolean, … } } — bật/tắt mục thông tin mở rộng (v2.5.2). Chỉ cập nhật các khoá được gửi (các khoá khác giữ nguyên).
 * Đọc–gộp–ghi trong MỘT transaction: hai lần bật/tắt gần nhau (mục khác nhau) không ghi đè nhau. Đồng thời kiểm tài khoản còn active (như mọi thao tác ghi hồ sơ).
 * Trả `{ profileExtras }` = cờ ĐÃ PHÂN GIẢI (đủ mọi khoá). Chỉ khoá đã biết được lưu — khoá lạ bị từ chối ở parseExtrasUpdate (không âm thầm bỏ qua).
 */
async function updateExtras(req, res) {
  try {
    const parsed = parseExtrasUpdate(req.body && req.body.extras);
    if (!parsed.ok) return res.status(400).json({ error: parsed.error });
    const ref = db.collection(COLLECTIONS.USERS).doc(req.authUid);
    const resolved = await db.runTransaction(async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists || snap.data().status !== ACCOUNT_STATUS.ACTIVE) {
        throw Object.assign(new Error("ACCOUNT_NOT_ACTIVE"), { code: "ACCOUNT_NOT_ACTIVE" });
      }
      const next = { ...resolveExtras(snap.data().profileExtras), ...parsed.value };
      // Chỉ lưu những khoá ĐÃ ĐƯỢC CHỦ CHỈNH hoặc đã lưu từ trước (không ghi cả bảng mặc định): đổi mặc định ở bản sau không bị "đóng băng" cho ai chưa từng chỉnh.
      const prevStored = snap.data().profileExtras && typeof snap.data().profileExtras === "object" ? snap.data().profileExtras : {};
      const stored = { ...Object.fromEntries(Object.entries(prevStored).filter(([, v]) => typeof v === "boolean")), ...parsed.value };
      tx.update(ref, { profileExtras: stored });
      return next;
    });
    return res.json({ profileExtras: resolved });
  } catch (err) {
    if (err && err.code === "ACCOUNT_NOT_ACTIVE") return res.status(403).json(ACCOUNT_NOT_ACTIVE_BODY);
    console.error("updateExtras error:", err);
    return res.status(500).json({ error: "Cập nhật thông tin mở rộng thất bại." });
  }
}

/**
 * POST /api/users/:uid/visit — ghi nhận người đăng nhập vừa ghé hồ sơ `:uid` (v2.5.2). Frontend gọi MỘT lần khi hiện hồ sơ người khác (fire-and-forget).
 * Cố ý là POST riêng chứ không tính trong GET hồ sơ: GET không có tác dụng phụ, bot/SSR/xem trước link không bao giờ để lại dấu, và chỉ người ĐÃ ĐĂNG NHẬP
 * (requireAuth) mới được ghi. Tự xem hồ sơ mình = bỏ qua. Trả `{ recorded }` (false khi bỏ qua vì tự xem / vừa ghi gần đây) — client không cần dùng.
 */
async function recordProfileVisit(req, res) {
  try {
    const ownerUid = req.params.uid;
    if (ownerUid === req.authUid) return res.json({ recorded: false });
    const live = await loadLivePublicUser(ownerUid);
    if (!live) return res.status(404).json(NOT_FOUND_USER);
    const out = await profileVisitors.recordVisit(ownerUid, req.authUid);
    return res.json({ recorded: out.recorded });
  } catch (err) {
    console.error("recordProfileVisit error:", err);
    return res.status(500).json({ error: "Không ghi nhận được lượt ghé thăm." });
  }
}

/**
 * GET /api/users/me/visitors — danh sách khách ghé thăm hồ sơ CỦA CHÍNH MÌNH: tối đa PROFILE.VISITORS_MAX, mới nhất trước, không trùng.
 * Mỗi phần tử = hồ sơ công khai của khách (tên hiển thị, Tag Name Search, huy hiệu, avatar…) + `visitedAt` (ISO). Chỉ chủ hồ sơ xem được (requireAuth + uid lấy từ token).
 */
async function listMyVisitors(req, res) {
  try {
    const visitors = await profileVisitors.listVisitors(req.authUid);
    res.set("Cache-Control", "no-store");
    return res.json({ visitors, max: PROFILE.VISITORS_MAX });
  } catch (err) {
    console.error("listMyVisitors error:", err);
    return res.status(500).json({ error: "Không tải được danh sách khách ghé thăm." });
  }
}

/**
 * PATCH /api/users/me
 * Dùng cho màn hình "Chào mừng & Setup tài khoản" khi đăng nhập lần đầu, và
 * cho việc chỉnh sửa hồ sơ sau này. KHÔNG cho phép đổi email/password ở đây.
 * body: { displayName?, birthday?, gender?, country?, bio? }
 *
 * v2.2.0: `fullName` (tên thật) bị TỪ CHỐI ở đây — đổi tên thật phải đi qua PUT /users/me/real-name (cần vừa nhập lại mật khẩu).
 * Tag Name Search cũng có endpoint riêng (PUT /users/me/tag-name) vì phải đổi khoá duy nhất trong một transaction.
 */
async function updateMe(req, res) {
  try {
    if (req.body && req.body.fullName !== undefined) {
      return res.status(400).json({
        error: "Đổi tên thật cần xác nhận lại mật khẩu — hãy dùng Cài đặt > Tài khoản > Thông tin.",
        code: "USE_REAL_NAME_ENDPOINT",
      });
    }
    // v2.5.2: `bio` (Tiểu sử) — đã làm sạch + kiểm độ dài ở validator (middleware/validators.js#bioField).
    const allowedFields = ["displayName", "birthday", "gender", "country", "bio"];
    const updates = {};
    for (const field of allowedFields) {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    }

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ error: "Không có dữ liệu để cập nhật." });
    }

    // v2.5.3 [TW-25]: trước đây ghi HAI lần (hồ sơ rồi `isFirstLogin`) — request chết giữa hai lần để lại hồ sơ đã sửa nhưng vẫn "đăng nhập lần đầu". Nay gộp MỘT lần `update` (nguyên tử).
    // Nếu đây là setup lần đầu, đánh dấu đã hoàn tất cùng lúc.
    if (req.authUser.isFirstLogin) updates.isFirstLogin = false;
    await db.collection(COLLECTIONS.USERS).doc(req.authUid).update(updates);

    return res.json({ message: "Cập nhật hồ sơ thành công." });
  } catch (err) {
    console.error("updateMe error:", err);
    return res.status(500).json({ error: "Cập nhật thất bại." });
  }
}

/**
 * POST /api/users/me/avatar
 * multipart/form-data, field "avatar". Ảnh nên được crop 1:1 ở frontend trước khi upload.
 *
 * Lưu ý: không dùng streamifier.from() — API đúng là createReadStream(),
 * hoặc đơn giản hơn là uploadStream.end(buffer) (không cần streamifier).
 */
async function uploadAvatar(req, res) {
  try {
    const { cloud_name, api_key, api_secret } = cloudinary.config();
    if (!cloud_name || !api_key || !api_secret) {
      console.error(
        "uploadAvatar: Cloudinary chưa được cấu hình đầy đủ (CLOUDINARY_CLOUD_NAME / API_KEY / API_SECRET)."
      );
      return res.status(503).json({
        error:
          "Máy chủ chưa cấu hình Cloudinary. Vui lòng kiểm tra biến môi trường CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET trên Render.",
      });
    }

    if (!req.file) {
      return res.status(400).json({ error: "Chưa chọn file ảnh hoặc file không hợp lệ." });
    }
    if (!req.file.buffer || req.file.buffer.length === 0) {
      return res.status(400).json({ error: "File ảnh rỗng, vui lòng chọn ảnh khác." });
    }

    // ==== VÁ #6 [LOW] — Kiểm tra file upload chỉ dựa vào mimetype (v0.8.3) ====
    // `middleware/upload.js` trước đây chỉ kiểm tra `file.mimetype` — giá trị
    // này do CLIENT tự khai báo trong header multipart, không phải điều
    // server xác minh từ nội dung file thật. Đổi Content-Type là qua được
    // filter đó dù file thực chất không phải ảnh. Ở đây đọc "magic bytes"
    // (vài byte đầu file) bằng `file-type` để xác định định dạng THẬT trước
    // khi đẩy lên Cloudinary — chỉ có thể làm ở bước này (không thể làm
    // trong `fileFilter` của multer vì buffer chưa đọc xong lúc đó).
    // v0.10.20: danh sách cho phép lấy từ ASSET_LIMITS (bỏ GIF/AVIF — xem utils/constants.js).
    const ALLOWED_IMAGE_MIMES = new Set(ASSET_LIMITS[ASSET_KIND.AVATAR].ALLOWED_MIMES);
    // v2.0.10 [BẢO MẬT F11]: kiểm chữ ký ảnh bằng mã của Twelve TRƯỚC, và chỉ đưa 4 KB đầu cho `file-type`
    // (xem utils/input.js#sniffImageMime — file-type cũ lặp vô hạn với file ASF dị dạng).
    const sniffed = sniffImageMime(req.file.buffer);
    const { fileTypeFromBuffer } = await import("file-type");
    const detected = sniffed ? await fileTypeFromBuffer(req.file.buffer.subarray(0, 4100)) : null;
    if (!sniffed || !ALLOWED_IMAGE_MIMES.has(sniffed) || !detected || !ALLOWED_IMAGE_MIMES.has(detected.mime)) {
      return res.status(400).json({
        error: "File không phải ảnh hợp lệ (nội dung file không khớp định dạng ảnh được hỗ trợ).",
      });
    }

    // v0.10.20: public_id CỐ ĐỊNH + overwrite (xem services/assets.service.js) — mỗi
    // user luôn chỉ có 1 avatar trên Cloudinary, đổi avatar không còn sinh ảnh mồ côi.
    const previousUrl = req.authUser?.avatarUrl || null;
    const uploadResult = await assets.putAvatar(req.authUid, req.file.buffer);

    if (!uploadResult?.secure_url) {
      console.error("Cloudinary trả về không có secure_url:", uploadResult);
      return res.status(500).json({ error: "Cloudinary không trả về URL ảnh." });
    }

    // Ghi user.avatarUrl + sổ `assets` trong 1 batch. Nếu bước này lỗi, ảnh trên
    // Cloudinary vẫn chỉ là 1 asset cố định của user (lần upload sau sẽ ghi đè) → không rò rỉ thêm.
    await assets.commitAvatarRecord(req.authUid, uploadResult);

    // Dọn lười asset avatar KIỂU CŨ (public_id ngẫu nhiên) của chính user này, nếu có.
    await assets.releaseSupersededAvatar(req.authUid, previousUrl, avatarPublicId(req.authUid));

    return res.json({ avatarUrl: uploadResult.secure_url });
  } catch (err) {
    // v0.9.6 [MEDIUM]: trước đây khối catch này tự dựng message chi tiết
    // (kể cả nội dung lỗi thô từ Cloudinary — có thể chứa mảnh api_key/
    // cloud_name) rồi trả THẲNG cho client, bỏ qua hoàn toàn error handler
    // tập trung ở server.js (vốn đã được vá để ẩn chi tiết ở production).
    // Log đầy đủ server-side để debug, nhưng chỉ trả message an toàn cho
    // client ở production; giữ chi tiết ở development để tiện debug local.
    console.error("uploadAvatar error:", err);
    const detail =
      err?.message ||
      err?.error?.message ||
      (typeof err === "string" ? err : null) ||
      "Tải ảnh đại diện thất bại.";
    const isProd = process.env.NODE_ENV === "production";
    return res.status(500).json({
      error: isProd ? "Tải ảnh đại diện thất bại. Vui lòng thử lại sau." : `Tải ảnh đại diện thất bại: ${detail}`,
    });
  }
}

// ==== v2.4.0 — Ảnh bìa hồ sơ ====
// v2.4.1: kèm KHUNG HIỂN THỊ `users/{uid}.coverCrop` ({x,y,width,height} theo % ảnh gốc) — người dùng kéo/thu phóng ảnh bìa như avatar
// nhưng KHÔNG cắt cứng ảnh, nên chỉnh lại được bất cứ lúc nào và dùng được cả cho ảnh dán bằng URL ngoài.
// Hai nguồn, MỘT trường `users/{uid}.coverUrl`:
//   • tải lên (POST /me/cover) → Cloudinary, public_id cố định theo uid, có dòng trong sổ `assets`;
//   • dán URL ngoài (PUT /me/cover) → chỉ lưu URL (đã kiểm https + domain được phép nhúng), không giữ file nào.
// Chuyển từ nguồn này sang nguồn kia (hoặc xoá) thì file Twelve đang giữ được gỡ để không thành rác.

/** URL này có trỏ vào CHÍNH ảnh bìa Twelve đang giữ cho `uid` không? (để không xoá file mà URL mới vẫn dùng) */
function pointsAtOwnCoverAsset(uid, url) {
  const parsed = parseCloudinaryUrl(url);
  return !!parsed && parsed.publicId === coverPublicId(uid) && parsed.cloudName === cloudinary.config().cloud_name;
}

/** POST /api/users/me/cover — multipart, field "cover". Frontend cắt 3:1 (1500x500) trước khi gửi. */
async function uploadCover(req, res) {
  try {
    const { cloud_name, api_key, api_secret } = cloudinary.config();
    if (!cloud_name || !api_key || !api_secret) {
      console.error("uploadCover: Cloudinary chưa được cấu hình đầy đủ.");
      return res.status(503).json({
        error:
          "Máy chủ chưa cấu hình Cloudinary. Vui lòng kiểm tra biến môi trường CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET trên Render.",
      });
    }
    if (!req.file) return res.status(400).json({ error: "Chưa chọn file ảnh hoặc file không hợp lệ." });
    if (!req.file.buffer || req.file.buffer.length === 0) {
      return res.status(400).json({ error: "File ảnh rỗng, vui lòng chọn ảnh khác." });
    }
    // v2.4.1: khung hiển thị (trường multipart "crop", chuỗi JSON) — kiểm TRƯỚC khi chạm Cloudinary.
    const crop = parseCoverCrop(req.body && req.body.crop);
    if (!crop.ok) return res.status(400).json({ error: crop.error });

    // Cùng cách kiểm chữ ký ảnh như avatar (v2.0.10 [F11]): mã của Twelve trước, chỉ đưa 4 KB đầu cho `file-type`.
    const allowed = new Set(ASSET_LIMITS[ASSET_KIND.COVER].ALLOWED_MIMES);
    const sniffed = sniffImageMime(req.file.buffer);
    const { fileTypeFromBuffer } = await import("file-type");
    const detected = sniffed ? await fileTypeFromBuffer(req.file.buffer.subarray(0, 4100)) : null;
    if (!sniffed || !allowed.has(sniffed) || !detected || !allowed.has(detected.mime)) {
      return res.status(400).json({ error: "File không phải ảnh hợp lệ (nội dung file không khớp định dạng ảnh được hỗ trợ)." });
    }

    const uploadResult = await assets.putCover(req.authUid, req.file.buffer);
    if (!uploadResult?.secure_url) {
      console.error("Cloudinary trả về không có secure_url (cover):", uploadResult);
      return res.status(500).json({ error: "Cloudinary không trả về URL ảnh." });
    }
    await assets.commitCoverRecord(req.authUid, uploadResult, crop.value || null);
    return res.json({ coverUrl: uploadResult.secure_url, coverCrop: crop.value || null });
  } catch (err) {
    console.error("uploadCover error:", err);
    const detail = err?.message || err?.error?.message || (typeof err === "string" ? err : null) || "Tải ảnh bìa thất bại.";
    const isProd = process.env.NODE_ENV === "production";
    return res.status(500).json({ error: isProd ? "Tải ảnh bìa thất bại. Vui lòng thử lại sau." : `Tải ảnh bìa thất bại: ${detail}` });
  }
}

/** PUT /api/users/me/cover  body: { url, crop? } — dùng ảnh từ đường dẫn bên ngoài. Không gửi crop: ảnh mới => khung mặc định (canh giữa). */
async function setCoverUrl(req, res) {
  try {
    const url = req.body && req.body.url;
    const previous = req.authUser?.coverUrl || null;
    const err = validateProfileCoverUrl(url, previous);
    if (err) return res.status(400).json({ error: err });
    const crop = parseCoverCrop(req.body.crop);
    if (!crop.ok) return res.status(400).json({ error: crop.error });
    const trimmed = url.trim();
    // Cùng URL đang dùng + không gửi crop => giữ nguyên khung đang có; URL khác => khung mặc định.
    const nextCrop = crop.value !== undefined ? crop.value : trimmed === previous ? req.authUser?.coverCrop || null : null;

    await db.collection(COLLECTIONS.USERS).doc(req.authUid).update({ coverUrl: trimmed, coverCrop: nextCrop });
    // Đang dùng ảnh tải lên mà chuyển sang URL ngoài => gỡ file Twelve đang giữ (trừ khi URL mới chính là file đó).
    if (trimmed !== previous && !pointsAtOwnCoverAsset(req.authUid, trimmed)) {
      await assets.releaseCoverAsset(req.authUid);
    }
    return res.json({ coverUrl: trimmed, coverCrop: nextCrop });
  } catch (err) {
    console.error("setCoverUrl error:", err);
    return res.status(500).json({ error: "Cập nhật ảnh bìa thất bại." });
  }
}

/**
 * PUT /api/users/me/cover/crop  body: { crop } — chỉnh lại khung hiển thị của ảnh bìa ĐANG CÓ (tải lên hay URL ngoài đều được),
 * không đụng tới ảnh. crop = null: về khung mặc định.
 */
async function setCoverCrop(req, res) {
  try {
    if (!req.authUser?.coverUrl) return res.status(400).json({ error: "Bạn chưa có ảnh bìa để chỉnh." });
    const crop = parseCoverCrop(req.body && req.body.crop);
    if (!crop.ok || crop.value === undefined) {
      return res.status(400).json({ error: crop.ok ? "Thiếu khung ảnh bìa (crop)." : crop.error });
    }
    await db.collection(COLLECTIONS.USERS).doc(req.authUid).update({ coverCrop: crop.value });
    return res.json({ coverUrl: req.authUser.coverUrl, coverCrop: crop.value });
  } catch (err) {
    console.error("setCoverCrop error:", err);
    return res.status(500).json({ error: "Cập nhật khung ảnh bìa thất bại." });
  }
}

/** DELETE /api/users/me/cover — gỡ ảnh bìa (về ảnh bìa mặc định). Idempotent. */
async function removeCover(req, res) {
  try {
    await db.collection(COLLECTIONS.USERS).doc(req.authUid).update({ coverUrl: null, coverCrop: null });
    await assets.releaseCoverAsset(req.authUid);
    return res.json({ coverUrl: null, coverCrop: null });
  } catch (err) {
    console.error("removeCover error:", err);
    return res.status(500).json({ error: "Gỡ ảnh bìa thất bại." });
  }
}

module.exports = {
  getMe,
  getPublicProfile,
  getPublicProfileByTag,
  updateMe,
  uploadAvatar,
  uploadCover,
  setCoverUrl,
  setCoverCrop,
  removeCover,
  listUserPosts,
  listPinnedPosts,
  listUserBlogs,
  getExtraInfo,
  updateExtras,
  recordProfileVisit,
  listMyVisitors,
};
