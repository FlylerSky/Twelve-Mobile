/**
 * ==== v2.5.3.2 [TW-01] — `GET /api/admin/ip-topology` (Cài đặt › Quản trị › Nhận diện IP; chỉ SA) ====
 *
 * Trả về cách server thấy CHÍNH request này (địa chỉ socket, chuỗi X-Forwarded-For, CF-Connecting-IP) và khoá IP sẽ ra gì ở từng cấu hình ứng viên (`TRUST_PROXY_HOPS=0…4`,
 * `TRUST_PROXY_MODE=cloudflare`), kèm kết luận so với CF-Connecting-IP. Mục đích: đo topology Render/Cloudflare thật bằng UI thay vì bật `DEBUG_IP_TOPOLOGY` rồi đọc log.
 *
 * An toàn: chỉ đọc, không ghi gì; nằm dưới `admin.routes` (requireAuth → requireActive → requireSA); hàm mô tả (utils/clientIp.js#describeIpTopology) chỉ đọc ba nguồn
 * địa chỉ nói trên, mọi giá trị trả ra đã được kiểm là IP hợp lệ (hoặc chuỗi header đã cắt/lọc ký tự), KHÔNG bao giờ trả `Authorization`, `x-twelve-ssr-secret` hay header khác.
 * Dữ liệu là IP của chính người gọi (SA) — không nhạy cảm với người khác. Không lưu, không log. `no-store` để trình duyệt/proxy không giữ lại.
 * (Không đọc `req.ip` ở đây: mọi truy cập địa chỉ client đi qua utils/clientIp.js — có test canh.)
 */
const { describeIpTopology } = require("../utils/clientIp");

function getIpTopology(req, res) {
  try {
    res.set("Cache-Control", "no-store");
    return res.json(describeIpTopology(req));
  } catch (err) {
    console.error("ipTopology.getIpTopology error:", err);
    return res.status(500).json({ error: "Không đo được nhận diện IP." });
  }
}

module.exports = { getIpTopology };
