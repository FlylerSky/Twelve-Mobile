const { db, auth } = require("../config/firebase");
const { healOrphanByEmail } = require("../services/orphanAuth");
const {
  COLLECTIONS,
  ACCOUNT_STATUS,
  ACCOUNT_ROLE,
  ROLE_TO_GROUP,
} = require("../utils/constants");
const {
  normalizeTagName,
  isValidTagName,
  isReservedTagName,
} = require("../utils/helpers");

/**
 * POST /api/auth/register
 * body: { fullName, displayName, tagName, birthday, gender, country, email, password }
 *
 * Tạo user trong Firebase Auth (enabled, emailVerified=false) + doc Firestore (status=PENDING).
 * Email xác minh được gửi từ Frontend bằng Firebase Client SDK (sendEmailVerification)
 * — không còn dùng Resend / mã kích hoạt tùy chỉnh.
 */
async function register(req, res) {
  try {
    const {
      fullName,
      displayName,
      tagName: rawTagName,
      birthday,
      gender,
      country,
      email,
      password,
    } = req.body;

    if (!fullName || !displayName || !rawTagName || !birthday || !gender || !country || !email || !password) {
      return res.status(400).json({ error: "Vui lòng điền đầy đủ thông tin đăng ký." });
    }

    if (!isValidTagName(rawTagName)) {
      return res.status(400).json({
        error: "Tag Name Search không hợp lệ. Chỉ dùng chữ thường, số, gạch dưới, 3-20 ký tự.",
      });
    }

    // v2.2.1 [A-04]: tag dành riêng (admin/twelve/support…) không đăng ký được — chặn mạo danh quản trị.
    if (isReservedTagName(rawTagName)) {
      return res.status(409).json({ error: "Tag Name Search này được dành riêng, vui lòng chọn tên khác." });
    }

    const tagName = normalizeTagName(rawTagName);
    const tagRef = db.collection(COLLECTIONS.TAGNAMES).doc(tagName);

    // Tạo user trong Firebase Auth — enabled để client có thể gọi sendEmailVerification
    // v2.0.5: kiểm tra tagName TRƯỚC khi tạo user Firebase. Trước đây luôn tạo user rồi mới phát hiện tag đã
    // dùng và phải xoá user vừa tạo (tốn 2 lệnh Auth, và để lại user mồ côi nếu tiến trình chết giữa chừng).
    // Giao dịch bên dưới vẫn là chốt chặn cuối cùng chống race.
    if ((await tagRef.get()).exists) {
      return res.status(409).json({ error: "Tag Name Search này đã được sử dụng." });
    }

    const createArgs = { email, password, displayName, emailVerified: false, disabled: false };
    let userRecord;
    try {
      userRecord = await auth.createUser(createArgs);
    } catch (err) {
      if (err.code !== "auth/email-already-exists") throw err;
      // v2.0.12 [N3]: email có thể đang bị giữ bởi tài khoản Auth MỒ CÔI do lần đăng ký trước bị ngắt giữa chừng (có dấu
      // registrationMarkers, không có hồ sơ, quá 10 phút). Dọn rồi thử lại đúng 1 lần; mọi trường hợp khác giữ nguyên 409.
      if (!(await healOrphanByEmail(email))) {
        return res.status(409).json({ error: "Email này đã được đăng ký." });
      }
      try {
        userRecord = await auth.createUser(createArgs);
      } catch (err2) {
        if (err2.code === "auth/email-already-exists") return res.status(409).json({ error: "Email này đã được đăng ký." });
        throw err2;
      }
    }

    const markerRef = db.collection(COLLECTIONS.REGISTRATION_MARKERS).doc(userRecord.uid);
    try {
      // Dấu "đang đăng ký dở": được xoá trong CHÍNH giao dịch tạo hồ sơ bên dưới; nếu tiến trình chết giữa chừng, dấu còn
      // sót cho phép dọn tài khoản Auth mồ côi một cách an toàn (xem services/orphanAuth.js).
      await markerRef.set({ email, createdAtMs: Date.now() });
      // Giao dịch: đảm bảo tagName chưa tồn tại rồi mới ghi user
      await db.runTransaction(async (tx) => {
        const tagSnap = await tx.get(tagRef);
        if (tagSnap.exists) {
          throw Object.assign(new Error("TAGNAME_TAKEN"), { code: "TAGNAME_TAKEN" });
        }

        const userRef = db.collection(COLLECTIONS.USERS).doc(userRecord.uid);
        // v2.2.0: tên thật nằm ở `userPrivate/{uid}` (Client SDK không đọc được), KHÔNG còn nằm trong hồ sơ `users/{uid}`
        // vì hồ sơ đó chủ tài khoản đọc thẳng được từ trình duyệt — xem services/userPrivate.js.
        tx.set(db.collection(COLLECTIONS.USER_PRIVATE).doc(userRecord.uid), { fullName, createdAt: new Date().toISOString() });
        tx.set(userRef, {
          uid: userRecord.uid,
          displayName,
          tagName,
          birthday,
          gender,
          country,
          email,
          avatarUrl: null,
          accountRole: ACCOUNT_ROLE.USER,
          accountGroup: ROLE_TO_GROUP[ACCOUNT_ROLE.USER],
          status: ACCOUNT_STATUS.PENDING,
          isFirstLogin: true,
          // postsScoreSum chỉ là CACHE (xem utils/helpers.js#postsScoreSumWrite)
          // — khởi tạo 0 cho nhất quán, không phải nguồn sự thật. KHÔNG hiển
          // thị trên UI frontend ở thời điểm hiện tại (v0.8.8).
          postsScoreSum: 0,
          // positiveScore (v0.8.17): NGƯỢC LẠI với postsScoreSum — đây LÀ
          // nguồn sự thật (cộng/trừ thuần túy, không tính lại từ đâu cả). Xem
          // utils/helpers.js#positiveScoreWrite để biết đầy đủ ngữ nghĩa
          // (có thể âm, không hồi tố hành động trước v0.8.17).
          positiveScore: 0,
          // accountScore (v0.8.23) = postsScoreSum + positiveScore — CŨNG
          // chỉ là cache (giống postsScoreSum), tự đối soát ở
          // utils/helpers.js#syncAccountScore (đăng nhập/truy cập) và ngay
          // tại mọi nơi ghi postsScoreSum/positiveScore (cộng cùng delta).
          // Hiển thị trên UI frontend (Menu > card info user), bấm vào xem
          // chi tiết nguồn gốc.
          accountScore: 0,
          // weeklySnapshot (v0.10.0) — mốc accountScore đầu tuần hiện tại,
          // dùng để tính "Điểm tăng trong tuần" ở trang Xu hướng (xem
          // trending.controller.js). null = chưa có mốc nào (sẽ tự khởi tạo
          // ở lần tính bảng xếp hạng tuần đầu tiên chạm tới tài khoản này).
          weeklySnapshot: null,
          createdAt: new Date().toISOString(),
        });
        tx.set(tagRef, { uid: userRecord.uid });
        tx.delete(markerRef);
      });
    } catch (err) {
      // rollback: xoá user vừa tạo trong Firebase Auth nếu ghi Firestore thất bại
      await auth.deleteUser(userRecord.uid).catch(() => {});
      await markerRef.delete().catch(() => {});
      if (err.code === "TAGNAME_TAKEN") {
        return res.status(409).json({ error: "Tag Name Search này đã có người dùng." });
      }
      throw err;
    }

    return res.status(201).json({
      message:
        "Đăng ký thành công. Vui lòng đăng nhập và xác minh email (Firebase sẽ gửi link xác minh) để kích hoạt tài khoản.",
      uid: userRecord.uid,
    });
  } catch (err) {
    console.error("register error:", err);
    return res.status(500).json({ error: "Đăng ký thất bại, vui lòng thử lại." });
  }
}

/**
 * GET /api/auth/check-tagname?tag=abc
 */
async function checkTagName(req, res) {
  const raw = req.query.tag || "";
  if (!isValidTagName(raw)) {
    return res.status(400).json({ available: false, error: "Tag Name Search không hợp lệ." });
  }
  // v2.2.1 [A-04]: tag dành riêng báo "không dùng được" (frontend hiển thị như tag đã có người dùng).
  if (isReservedTagName(raw)) return res.json({ available: false, reserved: true });
  const tagName = normalizeTagName(raw);
  const snap = await db.collection(COLLECTIONS.TAGNAMES).doc(tagName).get();
  return res.json({ available: !snap.exists });
}

/**
 * POST /api/auth/activation/sync
 * body: {} (dùng token Authorization)
 *
 * Frontend gọi sau khi phát hiện emailVerified=true (từ Firebase Auth).
 * Đồng bộ status Firestore từ PENDING → ACTIVE.
 */
async function syncActivation(req, res) {
  try {
    const uid = req.authUid;
    if (!uid) {
      return res.status(401).json({ error: "Chưa đăng nhập." });
    }

    // Kiểm tra emailVerified từ token đã decode (middleware đã verify)
    // req.authUser lấy từ Firestore; email_verified nằm trên decoded token.
    // Để chắc chắn, lấy lại userRecord từ Auth.
    const userRecord = await auth.getUser(uid);
    if (!userRecord.emailVerified) {
      return res.status(400).json({
        error: "Email chưa được xác minh. Vui lòng bấm link trong email Firebase gửi.",
        emailVerified: false,
      });
    }

    // v2.5.3 [TW-25]: trước đây `userRef.update({ status: ACTIVE })` KHÔNG kèm điều kiện trạng thái hiện tại — middleware đã chặn suspended/deleting, nhưng nếu SA khoá tài khoản
    // (hoặc quy trình xoá bắt đầu) đúng khoảng giữa lúc middleware đọc và lúc ghi này thì lệnh ghi vẫn lật trạng thái về `active`. Nay đọc lại và ghi trong MỘT transaction,
    // chỉ chuyển `pending → active`; mọi trạng thái khác (suspended, deleting, hồ sơ ma không có status) được giữ nguyên.
    const userRef = db.collection(COLLECTIONS.USERS).doc(uid);
    const outcome = await db.runTransaction(async (tx) => {
      const snap = await tx.get(userRef);
      if (!snap.exists) return { kind: "missing" };
      const status = snap.data().status;
      if (status === ACCOUNT_STATUS.ACTIVE) return { kind: "already" };
      if (status !== ACCOUNT_STATUS.PENDING) return { kind: "blocked", status };
      tx.update(userRef, { status: ACCOUNT_STATUS.ACTIVE });
      return { kind: "activated" };
    });

    if (outcome.kind === "missing") return res.status(404).json({ error: "Không tìm thấy hồ sơ người dùng." });
    if (outcome.kind === "already") return res.json({ message: "Tài khoản đã active.", status: ACCOUNT_STATUS.ACTIVE });
    if (outcome.kind === "blocked") {
      const code = outcome.status === ACCOUNT_STATUS.SUSPENDED ? "ACCOUNT_SUSPENDED" : outcome.status === ACCOUNT_STATUS.DELETING ? "ACCOUNT_DELETING" : "ACCOUNT_NOT_ACTIVATABLE";
      return res.status(403).json({ error: "Không thể kích hoạt tài khoản ở trạng thái hiện tại.", code });
    }
    return res.json({
      message: "Kích hoạt tài khoản thành công.",
      status: ACCOUNT_STATUS.ACTIVE,
    });
  } catch (err) {
    console.error("syncActivation error:", err);
    return res.status(500).json({ error: "Đồng bộ trạng thái thất bại." });
  }
}

/**
 * ==== v2.2.0 — Quên mật khẩu ====
 * POST /api/auth/forgot-password   body: { email, captchaToken }
 *
 * Backend + Firebase cùng làm: backend lo CAPTCHA (verifyCaptcha), giới hạn tần suất (theo IP ở route, theo EMAIL ở đây), chỉ gửi cho tài khoản
 * Twelve hợp lệ và LUÔN trả cùng một câu trả lời dù email có tồn tại hay không (không cho dò tài khoản); Firebase lo phần gửi email thật
 * bằng template "Password reset" cấu hình trong Firebase Console (REST `accounts:sendOobCode`). Twelve không có mailer riêng nên đây là cách
 * duy nhất vừa để backend kiểm soát vừa không cần domain gửi email.
 *
 * Cần biến môi trường FIREBASE_WEB_API_KEY (cùng giá trị VITE_FIREBASE_API_KEY — key Web này vốn công khai). Nếu key bị giới hạn theo
 * HTTP referrer, đặt thêm FIREBASE_WEB_API_REFERER (mặc định: origin đầu tiên trong CORS_ORIGIN).
 *
 * Lưu ý thẳng: Firebase API key là công khai nên ai cũng có thể gọi thẳng Firebase để gửi email đặt lại mật khẩu mà không qua endpoint này;
 * lớp bảo vệ ở đây chặn lạm dụng QUA ỨNG DỤNG Twelve và đưa mọi thứ về một đường duy nhất, nhưng không thể thay thế cấu hình chống
 * lạm dụng của Firebase (Authentication > Settings).
 */
const FORGOT_GENERIC_MESSAGE =
  "Nếu email này thuộc một tài khoản Twelve, chúng tôi đã gửi hướng dẫn đặt lại mật khẩu. Vui lòng kiểm tra hộp thư (kể cả mục spam).";
const FORGOT_EMAIL_COOLDOWN_MS = 60 * 1000;
const FORGOT_EMAIL_MAX_PER_HOUR = 5;
const forgotByEmail = new Map(); // email -> [timestamp...] (trong bộ nhớ từng instance — Firebase còn giới hạn riêng của nó)

function emailRateLimited(email, now = Date.now()) {
  const hits = (forgotByEmail.get(email) || []).filter((t) => now - t < 60 * 60 * 1000);
  if (hits.length >= FORGOT_EMAIL_MAX_PER_HOUR || (hits.length && now - hits[hits.length - 1] < FORGOT_EMAIL_COOLDOWN_MS)) {
    forgotByEmail.set(email, hits);
    return true;
  }
  hits.push(now);
  forgotByEmail.set(email, hits);
  if (forgotByEmail.size > 5000) forgotByEmail.delete(forgotByEmail.keys().next().value);
  return false;
}

// Tài khoản đăng ký TRƯỚC v2.0.5 được lưu với email Gmail đã bỏ dấu chấm/"+tag" (xem frontend/src/utils/email.js): thử cả hai dạng.
function emailCandidates(email) {
  const out = [email];
  const at = email.lastIndexOf("@");
  if (at > 0) {
    let local = email.slice(0, at);
    let domain = email.slice(at + 1);
    if (["gmail.com", "googlemail.com", "outlook.com", "hotmail.com", "live.com", "yahoo.com", "icloud.com", "me.com"].includes(domain)) local = local.split("+")[0];
    if (domain === "gmail.com" || domain === "googlemail.com") {
      local = local.replace(/\./g, "");
      domain = "gmail.com";
    }
    const legacy = `${local}@${domain}`;
    if (legacy !== email) out.push(legacy);
  }
  return out;
}

async function findTwelveAuthUser(email) {
  for (const candidate of emailCandidates(email)) {
    try {
      return await auth.getUserByEmail(candidate);
    } catch (err) {
      if (err.code !== "auth/user-not-found") throw err;
    }
  }
  return null;
}

/**
 * v2.2.1 [A-03] — phần việc TỐN THỜI GIAN và PHỤ THUỘC email có tồn tại hay không (tra Auth, đọc hồ sơ, gọi Firebase gửi email) được tách ra
 * và chạy SAU KHI đã trả lời client. Trước đây email có tài khoản mất thêm 1 lượt đọc Firestore + 1 lượt gọi identitytoolkit nên phản hồi
 * chậm hơn rõ rệt (kênh phụ thời gian), và các nhánh lỗi 502/429 chỉ xuất hiện với email có thật (kênh phụ về mã trạng thái) — cùng thông điệp
 * chung nhưng vẫn phân biệt được. Mọi chi tiết lỗi nay chỉ được ghi LOG.
 * Không bao giờ ném lỗi ra ngoài (đã trả lời client rồi).
 */
async function sendResetIfEligible(email, apiKey) {
  try {
    const record = await findTwelveAuthUser(email);
    if (!record) return;

    // Chỉ gửi cho tài khoản Twelve có hồ sơ và không bị khoá/đang xoá (tài khoản Auth của ứng dụng khác trong cùng dự án Firebase không thuộc Twelve).
    const profile = await db.collection(COLLECTIONS.USERS).doc(record.uid).get();
    if (!profile.exists || [ACCOUNT_STATUS.SUSPENDED, ACCOUNT_STATUS.DELETING].includes(profile.data().status)) return;

    const referer = process.env.FIREBASE_WEB_API_REFERER || (process.env.CORS_ORIGIN || "").split(",")[0].trim();
    const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${encodeURIComponent(apiKey)}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Firebase-Locale": "vi", // email bằng tiếng Việt
        ...(referer ? { Referer: referer.endsWith("/") ? referer : `${referer}/` } : {}),
      },
      body: JSON.stringify({ requestType: "PASSWORD_RESET", email: record.email }),
    });
    if (!resp.ok) {
      const body = await resp.json().catch(() => ({}));
      const code = body && body.error && body.error.message;
      // Chỉ log (không còn trả 429/502 riêng cho email có thật): theo dõi qua log để biết Firebase đang từ chối/giới hạn.
      console.error("forgotPassword: Firebase từ chối sendOobCode:", resp.status, code);
    }
  } catch (err) {
    console.error("forgotPassword (nền) error:", err);
  }
}

async function forgotPassword(req, res) {
  const apiKey = process.env.FIREBASE_WEB_API_KEY;
  if (!apiKey) {
    // Lỗi CẤU HÌNH — không phụ thuộc email nên không lộ gì về tài khoản.
    console.error("forgotPassword: thiếu FIREBASE_WEB_API_KEY — không gửi được email đặt lại mật khẩu.");
    return res.status(503).json({ error: "Máy chủ chưa cấu hình gửi email đặt lại mật khẩu (thiếu FIREBASE_WEB_API_KEY)." });
  }
  const email = req.body.email; // validator đã trim + chữ thường

  // Trả lời NGAY, cùng một câu, cùng một mã, cùng một thời gian cho mọi email (có/không có tài khoản, bị giới hạn theo email hay không).
  res.json({ message: FORGOT_GENERIC_MESSAGE });

  if (emailRateLimited(email)) return; // chặn theo email vẫn giữ nguyên: chỉ khác là không còn ảnh hưởng nội dung/thời gian phản hồi
  await sendResetIfEligible(email, apiKey);
}

/**
 * (Legacy / optional) POST /api/auth/activation/send
 * Giữ endpoint để tương thích tạm thời, nhưng chỉ trả về hướng dẫn dùng Firebase.
 * Không còn gửi mã tùy chỉnh.
 */
async function sendActivation(req, res) {
  return res.status(410).json({
    error:
      "Tính năng mã kích hoạt tùy chỉnh đã được thay bằng Firebase Email Verification. " +
      "Hãy đăng nhập rồi dùng nút 'Gửi lại email xác minh' trên giao diện (Firebase Client SDK).",
    code: "USE_FIREBASE_EMAIL_VERIFICATION",
  });
}

/**
 * (Legacy) POST /api/auth/activation/verify
 * Không còn hỗ trợ mã 6 số.
 */
async function verifyActivation(req, res) {
  return res.status(410).json({
    error:
      "Tính năng mã kích hoạt tùy chỉnh đã bị gỡ. Vui lòng xác minh qua link email do Firebase gửi.",
    code: "USE_FIREBASE_EMAIL_VERIFICATION",
  });
}

module.exports = {
  register,
  checkTagName,
  forgotPassword,
  __test: { emailRateLimited, emailCandidates, forgotByEmail },
  syncActivation,
  sendActivation,
  verifyActivation,
};
