/**
 * ==== v2.3.0 — API của mục "Gỡ lỗi" (Cài đặt → Quản trị) ====
 *   GET  /api/admin/debug/modules            → danh sách module + lần chạy gần nhất (tóm tắt)
 *   POST /api/admin/debug/modules/:id/run    → chạy MỘT module, trả kết quả đầy đủ (kiểm tra, số đo, log)
 * Mọi route nằm dưới admin.routes (requireAuth → requireActive → requireSA); route chạy còn đòi nhập lại mật khẩu gần đây + giới hạn tần suất.
 * Client chỉ gửi `id`; KHÔNG có cách nào đưa mã, lệnh hay tham số vào module.
 */
const { runModule, listModules } = require("../debug/runner");
const { ID_RE } = require("../debug/registry");

async function getModules(req, res) {
  try {
    return res.json(await listModules());
  } catch (err) {
    console.error("debug.getModules error:", err);
    return res.status(500).json({ error: "Không tải được danh sách module." });
  }
}

async function runOne(req, res) {
  try {
    const id = String(req.params.id || "");
    if (id.length > 64 || !ID_RE.test(id)) return res.status(404).json({ error: "Không có module này.", code: "DEBUG_NOT_FOUND" });
    const result = await runModule(id, { actorUid: req.authUid });
    return res.json(result);
  } catch (err) {
    if (err && err.status) return res.status(err.status).json({ error: err.message, code: err.code });
    console.error("debug.runOne error:", err);
    return res.status(500).json({ error: "Không chạy được module." });
  }
}

module.exports = { getModules, runOne };
