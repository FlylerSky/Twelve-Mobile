const rateLimit = require("express-rate-limit");
const { getClientKey, isTrustedSsrProxy } = require("../utils/clientIp");

/**
 * ==== v0.9.6 [HIGH] — Rate limiting riêng cho endpoint nghiệp vụ ====
 *
 * Trước đây các hành vi nghiệp vụ nhạy cảm (like/dislike, comment, share,
 * cập nhật hồ sơ) CHỈ được bảo vệ bởi `globalLimiter` dùng chung cho toàn
 * bộ `/api` (300 req/15 phút/IP — xem server.js). Không có giới hạn RIÊNG
 * cho từng hành vi, và limiter dùng chung chỉ tính theo IP, nên:
 *   - 1 IP có thể "đốt" gần hết 300 req/15 phút chỉ bằng riêng 1 hành vi
 *     (ví dụ spam like), ảnh hưởng luôn các request khác của chính họ.
 *   - Không phân biệt được nhiều tài khoản khác nhau NHƯNG cùng đứng sau
 *     1 IP (NAT, mạng công ty, 4G...) — giới hạn theo IP làm oan người
 *     dùng thật, trong khi kẻ tấn công dùng nhiều IP/proxy lại dễ bypass
 *     giới hạn IP mà không hề bị giới hạn theo TÀI KHOẢN (authUid).
 *
 * Cách vá: thêm limiter riêng cho từng nhóm hành vi, khoá theo `authUid`
 * (khi đã đăng nhập — tức đặt limiter SAU `requireAuth`/`optionalAuth` trong
 * route để `req.authUid` đã sẵn sàng) thay vì chỉ theo IP. Khách chưa đăng
 * nhập (route dùng `optionalAuth`, ví dụ tạo link share) vẫn bị giới hạn
 * theo IP như cũ — không có nhóm nào bị bỏ ngỏ hoàn toàn.
 *
 * Ngưỡng chọn RỘNG RÃI có chủ đích: mục tiêu là chặn spam/farm tự động,
 * KHÔNG phải giới hạn người dùng thật dùng bình thường (rủi ro xung đột
 * thấp — xem CHANGELOG-v0.9.6.md).
 */
// v2.5.3 [TW-01]: nhánh khách dùng `getClientKey(req)` (IP đúng sau Cloudflare, IPv6 về /64) thay vì `req.ip` thô.
function authOrIpKeyGenerator(req) {
  return req.authUid ? `uid:${req.authUid}` : `ip:${getClientKey(req)}`;
}

const reactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 90, // ~1 lượt like/dislike mỗi 10 giây trung bình
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đang thao tác quá nhanh, vui lòng thử lại sau ít phút." },
});

/**
 * ==== v2.3.0 — Giới hạn chạy module "Gỡ lỗi" ====
 * Chạy module có thể mở tiến trình con (tốn CPU/RAM trên máy Render miễn phí). "Chạy tất cả" chạy tuần tự ~9 module nên 60 lượt/15 phút là đủ thoải mái cho quản trị viên
 * nhưng chặn được tài khoản SA bị chiếm dụng làm công cụ tiêu tốn tài nguyên. Khoá theo tài khoản; runner còn tự khoá "chỉ một module chạy một lúc".
 */
const debugRunLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Chạy module Gỡ lỗi quá nhiều lần, vui lòng thử lại sau ít phút.", code: "DEBUG_RATE_LIMITED" },
});

/**
 * ==== v2.5.3.2 — Giới hạn cho `GET /api/admin/ip-topology` (chỉ SA, chỉ đọc) ====
 * Panel "Nhận diện IP" gọi 5 lần mỗi lần bấm "Đo ngay"; 60 lần/15 phút/tài khoản dư cho việc đo lại nhiều lần mà vẫn chặn script bị chiếm phiên SA gọi liên tục.
 */
const ipTopologyLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đo nhận diện IP quá nhiều lần, vui lòng thử lại sau ít phút.", code: "IP_TOPOLOGY_RATE_LIMITED" },
});

const commentLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 40,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đang bình luận quá nhanh, vui lòng thử lại sau ít phút." },
});

/**
 * ==== v2.0.5 — Giới hạn RIÊNG cho tạo / sửa bài viết ====
 * Trước đây POST/PATCH /api/posts chỉ chịu `globalLimiter` (300 req/15 phút/IP, dùng chung cả /api).
 * Mỗi bài tạo ra cộng +1 positiveScore cho tác giả và sinh sanitize HTML tốn CPU. Khoá theo tài khoản.
 */
// v2.0.5 — danh sách bình luận mỗi trang đọc thêm N hồ sơ tác giả; trước đây chỉ chịu globalLimiter.
const commentListLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 200,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn tải bình luận quá nhanh, vui lòng thử lại sau ít phút." },
});

const postCreateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 20, // 20 bài/giờ/tài khoản — thoải mái cho người dùng thật
  keyGenerator: authOrIpKeyGenerator,
  skipFailedRequests: true, // request bị từ chối (thiếu tiêu đề, quá dài…) không tốn lượt
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đăng bài quá nhanh, vui lòng thử lại sau ít phút." },
});
const postEditLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 60,
  keyGenerator: authOrIpKeyGenerator,
  skipFailedRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn sửa bài quá nhanh, vui lòng thử lại sau ít phút." },
});

const shareLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đang tạo link chia sẻ quá nhanh, vui lòng thử lại sau ít phút." },
});

/**
 * ==== v0.10.11 [HIGH] — trần tuyệt đối cho GET /:id (nơi view + share được
 * ĐẾM, không phải nơi tạo link share) ====
 *
 * Dedup 30 phút/viewerKey (registerView/registerShare, utils/helpers.js) +
 * việc không còn tin `sid` client tự chọn (vá cùng đợt, xem
 * viewerKeyFromRequest()) đã chặn phần lớn farm — nhưng dedup theo khoá vẫn
 * có thể bị lách nếu kẻ tấn công đổi IP (proxy/VPN). Limiter này là lớp
 * phòng thủ ĐỘC LẬP với khoá dedup: giới hạn CỨNG số lần gọi GET /:id theo
 * IP/uid, bất kể viewerKey tính ra là gì.
 * Ngưỡng RỘNG RÃI có chủ đích (đọc nhiều bài khác nhau liên tục vẫn thoải
 * mái — ~10 request/phút trung bình) — mục tiêu chỉ chặn flood tự động.
 */
// v2.0.4 [BẢO MẬT] — TRƯỚC ĐÂY limiter `skip` mọi request có UA chứa "googlebot"…
// Nhưng UA do client tự khai: gọi thẳng backend với UA giả + X-Forwarded-For
// ngẫu nhiên là bơm view/AI-view vô hạn (mỗi request = 1 transaction Firestore).
// Nay KHÔNG skip theo UA nữa. Crawler chỉ được NỚI hạn mức (không phải miễn trừ)
// khi request đã chứng minh đi qua middleware Vercel của dự án (secret khớp), và
// khoá theo IP thật mà middleware chuyển tiếp — nên 1 IP vẫn bị chặn trần.
const SEARCH_ENGINE_UA =
  /googlebot|google-inspectiontool|googleother|google-extended|google-cloudvertexbot|bingbot|duckduckbot|baiduspider|yandex|applebot/i;
function isSearchEngineCrawler(req) {
  return SEARCH_ENGINE_UA.test(req.headers["user-agent"] || "");
}
const VIEW_LIMIT_DEFAULT = 150;
const VIEW_LIMIT_VERIFIED_CRAWLER = 1500; // crawl dày đặc vẫn thoải mái, nhưng có trần
function viewKeyGenerator(req) {
  return req.authUid ? `uid:${req.authUid}` : `ip:${getClientKey(req)}`;
}
const viewLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: (req) =>
    isTrustedSsrProxy(req) && isSearchEngineCrawler(req) ? VIEW_LIMIT_VERIFIED_CRAWLER : VIEW_LIMIT_DEFAULT,
  keyGenerator: viewKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đang xem quá nhanh, vui lòng thử lại sau ít phút." },
});

/**
 * ==== v0.10.11 [MEDIUM] — /api/trending/* trước đây chỉ có globalLimiter
 * dùng chung (300 req/15 phút cho TOÀN BỘ /api) ====
 *
 * Phía sau các route này (đặc biệt cache miss của tab Tìm kiếm/Khám phá) là
 * quét TOÀN BỘ collection posts + blogs (xem trending.controller.js#
 * scanContentDocs) — tốn kém hơn nhiều so với 1 request /api thông thường.
 * Ngưỡng thấp hơn global nhưng vẫn đủ rộng cho việc gõ tìm kiếm thật (có
 * debounce 400ms ở frontend).
 */
const trendingLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 120,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đang thao tác quá nhanh, vui lòng thử lại sau ít phút." },
});

const profileWriteLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đang cập nhật hồ sơ quá nhanh, vui lòng thử lại sau ít phút." },
});

/**
 * ==== v0.10.20 — Giới hạn RIÊNG cho upload avatar ====
 * Trước đây upload avatar chỉ dùng chung `profileWriteLimiter` (30 lần/15 phút,
 * ~2.880 lần/ngày/tài khoản) — quá thoáng cho thao tác tốn tài nguyên Cloudinary.
 * Nay: 6 lần/giờ/tài khoản. `skipFailedRequests`: request bị từ chối (sai định
 * dạng, quá lớn...) KHÔNG tốn lượt của người dùng thật vì chưa chạm Cloudinary
 * (spam request lỗi vẫn bị profileWriteLimiter + globalLimiter chặn).
 */
const avatarUploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 6,
  keyGenerator: authOrIpKeyGenerator,
  skipFailedRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đổi ảnh đại diện quá nhiều lần, vui lòng thử lại sau ít phút." },
});

/**
 * ==== v2.4.0 — Giới hạn cho ảnh bìa hồ sơ và ghim bài ====
 * - coverUploadLimiter: upload ảnh bìa lên Cloudinary — 6 lần/giờ/tài khoản (như avatar). `skipFailedRequests`: request bị từ chối
 *   (sai định dạng/quá lớn) không tốn lượt vì chưa chạm Cloudinary.
 * - pinLimiter: ghim/gỡ ghim bài — 60 lần/15 phút/tài khoản (thao tác nhẹ: một lần ghi vào hồ sơ; đủ để thử sắp xếp lại nhiều lần).
 * - userPostsLimiter: danh sách bài / bài ghim của một hồ sơ — mỗi lần gọi đọc tới ~30 bài + tác giả, nặng hơn đọc hồ sơ trơn (200/15 phút/IP-or-uid).
 */
const coverUploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 6,
  keyGenerator: authOrIpKeyGenerator,
  skipFailedRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đổi ảnh bìa quá nhiều lần, vui lòng thử lại sau ít phút." },
});

const pinLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  keyGenerator: authOrIpKeyGenerator,
  skipFailedRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn ghim/gỡ ghim quá nhanh, vui lòng thử lại sau ít phút." },
});

const userPostsLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đang xem bài viết quá nhanh, vui lòng thử lại sau ít phút." },
});

/**
 * ==== v2.5.2 — Giới hạn cho khách ghé thăm và thông tin mở rộng ====
 * - visitRecordLimiter: POST /users/:uid/visit — frontend gọi MỘT lần mỗi lần mở hồ sơ người khác; 120 lần/15 phút/tài khoản dư cho việc lướt nhiều hồ sơ
 *   nhưng chặn script spam để "đẩy" người khác ra khỏi danh sách 50 khách gần nhất của một hồ sơ.
 * - profileExtrasWriteLimiter: bật/tắt mục thông tin mở rộng — mỗi lần bật/tắt là một lần ghi; 60 lần/15 phút/tài khoản (có 9 công tắc, đủ để chỉnh thoải mái;
 *   riêng limiter này để việc chỉnh công tắc không ăn vào hạn mức 30 lần của profileWriteLimiter dùng cho đổi tên/ảnh).
 */
const visitRecordLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 120,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đang ghé thăm hồ sơ quá nhanh, vui lòng thử lại sau ít phút." },
});

const profileExtrasWriteLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đang chỉnh thông tin mở rộng quá nhanh, vui lòng thử lại sau ít phút." },
});

/**
 * ==== v0.10.12 [LOW] — GET /api/users/:uid (xem hồ sơ công khai) trước đây
 * chỉ có globalLimiter dùng chung ====
 * Rủi ro vốn thấp (uid khó đoán, `toPublicUser()` đã lọc sạch field nhạy
 * cảm — xem báo cáo bảo mật v0.10.11, mục V-003) nhưng thêm 1 lớp riêng
 * không tốn gì, nhất quán với các route đọc khác đã có limiter riêng.
 */
const profileReadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đang xem hồ sơ quá nhanh, vui lòng thử lại sau ít phút." },
});

/**
 * ==== v2.2.0 — Giới hạn cho thao tác tài khoản nhạy cảm ====
 * - sensitiveAccountLimiter: xem/đổi tên thật, đổi Tag Name Search — 10 lần/15 phút/tài khoản. Mật khẩu đã được Firebase chặn
 *   brute-force (auth/too-many-requests) ở bước nhập lại mật khẩu; đây là lớp thứ hai cho phần backend.
 * - accountDeleteLimiter: yêu cầu xoá tài khoản — 3 lần/giờ/tài khoản (thực tế chỉ cần 1; chừa chỗ cho lần thử lại sau lỗi mạng).
 * - forgotPasswordLimiter: gửi email đặt lại mật khẩu — 5 lần/giờ/IP. Chặn thêm theo EMAIL (nhiều IP cùng làm phiền một người) nằm ở
 *   auth.controller.js#forgotPassword.
 */
const sensitiveAccountLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn thao tác quá nhiều lần, vui lòng thử lại sau ít phút." },
});

const accountDeleteLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 3,
  keyGenerator: authOrIpKeyGenerator,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đã gửi yêu cầu xoá tài khoản quá nhiều lần, vui lòng thử lại sau." },
});

const forgotPasswordLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  keyGenerator: (req) => `ip:${getClientKey(req)}`,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bạn đã yêu cầu đặt lại mật khẩu quá nhiều lần. Vui lòng thử lại sau." },
});

module.exports = {
  debugRunLimiter,
  ipTopologyLimiter,
  sensitiveAccountLimiter,
  accountDeleteLimiter,
  forgotPasswordLimiter,
  reactLimiter,
  commentLimiter,
  postCreateLimiter,
  postEditLimiter,
  commentListLimiter,
  shareLimiter,
  viewLimiter,
  trendingLimiter,
  profileWriteLimiter,
  avatarUploadLimiter,
  profileReadLimiter,
  coverUploadLimiter,
  pinLimiter,
  userPostsLimiter,
  visitRecordLimiter,
  profileExtrasWriteLimiter,
};
