/**
 * ==== VÁ #7 [LOW] — Thiếu validate định dạng cho các trường hồ sơ (v0.8.3) ====
 *
 * Trước đây `displayName`, `fullName`, `birthday`, `gender`, `country` chỉ
 * được kiểm tra "có tồn tại" (`!== undefined` / truthy), không kiểm tra định
 * dạng, độ dài tối đa, hay việc `country` có thuộc danh sách quốc gia hợp lệ
 * hay không — package `express-validator` đã có sẵn trong package.json
 * nhưng chưa được dùng ở đâu cả. File này tập trung toàn bộ validate hồ sơ
 * người dùng vào 1 nơi, dùng lại được cho cả `register` và `updateMe`.
 */
const { body, query, validationResult } = require("express-validator");
const { db } = require("../config/firebase");
const { COLLECTIONS, PROFILE } = require("../utils/constants");

const { cleanDisplayText, cleanBio, charLength, validateBirthday } = require("../utils/input");

const GENDER_VALUES = ["male", "female", "other"];

/**
 * Middleware dùng chung: đọc kết quả validate (do các validator chain ở dưới
 * gắn vào `req`) và trả 400 kèm thông báo lỗi ĐẦU TIÊN nếu có, nếu không thì
 * đi tiếp sang controller.
 */
function handleValidation(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: errors.array()[0].msg, fields: errors.array().map((e) => e.path) });
  }
  return next();
}

// Country hợp lệ = có tồn tại trong collection `countries` (đối chiếu thay vì
// chỉ kiểm tra "có giá trị") — collection này khá nhỏ (~13 quốc gia hiện tại)
// nên 1 lượt đọc doc theo id là đủ rẻ để chạy mỗi lần đăng ký/cập nhật hồ sơ.
//
// Lưu ý: đây là kiểm tra CHẤT LƯỢNG DỮ LIỆU (mức LOW trong báo cáo), không
// phải kiểm tra bảo mật — nếu Firestore tạm thời lỗi/timeout, KHÔNG được để
// lộ chi tiết lỗi hạ tầng ra ngoài qua message validate, và KHÔNG nên chặn
// toàn bộ luồng đăng ký chỉ vì 1 request phụ trợ này gặp sự cố tạm thời.
// Vì vậy khi có lỗi đọc Firestore, coi như "không xác minh được" -> cho qua
// (fail-open), chỉ log lỗi để theo dõi.
async function isKnownCountryCode(code) {
  if (typeof code !== "string" || !code.trim()) return false;
  try {
    const snap = await db.collection(COLLECTIONS.COUNTRIES).doc(code.trim().toUpperCase()).get();
    return snap.exists;
  } catch (err) {
    console.error("isKnownCountryCode: lỗi đọc Firestore, fail-open:", err.message);
    return true;
  }
}

// v2.0.10 [BẢO MẬT F7/F8/F9]:
//  - `.isString()` TRƯỚC khi sanitize: trước đây `.trim()` ép mọi kiểu về chuỗi nên mảng/đối tượng lọt qua thành "a"/"[object Object]".
//  - fullName/displayName được làm sạch ký tự Unicode nguy hiểm (bidi-override U+202E, rộng-0, điều khiển…) rồi MỚI kiểm độ dài.
//  - birthday kiểm tra nghiêm ngặt đúng lịch (không nhận 2023-02-31, 2020-W01-1, datetime…).
const fullNameField = () =>
  body("fullName")
    .isString()
    .withMessage("Họ và tên không hợp lệ.")
    .bail()
    .customSanitizer(cleanDisplayText)
    .isLength({ min: 1, max: 100 })
    .withMessage("Họ và tên phải từ 1-100 ký tự.");

const displayNameField = () =>
  body("displayName")
    .isString()
    .withMessage("Tên hiển thị không hợp lệ.")
    .bail()
    .customSanitizer(cleanDisplayText)
    .isLength({ min: 1, max: 50 })
    .withMessage("Tên hiển thị phải từ 1-50 ký tự.");

// v2.5.2 — Tiểu sử: chuỗi (có thể rỗng = xoá), làm sạch TRƯỚC khi kiểm độ dài (xuống dòng/khoảng trắng thừa không được tính), tối đa BIO_MAX ký tự và BIO_MAX_LINES dòng.
const bioField = () =>
  body("bio")
    .isString()
    .withMessage("Tiểu sử không hợp lệ.")
    .bail()
    .customSanitizer(cleanBio)
    .custom((value) => {
      if (charLength(value) > PROFILE.BIO_MAX) throw new Error(`Tiểu sử tối đa ${PROFILE.BIO_MAX} ký tự.`);
      if (value.split("\n").length > PROFILE.BIO_MAX_LINES) throw new Error(`Tiểu sử tối đa ${PROFILE.BIO_MAX_LINES} dòng.`);
      return true;
    });

const birthdayField = () =>
  body("birthday").custom((value) => {
    const r = validateBirthday(value);
    if (!r.ok) throw new Error(r.error);
    return true;
  });

const genderField = () =>
  body("gender").isString().withMessage("Giới tính không hợp lệ.").bail().isIn(GENDER_VALUES).withMessage(`Giới tính phải là một trong: ${GENDER_VALUES.join(", ")}.`);

const countryField = () =>
  body("country")
    .isString()
    .withMessage("Mã quốc gia không hợp lệ.")
    .bail()
    .trim()
    .isLength({ min: 1, max: 10 })
    .withMessage("Mã quốc gia không hợp lệ.")
    .bail()
    .custom(async (value) => {
      if (!(await isKnownCountryCode(value))) {
        throw new Error("Quốc gia không nằm trong danh sách hỗ trợ.");
      }
      return true;
    });

// v2.0.5 [SỬA LỖI]: trước đây dùng `.normalizeEmail()` mặc định — nó BỎ DẤU CHẤM và phần "+tag" của
// Gmail (John.Doe+x@gmail.com -> johndoe@gmail.com) rồi ghi đè req.body.email, nên Firebase user được
// tạo với email khác email người dùng gõ => đăng nhập bằng email gốc báo sai. Nay chỉ trim + chữ thường
// (Firebase Auth coi email không phân biệt hoa/thường).
const emailField = () =>
  body("email")
    .isString()
    .withMessage("Email không hợp lệ.")
    .bail()
    .trim()
    .isEmail()
    .withMessage("Email không hợp lệ.")
    .customSanitizer((v) => String(v).toLowerCase());

// v0.10.18 [báo cáo bảo mật L-3]: nâng tối thiểu 6 -> 8 ký tự. CHỈ áp dụng
// khi ĐĂNG KÝ mới — đăng nhập đi thẳng Firebase (không qua validator này) nên
// tài khoản cũ có mật khẩu 6–7 ký tự vẫn đăng nhập bình thường.
const passwordField = () =>
  body("password").isString().withMessage("Mật khẩu không hợp lệ.").bail().isLength({ min: 8, max: 128 }).withMessage("Mật khẩu phải có ít nhất 8 ký tự.");

// POST /api/auth/register — mọi field đều bắt buộc (giữ nguyên hành vi cũ:
// controller vẫn tự kiểm tra "đủ field" trước khi tới đây, các validator này
// bổ sung phần ĐỊNH DẠNG/ĐỘ DÀI mà trước đây hoàn toàn bỏ trống).
const registerValidators = [
  fullNameField(),
  displayNameField(),
  // tagName giữ nguyên validate riêng ở helpers.js#isValidTagName (dùng cả ở
  // register lẫn check-tagname) — không lặp lại logic ở đây.
  birthdayField(),
  genderField(),
  countryField(),
  emailField(),
  passwordField(),
];

const checkTagNameValidators = [
  query("tag").optional().isString().isLength({ max: 20 }),
];

// PATCH /api/users/me — mọi field đều optional (chỉ validate field nào có mặt
// trong body, giữ đúng hành vi "cập nhật từng phần" hiện tại). Mỗi field
// dùng 1 CHAIN MỚI (gọi lại factory) — KHÔNG tái sử dụng chain đã build ở
// registerValidators, vì ValidationChain là đối tượng mutable: gọi
// `.optional()` trên 1 chain đã tồn tại sẽ làm rò rỉ trạng thái sang mọi nơi
// khác đang dùng chung chain đó (kể cả registerValidators ở trên).
//
// v2.2.0: `fullName` KHÔNG còn nằm ở đây — đổi tên thật có endpoint riêng, bắt buộc vừa nhập lại mật khẩu
// (PUT /users/me/real-name + realNameValidators bên dưới). PATCH /users/me từ chối hẳn field này (xem users.controller.js#updateMe).
const updateMeValidators = [
  displayNameField().optional(),
  birthdayField().optional(),
  genderField().optional(),
  countryField().optional(),
  bioField().optional(), // v2.5.2
];

// PUT /api/users/me/real-name — tên thật là bắt buộc (không có "xoá tên thật"), cùng quy tắc làm sạch như lúc đăng ký.
const realNameValidators = [fullNameField()];

// POST /api/auth/forgot-password — chỉ cần email (CAPTCHA do verifyCaptcha kiểm riêng, trước bước này).
const forgotPasswordValidators = [emailField()];

module.exports = {
  handleValidation,
  registerValidators,
  checkTagNameValidators,
  updateMeValidators,
  realNameValidators,
  forgotPasswordValidators,
};
