const { db } = require("../config/firebase");
const { COLLECTIONS, ACCOUNT_STATUS } = require("../utils/constants");
const { isLiveProfile, isValidTagName, normalizeTagName } = require("../utils/helpers");
const { isSafeDocId } = require("../utils/input");

/**
 * ==== Tra HỒ SƠ CÔNG KHAI còn "sống" — dùng chung cho API (users.controller) và SSR cho bot (ssr.routes) ====
 * Một nơi duy nhất giữ quy tắc "hồ sơ nào được coi là tồn tại với người ngoài" nên API và trang SSR không thể lệch nhau.
 */

/**
 * v2.4.0 — nạp hồ sơ CÔNG KHAI còn "sống" của `uid` (dùng chung cho hồ sơ, danh sách bài và bài ghim).
 * Trả `{ data }` hoặc `null` (=> 404). Quy tắc không đổi so với trước: id lạ, hồ sơ "ma" (không có status — v2.2.1 [A-02]),
 * tài khoản pending (v2.0.4) và đang bị xoá (v2.2.0) đều 404 như thể không tồn tại; suspended vẫn công khai.
 */
async function loadLivePublicUser(uid) {
  // v2.2.1 [A-01]: id có "/" làm SDK Firestore ném lỗi (từng làm SẬP cả tiến trình) hoặc trỏ vào tài liệu lồng nhau — chặn trước khi chạm Firestore.
  if (!isSafeDocId(uid)) return null;
  const snap = await db.collection(COLLECTIONS.USERS).doc(uid).get();
  if (!snap.exists) return null;
  const data = snap.data();
  if (!isLiveProfile(data) || data.status === ACCOUNT_STATUS.PENDING || data.status === ACCOUNT_STATUS.DELETING) return null;
  return { data };
}

/**
 * v2.4.2.1 — nạp hồ sơ CÔNG KHAI còn "sống" theo TAG NAME SEARCH (URL hồ sơ nay là /u/@<tag>, không còn lộ UID).
 * Trả `{ uid, data }` hoặc `null` (=> 404). Đi qua `tagNames/{tag}` (doc id = tag không "@", giá trị `{ uid }` — cũng là khoá duy nhất
 * của Tag Name nên không thể hai tài khoản cùng một tag) rồi dùng lại loadLivePublicUser: mọi quy tắc 404 cũ (hồ sơ "ma", pending, đang xoá) giữ nguyên.
 * Đối chiếu ngược: `users/{uid}.tagName` PHẢI đúng bằng tag đang tra. Document `tagNames` có thể lệch (dữ liệu cũ, đổi tag dở dang…) — lệch thì 404,
 * không bao giờ hiện hồ sơ của người không còn giữ tag đó.
 */
async function loadLivePublicUserByTag(rawTag) {
  if (typeof rawTag !== "string" || !isValidTagName(rawTag)) return null;
  const tag = normalizeTagName(rawTag);
  const tagSnap = await db.collection(COLLECTIONS.TAGNAMES).doc(tag).get();
  if (!tagSnap.exists) return null;
  const uid = tagSnap.data() && tagSnap.data().uid;
  if (typeof uid !== "string") return null;
  const live = await loadLivePublicUser(uid);
  if (!live) return null;
  if (normalizeTagName(live.data.tagName || "") !== tag) return null;
  return { uid, data: live.data };
}

module.exports = { loadLivePublicUser, loadLivePublicUserByTag };
