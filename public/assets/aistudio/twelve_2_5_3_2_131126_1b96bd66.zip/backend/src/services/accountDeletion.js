const crypto = require("crypto");
const os = require("os");
const { db, auth } = require("../config/firebase");
const assets = require("./assets.service");
const { deleteContentTree } = require("../utils/cascade");
const { COLLECTIONS, ACCOUNT_STATUS, ACCOUNT_DELETION } = require("../utils/constants");

/**
 * ==== v2.2.0 — XOÁ TÀI KHOẢN: bền vững qua sập server, có hàng chờ ====
 *
 * YÊU CẦU: người dùng bấm xoá rồi tắt trình duyệt / mất mạng / server sập giữa chừng thì hệ thống VẪN phải xoá xong, và nhiều
 * yêu cầu cùng lúc không được làm nghẽn server.
 *
 * THIẾT KẾ
 *  1. GHI NHỚ TRƯỚC: trước khi xoá bất cứ thứ gì, `requestDeletion` ghi `accountDeletions/{uid}` VÀ đổi `users/{uid}.status = "deleting"`
 *     trong CÙNG một transaction (hoặc cả hai, hoặc không cái nào). Từ lúc này việc xoá không còn phụ thuộc vào request của người dùng:
 *     request trả 202 ngay, phần còn lại chạy NỀN trong server.
 *  2. Collection `accountDeletions` vừa là SỔ THEO DÕI (biết tài khoản nào đang xoá dở, đến bước nào) vừa là HÀNG CHỜ: mỗi instance
 *     chỉ xử lý tối đa ACCOUNT_DELETION.MAX_CONCURRENT tài khoản cùng lúc, số còn lại nằm chờ trong sổ theo thứ tự yêu cầu.
 *  3. CÁC BƯỚC (STEPS) xếp theo thứ tự, MỖI BƯỚC IDEMPOTENT (chạy lại bao nhiêu lần cũng ra cùng kết quả), nên sập ở đâu cũng chỉ cần
 *     chạy lại từ bước đang dở:
 *        lock → content (bài viết + blog) → assets (Cloudinary + sổ assets) → residual (tagName, dữ liệu riêng, subcollection)
 *             → auth (tài khoản Firebase Auth) → profile (users/{uid}, SAU CÙNG)
 *     Hồ sơ `users/{uid}` bị xoá CUỐI CÙNG nên khi sập giữa chừng nó còn đó với status `deleting` — vừa là dấu vết, vừa giữ lại
 *     `tagName`/`avatarUrl` để các bước sau còn biết phải dọn gì. Sổ `accountDeletions/{uid}` chỉ bị xoá khi MỌI thứ đã xong.
 *  4. HỢP ĐỒNG (lease) thay vì khoá cứng: instance nhận việc ghi `leaseUntilMs` và gia hạn liên tục. Instance chết ⇒ lease hết hạn ⇒
 *     instance khác (hoặc chính nó sau khi khởi động lại) nhận tiếp. Nhận việc dùng transaction nên hai instance không bao giờ
 *     cùng giữ một lease; nếu lỡ chạy chồng thì vẫn an toàn vì các bước idempotent.
 *  5. NHẶT VIỆC DANG DỞ: `startSweeper()` quét sổ 1 lần sau khi khởi động và mỗi phút. Lỗi tạm thời ⇒ thử lại với backoff tăng dần;
 *     quá MAX_FAILURES lần ⇒ `failed` (không tự thử nữa, cần người xem: scripts/account-deletions.js).
 *  6. KIỂM CUỐI: trước khi xoá hồ sơ, kiểm lại không còn bài/blog nào của uid (phòng request ghi dở lọt qua lúc khoá); còn ⇒ quay lại bước content.
 *  7. (v2.2.1 [A-02]) VERIFY SAU XOÁ: một request đã qua middleware nhưng bị kẹt có thể ghi MUỘN, sau cả bước `profile` (dựng lại `userPrivate/{uid}`,
 *     hồ sơ "ma" `users/{uid}` chỉ có điểm số, bài mồ côi). Các đường ghi chính đã được chuyển sang transaction có kiểm tra `active` (xem
 *     utils/helpers.js#assertActorActive, services/userPrivate.js) nên khe hở này gần như đã đóng; verify là LƯỚI AN TOÀN CHUNG cho phần còn lại:
 *     sau VERIFY_DELAY_MS (mặc định 2 phút) kể từ khi hồ sơ bị xoá, quét lại và dọn nốt mọi thứ của uid rồi mới xoá sổ theo dõi.
 *
 * KHÔNG LÀM (cố ý): bình luận / lượt like của user này trên bài NGƯỜI KHÁC được giữ nguyên (tác giả hiển thị là "Người dùng Twelve" vì hồ sơ
 * đã mất) — xoá chúng phải chỉnh lại bộ đếm trên bài người khác, thuộc phạm vi khác. Xem PATCH-12-NOTES.md.
 */

const COL = () => db.collection(COLLECTIONS.ACCOUNT_DELETIONS);
const USERS = () => db.collection(COLLECTIONS.USERS);

const envVerifyDelay = parseInt(process.env.ACCOUNT_DELETION_VERIFY_DELAY_MS, 10);
const CFG = {
  ...ACCOUNT_DELETION,
  MAX_CONCURRENT: Math.max(1, parseInt(process.env.ACCOUNT_DELETION_CONCURRENCY, 10) || ACCOUNT_DELETION.MAX_CONCURRENT),
  VERIFY_DELAY_MS: Number.isFinite(envVerifyDelay) ? Math.max(0, envVerifyDelay) : ACCOUNT_DELETION.VERIFY_DELAY_MS,
};

const INSTANCE_ID = `${process.env.RENDER_INSTANCE_ID || os.hostname()}:${process.pid}:${crypto.randomBytes(4).toString("hex")}`;

// Mã riêng để bước "profile" báo "còn bài sót, quay lại bước content".
class RewindError extends Error {
  constructor(toStep, reason) {
    super(reason || `rewind to ${toStep}`);
    this.name = "RewindError";
    this.toStep = toStep;
  }
}

const isAuthNotFound = (err) => err && (err.code === "auth/user-not-found" || err.errorInfo?.code === "auth/user-not-found");

// ---------------------------------------------------------------- các bước (idempotent)

/** Đổi status = deleting (nếu chưa) + vô hiệu hoá & thu hồi phiên Firebase Auth (chặn đăng nhập mới, token cũ chết trong ≤60 giây). */
async function stepLock(uid) {
  const ref = USERS().doc(uid);
  const snap = await ref.get();
  if (snap.exists && snap.data().status !== ACCOUNT_STATUS.DELETING) {
    await ref.update({ status: ACCOUNT_STATUS.DELETING, deletionRequestedAt: new Date().toISOString() });
  }
  try {
    await auth.updateUser(uid, { disabled: true });
    await auth.revokeRefreshTokens(uid);
  } catch (err) {
    if (!isAuthNotFound(err)) throw err; // đã xoá ở lần chạy trước: bình thường
  }
}

/** Xoá mọi bài viết + blog (kể cả bản nháp) của uid, kèm toàn bộ subcollection (comments/views/reactions/shares…). */
async function deleteAuthored(collectionName, uid, beat) {
  let total = 0;
  let previousIds = "";
  for (;;) {
    const snap = await db.collection(collectionName).where("authorUid", "==", uid).limit(CFG.CONTENT_BATCH).get();
    if (snap.empty) break;
    const ids = snap.docs.map((d) => d.id).join(",");
    // Lô vừa xoá mà truy vấn vẫn trả đúng lô đó ⇒ việc xoá không có tác dụng: đừng quay vô hạn, báo lỗi để thử lại sau.
    if (ids === previousIds) throw new Error(`Không xoá được ${collectionName} của ${uid} (lô lặp lại: ${ids}).`);
    previousIds = ids;
    for (const doc of snap.docs) {
      await deleteContentTree(db, doc.ref); // NÉM LỖI nếu thất bại (khác purgeContentSubcollections)
      await doc.ref.delete(); // recursiveDelete đã xoá cả doc; với đường fallback thì cần dòng này (xoá doc không tồn tại là no-op)
      total++;
    }
    await beat();
  }
  return total;
}

async function stepContent(uid, ctx) {
  await deleteAuthored(COLLECTIONS.POSTS, uid, ctx.beat);
  await deleteAuthored(COLLECTIONS.BLOGS, uid, ctx.beat);
}

/** Cloudinary (asset đã đăng ký + asset kiểu cũ trong thư mục của user) + sổ `assets`, và avatar kiểu cũ còn trong hồ sơ. */
async function stepAssets(uid) {
  const snap = await USERS().doc(uid).get();
  const avatarUrl = snap.exists ? snap.data().avatarUrl : null;
  await assets.deleteAllAssetsOfUser(uid);
  // Avatar kiểu cũ (public_id ngẫu nhiên, không có trong sổ): chỉ xoá nếu nằm trong thư mục avatar của CHÍNH uid này (kiểm trong hàm).
  if (avatarUrl) await assets.releaseSupersededAvatar(uid, avatarUrl, null, { strict: true });
}

/** Giải phóng Tag Name Search, xoá dữ liệu riêng, dấu đăng ký dở, danh sách khách ghé thăm và mọi subcollection của hồ sơ (positiveScoreLogs…). */
async function stepResidual(uid) {
  const userRef = USERS().doc(uid);
  const snap = await userRef.get();
  const tagName = snap.exists ? snap.data().tagName : null;
  if (tagName) {
    const tagRef = db.collection(COLLECTIONS.TAGNAMES).doc(String(tagName));
    const tagSnap = await tagRef.get();
    // Chỉ giải phóng nếu tag THẬT SỰ đang trỏ về uid này (không xoá nhầm tag của người khác).
    if (tagSnap.exists && tagSnap.data().uid === uid) await tagRef.delete();
  }
  await db.collection(COLLECTIONS.USER_PRIVATE).doc(uid).delete();
  await db.collection(COLLECTIONS.REGISTRATION_MARKERS).doc(uid).delete();
  // v2.5.2: danh sách khách ghé thăm hồ sơ của uid này (uid của uid này trong danh sách NGƯỜI KHÁC chỉ là một mã, bị lọc khi đọc — không cần quét dọn).
  await db.collection(COLLECTIONS.PROFILE_VISITORS).doc(uid).delete();

  const subs = typeof userRef.listCollections === "function" ? await userRef.listCollections() : [userRef.collection("positiveScoreLogs")];
  for (const col of subs) {
    if (typeof db.recursiveDelete === "function") await db.recursiveDelete(col);
  }
}

async function stepAuth(uid) {
  try {
    await auth.deleteUser(uid);
  } catch (err) {
    if (!isAuthNotFound(err)) throw err;
  }
}

/** Bước CUỐI: kiểm không còn nội dung/asset của uid rồi mới xoá hồ sơ. */
async function stepProfile(uid) {
  const [p, b, a] = await Promise.all([
    db.collection(COLLECTIONS.POSTS).where("authorUid", "==", uid).limit(1).get(),
    db.collection(COLLECTIONS.BLOGS).where("authorUid", "==", uid).limit(1).get(),
    db.collection(COLLECTIONS.ASSETS).where("ownerUid", "==", uid).limit(1).get(),
  ]);
  if (!p.empty || !b.empty) throw new RewindError("content", "còn bài viết/blog sót ở bước kiểm cuối");
  if (!a.empty) throw new RewindError("assets", "còn asset sót ở bước kiểm cuối");
  await USERS().doc(uid).delete();
}

/**
 * v2.2.1 [A-02] — bước VERIFY (sau `profile`, sau độ trễ VERIFY_DELAY_MS): còn gì của uid thì quay lại bước tương ứng để dọn.
 *   • bài/blog/asset còn sót  ⇒ quay lại `content`/`assets`
 *   • `userPrivate`, dấu đăng ký dở, `profileVisitors` (v2.5.2), hoặc hồ sơ users/{uid} (tức hồ sơ "ma" bị dựng lại bằng set+merge) ⇒ quay lại `residual`
 *     (residual xoá cả subcollection như positiveScoreLogs; `profile` sau đó xoá document hồ sơ).
 * Không còn gì ⇒ hoàn tất, sổ theo dõi được xoá.
 */
async function stepVerify(uid) {
  const [p, b, a, user, priv, marker, visitors] = await Promise.all([
    db.collection(COLLECTIONS.POSTS).where("authorUid", "==", uid).limit(1).get(),
    db.collection(COLLECTIONS.BLOGS).where("authorUid", "==", uid).limit(1).get(),
    db.collection(COLLECTIONS.ASSETS).where("ownerUid", "==", uid).limit(1).get(),
    USERS().doc(uid).get(),
    db.collection(COLLECTIONS.USER_PRIVATE).doc(uid).get(),
    db.collection(COLLECTIONS.REGISTRATION_MARKERS).doc(uid).get(),
    db.collection(COLLECTIONS.PROFILE_VISITORS).doc(uid).get(),
  ]);
  if (!p.empty || !b.empty) throw new RewindError("content", "verify: còn bài viết/blog bị ghi muộn sau khi xoá");
  if (!a.empty) throw new RewindError("assets", "verify: còn asset bị ghi muộn sau khi xoá");
  if (user.exists || priv.exists || marker.exists || visitors.exists) throw new RewindError("residual", "verify: dữ liệu của uid bị dựng lại sau khi xoá");
}

const STEPS = [
  { name: "lock", run: stepLock },
  { name: "content", run: stepContent },
  { name: "assets", run: stepAssets },
  { name: "residual", run: stepResidual },
  { name: "auth", run: stepAuth },
  { name: "profile", run: stepProfile },
  { name: "verify", run: stepVerify },
];

// ---------------------------------------------------------------- yêu cầu xoá (gọi từ controller)

class DeletionRequestError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

/**
 * Ghi nhớ yêu cầu + khoá hồ sơ trong MỘT transaction, rồi kích hoạt xử lý nền. Idempotent: gọi lại khi đã có sổ thì không tạo thêm.
 * KHÔNG kiểm tra mật khẩu/quyền ở đây — việc đó thuộc controller (requireAuth + requireRecentAuth + chặn SA).
 * v2.5.3 [TW-08, rà soát độc lập]: tuỳ chọn `onlyIfStatus` — chỉ xếp hàng xoá nếu hồ sơ ĐANG ở trạng thái đó NGAY TRONG transaction. Sweeper `pending` truyền "pending":
 * nếu người dùng vừa được kích hoạt (syncActivation) giữa lúc sweeper kiểm lại và lúc transaction này chạy thì KHÔNG được lật `active` → `deleting`. Trả `true` nếu đã xếp hàng
 * (hoặc đã có sẵn), `false` nếu bị bỏ qua vì trạng thái đã đổi. Gọi không có tuỳ chọn = hành vi cũ (luôn xếp hàng).
 * Khe còn lại (không đóng được bằng transaction Firestore): Firebase Auth là hệ thống khác — người dùng bấm link xác minh đúng vài mili-giây giữa lần kiểm Auth và transaction này.
 * Hồ sơ `pending` quá 7 ngày chưa có nội dung nào (pending không đăng bài được), nên hậu quả chỉ là phải đăng ký lại.
 */
async function requestDeletion(uid, { onlyIfStatus = null } = {}) {
  const ref = COL().doc(uid);
  const userRef = USERS().doc(uid);
  const now = Date.now();
  const queued = await db.runTransaction(async (tx) => {
    const [entry, user] = await Promise.all([tx.get(ref), tx.get(userRef)]);
    if (!user.exists) throw new DeletionRequestError(404, "Không tìm thấy tài khoản.", "NOT_FOUND");
    if (onlyIfStatus && user.data().status !== onlyIfStatus) return false;
    if (!entry.exists) {
      tx.set(ref, {
        uid,
        status: "queued",
        step: STEPS[0].name,
        requestedAt: new Date(now).toISOString(),
        requestedAtMs: now,
        failures: 0,
        rewinds: 0,
        leaseOwner: null,
        leaseUntilMs: 0,
        nextAttemptAtMs: 0,
        lastError: null,
        lastErrorAtMs: null,
      });
    }
    if (user.data().status !== ACCOUNT_STATUS.DELETING) {
      tx.update(userRef, { status: ACCOUNT_STATUS.DELETING, deletionRequestedAt: new Date(now).toISOString() });
    }
    return true;
  });
  if (queued) kick();
  return queued;
}

// ---------------------------------------------------------------- bộ xử lý nền

const active = new Set(); // uid đang được instance NÀY xử lý
let pumping = false;
let stopped = false;
let timers = [];

function backoffMs(failures) {
  return Math.min(CFG.BACKOFF_MAX_MS, CFG.BACKOFF_BASE_MS * 2 ** Math.max(0, failures - 1));
}

/** Nhận việc bằng transaction: chỉ một instance giữ được lease của một uid tại một thời điểm. Trả sổ nếu nhận được, null nếu không. */
async function claim(uid) {
  const ref = COL().doc(uid);
  const now = Date.now();
  return db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) return null;
    const e = snap.data();
    if (e.status === "failed") return null;
    if ((e.leaseUntilMs || 0) > now && e.leaseOwner !== INSTANCE_ID) return null;
    tx.update(ref, { status: "running", leaseOwner: INSTANCE_ID, leaseUntilMs: now + CFG.LEASE_MS });
    return e;
  });
}

async function recordFailure(uid, err) {
  const ref = COL().doc(uid);
  const snap = await ref.get();
  if (!snap.exists) return;
  const failures = (snap.data().failures || 0) + 1;
  const dead = failures >= CFG.MAX_FAILURES;
  const now = Date.now();
  await ref.update({
    status: dead ? "failed" : "retrying",
    failures,
    lastError: String((err && err.message) || err).slice(0, 500),
    lastErrorAtMs: now,
    leaseOwner: null,
    leaseUntilMs: 0,
    nextAttemptAtMs: now + backoffMs(failures),
  });
  if (dead) console.error(`[account-deletion] uid=${uid} THẤT BẠI sau ${failures} lần — cần xử lý tay (scripts/account-deletions.js):`, err);
}

/** Xử lý một uid từ bước đang dở tới hết. Không bao giờ ném lỗi ra ngoài (mọi lỗi đã được ghi vào sổ). */
async function processOne(uid) {
  const entry = await claim(uid);
  if (!entry) return false;
  const ref = COL().doc(uid);

  const beat = async () => {
    await ref.update({ leaseOwner: INSTANCE_ID, leaseUntilMs: Date.now() + CFG.LEASE_MS });
  };
  // Một thao tác dài (recursiveDelete bài có hàng chục nghìn lượt xem…) vẫn phải gia hạn lease — đừng để instance khác nhảy vào giữa chừng.
  const hb = setInterval(() => beat().catch(() => {}), Math.max(1000, Math.floor(CFG.LEASE_MS / 3)));
  if (typeof hb.unref === "function") hb.unref();

  try {
    let idx = Math.max(0, STEPS.findIndex((s) => s.name === entry.step));
    let rewinds = entry.rewinds || 0;
    let verifyAfterMs = entry.verifyAfterMs || 0;
    while (idx < STEPS.length) {
      const step = STEPS[idx];
      await ref.update({ step: step.name, leaseOwner: INSTANCE_ID, leaseUntilMs: Date.now() + CFG.LEASE_MS });
      if (step.name === "verify") {
        // v2.2.1 [A-02]: hồ sơ vừa xoá xong — chưa verify ngay mà đợi hết cửa sổ an toàn (ghi mốc 1 lần, bền qua sập/khởi động lại).
        if (!verifyAfterMs) {
          verifyAfterMs = Date.now() + CFG.VERIFY_DELAY_MS;
          await ref.update({ verifyAfterMs });
        }
        if (Date.now() < verifyAfterMs) {
          clearInterval(hb);
          await ref.update({ status: "waiting_verify", leaseOwner: null, leaseUntilMs: 0, nextAttemptAtMs: verifyAfterMs });
          return false; // chưa hoàn tất: sweeper nhặt lại đúng lúc `verifyAfterMs` (không chiếm chỗ xử lý song song trong lúc chờ)
        }
      }
      try {
        await step.run(uid, { beat });
      } catch (err) {
        if (err instanceof RewindError && rewinds < CFG.MAX_REWINDS) {
          rewinds++;
          await ref.update({ rewinds });
          idx = Math.max(0, STEPS.findIndex((s) => s.name === err.toStep));
          continue;
        }
        throw err;
      }
      idx++;
    }
    clearInterval(hb);
    // MỌI thứ đã xong ⇒ dọn nốt sổ theo dõi (nếu xoá sổ lỗi, lần quét sau chạy lại — các bước no-op — rồi xoá tiếp).
    await ref.delete();
    console.log(`[account-deletion] hoàn tất uid=${uid}`);
    return true;
  } catch (err) {
    clearInterval(hb);
    console.error(`[account-deletion] lỗi uid=${uid} ở bước hiện tại:`, err && err.message);
    await recordFailure(uid, err).catch((e) => console.error("[account-deletion] không ghi được lỗi vào sổ:", e.message));
    return false;
  } finally {
    clearInterval(hb);
  }
}

function launch(uid) {
  active.add(uid);
  processOne(uid)
    .catch((err) => console.error("[account-deletion] processOne:", err && err.message))
    .finally(() => {
      active.delete(uid);
      setImmediate(() => pump().catch(() => {})); // còn việc chờ thì lấy tiếp
    });
}

/** Lấy các tài khoản cũ nhất đang chờ (và không bị instance khác giữ) cho tới khi hết chỗ. */
async function pump() {
  if (pumping || stopped) return;
  pumping = true;
  try {
    const slots = CFG.MAX_CONCURRENT - active.size;
    if (slots <= 0) return;
    // Sổ này nhỏ (chỉ chứa tài khoản đang xoá dở) ⇒ đọc rồi lọc/sắp xếp trong bộ nhớ, KHÔNG cần composite index.
    const snap = await COL().limit(200).get();
    const now = Date.now();
    const candidates = snap.docs
      .map((d) => d.data())
      .filter((e) => e && e.uid && e.status !== "failed" && !active.has(e.uid) && (e.leaseUntilMs || 0) <= now && (e.nextAttemptAtMs || 0) <= now)
      .sort((a, b) => (a.requestedAtMs || 0) - (b.requestedAtMs || 0));
    for (const e of candidates.slice(0, slots)) launch(e.uid);
  } catch (err) {
    console.error("[account-deletion] pump:", err && err.message);
  } finally {
    pumping = false;
  }
}

function kick() {
  setImmediate(() => pump().catch(() => {}));
}

/** Gọi 1 lần từ server.js: nhặt việc dang dở sau khi khởi động + quét định kỳ. */
function startSweeper() {
  stopped = false;
  const boot = setTimeout(() => pump().catch(() => {}), CFG.BOOT_DELAY_MS);
  const loop = setInterval(() => pump().catch(() => {}), CFG.SWEEP_INTERVAL_MS);
  [boot, loop].forEach((t) => typeof t.unref === "function" && t.unref());
  timers = [boot, loop];
}

/** SIGTERM (Render deploy/restart): trả lease ngay để instance mới nhận tiếp, khỏi chờ lease hết hạn. */
async function releaseLeases() {
  stopped = true;
  timers.forEach((t) => clearTimeout(t) || clearInterval(t));
  await Promise.all(
    [...active].map((uid) =>
      COL()
        .doc(uid)
        .update({ leaseOwner: null, leaseUntilMs: 0, status: "queued" })
        .catch(() => {})
    )
  );
}

module.exports = {
  requestDeletion,
  startSweeper,
  releaseLeases,
  pump,
  DeletionRequestError,
  STEPS,
  __test: { claim, processOne, recordFailure, active, INSTANCE_ID, CFG, RewindError, backoffMs, reset: () => { stopped = false; pumping = false; active.clear(); } },
};
