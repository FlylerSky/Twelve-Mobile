const { db } = require("../config/firebase");
const { COLLECTIONS } = require("../utils/constants");
const { isReservedTagName } = require("../utils/helpers");

/**
 * ==== v2.2.2 [R-03] — tag dành riêng ĐANG bị tài khoản thường giữ ====
 * Danh sách tag dành riêng chỉ chặn đăng ký/đổi tag MỚI; tài khoản đã giữ tag đó từ trước không bị đụng tới. Hàm này CHỈ ĐỌC: liệt kê các tag trong
 * `tagNames` mà bộ so khớp hiện tại coi là dành riêng, kèm nhóm tài khoản chủ sở hữu (SA là chính đáng; còn lại nên xem xét liên hệ để đổi tên).
 */
async function auditReservedTags() {
  const snap = await db.collection(COLLECTIONS.TAGNAMES).get();
  const hits = [];
  for (const doc of snap.docs) {
    if (!isReservedTagName(doc.id)) continue;
    const uid = doc.data().uid;
    let group = null;
    let status = null;
    if (uid) {
      const user = await db.collection(COLLECTIONS.USERS).doc(uid).get();
      if (user.exists) { group = user.data().accountGroup || null; status = user.data().status || null; }
    }
    hits.push({ tag: doc.id, uid: uid || null, accountGroup: group, status });
  }
  return { scanned: snap.size, hits };
}

module.exports = { auditReservedTags };
