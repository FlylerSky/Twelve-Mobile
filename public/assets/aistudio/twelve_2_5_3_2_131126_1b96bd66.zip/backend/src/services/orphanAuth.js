const { db, auth } = require("../config/firebase");
const { COLLECTIONS } = require("../utils/constants");

/**
 * ==== v2.0.12 [Báo cáo Phiên 3 — N3] Tài khoản Firebase Auth "mồ côi" do đăng ký dở ====
 *
 * `POST /auth/register` tạo user Firebase Auth TRƯỚC rồi mới ghi hồ sơ Firestore trong một giao dịch. Nếu tiến trình chết
 * giữa hai bước (restart/crash), email đã tồn tại trong Auth nhưng không có hồ sơ: người dùng đăng ký lại gặp "email đã
 * đăng ký" nhưng không đăng nhập được hồ sơ nào.
 *
 * THIẾT KẾ AN TOÀN: KHÔNG BAO GIỜ xoá tài khoản Auth chỉ vì "không có hồ sơ" — cùng dự án Firebase có thể còn ứng dụng khác
 * (vd. app Android) tạo tài khoản Auth không có hồ sơ Twelve; xoá nhầm = mất tài khoản/chiếm quyền. Thay vào đó luồng đăng ký
 * ghi một DẤU `registrationMarkers/{uid}` ngay sau khi tạo user Auth và xoá dấu đó trong chính giao dịch tạo hồ sơ. Chỉ tài
 * khoản có dấu còn sót (và không có hồ sơ, đã quá hạn ân hạn) mới được coi là mồ côi của luồng đăng ký Twelve.
 */

const ORPHAN_GRACE_MS = 10 * 60 * 1000; // đang đăng ký dở thật (chưa xong giao dịch) thì chưa được xoá

/**
 * Phân loại một dấu đăng ký. Trả { orphan:boolean, reason }.
 * - orphan khi: dấu tồn tại, KHÔNG có hồ sơ users/{uid}, và dấu đã quá ORPHAN_GRACE_MS.
 */
async function classifyMarker(uid, marker, now = Date.now()) {
  const profile = await db.collection(COLLECTIONS.USERS).doc(uid).get();
  if (profile.exists) return { orphan: false, reason: "has-profile" }; // đăng ký xong nhưng chưa dọn dấu (an toàn: chỉ xoá dấu)
  const age = now - (Number(marker.createdAtMs) || 0);
  if (age < ORPHAN_GRACE_MS) return { orphan: false, reason: "in-grace" };
  return { orphan: true, reason: "no-profile" };
}

/**
 * Dùng khi `createUser` báo email đã tồn tại: nếu tài khoản đó là mồ côi của luồng đăng ký Twelve thì xoá để cho phép
 * đăng ký lại. Trả true nếu đã dọn. KHÔNG ném lỗi (mọi sự cố => false => giữ nguyên hành vi 409 cũ).
 */
async function healOrphanByEmail(email) {
  try {
    const existing = await auth.getUserByEmail(email);
    const markerRef = db.collection(COLLECTIONS.REGISTRATION_MARKERS).doc(existing.uid);
    const marker = await markerRef.get();
    if (!marker.exists) return false; // không do luồng đăng ký Twelve tạo => tuyệt đối không đụng tới
    const verdict = await classifyMarker(existing.uid, marker.data());
    if (!verdict.orphan) return false;
    await auth.deleteUser(existing.uid);
    await markerRef.delete();
    console.warn(`[register] đã dọn tài khoản Auth mồ côi ${existing.uid} (đăng ký dở trước đó)`);
    return true;
  } catch (err) {
    console.error("healOrphanByEmail lỗi (bỏ qua):", err.message);
    return false;
  }
}

/**
 * Quét toàn bộ dấu đăng ký (dùng cho script dọn). `apply=false` chỉ liệt kê.
 * Trả { scanned, orphans:[{uid,email,ageMin,authExists}], staleMarkers, deleted }.
 */
async function cleanupOrphans({ apply = false, now = Date.now() } = {}) {
  const result = { scanned: 0, orphans: [], staleMarkers: 0, deleted: 0 };
  const snap = await db.collection(COLLECTIONS.REGISTRATION_MARKERS).get();
  for (const doc of snap.docs) {
    result.scanned++;
    const marker = doc.data();
    const verdict = await classifyMarker(doc.id, marker, now);
    if (verdict.reason === "has-profile") {
      // Đăng ký thành công nhưng dấu chưa được xoá (hiếm): chỉ dọn dấu, KHÔNG đụng tới tài khoản Auth.
      result.staleMarkers++;
      if (apply) await doc.ref.delete();
      continue;
    }
    if (!verdict.orphan) continue;
    let authExists = true;
    try {
      await auth.getUser(doc.id);
    } catch (err) {
      authExists = false;
    }
    result.orphans.push({ uid: doc.id, email: marker.email || "", ageMin: Math.round((now - (Number(marker.createdAtMs) || 0)) / 60000), authExists });
    if (apply) {
      if (authExists) {
        try {
          await auth.deleteUser(doc.id);
        } catch (err) {
          if (err.code !== "auth/user-not-found") throw err; // đã mất trong lúc quét: chỉ dọn dấu
        }
      }
      await doc.ref.delete();
      result.deleted++;
    }
  }
  return result;
}

module.exports = { healOrphanByEmail, cleanupOrphans, classifyMarker, ORPHAN_GRACE_MS };
