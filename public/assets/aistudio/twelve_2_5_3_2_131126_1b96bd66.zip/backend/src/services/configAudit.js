const { db } = require("../config/firebase");
const { COLLECTIONS } = require("../utils/constants");

/**
 * ==== v2.5.3 [TW-09] — Nhật ký thay đổi cấu hình của SA (ai, lúc nào, thay đổi gì) ====
 * Trước 2.5.3 `config/embedDomains` và `config/fonts` chỉ lưu `updatedByUid` của LẦN SỬA CUỐI — sửa hai lần là mất dấu lần đầu, và xoá báo cáo CSP không để lại dấu gì.
 * Mỗi lần SA đổi allowlist iframe/ảnh (ảnh hưởng cả `frame-src` hiệu lực của sanitizer), danh sách font, hoặc đặt lại bảng báo cáo CSP đều ghi MỘT document mới (chỉ thêm, không sửa)
 * vào `configAudit/{autoId}`: `{ action, byUid, atMs, at, diff, v }`.
 *
 * Ghi CÙNG MỘT batch với thay đổi cấu hình (embed/fonts) ⇒ hoặc có cả hai hoặc không có gì; ghi TRƯỚC khi thực hiện (đặt lại CSP) ⇒ không có thay đổi "không để lại dấu".
 * `diff` là TÓM TẮT có giới hạn (≤ MAX_ITEMS mục, mỗi chuỗi ≤ MAX_STR ký tự) — không lưu cả danh sách. KHÔNG lưu IP, email hay token.
 * rules chặn hoàn toàn Client SDK (xem firestore.rules); SA đọc qua GET /api/admin/config-audit hoặc Firebase Console.
 */
const MAX_ITEMS = 100;
const MAX_STR = 200;
const SCHEMA = 1;

const clip = (v, n = MAX_STR) => String(v == null ? "" : v).slice(0, n);
const capList = (arr) => arr.slice(0, MAX_ITEMS).map((x) => clip(x));

/** So hai danh sách theo khoá: trả { added, removed, changed } (nhãn rút gọn) + tổng trước/sau. `fingerprintOf` dùng để phát hiện sửa giá trị của cùng một khoá. */
function listDiff(before, after, { keyOf, labelOf, fingerprintOf = () => "" }) {
  const b = new Map((Array.isArray(before) ? before : []).map((x) => [keyOf(x), x]));
  const a = new Map((Array.isArray(after) ? after : []).map((x) => [keyOf(x), x]));
  const added = [];
  const removed = [];
  const changed = [];
  for (const [k, v] of a) {
    if (!b.has(k)) added.push(labelOf(v));
    else if (fingerprintOf(b.get(k)) !== fingerprintOf(v)) changed.push(labelOf(v));
  }
  for (const [k, v] of b) if (!a.has(k)) removed.push(labelOf(v));
  const cap = (list) => ({ count: list.length, items: capList(list) });
  return { added: cap(added), removed: cap(removed), changed: cap(changed), total: { before: b.size, after: a.size } };
}

const domainKey = (d) => `${String(d && d.domain || "").toLowerCase()}|${String(d && d.path || "")}`;
const domainLabel = (d) => `${(d && d.domain) || ""}${d && d.path ? `/${d.path}` : ""}`;

/** Diff cấu hình domain nhúng: danh sách domain + công tắc bật/tắt. */
function diffEmbedDomains(before, after) {
  const beforeEnabled = !before || before.enabled !== false;
  const afterEnabled = after.enabled !== false;
  return {
    enabled: beforeEnabled === afterEnabled ? { unchanged: afterEnabled } : { from: beforeEnabled, to: afterEnabled },
    domains: listDiff(before && before.domains, after.domains, { keyOf: domainKey, labelOf: domainLabel }),
  };
}

const fontSource = (f) => (f && f.kind === "file" ? `file:${f.file}` : `url:${f && f.url}`);
/** Diff danh sách font: thêm/bỏ theo `id`; "changed" khi đổi nguồn (url/file), kiểu hoặc độ đậm của cùng một font. */
function diffFonts(before, after) {
  return listDiff(before, after, {
    keyOf: (f) => String(f && f.id),
    labelOf: (f) => `${clip(f && f.label, 60)} (${fontSource(f)})`,
    fingerprintOf: (f) => `${f && f.kind}|${fontSource(f)}|${f && f.weight}`,
  });
}

function buildEntry({ action, uid, diff }) {
  const now = Date.now();
  return { v: SCHEMA, action: clip(action, 60), byUid: clip(uid, 128) || null, atMs: now, at: new Date(now).toISOString(), diff: diff || {} };
}

/** Tham chiếu document nhật ký mới (id tự sinh) — dùng chung batch với việc ghi cấu hình. */
const newAuditRef = () => db.collection(COLLECTIONS.CONFIG_AUDIT).doc();

/** Ghi một mục độc lập (cho thay đổi không đi kèm ghi Firestore, vd. đặt lại bảng CSP trong RAM). Ném lỗi nếu ghi thất bại — caller KHÔNG được thực hiện thay đổi. */
async function record(entryInput) {
  const entry = buildEntry(entryInput);
  await newAuditRef().set(entry);
  return entry;
}

/** Mục mới nhất trước. */
async function listRecent(limit = 50) {
  const n = Math.min(200, Math.max(1, Number.parseInt(limit, 10) || 50));
  const snap = await db.collection(COLLECTIONS.CONFIG_AUDIT).orderBy("atMs", "desc").limit(n).get();
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

module.exports = { buildEntry, newAuditRef, record, listRecent, diffEmbedDomains, diffFonts, listDiff, MAX_ITEMS, MAX_STR };
