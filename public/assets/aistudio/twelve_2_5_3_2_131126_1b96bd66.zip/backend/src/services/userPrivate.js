const { db, admin } = require("../config/firebase");
const { COLLECTIONS, ACCOUNT_STATUS } = require("../utils/constants");

/**
 * ==== v2.2.0 — Dữ liệu RIÊNG của user: tên thật (`fullName`) ====
 *
 * VÌ SAO TÁCH KHỎI `users/{uid}`: rules cho CHÍNH CHỦ đọc nguyên document `users/{uid}` bằng Client SDK (AuthContext dùng onSnapshot để
 * cập nhật điểm tài khoản realtime) — nên MỌI field trong document đó, kể cả `fullName`, đều đi tới trình duyệt. Che nó ở giao diện thì
 * ai mở DevTools vẫn thấy, và yêu cầu "xem/đổi tên thật phải nhập mật khẩu" thành hình thức. Firestore không cho ẩn từng field, nên tên
 * thật nằm ở collection `userPrivate/{uid}` mà rules chặn hoàn toàn (chỉ Admin SDK của backend đọc/ghi được), và chỉ trả ra qua
 * endpoint yêu cầu `requireRecentAuth` (vừa nhập lại mật khẩu).
 *
 * TƯƠNG THÍCH NGƯỢC: tài khoản tạo trước v2.2.0 còn `fullName` trong `users/{uid}`. `readRealName` tự CHUYỂN lười sang `userPrivate`
 * lần đầu chủ tài khoản xem/đổi; `scripts/migrate-fullname-private.js` chuyển hàng loạt phần còn lại. Cho tới khi chuyển, backend vẫn
 * không bao giờ trả `fullName` trong GET /users/me, và frontend cũng lọc nó khỏi dữ liệu realtime.
 */

const PRIV = () => db.collection(COLLECTIONS.USER_PRIVATE);
const USERS = () => db.collection(COLLECTIONS.USERS);
const FieldValue = () => admin.firestore.FieldValue;

/** Ném ACCOUNT_NOT_ACTIVE nếu hồ sơ không còn (hoặc không còn `active`) — dùng BÊN TRONG transaction, sau khi đã đọc hồ sơ. */
function ensureActive(userSnap) {
  if (!userSnap.exists || userSnap.data().status !== ACCOUNT_STATUS.ACTIVE) {
    throw Object.assign(new Error("ACCOUNT_NOT_ACTIVE"), { code: "ACCOUNT_NOT_ACTIVE" });
  }
}

/**
 * Chuyển `fullName` từ users/{uid} sang userPrivate/{uid} trong MỘT transaction (ghi nơi mới + xoá nơi cũ cùng lúc, cả hai hoặc không cái nào).
 * v2.2.1 [A-02]: trước đây là 2 lệnh rời (set merge rồi update) — `set + merge` TẠO LẠI `userPrivate/{uid}` nếu tài khoản vừa bị xoá xong.
 * Nay transaction đọc `users/{uid}` và chỉ ghi khi tài khoản còn active.
 */
async function moveLegacyFullName(uid, fullName) {
  await db.runTransaction(async (tx) => {
    const userRef = USERS().doc(uid);
    const user = await tx.get(userRef);
    ensureActive(user);
    tx.set(PRIV().doc(uid), { fullName, migratedAt: new Date().toISOString() }, { merge: true });
    tx.update(userRef, { fullName: FieldValue().delete() });
  });
}

/** Tên thật của uid ("" nếu chưa có). Chỉ gọi sau khi đã qua requireRecentAuth. Ném ACCOUNT_NOT_ACTIVE nếu tài khoản vừa bị xoá/khoá. */
async function readRealName(uid) {
  const priv = await PRIV().doc(uid).get();
  if (priv.exists && typeof priv.data().fullName === "string") return priv.data().fullName;

  const user = await USERS().doc(uid).get();
  const legacy = user.exists ? user.data().fullName : undefined;
  if (typeof legacy === "string" && legacy) {
    await moveLegacyFullName(uid, legacy);
    return legacy;
  }
  return "";
}

/**
 * Đặt tên thật mới (đã được validator làm sạch) và dọn field cũ nếu còn.
 * v2.2.1 [A-02 / T-220-01]: làm trong transaction có kiểm tra trạng thái. Transaction đọc `users/{uid}` nên bị tuần tự hoá với transaction
 * `requestDeletion` (cùng ghi document đó): một request bị kẹt giữa middleware và bước ghi không thể dựng lại `userPrivate/{uid}`
 * sau khi tài khoản đã bị xoá (hoặc đang bị xoá) — nó nhận ACCOUNT_NOT_ACTIVE và không ghi gì.
 */
async function writeRealName(uid, fullName) {
  await db.runTransaction(async (tx) => {
    const userRef = USERS().doc(uid);
    const user = await tx.get(userRef);
    ensureActive(user);
    tx.set(PRIV().doc(uid), { fullName, updatedAt: new Date().toISOString() }, { merge: true });
    if (user.data().fullName !== undefined) tx.update(userRef, { fullName: FieldValue().delete() });
  });
}

/** Bỏ `fullName` khỏi đối tượng user trước khi trả ra API (phòng tài khoản cũ chưa chuyển). */
function withoutRealName(user) {
  if (!user || typeof user !== "object") return user;
  const { fullName, ...rest } = user; // eslint-disable-line no-unused-vars
  return rest;
}

module.exports = { readRealName, writeRealName, moveLegacyFullName, withoutRealName };
