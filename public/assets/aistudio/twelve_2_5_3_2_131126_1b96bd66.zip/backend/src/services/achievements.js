const { db } = require("../config/firebase");
const { COLLECTIONS, PROFILE } = require("../utils/constants");
const { toIsoString } = require("../utils/time");

/**
 * ==== v2.5.2 — THÀNH TÍCH của một người dùng (hộp "Xem thêm" ở trang Profile) ====
 *
 * Nguồn dữ liệu: `weeklyLeaderboards/{mãTuần}` — top 10 người tăng điểm tài khoản mạnh nhất mỗi tuần, do trang Xu hướng CHỐT một lần khi tuần kết thúc và
 * KHÔNG BAO GIỜ ghi đè (xem trending.controller.js#performWeekRollover). Mỗi doc: `{ weekCode, top10: [{ rank, uid, weeklyGrowth, … }], totalParticipants, finalizedAt }`.
 *
 * Firestore không truy vấn được "mảng chứa đối tượng có uid = X", nên đọc CẢ collection rồi dựng chỉ mục uid → các tuần. Collection này nhỏ
 * (đúng MỘT doc mỗi tuần, ~52/năm; mỗi doc vài KB) và bản ghi đã chốt không đổi, nên:
 *   • cache trong bộ nhớ CACHE_MS (một lần quét phục vụ MỌI người xem, thay vì mỗi lần mở "Xem thêm" tốn N lượt đọc);
 *   • "single-flight": nhiều request đồng thời chỉ quét một lần;
 *   • tuần mới được chốt sau tối đa CACHE_MS mới hiện ở hồ sơ — chấp nhận được (thành tích không cần tức thời).
 * Lỗi quét → ném lỗi cho caller (controller trả 500); KHÔNG cache lỗi.
 *
 * Số điểm tài khoản (`accountScore`) lấy từ hồ sơ do controller truyền vào — đây là con số vốn công khai (bảng xếp hạng người dùng ở Xu hướng).
 * Bảng Hashtag của Xu hướng (hashtagWeeklyLeaderboards, hashtagExploreSnapshots) là thành tích của HASHTAG, không gắn với người dùng nào nên không dùng ở đây.
 */
const CACHE_MS = 5 * 60 * 1000;
let cache = { at: 0, index: null };
let inflight = null;

/** "N.K.MM.YYYY" → N (số tuần tổng, tăng dần) để sắp tuần mới nhất trước. Mã lạ → 0. */
function weekNumber(code) {
  const n = Number.parseInt(String(code || "").split(".")[0], 10);
  return Number.isFinite(n) ? n : 0;
}

async function buildIndex() {
  const snap = await db.collection(COLLECTIONS.WEEKLY_LEADERBOARDS).get();
  const byUid = new Map();
  let weeks = 0;
  snap.docs.forEach((doc) => {
    const d = doc.data();
    if (!d || !Array.isArray(d.top10)) return;
    weeks += 1;
    const weekCode = typeof d.weekCode === "string" && d.weekCode ? d.weekCode : doc.id;
    const finalizedAt = toIsoString(d.finalizedAt);
    d.top10.forEach((e) => {
      if (!e || typeof e.uid !== "string" || !Number.isFinite(e.rank)) return;
      const list = byUid.get(e.uid) || [];
      list.push({ weekCode, rank: e.rank, weeklyGrowth: Number.isFinite(e.weeklyGrowth) ? e.weeklyGrowth : 0, finalizedAt });
      byUid.set(e.uid, list);
    });
  });
  return { byUid, weeks };
}

async function getIndex() {
  const now = Date.now();
  if (cache.index && now - cache.at < CACHE_MS) return cache.index;
  if (!inflight) {
    inflight = buildIndex()
      .then((index) => {
        cache = { at: Date.now(), index };
        return index;
      })
      .finally(() => {
        inflight = null;
      });
  }
  return inflight;
}

/** Chỉ dùng trong test: bỏ cache để mỗi ca đọc dữ liệu mới. */
function resetAchievementsCache() {
  cache = { at: 0, index: null };
  inflight = null;
}

/**
 * Thành tích của `uid`.
 * @param {string} uid
 * @param {{ accountScore?: number }} [profile] hồ sơ (để lấy điểm tài khoản)
 * @returns {Promise<{ accountScore: number, weekly: { weeksRecorded: number, top10Count: number, top3Count: number, firstPlaceCount: number,
 *            best: {weekCode, rank, weeklyGrowth}|null, recent: {weekCode, rank, weeklyGrowth}[] } }>}
 *   - weeksRecorded: tổng số tuần đã được chốt (mẫu số cho "vào top 10 X/Y tuần");
 *   - best: tuần có thứ hạng cao nhất (hoà hạng → tuần tăng điểm nhiều hơn, rồi tuần gần hơn);
 *   - recent: tối đa PROFILE.ACHIEVEMENT_RECENT_WEEKS tuần gần nhất mà người này lọt top 10, tuần mới nhất trước.
 */
async function getUserAchievements(uid, profile = {}) {
  const { byUid, weeks } = await getIndex();
  const entries = (byUid.get(uid) || []).slice().sort((a, b) => weekNumber(b.weekCode) - weekNumber(a.weekCode));
  const pick = ({ weekCode, rank, weeklyGrowth }) => ({ weekCode, rank, weeklyGrowth });
  let best = null;
  for (const e of entries) {
    if (!best || e.rank < best.rank || (e.rank === best.rank && e.weeklyGrowth > best.weeklyGrowth)) best = e; // entries đã mới → cũ: hoà tuyệt đối giữ tuần gần hơn
  }
  return {
    accountScore: Number.isFinite(profile.accountScore) ? profile.accountScore : 0,
    weekly: {
      weeksRecorded: weeks,
      top10Count: entries.length,
      top3Count: entries.filter((e) => e.rank <= 3).length,
      firstPlaceCount: entries.filter((e) => e.rank === 1).length,
      best: best ? pick(best) : null,
      recent: entries.slice(0, PROFILE.ACHIEVEMENT_RECENT_WEEKS).map(pick),
    },
  };
}

module.exports = { getUserAchievements, resetAchievementsCache, weekNumber };
