const { db } = require("../config/firebase");
const { COLLECTIONS, ACCOUNT_STATUS, PROFILE } = require("../utils/constants");
const { isLiveProfile, toPublicUser } = require("../utils/helpers");
const { isSafeDocId } = require("../utils/input");

/**
 * ==== v2.5.2 — KHÁCH GHÉ THĂM hồ sơ ====
 *
 * Lưu: MỘT document `profileVisitors/{uid chủ hồ sơ}` = `{ visitors: [{ uid, at }], updatedAt }`, mới nhất ĐỨNG ĐẦU, tối đa PROFILE.VISITORS_MAX (50) người.
 *   • KHÔNG TRÙNG: mỗi người chỉ một dòng; vào lại thì dòng cũ bị bỏ và người đó lên đầu với thời điểm mới.
 *   • Chỉ lưu `{ uid, at }` — tên/tag/huy hiệu/avatar đọc TƯƠI từ hồ sơ lúc xem (đổi tên → danh sách đổi theo; không nhân bản dữ liệu cá nhân).
 *   • Chỉ ghi người ĐÃ ĐĂNG NHẬP (khách ẩn danh không có hồ sơ để hiện) và không ghi chính chủ.
 * Vì sao một document thay vì mỗi khách một document: đọc danh sách = 1 lượt đọc + 1 lượt getAll (≤ 50), không cần truy vấn/xoá phần dư khi vượt 50;
 * kích thước cố định (~50 × 60 byte). Đánh đổi: các lượt ghé thăm CÙNG LÚC vào một hồ sơ bị tuần tự hoá bởi transaction (Firestore ~1 ghi/giây/doc);
 * ở quy mô Twelve đủ dùng, và `VISIT_REFRESH_MS` bỏ qua ghi lặp của người đang đứng đầu.
 *
 * Quyền xem: chỉ CHỦ hồ sơ (GET /users/me/visitors — requireAuth). Collection bị rules chặn hoàn toàn Client SDK.
 * Dọn dẹp: xoá tài khoản xoá luôn doc này (services/accountDeletion.js#stepResidual). Khách đã xoá tài khoản ở danh sách người khác bị LỌC khi đọc (không hiện).
 */

const REF = (ownerUid) => db.collection(COLLECTIONS.PROFILE_VISITORS).doc(ownerUid);

/** Hồ sơ này có hiển thị công khai được không (cùng quy tắc loadLivePublicUser: không "ma", không pending, không đang xoá)? */
function isPublicLive(data) {
  return isLiveProfile(data) && data.status !== ACCOUNT_STATUS.PENDING && data.status !== ACCOUNT_STATUS.DELETING;
}

/** Danh sách thô đã làm sạch: chỉ `{ uid, at }` hợp lệ, không trùng uid, tối đa VISITORS_MAX. Dữ liệu hỏng không làm sập — bị bỏ qua. */
function normalizeVisitors(raw) {
  const seen = new Set();
  const out = [];
  for (const e of Array.isArray(raw) ? raw : []) {
    if (!e || typeof e.uid !== "string" || !isSafeDocId(e.uid) || seen.has(e.uid) || !Number.isFinite(e.at)) continue;
    seen.add(e.uid);
    out.push({ uid: e.uid, at: e.at });
    if (out.length >= PROFILE.VISITORS_MAX) break;
  }
  return out;
}

/**
 * Ghi nhận `visitorUid` vừa ghé hồ sơ của `ownerUid`.
 * @returns {Promise<{ recorded: boolean, reason?: "self"|"owner-unavailable"|"recent" }>}
 *   - "self": tự xem hồ sơ mình — không ghi;
 *   - "owner-unavailable": chủ hồ sơ không còn/không công khai — KHÔNG dựng lại document (tránh dữ liệu "ma" sau khi xoá tài khoản, giống assertActorActive);
 *   - "recent": người này đang đứng đầu và mới vào lại trong VISIT_REFRESH_MS — bỏ qua để khỏi ghi Firestore mỗi lần tải lại trang.
 */
async function recordVisit(ownerUid, visitorUid, now = Date.now()) {
  if (!isSafeDocId(ownerUid) || !isSafeDocId(visitorUid)) return { recorded: false, reason: "owner-unavailable" };
  if (ownerUid === visitorUid) return { recorded: false, reason: "self" };

  return db.runTransaction(async (tx) => {
    // Đọc TRƯỚC, ghi sau. Đọc hồ sơ chủ trong transaction: tuần tự hoá với transaction xoá tài khoản (cùng ghi `users/{uid}`).
    const ownerSnap = await tx.get(db.collection(COLLECTIONS.USERS).doc(ownerUid));
    if (!ownerSnap.exists || !isPublicLive(ownerSnap.data())) return { recorded: false, reason: "owner-unavailable" };
    const ref = REF(ownerUid);
    const snap = await tx.get(ref);
    const current = normalizeVisitors(snap.exists ? snap.data().visitors : []);

    if (current[0] && current[0].uid === visitorUid && now - current[0].at < PROFILE.VISIT_REFRESH_MS) {
      return { recorded: false, reason: "recent" };
    }
    const next = [{ uid: visitorUid, at: now }, ...current.filter((e) => e.uid !== visitorUid)].slice(0, PROFILE.VISITORS_MAX);
    tx.set(ref, { visitors: next, updatedAt: now });
    return { recorded: true };
  });
}

/**
 * Danh sách khách ghé thăm của `ownerUid` để hiển thị: mới nhất trước, mỗi phần tử là hồ sơ công khai của khách (toPublicUser: tên, tag, huy hiệu, avatar…)
 * kèm `visitedAt` (ISO). Khách không còn tồn tại/không công khai bị lọc.
 */
async function listVisitors(ownerUid) {
  if (!isSafeDocId(ownerUid)) return [];
  const snap = await REF(ownerUid).get();
  const entries = normalizeVisitors(snap.exists ? snap.data().visitors : []);
  if (entries.length === 0) return [];
  const users = await db.getAll(...entries.map((e) => db.collection(COLLECTIONS.USERS).doc(e.uid)));
  const out = [];
  users.forEach((u, i) => {
    if (!u.exists || !isPublicLive(u.data())) return;
    out.push({ ...toPublicUser({ uid: entries[i].uid, ...u.data() }), visitedAt: new Date(entries[i].at).toISOString() });
  });
  return out;
}

module.exports = { recordVisit, listVisitors, normalizeVisitors };
