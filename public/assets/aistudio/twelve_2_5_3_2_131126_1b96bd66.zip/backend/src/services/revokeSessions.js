const { db, auth } = require("../config/firebase");
const { COLLECTIONS, ACCOUNT_GROUP, ACCOUNT_ROLE } = require("../utils/constants");
const { isSafeDocId } = require("../utils/input");

/**
 * ==== v2.5.3 [TW-05] — Thu hồi phiên của tài khoản bị lộ/đã giao cho bên khác (công cụ vận hành, KHÔNG có endpoint HTTP) ====
 * Báo cáo bảo mật 2.5.2 ghi tài khoản SA thử nghiệm đã giao cho công cụ AI. Đổi mật khẩu một mình KHÔNG làm ID token đã cấp hết hiệu lực ngay (token sống tới ~1 giờ, refresh token sống mãi
 * tới khi bị thu hồi). Hàm này làm đúng phần mà Console không có nút: (tuỳ chọn) HẠ nhóm về RA/`user` ở Firestore, (tuỳ chọn) vô hiệu hoá tài khoản Auth, rồi `revokeRefreshTokens(uid)`.
 * `requireAuth` kiểm thu hồi có cache 60 giây (middleware/auth.js) nên token cũ bị từ chối trong ≤ 1 phút sau khi chạy.
 * KHÔNG đặt/đổi mật khẩu ở đây (mật khẩu không được đi qua dòng lệnh): đổi ở Firebase Console > Authentication hoặc dùng "Quên mật khẩu". MẶC ĐỊNH LÀ DRY-RUN.
 *
 * Thứ tự khi --apply: hạ nhóm → vô hiệu hoá → thu hồi (hạ nhóm trước để dù bước sau lỗi, quyền cao đã mất). Mỗi tài khoản độc lập: một tài khoản lỗi không chặn các tài khoản còn lại.
 */
async function resolveTargets({ uids = [], emails = [] }) {
  const out = [];
  const seen = new Set();
  const push = (uid, note) => { if (!seen.has(uid)) { seen.add(uid); out.push({ uid, note }); } };
  for (const uid of uids) {
    if (!isSafeDocId(uid)) { out.push({ uid: String(uid).slice(0, 40), error: "uid không hợp lệ" }); continue; }
    push(uid);
  }
  for (const email of emails) {
    try {
      const rec = await auth.getUserByEmail(String(email).trim().toLowerCase());
      push(rec.uid, `từ email`);
    } catch (err) {
      out.push({ uid: null, error: `không tìm thấy tài khoản Auth cho một email đã nêu (${err && err.code ? err.code : "lỗi"})` });
    }
  }
  return out;
}

async function revokeUserSessions({ uids = [], emails = [], apply = false, disable = false, demote = false } = {}) {
  const targets = await resolveTargets({ uids, emails });
  const results = [];
  for (const t of targets) {
    if (t.error) { results.push({ uid: t.uid, ok: false, error: t.error }); continue; }
    const row = { uid: t.uid, ok: true, before: {}, actions: [] };
    try {
      let rec = null;
      try { rec = await auth.getUser(t.uid); } catch (err) {
        if (err && (err.code === "auth/user-not-found" || err.errorInfo?.code === "auth/user-not-found")) { results.push({ uid: t.uid, ok: false, error: "không có tài khoản Auth với uid này" }); continue; }
        throw err;
      }
      const snap = await db.collection(COLLECTIONS.USERS).doc(t.uid).get();
      const profile = snap.exists ? snap.data() : null;
      row.before = { group: profile ? profile.accountGroup || null : "(không có hồ sơ)", role: profile ? profile.accountRole || null : null, status: profile ? profile.status || null : null, disabled: !!rec.disabled, tokensValidAfter: rec.tokensValidAfterTime || null };

      if (demote && profile && (profile.accountGroup !== ACCOUNT_GROUP.RA || profile.accountRole !== ACCOUNT_ROLE.USER)) row.actions.push("demote");
      if (disable && !rec.disabled) row.actions.push("disable");
      row.actions.push("revoke");

      if (apply) {
        if (row.actions.includes("demote")) await db.collection(COLLECTIONS.USERS).doc(t.uid).update({ accountGroup: ACCOUNT_GROUP.RA, accountRole: ACCOUNT_ROLE.USER });
        if (row.actions.includes("disable")) await auth.updateUser(t.uid, { disabled: true });
        await auth.revokeRefreshTokens(t.uid);
      }
    } catch (err) {
      row.ok = false;
      row.error = err && err.message ? err.message : String(err);
    }
    results.push(row);
  }
  return { apply, results };
}

module.exports = { revokeUserSessions, resolveTargets };
