const { db, auth } = require("../config/firebase");
const { COLLECTIONS, ACCOUNT_STATUS } = require("../utils/constants");
const accountDeletion = require("./accountDeletion");

/**
 * ==== v2.2.1 [A-04] — dọn tài khoản `pending` QUÁ HẠN ====
 * Tài khoản đăng ký xong ở trạng thái `pending` (chờ xác minh email). Trước 2.2.1 không có gì dọn các tài khoản không bao giờ được xác minh, nên mỗi
 * tài khoản như vậy giữ một `tagNames/{tag}` và một email Firebase mãi mãi: chiếm tag, chiếm email của người khác (người thật đăng ký sau gặp 409), phình dữ liệu.
 *
 * AN TOÀN: KHÔNG đụng tới tài khoản mà Firebase Auth báo `emailVerified === true` (đã xác minh nhưng chưa đăng nhập lại để đồng bộ status), không đụng tới
 * hồ sơ thiếu `createdAt` (không biết tuổi). Việc xoá dùng lại quy trình bền vững `accountDeletion.requestDeletion` (xoá tag, dữ liệu riêng, tài khoản Auth, hồ sơ).
 * Mặc định quá hạn = 14 ngày. Dry-run theo mặc định (xem scripts/cleanup-pending-accounts.js).
 */
/**
 * ==== v2.5.3 [TW-08] — dọn pending THƯỜNG XUYÊN, hạn ngắn hơn, quét theo trang ====
 * Trước 2.5.3 chỉ có script chạy tay (`npm run pending:cleanup:apply`) và `SCAN_LIMIT = 2000` cứng: người giải được CAPTCHA tạo hàng loạt tài khoản `pending` thì giữ
 * Tag Name + email (kể cả bằng `+alias`) vô thời hạn — người thật đăng ký sau gặp 409. Nay:
 *   - Hạn mặc định 7 ngày (env PENDING_MAX_AGE_DAYS, 1–90; trước là 14). Email xác minh của Firebase hết hạn sớm hơn mốc này; người cần thêm thời gian vẫn đăng ký lại được.
 *   - `startPendingSweeper()` (gọi từ server.js) tự chạy sau khi khởi động và mỗi 6 giờ (env PENDING_SWEEP_INTERVAL_MIN, 15–1440). Tắt hẳn bằng PENDING_SWEEPER=off.
 *   - Quét THEO TRANG (con trỏ `startAfter`, 500 hồ sơ/trang, tối đa MAX_SCAN = 20 000) thay vì một lần 2000 — pending cũ không còn bị "che" bởi 2000 hồ sơ mới hơn.
 *   - Giới hạn số tài khoản xếp hàng xoá MỖI LẦN CHẠY của sweeper (PENDING_SWEEP_MAX_PER_RUN, mặc định 500, 1–5000): nếu logic nào đó sai thì thiệt hại bị chặn ở mức đó.
 *     Phần còn lại (`truncated`) được lần chạy sau xử lý tiếp.
 * Các bảo vệ cũ GIỮ NGUYÊN: không đụng tài khoản Auth báo `emailVerified`, không đụng hồ sơ thiếu `createdAt`, kiểm lại ngay trước từng lần xếp hàng (R-04), việc xoá đi qua
 * quy trình bền vững `accountDeletion.requestDeletion`. Nhật ký của sweeper chỉ ghi SỐ LƯỢNG — không ghi email/uid.
 */
const DEFAULT_MAX_AGE_DAYS = 7;
const PAGE_SIZE = 500;
const MAX_SCAN = 20000;
const DEFAULT_SWEEP_INTERVAL_MIN = 360;
const DEFAULT_SWEEP_MAX_PER_RUN = 500;
const BOOT_DELAY_MS = 3 * 60 * 1000; // chờ sau khi khởi động để không dồn tải đúng lúc deploy

const intEnv = (name, def, min, max) => {
  const n = Number.parseInt(process.env[name], 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def;
};
const pendingMaxAgeDays = () => intEnv("PENDING_MAX_AGE_DAYS", DEFAULT_MAX_AGE_DAYS, 1, 90);
const pendingSweeperEnabled = () => String(process.env.PENDING_SWEEPER || "").trim().toLowerCase() !== "off";
const sweepIntervalMs = () => intEnv("PENDING_SWEEP_INTERVAL_MIN", DEFAULT_SWEEP_INTERVAL_MIN, 15, 1440) * 60 * 1000;
const sweepMaxPerRun = () => intEnv("PENDING_SWEEP_MAX_PER_RUN", DEFAULT_SWEEP_MAX_PER_RUN, 1, 5000);

const ISO_DATETIME = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/;

async function isEmailVerified(uid) {
  try {
    const rec = await auth.getUser(uid);
    return !!(rec && rec.emailVerified);
  } catch (err) {
    if (err && (err.code === "auth/user-not-found" || err.errorInfo?.code === "auth/user-not-found")) return false; // không còn tài khoản Auth: hồ sơ mồ côi
    throw err;
  }
}

async function cleanupExpiredPending({ apply = false, maxAgeDays = pendingMaxAgeDays(), now = Date.now(), maxExpired = Infinity, maxScan = MAX_SCAN, pageSize = PAGE_SIZE } = {}) {
  const cutoff = now - maxAgeDays * 24 * 60 * 60 * 1000;
  const expired = [];
  let scanned = 0;
  let skippedVerified = 0;
  let skippedYoung = 0;
  let skippedNoDate = 0;
  let skippedError = 0;
  let truncated = false;
  let last = null;
  // Quét theo trang bằng con trỏ — mặc định Firestore sắp theo id tài liệu nên không cần chỉ mục tổng hợp mới.
  while (scanned < maxScan) {
    let q = db.collection(COLLECTIONS.USERS).where("status", "==", ACCOUNT_STATUS.PENDING).limit(Math.min(pageSize, maxScan - scanned));
    if (last) q = q.startAfter(last);
    const snap = await q.get();
    if (!snap.docs.length) break;
    for (const doc of snap.docs) {
      const d = doc.data();
      // v2.5.3 (rà soát độc lập): chỉ chấp nhận chuỗi ISO (đúng thứ `register` ghi). `Date.parse` cũng nuốt "2020" hoặc số nhỏ như một năm xa xưa ⇒ hồ sơ có `createdAt` lạ bị coi là "rất cũ"
      // và bị xoá. Hồ sơ lệch định dạng thì BỎ QUA (an toàn), không đoán.
      const created = typeof d.createdAt === "string" && ISO_DATETIME.test(d.createdAt) ? Date.parse(d.createdAt) : NaN;
      if (!Number.isFinite(created)) { skippedNoDate++; continue; }
      if (created > cutoff) { skippedYoung++; continue; }
      // Một lỗi Auth tạm thời (quota/5xx) chỉ bỏ qua RIÊNG hồ sơ đó — không huỷ cả lượt quét. Không xác định được ⇒ không xoá.
      let verified;
      try { verified = await isEmailVerified(doc.id); } catch (err) { skippedError++; continue; }
      if (verified) { skippedVerified++; continue; }
      expired.push({ uid: doc.id, email: d.email || null, tagName: d.tagName || null, ageDays: Math.floor((now - created) / 86400000) });
      if (expired.length >= maxExpired) { truncated = true; break; }
    }
    scanned += snap.docs.length;
    last = snap.docs[snap.docs.length - 1];
    if (truncated) break;
    if (snap.docs.length < Math.min(pageSize, maxScan)) break; // trang cuối
  }
  if (scanned >= maxScan) truncated = true;
  let queued = 0;
  let skippedLate = 0;
  if (apply) {
    for (const e of expired) {
      try {
        // v2.2.2 [R-04]: danh sách được lập TRƯỚC khi lặp xoá; với danh sách dài, người vừa xác minh email (hoặc vừa được kích hoạt) giữa hai vòng không được bị xoá.
        // Kiểm lại NGAY trước từng lần xếp hàng: email chưa xác minh VÀ hồ sơ vẫn còn `pending`.
        const fresh = await db.collection(COLLECTIONS.USERS).doc(e.uid).get();
        let verifiedNow;
        try { verifiedNow = await isEmailVerified(e.uid); } catch (err) { skippedError++; continue; } // không chắc ⇒ không xoá
        if (!fresh.exists || fresh.data().status !== ACCOUNT_STATUS.PENDING || verifiedNow) {
          skippedLate++;
          continue;
        }
        // v2.5.3 (rà soát độc lập): `onlyIfStatus` kiểm lại `pending` NGAY TRONG transaction xếp hàng — người vừa được kích hoạt giữa hai bước không bị lật sang `deleting`.
        if (await accountDeletion.requestDeletion(e.uid, { onlyIfStatus: ACCOUNT_STATUS.PENDING })) queued++;
        else skippedLate++;
      } catch (err) {
        console.error(`  ! Không xếp hàng xoá được ${e.uid}:`, err.message);
      }
    }
  }
  return { scanned, expired, queued, skippedLate, skippedVerified, skippedYoung, skippedNoDate, skippedError, truncated };
}

// ---------------------------------------------------------------- sweeper (v2.5.3 — TW-08)
let sweeping = false;
let sweepTimers = [];

/** Một lượt dọn của sweeper: áp dụng thật, có trần số tài khoản/lượt. Không bao giờ ném lỗi ra ngoài (chỉ ghi nhật ký không chứa PII). */
async function sweepOnce({ now = Date.now() } = {}) {
  if (sweeping) return null; // không chạy chồng nhau
  sweeping = true;
  try {
    const r = await cleanupExpiredPending({ apply: true, maxAgeDays: pendingMaxAgeDays(), now, maxExpired: sweepMaxPerRun() });
    if (r.queued || r.truncated) {
      console.log(`[pending-sweeper] đã quét ${r.scanned}, xếp hàng xoá ${r.queued} tài khoản pending quá hạn${r.skippedLate ? `, bỏ qua ${r.skippedLate} (vừa xác minh/kích hoạt)` : ""}${r.truncated ? " — còn nữa, lượt sau xử lý tiếp" : ""}.`);
    }
    return r;
  } catch (err) {
    console.error("[pending-sweeper] lỗi:", err && err.message);
    return null;
  } finally {
    sweeping = false;
  }
}

/** Gọi 1 lần từ server.js. PENDING_SWEEPER=off tắt hẳn. Timer unref: không giữ tiến trình sống. Trả về true nếu đã bật. */
function startPendingSweeper({ bootDelayMs = BOOT_DELAY_MS, intervalMs = sweepIntervalMs() } = {}) {
  stopPendingSweeper();
  if (!pendingSweeperEnabled()) return false;
  const boot = setTimeout(() => sweepOnce().catch(() => {}), bootDelayMs);
  const loop = setInterval(() => sweepOnce().catch(() => {}), intervalMs);
  [boot, loop].forEach((t) => typeof t.unref === "function" && t.unref());
  sweepTimers = [boot, loop];
  return true;
}

function stopPendingSweeper() {
  sweepTimers.forEach((t) => { clearTimeout(t); clearInterval(t); });
  sweepTimers = [];
}

module.exports = {
  cleanupExpiredPending,
  startPendingSweeper,
  stopPendingSweeper,
  sweepOnce,
  pendingMaxAgeDays,
  pendingSweeperEnabled,
  sweepIntervalMs,
  sweepMaxPerRun,
  DEFAULT_MAX_AGE_DAYS,
  PAGE_SIZE,
  MAX_SCAN,
};
