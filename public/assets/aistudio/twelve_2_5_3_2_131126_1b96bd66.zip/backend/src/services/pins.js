const { db } = require("../config/firebase");
const { COLLECTIONS, PROFILE, ACCOUNT_STATUS } = require("../utils/constants");
const { isSafeDocId } = require("../utils/input");

/**
 * ==== v2.4.0 — Bài viết GHIM lên Trang chủ hồ sơ ====
 *
 * Lưu ở hồ sơ người dùng: `users/{uid}.pinnedPostIds` = mảng id bài, THEO THỨ TỰ HIỂN THỊ (bài vừa ghim đứng đầu).
 * Vì sao ở hồ sơ mà không phải cờ `isPinned` trên từng bài:
 *   • giới hạn số bài ghim (PROFILE.PINNED_POSTS_MAX) kiểm trong MỘT transaction trên MỘT document — không cần truy vấn đếm;
 *   • đọc bài ghim là một lần `getAll` theo id (không cần chỉ mục mới);
 *   • chủ tài khoản đã nghe realtime document `users/{uid}` (AuthContext) nên mọi thẻ bài của chính mình biết ngay bài nào đang ghim,
 *     không cần gọi API thêm.
 * Hệ quả cần tự dọn: bài bị xoá thì id còn nằm trong mảng. Có HAI lớp dọn (cả hai best-effort, idempotent):
 *   1. deletePost gọi removePinsBestEffort sau khi xoá bài;
 *   2. đọc bài ghim (users.controller#listPinnedPosts) tự loại id không còn bài / không còn của người này và gỡ khỏi mảng.
 * Chỉ bài trong collection `posts` ghim được (Blog là nội dung của SA, không có hồ sơ tác giả để ghim).
 */

class PinError extends Error {
  constructor(code, status, message) {
    super(code);
    this.code = code;
    this.status = status;
    this.userMessage = message;
  }
}

/** Mảng id hợp lệ, không trùng, giữ thứ tự. Dữ liệu lạ (không phải mảng / phần tử lạ) bị bỏ chứ không làm hỏng hồ sơ. */
function normalizePinnedIds(raw) {
  if (!Array.isArray(raw)) return [];
  const out = [];
  const seen = new Set();
  for (const id of raw) {
    if (typeof id !== "string" || !isSafeDocId(id) || seen.has(id)) continue;
    seen.add(id);
    out.push(id);
  }
  return out;
}

const accountNotActive = () => Object.assign(new Error("ACCOUNT_NOT_ACTIVE"), { code: "ACCOUNT_NOT_ACTIVE" });

/**
 * Ghim bài `postId` của CHÍNH `uid`. Idempotent: bài đã ghim thì trả nguyên danh sách (changed=false), không tính vào giới hạn.
 * Ném PinError: POST_NOT_FOUND (404) · NOT_POST_OWNER (403) · PIN_LIMIT_REACHED (409); hoặc ACCOUNT_NOT_ACTIVE.
 */
async function pinPost(uid, postId) {
  const userRef = db.collection(COLLECTIONS.USERS).doc(uid);
  const postRef = db.collection(COLLECTIONS.POSTS).doc(postId);
  return db.runTransaction(async (tx) => {
    // Firestore: đọc hết trước, ghi sau.
    const userSnap = await tx.get(userRef);
    const postSnap = await tx.get(postRef);
    if (!userSnap.exists || userSnap.data().status !== ACCOUNT_STATUS.ACTIVE) throw accountNotActive();
    if (!postSnap.exists) throw new PinError("POST_NOT_FOUND", 404, "Không tìm thấy bài viết.");
    if (postSnap.data().authorUid !== uid) {
      throw new PinError("NOT_POST_OWNER", 403, "Bạn chỉ ghim được bài viết của chính mình.");
    }
    const current = normalizePinnedIds(userSnap.data().pinnedPostIds);
    if (current.includes(postId)) return { pinnedPostIds: current, changed: false };
    if (current.length >= PROFILE.PINNED_POSTS_MAX) {
      throw new PinError(
        "PIN_LIMIT_REACHED",
        409,
        `Bạn chỉ ghim được tối đa ${PROFILE.PINNED_POSTS_MAX} bài. Hãy gỡ ghim một bài trước.`
      );
    }
    const next = [postId, ...current];
    tx.update(userRef, { pinnedPostIds: next });
    return { pinnedPostIds: next, changed: true };
  });
}

/**
 * Gỡ ghim. KHÔNG đọc bài (bài đã bị xoá vẫn gỡ được id còn sót). Idempotent.
 */
async function unpinPost(uid, postId) {
  const userRef = db.collection(COLLECTIONS.USERS).doc(uid);
  return db.runTransaction(async (tx) => {
    const userSnap = await tx.get(userRef);
    if (!userSnap.exists || userSnap.data().status !== ACCOUNT_STATUS.ACTIVE) throw accountNotActive();
    const current = normalizePinnedIds(userSnap.data().pinnedPostIds);
    const next = current.filter((id) => id !== postId);
    if (next.length === current.length) return { pinnedPostIds: current, changed: false };
    tx.update(userRef, { pinnedPostIds: next });
    return { pinnedPostIds: next, changed: true };
  });
}

/**
 * Gỡ các id khỏi danh sách ghim của `uid`, không bao giờ ném lỗi và KHÔNG tạo lại hồ sơ đã bị xoá
 * (đọc trước, hồ sơ không còn thì thôi — khác `set(..., {merge:true})` vốn dựng lại hồ sơ "ma", xem v2.2.1 [A-02]).
 */
async function removePinsBestEffort(uid, postIds) {
  try {
    const dead = new Set(postIds);
    if (!uid || dead.size === 0) return false;
    const userRef = db.collection(COLLECTIONS.USERS).doc(uid);
    return await db.runTransaction(async (tx) => {
      const snap = await tx.get(userRef);
      if (!snap.exists) return false;
      const current = normalizePinnedIds(snap.data().pinnedPostIds);
      const next = current.filter((id) => !dead.has(id));
      if (next.length === current.length) return false;
      tx.update(userRef, { pinnedPostIds: next });
      return true;
    });
  } catch (err) {
    console.error("removePinsBestEffort (bỏ qua, lần đọc bài ghim sau sẽ tự dọn):", err?.message || err);
    return false;
  }
}

module.exports = { PinError, normalizePinnedIds, pinPost, unpinPost, removePinsBestEffort };
