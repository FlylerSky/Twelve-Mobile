const { db, auth } = require("../config/firebase");
const { COLLECTIONS } = require("../utils/constants");

/**
 * ==== v2.2.1 [A-02] — dọn "hồ sơ ma" và dữ liệu riêng mồ côi ====
 * Trước 2.2.1, một thao tác cộng điểm (`set + merge`) chạy dở/muộn có thể DỰNG LẠI document `users/{uid}` của tài khoản đã bị xoá, chỉ chứa điểm số
 * (không có `status`/`email`/`tagName`…); tương tự `PUT /me/real-name` bị kẹt có thể dựng lại `userPrivate/{uid}` (tên thật). Code mới không còn tạo ra chúng
 * (và bước `verify` của quy trình xoá dọn nốt), nhưng DỮ LIỆU ĐÃ CÓ TỪ TRƯỚC thì cần quét một lần.
 *
 * AN TOÀN: chỉ coi là "ma" khi hồ sơ KHÔNG có bất kỳ trường nhận dạng nào (status/email/tagName/displayName/uid) VÀ không còn tài khoản Firebase Auth cùng uid.
 * `userPrivate/{uid}` chỉ bị coi là mồ côi khi KHÔNG có `users/{uid}` và KHÔNG có tài khoản Auth. Không bao giờ đụng vào hồ sơ có `status`.
 */
const IDENTITY_FIELDS = ["status", "email", "tagName", "displayName", "uid"];

async function authExists(uid) {
  try {
    await auth.getUser(uid);
    return true;
  } catch (err) {
    if (err && (err.code === "auth/user-not-found" || err.errorInfo?.code === "auth/user-not-found")) return false;
    throw err;
  }
}

const hasIdentity = (data) => IDENTITY_FIELDS.some((f) => data && data[f] !== undefined && data[f] !== null && data[f] !== "");

async function findGhosts() {
  const ghostProfiles = [];
  const strayPrivate = [];

  const users = await db.collection(COLLECTIONS.USERS).select(...IDENTITY_FIELDS, "positiveScore", "accountScore").get();
  const liveUserIds = new Set();
  for (const doc of users.docs) {
    const data = doc.data();
    if (hasIdentity(data)) { liveUserIds.add(doc.id); continue; }
    if (await authExists(doc.id)) { liveUserIds.add(doc.id); continue; } // còn tài khoản Auth: KHÔNG coi là ma
    ghostProfiles.push({ uid: doc.id, positiveScore: data.positiveScore ?? null, accountScore: data.accountScore ?? null });
  }

  const priv = await db.collection(COLLECTIONS.USER_PRIVATE).select().get();
  for (const doc of priv.docs) {
    if (liveUserIds.has(doc.id)) continue;
    if (ghostProfiles.some((g) => g.uid === doc.id)) { strayPrivate.push({ uid: doc.id }); continue; }
    const user = await db.collection(COLLECTIONS.USERS).doc(doc.id).get();
    if (user.exists) continue; // có hồ sơ (kể cả loại khác) — không đụng
    if (await authExists(doc.id)) continue;
    strayPrivate.push({ uid: doc.id });
  }
  return { ghostProfiles, strayPrivate };
}

async function purgeGhosts({ apply = false } = {}) {
  const { ghostProfiles, strayPrivate } = await findGhosts();
  let deleted = 0;
  if (apply) {
    for (const g of ghostProfiles) {
      const ref = db.collection(COLLECTIONS.USERS).doc(g.uid);
      if (typeof db.recursiveDelete === "function") await db.recursiveDelete(ref); // kèm subcollection (positiveScoreLogs…)
      else await ref.delete();
      deleted++;
    }
    for (const s of strayPrivate) {
      await db.collection(COLLECTIONS.USER_PRIVATE).doc(s.uid).delete();
      deleted++;
    }
  }
  return { ghostProfiles, strayPrivate, deleted };
}

module.exports = { findGhosts, purgeGhosts };
