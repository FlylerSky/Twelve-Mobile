// v2.5.3.2 — đo và canh nhận diện IP client (TW-01) + cấu hình CSP/Permissions-Policy của SPA. Xem PATCH-26-NOTES.md.
// Mấu chốt: các test ở đây chạy trên Express THẬT (đặt `trust proxy`, gửi X-Forwarded-For qua socket) chứ không giả `req.ip` — vì lỗi ở 2.5.3 là "khoá IP có đúng/ổn định không",
// thứ mà test giả `req.ip` (security-253.test.js) không thể phát hiện.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const http = require("node:http");
const express = require("express");
const rateLimit = require("express-rate-limit");

const clientIp = require("../src/utils/clientIp");
const { describeIpTopology, getClientKey, trustProxySetting, parseRangeList, isTrustedProxyAddress } = clientIp;

const BACKEND = path.join(__dirname, "..");
const FRONTEND = path.join(BACKEND, "..", "frontend");
const haveFrontend = fs.existsSync(path.join(FRONTEND, "vercel.json"));
const read = (p) => fs.readFileSync(p, "utf8");
const stripLineComments = (s) => s.split("\n").filter((l) => !/^\s*(\/\/|\*|\/\*)/.test(l)).join("\n");

const ENV_KEYS = ["TRUST_PROXY_MODE", "TRUST_PROXY_HOPS", "TRUST_PROXY_EXTRA", "CLOUDFLARE_EXTRA_RANGES", "CLIENT_IP_MODE"];
function withEnv(env, fn) {
  const saved = {};
  for (const k of ENV_KEYS) { saved[k] = process.env[k]; delete process.env[k]; }
  Object.assign(process.env, env);
  const restore = () => { for (const k of ENV_KEYS) { if (saved[k] === undefined) delete process.env[k]; else process.env[k] = saved[k]; } };
  let out;
  try { out = fn(); } catch (err) { restore(); throw err; }
  if (out && typeof out.then === "function") return out.finally(restore);
  restore();
  return out;
}

/** Dựng app Express THẬT với `trust proxy` theo env hiện tại, trả về hàm gọi tuần tự (socket thật ⇒ peer là 127.0.0.1, còn chuỗi proxy do header X-Forwarded-For mô phỏng). */
function startApp(extra) {
  const app = express();
  app.set("trust proxy", trustProxySetting());
  app.get("/", (req, res) => res.json({ ip: String(req.ip).replace(/^::ffff:/, ""), key: getClientKey(req), desc: describeIpTopology(req) }));
  if (extra) extra(app);
  const agent = new http.Agent({ keepAlive: true });
  return new Promise((resolve) => {
    const srv = app.listen(0, "127.0.0.1", () => {
      const call = (headers = {}, urlPath = "/") =>
        new Promise((res, rej) => {
          http.get({ host: "127.0.0.1", port: srv.address().port, path: urlPath, headers, agent }, (r) => {
            let body = "";
            r.on("data", (d) => (body += d));
            r.on("end", () => { let json = null; try { json = JSON.parse(body); } catch { /* không phải JSON */ } res({ status: r.statusCode, headers: r.headers, json }); });
          }).on("error", rej);
        });
      resolve({ call, close: () => { agent.destroy(); srv.close(); } });
    });
  });
}
const hdr = (xff, cf) => ({ ...(xff ? { "x-forwarded-for": xff } : {}), ...(cf ? { "cf-connecting-ip": cf } : {}) });
const mkReq = ({ ip, peer, xff, cf, extra = {} } = {}) => ({
  ip, ips: [], socket: { remoteAddress: peer || ip },
  headers: { ...(xff ? { "x-forwarded-for": xff } : {}), ...(cf ? { "cf-connecting-ip": cf } : {}), ...extra },
});

// ============================================================ Mô hình đo khớp Express thật
test("2.5.3.2: describeIpTopology khớp ĐÚNG `req.ip` của Express thật cho từng cấu hình (hop 0–3 và chế độ cloudflare), kể cả IPv6 và chuỗi có hop nội bộ", async () => {
  const chains = [
    ["198.51.100.7, 104.16.0.5", "198.51.100.7"],
    ["198.51.100.7, 104.16.0.5, 10.1.2.3", "198.51.100.7"],
    ["9.9.9.9, 198.51.100.7, 104.16.0.5", "198.51.100.7"],
    [null, null],
    ["2001:db8::1, 2606:4700::1", "2001:db8::1"],
  ];
  const settings = [
    ...[0, 1, 2, 3].map((h) => ({ env: { TRUST_PROXY_HOPS: String(h) }, want: { TRUST_PROXY_HOPS: h } })),
    { env: { TRUST_PROXY_MODE: "cloudflare" }, want: { TRUST_PROXY_MODE: "cloudflare" } },
  ];
  for (const s of settings) {
    await withEnv(s.env, async () => {
      const app = await startApp();
      try {
        for (const [xff, cf] of chains) {
          const r = (await app.call(hdr(xff, cf))).json;
          const cand = r.desc.candidates.find((c) => JSON.stringify(c.setting) === JSON.stringify(s.want));
          assert.equal(cand.address, r.ip, `${JSON.stringify(s.want)} với X-Forwarded-For=${xff}: mô hình ${cand.address} ≠ Express ${r.ip}`);
        }
      } finally {
        app.close();
      }
    });
  }
});

test("2.5.3.2: cấu hình mặc định KHÔNG đổi — trust proxy = 1 hop (như 2.5.3), chế độ `cloudflare` chỉ bật khi đặt env, mục env hỏng bị bỏ", () => {
  withEnv({}, () => {
    assert.equal(clientIp.trustProxyMode(), "hops");
    assert.equal(trustProxySetting(), 1);
  });
  withEnv({ TRUST_PROXY_HOPS: "2" }, () => assert.equal(trustProxySetting(), 2));
  withEnv({ TRUST_PROXY_HOPS: "abc" }, () => assert.equal(trustProxySetting(), 1));
  withEnv({ TRUST_PROXY_MODE: "bất-kỳ" }, () => assert.equal(trustProxySetting(), 1, "giá trị lạ ⇒ về mặc định, không bật nhầm"));
  withEnv({ TRUST_PROXY_MODE: "CloudFlare", TRUST_PROXY_EXTRA: "203.0.113.0/24, rác, 10.0.0.1, 1.2.3.4/99, ::1/129, 2001:db8::/32, 1.2.3.4/5/6" }, () => {
    const s = trustProxySetting();
    assert.ok(Array.isArray(s));
    for (const k of ["loopback", "linklocal", "uniquelocal", "104.16.0.0/13", "2606:4700::/32", "203.0.113.0/24", "10.0.0.1", "2001:db8::/32"]) assert.ok(s.includes(k), k);
    for (const bad of ["rác", "1.2.3.4/99", "::1/129", "1.2.3.4/5/6"]) assert.ok(!s.includes(bad), `mục hỏng ${bad} phải bị bỏ`);
  });
  assert.deepEqual(parseRangeList("1.1.1.1, 2.2.2.0/24,,  x ,2001:db8::1"), ["1.1.1.1", "2.2.2.0/24", "2001:db8::1"]);
  assert.equal(isTrustedProxyAddress("10.1.2.3"), true);
  assert.equal(isTrustedProxyAddress("104.16.0.1"), true);
  assert.equal(isTrustedProxyAddress("::ffff:10.1.2.3"), true);
  assert.equal(isTrustedProxyAddress("8.8.8.8"), false);
  assert.equal(isTrustedProxyAddress("không-phải-ip"), false);
});

// ============================================================ Khoá IP ổn định / đúng người
test("TW-01 (canh): cùng MỘT client đi qua 60 edge Cloudflare khác nhau ⇒ đúng MỘT khoá (cấu hình mặc định, Express thật)", async () => {
  await withEnv({}, async () => {
    const app = await startApp();
    try {
      const keys = new Set();
      for (let i = 0; i < 60; i++) {
        const edge = [`104.16.${i}.1`, `172.64.${i}.9`, `162.158.${i}.3`][i % 3];
        const r = (await app.call(hdr(`203.0.113.9, ${edge}`, "203.0.113.9"))).json;
        keys.add(r.key);
        assert.equal(r.desc.verdict.code, "OK");
      }
      assert.deepEqual([...keys], ["203.0.113.9"]);
      // IPv6: nhiều địa chỉ trong cùng /64 cũng ra MỘT khoá
      const v6 = new Set();
      for (let i = 0; i < 20; i++) v6.add((await app.call(hdr(`2001:db8:1:2::${i + 1}, 2606:4700::${i + 1}`, `2001:db8:1:2::${i + 1}`))).json.key);
      assert.equal(v6.size, 1);
    } finally {
      app.close();
    }
  });
});

test("TW-01 (canh): hai client KHÁC nhau không bao giờ chung khoá ở cấu hình mặc định khi chuỗi đúng 2 mục [client, edge]", async () => {
  await withEnv({}, async () => {
    const app = await startApp();
    try {
      const a = (await app.call(hdr("203.0.113.9, 104.16.0.5", "203.0.113.9"))).json.key;
      const b = (await app.call(hdr("203.0.113.10, 104.16.0.5", "203.0.113.10"))).json.key;
      assert.notEqual(a, b);
    } finally {
      app.close();
    }
  });
});

test("TW-01 (rủi ro đã biết, có phát hiện): nếu Render thêm một hop NỘI BỘ sau Cloudflare, cấu hình mặc định gom mọi người vào MỘT khoá — công cụ đo phải báo và chế độ `cloudflare` phải sửa được", async () => {
  const internalHop = "10.9.8.7";
  const chain = (client) => hdr(`${client}, 104.16.0.5, ${internalHop}`, client);
  await withEnv({}, async () => {
    const app = await startApp();
    try {
      const a = (await app.call(chain("203.0.113.9"))).json;
      const b = (await app.call(chain("203.0.113.10"))).json;
      assert.equal(a.key, internalHop, "mặc định: khoá = IP nội bộ cho MỌI người (đúng hiện tượng 'một bucket chung')");
      assert.equal(a.key, b.key);
      assert.equal(a.desc.verdict.code, "MISMATCH_FIXABLE", "công cụ đo phải báo sai");
      assert.deepEqual(a.desc.verdict.suggestions, [{ TRUST_PROXY_MODE: "cloudflare" }, { TRUST_PROXY_HOPS: 2 }], "gợi ý: chế độ cloudflare, rồi số hop NHỎ NHẤT đúng (không gợi ý 3/4)");
    } finally {
      app.close();
    }
  });
  await withEnv({ TRUST_PROXY_MODE: "cloudflare" }, async () => {
    const app = await startApp();
    try {
      const a = (await app.call(chain("203.0.113.9"))).json;
      const b = (await app.call(chain("203.0.113.10"))).json;
      assert.equal(a.key, "203.0.113.9");
      assert.equal(b.key, "203.0.113.10");
      assert.equal(a.desc.verdict.code, "OK");
    } finally {
      app.close();
    }
  });
  // Số hop đúng (2) cũng sửa được — nhưng cố định vào topology hiện tại (khác với chế độ cloudflare)
  await withEnv({ TRUST_PROXY_HOPS: "2" }, async () => {
    const app = await startApp();
    try {
      assert.equal((await app.call(chain("203.0.113.9"))).json.key, "203.0.113.9");
    } finally {
      app.close();
    }
  });
});

test("TW-01 (chống giả): chế độ `cloudflare` không bao giờ chọn mục do client tự đặt ở bên trái X-Forwarded-For, kể cả khi mục giả mạo là IP Cloudflare hay CF-Connecting-IP giả", async () => {
  await withEnv({ TRUST_PROXY_MODE: "cloudflare" }, async () => {
    const app = await startApp();
    try {
      const keyOf = async (xff, cf) => (await app.call(hdr(xff, cf))).json.key;
      assert.equal(await keyOf("1.1.1.1, 2.2.2.2, 203.0.113.9, 104.16.0.5", "203.0.113.9"), "203.0.113.9", "nhiều mục giả bên trái");
      assert.equal(await keyOf("104.16.0.7, 203.0.113.9, 104.16.0.5", "203.0.113.9"), "203.0.113.9", "mục giả bên trái trông như IP Cloudflare");
      assert.equal(await keyOf("6.6.6.6, 203.0.113.9", null), "203.0.113.9", "không qua Cloudflare: lấy mục do proxy nối vào, không phải mục client tự khai");
      assert.equal(await keyOf("203.0.113.9", "6.6.6.6"), "203.0.113.9", "CF-Connecting-IP giả khi hop cuối không phải Cloudflare bị bỏ qua");
      assert.equal(await keyOf(null, null), "127.0.0.1", "không có X-Forwarded-For: dùng địa chỉ socket");
    } finally {
      app.close();
    }
  });
});

// ============================================================ limiter: header đếm chỉ do MỘT limiter ghi, và 429 xuất hiện đúng ngưỡng dù đổi edge
test("TW-01 (canh, theo gợi ý của báo cáo phụ lục): 310 request tuần tự của MỘT client đổi edge liên tục ⇒ đúng 300×200 rồi 10×429, `x-ratelimit-remaining` giảm đều từng đơn vị", async () => {
  await withEnv({}, async () => {
    const ipKey = (req) => `ip:${getClientKey(req)}`;
    const app = await startApp((a) => {
      // y hệt server.js: globalLimiter 300/15 phút, khoá bằng getClientKey, header kiểu cũ (x-ratelimit-*)
      a.use("/limited", rateLimit({ windowMs: 15 * 60 * 1000, max: 300, keyGenerator: ipKey }));
      a.get("/limited", (req, res) => res.json({ ok: true }));
    });
    try {
      let ok = 0, blocked = 0;
      let prev = null;
      for (let i = 0; i < 310; i++) {
        const edge = `104.${16 + (i % 7)}.${i % 250}.${1 + (i % 200)}`; // 7 dải /13–/14 khác nhau, mỗi request một edge
        const r = await app.call(hdr(`203.0.113.9, ${edge}`, "203.0.113.9"), "/limited");
        if (r.status === 200) {
          ok++;
          const remaining = Number(r.headers["x-ratelimit-remaining"]);
          if (prev !== null) assert.equal(remaining, prev - 1, `request ${i + 1}: remaining phải giảm đúng 1 (một khoá duy nhất)`);
          prev = remaining;
        } else {
          assert.equal(r.status, 429);
          blocked++;
        }
      }
      assert.equal(ok, 300);
      assert.equal(blocked, 10);
    } finally {
      app.close();
    }
  });
});

test("canh việc đọc số liệu: header `x-ratelimit-*` trên /api/* chỉ do globalLimiter (và authLimiter ở /api/auth) ghi — mọi limiter khác tắt legacyHeaders (nên không thể 'ghi đè nhau' như báo cáo phụ lục §9 giả định)", () => {
  const server = stripLineComments(read(path.join(BACKEND, "server.js")));
  const serverLimiters = server.match(/rateLimit\(\{[\s\S]*?\}\)/g) || [];
  assert.equal(serverLimiters.length, 2, "server.js: globalLimiter + authLimiter");
  for (const c of serverLimiters) assert.ok(!/legacyHeaders:\s*false/.test(c), "hai limiter chung vẫn phát header kiểu cũ (x-ratelimit-*)");
  const others = ["src/middleware/rateLimiters.js", "src/routes/auth.routes.js", "src/routes/csp.routes.js"].flatMap((rel) => (stripLineComments(read(path.join(BACKEND, rel))).match(/rateLimit\(\{[\s\S]*?\}\)/g) || []).map((c) => [rel, c]));
  assert.ok(others.length >= 20);
  for (const [rel, c] of others) assert.match(c, /legacyHeaders:\s*false/, `${rel}: limiter này sẽ ghi x-ratelimit-* đè lên globalLimiter`);
});

// ============================================================ Tính an toàn của công cụ đo
test("2.5.3.2: describeIpTopology chỉ trả địa chỉ hợp lệ + chuỗi header đã lọc/cắt; KHÔNG lộ Authorization/secret/cookie; chuỗi X-Forwarded-For dài bị giới hạn", () => {
  const req = mkReq({
    ip: "104.16.0.5", peer: "10.0.0.2", xff: "a\u0000b<script>, 203.0.113.9, 104.16.0.5", cf: "203.0.113.9",
    extra: { authorization: "Bearer SECRET-ID-TOKEN", "x-twelve-ssr-secret": "SUPER-SECRET-VALUE", cookie: "sid=COOKIE-VALUE", "x-twelve-client-ip": "6.6.6.6" },
  });
  const desc = describeIpTopology(req);
  const text = JSON.stringify(desc);
  for (const leak of ["SECRET-ID-TOKEN", "SUPER-SECRET-VALUE", "COOKIE-VALUE", "6.6.6.6", "<script>"]) assert.ok(!text.includes(leak), `không được lộ ${leak}`);
  assert.deepEqual(Object.keys(desc).sort(), ["candidates", "chain", "cfConnectingIp", "current", "peer", "peerTrusted", "verdict", "xff", "xffRaw"].sort());
  assert.equal(desc.xff[0], "(không hợp lệ)");
  assert.match(desc.xffRaw, /^[0-9a-fA-F:.,\s?]*$/, "chỉ còn ký tự có thể thuộc danh sách IP; mọi ký tự khác (điều khiển, <, >, chữ ngoài hex…) bị thay bằng ?");

  const long = describeIpTopology(mkReq({ ip: "1.1.1.1", xff: Array.from({ length: 1000 }, (_, i) => `1.1.${i % 250}.1`).join(", ") }));
  assert.ok(long.xff.length <= 20);
  assert.ok(long.xffRaw.length <= 300);
  assert.doesNotThrow(() => describeIpTopology({ headers: {}, socket: {} }));
});

test("2.5.3.2: các kết luận (verdict) — OK / MISMATCH_FIXABLE / MISMATCH_UNKNOWN / NO_CF_HEADER; không khuyên chế độ cloudflare khi proxy sát app KHÔNG thuộc dải tin cậy", () => {
  withEnv({}, () => {
    // OK: topology đúng như thiết kế
    assert.equal(describeIpTopology(mkReq({ ip: "104.16.0.5", peer: "10.0.0.1", xff: "203.0.113.9, 104.16.0.5", cf: "203.0.113.9" })).verdict.code, "OK");
    // Có hop nội bộ thừa: khoá = IP nội bộ ⇒ sai, gợi ý đúng
    const d = describeIpTopology(mkReq({ ip: "10.1.2.3", peer: "10.0.0.2", xff: "203.0.113.9, 104.16.0.5, 10.1.2.3", cf: "203.0.113.9" }));
    assert.equal(d.verdict.code, "MISMATCH_FIXABLE");
    assert.deepEqual(d.verdict.suggestions, [{ TRUST_PROXY_MODE: "cloudflare" }, { TRUST_PROXY_HOPS: 2 }]);
    assert.equal(d.peerTrusted, true);
    // Proxy sát app là địa chỉ CÔNG KHAI không thuộc dải tin cậy: chế độ cloudflare sẽ không tin nó ⇒ không được gợi ý (chỉ còn số hop)
    const p = describeIpTopology(mkReq({ ip: "8.8.8.8", peer: "8.8.8.8", xff: "203.0.113.9, 104.16.0.5", cf: "203.0.113.9" }));
    assert.equal(p.peerTrusted, false);
    assert.equal(p.verdict.code, "MISMATCH_FIXABLE");
    assert.deepEqual(p.verdict.suggestions, [{ TRUST_PROXY_HOPS: 1 }]);
    assert.equal(p.candidates[0].usable, false);
    // Không cấu hình nào cho ra IP mà Cloudflare báo
    assert.equal(describeIpTopology(mkReq({ ip: "8.8.8.8", peer: "8.8.8.8", cf: "203.0.113.9" })).verdict.code, "MISMATCH_UNKNOWN");
    // Không có CF-Connecting-IP ⇒ không có gì để đối chiếu
    const n = describeIpTopology(mkReq({ ip: "104.16.0.5", peer: "10.0.0.1", xff: "203.0.113.9, 104.16.0.5" }));
    assert.equal(n.verdict.code, "NO_CF_HEADER");
    assert.deepEqual(n.verdict.suggestions, []);
  });
  // CLIENT_IP_MODE=proxy: không đọc CF-Connecting-IP ⇒ khoá = IP edge ⇒ báo sai (đúng với hành vi 2.5.2)
  withEnv({ CLIENT_IP_MODE: "proxy" }, () => {
    assert.equal(describeIpTopology(mkReq({ ip: "104.16.0.5", peer: "10.0.0.1", xff: "203.0.113.9, 104.16.0.5", cf: "203.0.113.9" })).verdict.code, "MISMATCH_FIXABLE");
  });
});

// ============================================================ Nối dây
test("2.5.3.2: GET /api/admin/ip-topology nằm DƯỚI router.use(requireSA), có limiter riêng khoá theo tài khoản, controller chỉ đọc + no-store và không chạm req.ip", () => {
  const routes = read(path.join(BACKEND, "src/routes/admin.routes.js"));
  const iGuard = routes.indexOf("router.use(requireAuth, requireActive, requireSA)");
  const iRoute = routes.indexOf('router.get("/ip-topology"');
  assert.ok(iGuard > -1 && iRoute > iGuard, "route phải nằm sau khoá quyền SA");
  assert.match(routes, /router\.get\("\/ip-topology",\s*ipTopologyLimiter,\s*ipTopologyCtrl\.getIpTopology\)/);
  const limiters = read(path.join(BACKEND, "src/middleware/rateLimiters.js"));
  assert.match(limiters, /const ipTopologyLimiter = rateLimit\(\{[\s\S]*?keyGenerator: authOrIpKeyGenerator[\s\S]*?legacyHeaders: false[\s\S]*?\}\);/);
  assert.match(limiters, /module\.exports = \{[\s\S]*ipTopologyLimiter/);
  const ctrl = stripLineComments(read(path.join(BACKEND, "src/controllers/ipTopology.controller.js")));
  assert.match(ctrl, /no-store/);
  assert.ok(!/\breq\.ip\b/.test(ctrl) && !/\.(post|put|patch|delete)\(/i.test(ctrl));
  const server = stripLineComments(read(path.join(BACKEND, "server.js")));
  assert.match(server, /app\.set\("trust proxy", trustProxySetting\(\)\)/);
  assert.ok(!/trustProxyHops\(/.test(server), "server.js không còn gọi trực tiếp trustProxyHops()");
});

test("2.5.3.2: controller trả JSON no-store; lỗi bên trong ⇒ 500 gọn (không lộ stack)", () => {
  const { getIpTopology } = require("../src/controllers/ipTopology.controller");
  const mkRes = () => { const r = { headers: {}, set(k, v) { r.headers[k] = v; return r; }, status(c) { r.code = c; return r; }, json(b) { r.body = b; return r; } }; return r; };
  const ok = mkRes();
  getIpTopology(mkReq({ ip: "104.16.0.5", peer: "10.0.0.1", xff: "203.0.113.9, 104.16.0.5", cf: "203.0.113.9" }), ok);
  assert.equal(ok.headers["Cache-Control"], "no-store");
  assert.equal(ok.body.verdict.code, "OK");
  const realErr = console.error;
  console.error = () => {};
  try {
    const bad = mkRes();
    getIpTopology({}, bad); // thiếu headers ⇒ ném bên trong
    assert.equal(bad.code, 500);
    assert.deepEqual(Object.keys(bad.body), ["error"]);
  } finally {
    console.error = realErr;
  }
});

// ============================================================ vercel.json (SPA)
const vercel = () => JSON.parse(read(path.join(FRONTEND, "vercel.json")));
const headerOf = (cfg, key) => cfg.headers[0].headers.find((h) => h.key === key).value;
const directives = (v) => Object.fromEntries(v.split(";").map((s) => s.trim()).filter(Boolean).map((s) => { const [k, ...rest] = s.split(/\s+/); return [k, rest]; }));

test("2.5.3.2: vercel.json — bỏ `usb=()` khỏi Permissions-Policy (trình duyệt báo 'Unrecognized feature'), các quyền còn lại giữ nguyên", { skip: !haveFrontend && "không có thư mục ../frontend" }, () => {
  const pp = headerOf(vercel(), "Permissions-Policy");
  assert.ok(!/\busb\b/.test(pp));
  for (const f of ["camera", "microphone", "geolocation", "payment"]) assert.match(pp, new RegExp(`${f}=\\(\\)`));
});

test("2.5.3.2: vercel.json — ImageKit có trong img-src Report-Only (ảnh thật của nền tảng, 88 vi phạm đã thấy) nhưng img-src/frame-src VẪN chưa enforce và script-src enforce KHÔNG mở thêm gì", { skip: !haveFrontend && "không có thư mục ../frontend" }, () => {
  const cfg = vercel();
  const ro = directives(headerOf(cfg, "Content-Security-Policy-Report-Only"));
  const enforced = directives(headerOf(cfg, "Content-Security-Policy"));
  assert.ok(ro["img-src"].includes("https://ik.imagekit.io"));
  assert.ok(ro["img-src"].includes("https://res.cloudinary.com"));
  assert.ok(!ro["img-src"].includes("https:"), "không quay lại `https:` trần");
  assert.equal(enforced["img-src"], undefined, "img-src chưa enforce: cần ≥ 7 ngày quan sát bảng báo cáo CSP (xem PATCH-26-NOTES.md)");
  assert.equal(enforced["frame-src"], undefined);
  assert.deepEqual(enforced["script-src"], ["'self'", "https://challenges.cloudflare.com"], "enforce script-src giữ nguyên (reCAPTCHA chỉ mở khi vận hành quyết định bật App Check — PATCH-25-NOTES.md §4)");
  assert.deepEqual(enforced["script-src-attr"], ["'none'"]);
  // ImageKit không được lọt vào nơi nó không cần
  assert.ok(!(enforced["script-src"] || []).some((s) => /imagekit/.test(s)));
  assert.ok(!(ro["script-src"] || []).some((s) => /imagekit/.test(s)));
});
