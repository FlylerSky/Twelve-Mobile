// v2.0.12 — kiểm thử bản vá theo Báo cáo bảo mật Phiên 3: N2 (bỏ cookie-parser), N3 (đăng ký dở / Auth mồ côi), F3 (công tắc).
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const { install } = require("./helpers/fakeFirebase");
const fb = install({ tokens: {} });
const S = fb.store;

const mockRes = () => {
  const r = { statusCode: 200, body: null };
  r.status = (c) => ((r.statusCode = c), r);
  r.json = (b) => ((r.body = b), r);
  return r;
};
const reset = () => {
  Object.keys(S).forEach((k) => delete S[k]);
  fb.authUsers.clear();
};

// ------------------------------------------------------------------ N2
test("N2: cookie-parser đã được gỡ khỏi mã nguồn và dependency", () => {
  const server = fs.readFileSync(path.join(__dirname, "../server.js"), "utf8");
  const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, "../package.json"), "utf8"));
  assert.ok(!/require\(["']cookie-parser["']\)|cookieParser\(/.test(server));
  assert.equal(pkg.dependencies["cookie-parser"], undefined);
  assert.throws(() => require.resolve("cookie-parser"), /Cannot find module/);
  // Không có chỗ nào dùng cookie => gỡ không làm mất chức năng.
  const hits = [];
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
    const p = path.join(d, e.name);
    if (e.isDirectory()) return walk(p);
    if (e.name.endsWith(".js") && /\breq\.(cookies|signedCookies)\b|\bres\.cookie\(|COOKIE_SECRET/.test(fs.readFileSync(p, "utf8").replace(/\/\/.*$/gm, ""))) hits.push(p);
  });
  walk(path.join(__dirname, "../src"));
  assert.deepEqual(hits, []);
});

// ------------------------------------------------------------------ N3
const { register } = require("../src/controllers/auth.controller");
const { cleanupOrphans, ORPHAN_GRACE_MS } = require("../src/services/orphanAuth");
const body = (over = {}) => ({ fullName: "Nguyễn Văn A", displayName: "Văn A", tagName: "vana", birthday: "1999-01-01", gender: "male", country: "VN", email: "a@example.com", password: "12345678", ...over });
const doRegister = async (over) => { const res = mockRes(); await register({ body: body(over), headers: {} }, res); return res; };
const addAuth = (uid, email, ageMs = 0) => fb.authUsers.set(uid, { uid, email, metadata: { creationTime: new Date(Date.now() - ageMs).toUTCString() } });

test("N3: đăng ký thành công — dấu đăng ký được dọn trong cùng giao dịch", async () => {
  reset();
  const res = await doRegister();
  assert.equal(res.statusCode, 201, JSON.stringify(res.body));
  const uid = res.body.uid;
  assert.ok(S[`users/${uid}`], "có hồ sơ");
  assert.ok(!(`registrationMarkers/${uid}` in S), "dấu đã bị xoá");
  assert.equal(fb.authUsers.size, 1);
});

test("N3: đăng ký bị ngắt giữa chừng (dấu còn sót, không có hồ sơ, quá 10 phút) => đăng ký lại được", async () => {
  reset();
  addAuth("orphan1", "a@example.com");
  S["registrationMarkers/orphan1"] = { email: "a@example.com", createdAtMs: Date.now() - ORPHAN_GRACE_MS - 60000 };
  const res = await doRegister();
  assert.equal(res.statusCode, 201, JSON.stringify(res.body));
  assert.ok(!fb.authUsers.has("orphan1"), "tài khoản mồ côi đã bị xoá");
  assert.ok(!("registrationMarkers/orphan1" in S));
  assert.ok(S[`users/${res.body.uid}`]);
});

test("N3: AN TOÀN — không xoá khi còn trong thời gian ân hạn (có thể đang đăng ký dở thật)", async () => {
  reset();
  addAuth("inflight", "a@example.com");
  S["registrationMarkers/inflight"] = { email: "a@example.com", createdAtMs: Date.now() - 60000 };
  const res = await doRegister();
  assert.equal(res.statusCode, 409);
  assert.ok(fb.authUsers.has("inflight"));
  assert.ok("registrationMarkers/inflight" in S);
});

test("N3: AN TOÀN — tài khoản Auth KHÔNG có dấu (vd. do ứng dụng khác cùng dự án Firebase tạo) tuyệt đối không bị xoá", async () => {
  reset();
  addAuth("other-app", "a@example.com", 365 * 24 * 3600 * 1000); // cũ cả năm, không có hồ sơ Twelve, không có dấu
  const res = await doRegister();
  assert.equal(res.statusCode, 409);
  assert.ok(fb.authUsers.has("other-app"), "kẻ đăng ký email của nạn nhân không thể xoá tài khoản của họ");
});

test("N3: AN TOÀN — tài khoản đã có hồ sơ không bao giờ bị xoá, kể cả khi còn dấu thừa", async () => {
  reset();
  addAuth("real", "a@example.com");
  S["users/real"] = { status: "active" };
  S["registrationMarkers/real"] = { email: "a@example.com", createdAtMs: 0 };
  const res = await doRegister();
  assert.equal(res.statusCode, 409);
  assert.ok(fb.authUsers.has("real"));
});

test("N3: tagName bị trùng => hoàn tác sạch (xoá cả tài khoản Auth lẫn dấu)", async () => {
  reset();
  S["tagNames/vana"] = { uid: "someone" };
  const res = await doRegister();
  assert.equal(res.statusCode, 409);
  assert.equal(fb.authUsers.size, 0);
  assert.ok(!Object.keys(S).some((k) => k.startsWith("registrationMarkers/")));
});

test("N3: script dọn — dry-run chỉ liệt kê, --apply chỉ xoá tài khoản có dấu + không hồ sơ + quá hạn", async () => {
  reset();
  const old = Date.now() - ORPHAN_GRACE_MS - 1;
  addAuth("o1", "o1@x.com"); S["registrationMarkers/o1"] = { email: "o1@x.com", createdAtMs: old };
  addAuth("fresh", "f@x.com"); S["registrationMarkers/fresh"] = { email: "f@x.com", createdAtMs: Date.now() - 1000 };
  addAuth("done", "d@x.com"); S["users/done"] = { status: "active" }; S["registrationMarkers/done"] = { email: "d@x.com", createdAtMs: old };
  addAuth("foreign", "z@x.com"); // không dấu
  const realGetUser = fb.auth.getUser; // Firebase thật ném auth/user-not-found cho uid không tồn tại
  fb.auth.getUser = async (uid) => { if (!fb.authUsers.has(uid)) throw Object.assign(new Error("nf"), { code: "auth/user-not-found" }); return fb.authUsers.get(uid); };
  S["registrationMarkers/gone"] = { email: "g@x.com", createdAtMs: old }; // Auth đã mất, dấu còn

  const dry = await cleanupOrphans({ apply: false });
  assert.deepEqual(dry.orphans.map((o) => o.uid).sort(), ["gone", "o1"]);
  assert.equal(dry.staleMarkers, 1);
  assert.equal(dry.deleted, 0);
  assert.equal(fb.authUsers.size, 4, "dry-run không xoá gì");

  const applied = await cleanupOrphans({ apply: true });
  assert.equal(applied.deleted, 2);
  assert.ok(!fb.authUsers.has("o1"));
  for (const keep of ["fresh", "done", "foreign"]) assert.ok(fb.authUsers.has(keep), keep);
  assert.ok(!("registrationMarkers/o1" in S) && !("registrationMarkers/gone" in S) && !("registrationMarkers/done" in S));
  assert.ok("registrationMarkers/fresh" in S);
  fb.auth.getUser = realGetUser;
});

// ------------------------------------------------------------------ F3
const { registerView } = require("../src/utils/helpers");
const { POST_SCORE_WEIGHTS } = require("../src/utils/helpers"); // dùng đúng trọng số thật của mã nguồn

const seedPost = () => {
  reset();
  S["users/viewer"] = { status: "active", positiveScore: 0 };
  S["users/author"] = { status: "active", postsScoreSum: 0 };
  S["posts/p1"] = { authorUid: "author", viewCount: 0, externalPostScore: 0 };
  S["posts/p2"] = { authorUid: "author", viewCount: 0, externalPostScore: 0 };
};
const viewAt = async (when, postId = "p1") => {
  const real = Date.now;
  Date.now = () => when;
  try {
    return await registerView(fb.db, fb.admin, "posts", postId, { viewerKey: "uid:viewer", isAi: false, viewerUid: "viewer", authorUid: "author" });
  } finally {
    Date.now = real;
  }
};
const T0 = Date.UTC(2026, 9, 6, 12, 0, 0);
const MIN = 60 * 1000;

// v2.5.3 [TW-03]: mặc định ĐẢO sang BẬT (trước đây tắt). Test cũ "mặc định tắt" đổi thành "đặt off mới giữ hành vi cũ"; test "mặc định bật" nằm ở security-253.test.js.
test("F3: đặt VIEW_SCORE_ONCE_PER_PAIR=off — hành vi cũ: sau mỗi cửa sổ 30 phút lại được cộng điểm", async () => {
  process.env.VIEW_SCORE_ONCE_PER_PAIR = "off";
  try {
    seedPost();
    await viewAt(T0); await viewAt(T0 + 10 * MIN); await viewAt(T0 + 31 * MIN); await viewAt(T0 + 70 * MIN);
    assert.equal(S["posts/p1"].viewCount, 3, "lượt xem trong cửa sổ không tính");
    assert.equal(S["users/viewer"].positiveScore, 3);
    assert.equal(S["posts/p1"].externalPostScore, 3 * POST_SCORE_WEIGHTS.view);
  } finally {
    delete process.env.VIEW_SCORE_ONCE_PER_PAIR;
  }
});

test("F3: BẬT — viewCount vẫn tăng nhưng điểm chỉ cộng 1 lần cho mỗi cặp (người xem, bài)", async () => {
  process.env.VIEW_SCORE_ONCE_PER_PAIR = "on";
  try {
    seedPost();
    await viewAt(T0); await viewAt(T0 + 31 * MIN); await viewAt(T0 + 70 * MIN); await viewAt(T0 + 200 * MIN);
    assert.equal(S["posts/p1"].viewCount, 4, "số lượt xem hiển thị vẫn đếm như cũ");
    assert.equal(S["users/viewer"].positiveScore, 1, "chỉ +1 điểm cho người xem");
    assert.equal(S["posts/p1"].externalPostScore, POST_SCORE_WEIGHTS.view, "chỉ cộng 1 lần cho tác giả");
    assert.equal(S["users/author"].postsScoreSum, POST_SCORE_WEIGHTS.view);
    const view = S["posts/p1/views/uid:viewer"];
    assert.ok(view.scoredAtMs, "đã đánh dấu đã tính điểm");

    await viewAt(T0 + 1 * MIN, "p2"); // bài KHÁC vẫn được tính điểm lần đầu
    assert.equal(S["users/viewer"].positiveScore, 2);
    assert.equal(S["posts/p2"].externalPostScore, POST_SCORE_WEIGHTS.view);
  } finally {
    delete process.env.VIEW_SCORE_ONCE_PER_PAIR;
  }
});

test("F3: BẬT — bản ghi view cũ (chưa có scoredAtMs) được tính điểm thêm đúng 1 lần rồi khoá", async () => {
  process.env.VIEW_SCORE_ONCE_PER_PAIR = "on";
  try {
    seedPost();
    S["posts/p1/views/uid:viewer"] = { lastViewedAtMs: T0 - 100 * MIN }; // dữ liệu từ trước khi có công tắc
    await viewAt(T0);
    await viewAt(T0 + 40 * MIN);
    assert.equal(S["users/viewer"].positiveScore, 1);
    assert.equal(S["posts/p1"].viewCount, 2);
  } finally {
    delete process.env.VIEW_SCORE_ONCE_PER_PAIR;
  }
});
