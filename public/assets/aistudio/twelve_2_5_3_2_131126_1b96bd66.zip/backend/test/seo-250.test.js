// Kiểm thử v2.5.0 [SEO]: Microdata DiscussionForumPosting, bình luận trong SSR, alt ảnh dự phòng, liên kết nội bộ,
// JSON-LD BlogPosting/ProfilePage/Breadcrumb, mô tả riêng từng trang, sitemap ảnh, robots.txt.
// Dùng Firestore GIẢ (in-memory) + Express thật — không cần mạng hay service account.
const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");
const http = require("node:http");
const express = require("express");

// ------------------------------------------------------------ Firestore giả (có subcollection `comments`)
const ts = (iso) => {
  const d = new Date(iso);
  return { toMillis: () => d.getTime(), toDate: () => d, _seconds: Math.floor(d.getTime() / 1000) };
};
const IMG_HTML = '<p>Mở đầu</p><img src="https://img.example/a.png"><img src="https://img.example/b.png" alt="Biểu đồ doanh thu"><img src="https://img.example/c.png" alt="">';
const DATA = {
  users: {
    u1: { uid: "u1", displayName: "An", tagName: "annguyen", status: "active", accountGroup: "USER", accountRole: "user", createdAt: ts("2026-01-01T00:00:00Z") },
    u2: { uid: "u2", displayName: "Binh", tagName: "binh", status: "pending", accountGroup: "USER", accountRole: "user" },
    u3: { uid: "u3", displayName: "Chi", tagName: "chi", status: "suspended", accountGroup: "USER", accountRole: "user" },
    u4: { uid: "u4", displayName: "Dung", tagName: "dung", status: "active", accountGroup: "USER", accountRole: "user", createdAt: ts("2026-02-01T00:00:00Z") },
  },
  tagNames: { annguyen: { uid: "u1" }, binh: { uid: "u2" }, chi: { uid: "u3" }, dung: { uid: "u4" } },
  posts: {
    p1: {
      id: "p1", authorUid: "u1", title: 'Bài "một" <b>', contentHtml: IMG_HTML, excerpt: "Mở đầu", hashtags: ["#a", "#b"], hashtagsLower: ["#a", "#b"],
      createdAt: ts("2026-03-01T00:00:00Z"), updatedAt: ts("2026-03-02T00:00:00Z"), commentCount: 5, likeCount: 3, viewCount: 9,
      coverImageUrl: "https://img.example/cover.png",
    },
    p2: { id: "p2", authorUid: "u1", title: "Bài hai", contentHtml: "<p>Hai</p>", excerpt: "Hai", hashtags: ["#a"], hashtagsLower: ["#a"], createdAt: ts("2026-04-01T00:00:00Z"), updatedAt: ts("2026-04-01T00:00:00Z") },
    p3: { id: "p3", authorUid: "u4", title: "Bài của Dũng", contentHtml: "<p>Ba</p>", excerpt: "Ba", hashtags: ["#a"], hashtagsLower: ["#a"], createdAt: ts("2026-04-05T00:00:00Z"), updatedAt: ts("2026-04-05T00:00:00Z") },
    p4: { id: "p4", authorUid: "u1", title: "Bài không ảnh bìa", contentHtml: "<p>Bốn</p>", excerpt: "Bốn", hashtags: [], hashtagsLower: [], createdAt: ts("2026-04-06T00:00:00Z"), updatedAt: ts("2026-04-06T00:00:00Z"), commentCount: 0 },
    // Ảnh bìa không an toàn: không được lọt vào sitemap ảnh.
    p5: { id: "p5", authorUid: "u1", title: "Bài ảnh xấu", contentHtml: "<p>x</p>", excerpt: "x", hashtags: [], hashtagsLower: [], createdAt: ts("2026-04-07T00:00:00Z"), coverImageUrl: "http://insecure.example/x.png" },
  },
  blogs: {
    b1: {
      id: "b1", authorUid: "u1", title: "Blog xuất bản", contentHtml: "<p>B</p>", excerpt: "B", hashtags: ["#a"], hashtagsLower: ["#a"], isPublished: true,
      createdAt: ts("2026-02-01T00:00:00Z"), updatedAt: ts("2026-02-01T00:00:00Z"), commentCount: 1,
    },
  },
  "posts/p1/comments": {
    c1: { id: "c1", authorUid: "u4", content: "Bình luận <script>alert(1)</script> đầu", createdAt: ts("2026-03-01T01:00:00Z") },
    c2: { id: "c2", authorUid: "u3", content: "BÌNH LUẬN CỦA TÀI KHOẢN BỊ KHOÁ", createdAt: ts("2026-03-01T02:00:00Z") },
    c3: { id: "c3", authorUid: "u2", content: "BÌNH LUẬN CỦA TÀI KHOẢN CHƯA KÍCH HOẠT", createdAt: ts("2026-03-01T03:00:00Z") },
    c4: { id: "c4", authorUid: "ghost", content: "BÌNH LUẬN CỦA HỒ SƠ MA", createdAt: ts("2026-03-01T04:00:00Z") },
    c5: { id: "c5", authorUid: "u1", content: "Cảm ơn bạn", createdAt: ts("2026-03-01T05:00:00Z"), isEdited: true, updatedAt: ts("2026-03-01T06:00:00Z") },
  },
  "blogs/b1/comments": {
    k1: { id: "k1", authorUid: "u4", content: "Hay quá", createdAt: ts("2026-02-02T00:00:00Z") },
  },
};
let failComments = false;
const matches = (row, f) =>
  f.op === "==" ? row[f.field] === f.value : f.op === "array-contains" ? (row[f.field] || []).includes(f.value) : false;
function makeQuery(name, filters = [], order = null, max = Infinity) {
  const q = {
    where: (field, op, value) => makeQuery(name, [...filters, { field, op, value }], order, max),
    orderBy: (field, dir) => makeQuery(name, filters, { field, dir }, max),
    limit: (n) => makeQuery(name, filters, order, n),
    select: () => q,
    async get() {
      if (failComments && name.endsWith("/comments")) throw new Error("comments down");
      let rows = Object.entries(DATA[name] || {}).map(([id, v]) => ({ id, v })).filter(({ v }) => filters.every((f) => matches(v, f)));
      if (order) rows.sort((a, b) => (order.dir === "desc" ? -1 : 1) * (a.v[order.field].toMillis() - b.v[order.field].toMillis()));
      rows = rows.slice(0, max);
      return { docs: rows.map(({ id, v }) => ({ id, exists: true, data: () => v, get: (k) => v[k] })), size: rows.length };
    },
  };
  return q;
}
const fakeDb = {
  collection(name) {
    return Object.assign(makeQuery(name), {
      doc(id) {
        return {
          id,
          async get() {
            const v = (DATA[name] || {})[id];
            return { id, exists: !!v, data: () => v, get: (k) => v && v[k] };
          },
          async update() {},
          collection: (sub) => makeQuery(`${name}/${id}/${sub}`),
          __col: name,
        };
      },
    });
  },
  async getAll(...refs) {
    return refs
      .filter((r) => r && r.__col)
      .map((r) => {
        const v = (DATA[r.__col] || {})[r.id];
        return { id: r.id, exists: !!v, get: (k) => v && v[k] };
      });
  },
  async runTransaction(fn) {
    return fn({ get: async () => ({ exists: false, data: () => ({}) }), set() {}, update() {} });
  },
  batch: () => ({ set() {}, update() {}, commit: async () => {} }),
};
const fakeAdmin = { firestore: { FieldValue: { increment: (n) => ({ n }), serverTimestamp: () => ({}) } } };
const fbPath = require.resolve("../src/config/firebase");
require.cache[fbPath] = { id: fbPath, filename: fbPath, loaded: true, exports: { db: fakeDb, admin: fakeAdmin, auth: {} } };

process.env.FRONTEND_URL = "https://twelve.example";
process.env.SSR_PROXY_SECRET = "top-secret";
delete process.env.SITE_LOGO_URL;

function buildApp() {
  const app = express();
  app.set("views", path.join(__dirname, "../src/views"));
  app.set("view engine", "ejs");
  app.use((req, res, next) => {
    res.locals.cspNonce = "nonce123";
    next();
  });
  app.use("/", require("../src/routes/ssr.routes"));
  return app;
}
function listen(app) {
  return new Promise((resolve) => {
    const server = http.createServer(app).listen(0, () => resolve({ server, base: `http://127.0.0.1:${server.address().port}` }));
  });
}
const BOT = { "x-twelve-ssr-secret": "top-secret", "x-twelve-client-ip": "9.9.9.9", "user-agent": "Googlebot/2.1" };

/** Mọi khối JSON-LD của trang, đã parse. */
function jsonLdBlocks(html) {
  return [...html.matchAll(/<script type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)].map((m) => JSON.parse(m[1]));
}
const types = (blocks) => blocks.map((b) => b["@type"]);

// ------------------------------------------------------------ ensureImageAlts
test("ensureImageAlts: điền alt thiếu/rỗng, giữ alt mô tả, escape tiêu đề, không nhầm data-alt", () => {
  const { ensureImageAlts } = require("../src/utils/ssrContent");
  const out = ensureImageAlts(IMG_HTML, 'Bài "một" <b>');
  assert.match(out, /<img alt="Bài &quot;một&quot; &lt;b&gt; — hình 1" src="https:\/\/img\.example\/a\.png">/);
  assert.match(out, /alt="Biểu đồ doanh thu"/, "alt mô tả được giữ nguyên");
  assert.ok(!out.includes('alt=""'), "alt rỗng bị thay");
  assert.match(out, /alt="Bài &quot;một&quot; &lt;b&gt; — hình 3"/, "ảnh thứ 3 đánh số 3");

  const dataAlt = ensureImageAlts('<img data-alt="x" src="https://i.example/z.png">', "Tiêu đề");
  assert.match(dataAlt, / alt="Tiêu đề — hình 1"/, "data-alt không được coi là alt");

  assert.equal(ensureImageAlts("<p>không ảnh</p>", "T"), "<p>không ảnh</p>");
  assert.equal(ensureImageAlts("", "T"), "");
  assert.equal(ensureImageAlts("<img src=x>", ""), "<img src=x>", "không có tiêu đề thì không bịa alt");
  const long = ensureImageAlts("<img src=x>", "a".repeat(300));
  assert.ok(/alt="a{99}… — hình 1"/.test(long), "tiêu đề dài bị cắt 100 ký tự");
});

// ------------------------------------------------------------ SSR bài viết
test("SSR bài viết: Microdata DiscussionForumPosting + bình luận + liên kết nội bộ + alt ảnh", async (t) => {
  const { server, base } = await listen(buildApp());
  t.after(() => server.close());
  const r = await fetch(`${base}/post/p1`, { headers: BOT });
  assert.equal(r.status, 200);
  const html = await r.text();

  // Microdata đúng loại, thân bài là `text`
  assert.match(html, /itemtype="https:\/\/schema\.org\/DiscussionForumPosting"/);
  assert.match(html, /itemprop="headline"/);
  assert.match(html, /<div class="post-content" itemprop="text">/);
  assert.match(html, /itemprop="datePublished" datetime="2026-03-01T00:00:00\.000Z"/);
  assert.match(html, /<meta itemprop="dateModified" content="2026-03-02T00:00:00\.000Z" \/>/);
  assert.match(html, /itemprop="commentCount" content="5"/);
  assert.match(html, /itemprop="author" itemscope itemtype="https:\/\/schema\.org\/Person"/);
  assert.match(html, /href="https:\/\/twelve\.example\/u\/@annguyen" itemprop="url"/);
  assert.match(html, /LikeAction[\s\S]*?id="like-count" itemprop="userInteractionCount">3</);

  // JSON-LD của bài viết CHỈ còn BreadcrumbList (không nhân đôi với Microdata, không còn Article)
  const blocks = jsonLdBlocks(html);
  assert.deepEqual(types(blocks), ["BreadcrumbList"]);
  assert.ok(!html.includes('"@type":"Article"'));

  // Bình luận: chỉ tác giả ACTIVE, escape XSS, đúng thứ tự cũ -> mới, có Microdata Comment
  assert.ok(html.includes("Bình luận &lt;script&gt;alert(1)&lt;/script&gt; đầu"), "nội dung bình luận được escape");
  assert.ok(!html.includes("<script>alert(1)"), "không có script chèn qua bình luận");
  assert.ok(html.includes("Cảm ơn bạn"));
  assert.ok(!html.includes("BỊ KHOÁ") && !html.includes("CHƯA KÍCH HOẠT") && !html.includes("HỒ SƠ MA"), "bình luận của hồ sơ không active không được lộ cho bot");
  assert.ok(html.indexOf("Bình luận &lt;script") < html.indexOf("Cảm ơn bạn"), "thứ tự cũ nhất trước");
  assert.equal((html.match(/itemtype="https:\/\/schema\.org\/Comment"/g) || []).length, 2);
  assert.match(html, /<meta itemprop="url" content="https:\/\/twelve\.example\/post\/p1#comment-c1" \/>/);
  assert.match(html, /id="comment-c5"/);
  assert.match(html, /Còn nhiều bình luận khác/, "commentCount (5) > số bình luận đang hiển thị (2)");
  assert.ok(!html.includes("tải phía client"), "câu cũ đã bỏ");

  // Alt ảnh dự phòng trong thân bài + alt mô tả giữ nguyên; ảnh bìa có alt
  assert.match(html, /<img alt="Bài &quot;một&quot; &lt;b&gt; — hình 1"[^>]* src="https:\/\/img\.example\/a\.png"/);
  assert.match(html, /alt="Biểu đồ doanh thu"/);
  assert.match(html, /class="cover" itemprop="image" src="https:\/\/img\.example\/cover\.png" alt="Ảnh bìa: Bài &#34;một&#34; &lt;b&gt;"/);
  assert.match(html, /<meta property="og:image:alt" content="Bài &#34;một&#34; &lt;b&gt;" \/>/);
  assert.match(html, /<meta name="twitter:image:alt"/);
  assert.match(html, /<meta property="article:section" content="Bài viết" \/>/);

  // Liên kết nội bộ: cùng chủ đề (#a) + bài khác của tác giả; không tự link chính nó
  assert.match(html, /<h2>Cùng chủ đề #a<\/h2>/);
  assert.match(html, /<h2>Bài khác của An<\/h2>/);
  const related = html.slice(html.indexOf('<aside class="related">'));
  assert.ok(related.includes('href="https://twelve.example/post/p2"'));
  assert.ok(related.includes('href="https://twelve.example/post/p3"'), "bài cùng hashtag của tác giả khác");
  assert.ok(!related.includes('href="https://twelve.example/post/p1"'), "không link tới chính bài đang xem");
});

test("SSR bài viết: không bình luận => không đọc subcollection; chỉ có Microdata của bài", async (t) => {
  const { server, base } = await listen(buildApp());
  t.after(() => server.close());
  failComments = true; // nếu code đọc subcollection sẽ ném lỗi => trang vẫn phải 200
  const html = await (await fetch(`${base}/post/p4`, { headers: BOT })).text();
  failComments = false;
  assert.ok(html.includes("Chưa có bình luận nào."));
  assert.equal((html.match(/schema\.org\/Comment"/g) || []).length, 0);
  assert.ok(!html.includes("Cùng chủ đề"), "bài không có hashtag => không có khối cùng chủ đề");
  assert.match(html, /<h2>Bài khác của An<\/h2>/);
});

test("SSR bài viết: đọc bình luận lỗi => trang vẫn 200 (phần phụ không làm hỏng SSR)", async (t) => {
  const { server, base } = await listen(buildApp());
  t.after(() => server.close());
  failComments = true;
  const origErr = console.error;
  console.error = () => {};
  try {
    const r = await fetch(`${base}/post/p1`, { headers: BOT });
    assert.equal(r.status, 200);
    const html = await r.text();
    assert.match(html, /Mở bản đầy đủ để xem 5 bình luận/);
    assert.equal((html.match(/schema\.org\/Comment"/g) || []).length, 0);
  } finally {
    console.error = origErr;
    failComments = false;
  }
});

// ------------------------------------------------------------ SSR blog
test("SSR blog: JSON-LD BlogPosting kèm comment, không dùng Microdata của bài viết", async (t) => {
  const { server, base } = await listen(buildApp());
  t.after(() => server.close());
  const html = await (await fetch(`${base}/blog/b1`, { headers: BOT })).text();
  assert.ok(!html.includes("DiscussionForumPosting"), "blog không dùng DiscussionForumPosting");
  const blocks = jsonLdBlocks(html);
  assert.deepEqual(types(blocks), ["BlogPosting", "BreadcrumbList"]);
  const blog = blocks[0];
  assert.equal(blog.headline, "Blog xuất bản");
  assert.equal(blog.inLanguage, "vi");
  assert.equal(blog.keywords, "#a");
  assert.equal(blog.commentCount, 1);
  assert.equal(blog.comment.length, 1);
  assert.equal(blog.comment[0]["@type"], "Comment");
  assert.equal(blog.comment[0].text, "Hay quá");
  assert.equal(blog.comment[0].author.url, "https://twelve.example/u/@dung");
  assert.equal(blog.comment[0].url, "https://twelve.example/blog/b1#comment-k1");
  assert.equal(blog.image, undefined, "blog không ảnh bìa: không đưa ảnh OG mặc định vào dữ liệu có cấu trúc");
  assert.match(html, /<meta property="og:image" content="https:\/\/twelve\.example\/og-default\.png"/, "OG vẫn dùng ảnh mặc định");
});

// ------------------------------------------------------------ Hồ sơ / hashtag / danh sách
test("SSR hồ sơ: ProfilePage có dateCreated, 'Tham gia từ' không in [object Object]; mô tả riêng theo bài gần đây", async (t) => {
  const { server, base } = await listen(buildApp());
  t.after(() => server.close());
  const html = await (await fetch(`${base}/u/@annguyen`, { headers: BOT })).text();
  assert.ok(!html.includes("[object Object]"), "createdAt Timestamp phải được chuẩn hoá");
  assert.match(html, /Tham gia từ [^<\n]*2026/);
  const blocks = jsonLdBlocks(html);
  assert.deepEqual(types(blocks), ["ProfilePage", "BreadcrumbList", "ItemList"]);
  assert.equal(blocks[0].dateCreated, "2026-01-01T00:00:00.000Z");
  assert.equal(blocks[0].mainEntity.identifier, "@annguyen");
  const desc = html.match(/<meta name="description" content="([^"]*)"/)[1];
  assert.ok(desc.startsWith("Hồ sơ An (@annguyen) trên Twelve."));
  assert.ok(desc.includes("Bài viết gần đây:") && desc.includes("Bài ảnh xấu"), "mô tả nêu tiêu đề bài mới nhất");
  assert.ok(desc.length <= 160);
});

test("SSR hashtag: mô tả nêu số bài + tiêu đề, có BreadcrumbList; hashtag rỗng vẫn 404", async (t) => {
  const { server, base } = await listen(buildApp());
  t.after(() => server.close());
  const r = await fetch(`${base}/trending?tab=hashtag&hashtag=%23A`, { headers: BOT });
  assert.equal(r.status, 200);
  const html = await r.text();
  const desc = html.match(/<meta name="description" content="([^"]*)"/)[1];
  assert.match(desc, /^\d+ bài viết và blog mới nhất với hashtag #a trên Twelve: /);
  const blocks = jsonLdBlocks(html);
  assert.deepEqual(types(blocks), ["CollectionPage", "BreadcrumbList"]);
  const crumbs = blocks[1].itemListElement.map((c) => c.name);
  assert.deepEqual(crumbs, ["Trang chủ", "Xu hướng", "#a"]);
  assert.equal((await fetch(`${base}/trending?tab=hashtag&hashtag=%23khongco`, { headers: BOT })).status, 404);
});

test("SSR trang chủ/blog: tiêu đề + mô tả KHỚP bản SPA; WebSite + Organization; Breadcrumb ở /blog", async (t) => {
  const { server, base } = await listen(buildApp());
  t.after(() => server.close());
  const home = await (await fetch(`${base}/__ssr/home`, { headers: BOT })).text();
  assert.match(home, /<title>Twelve — Nền tảng mạng xã hội chia sẻ bài viết<\/title>/);
  assert.ok(home.includes('content="Twelve là nền tảng mạng xã hội chia sẻ bài viết, bình luận và xếp hạng nội dung theo tuần. Khám phá bài viết mới, blog và bảng xu hướng."'));
  assert.deepEqual(types(jsonLdBlocks(home)), ["WebSite", "Organization", "ItemList"]);
  const blog = await (await fetch(`${base}/__ssr/blog`, { headers: BOT })).text();
  assert.match(blog, /<title>Blog \| Twelve<\/title>/);
  assert.ok(blog.includes('content="Danh sách bài viết blog trên Twelve, cập nhật mới nhất."'));
  assert.deepEqual(types(jsonLdBlocks(blog)), ["ItemList", "BreadcrumbList"]);
});

// ------------------------------------------------------------ Sitemap ảnh + robots.txt
test("sitemap: có <image:image> cho ảnh bìa https hợp lệ, bỏ ảnh http/không hợp lệ; robots.txt chặn trang riêng tư", async (t) => {
  delete process.env.SITEMAP_REFRESH_TOKEN;
  delete require.cache[require.resolve("../src/controllers/seo.controller")];
  delete require.cache[require.resolve("../src/routes/seo.routes")];
  const app = express();
  app.use("/", require("../src/routes/seo.routes"));
  const { server, base } = await listen(app);
  t.after(() => server.close());

  const xml = await (await fetch(`${base}/sitemap-1.xml`)).text();
  assert.match(xml, /<urlset xmlns="http:\/\/www\.sitemaps\.org\/schemas\/sitemap\/0\.9" xmlns:image="http:\/\/www\.google\.com\/schemas\/sitemap-image\/1\.1">/);
  assert.match(xml, /<loc>https:\/\/twelve\.example\/post\/p1<\/loc><lastmod>[^<]+<\/lastmod><image:image><image:loc>https:\/\/img\.example\/cover\.png<\/image:loc><\/image:image><\/url>/);
  assert.ok(!xml.includes("insecure.example"), "ảnh http không vào sitemap");
  assert.match(xml, /<loc>https:\/\/twelve\.example\/post\/p5<\/loc><lastmod>[^<]*<\/lastmod><\/url>/, "bài có ảnh bìa xấu vẫn có URL, chỉ thiếu thẻ ảnh");

  const { safeImageUrl } = require("../src/controllers/seo.controller").__test;
  assert.equal(safeImageUrl("https://a.example/x.png"), "https://a.example/x.png");
  assert.equal(safeImageUrl("javascript:alert(1)"), null);
  assert.equal(safeImageUrl("https://a.example/x y.png"), null);
  assert.equal(safeImageUrl('https://a.example/x".png'), null);
  assert.equal(safeImageUrl("https://a.example/" + "a".repeat(2100)), null);
  assert.equal(safeImageUrl(undefined), null);

  const robots = await fetch(`${base}/robots.txt`);
  const txt = await robots.text();
  assert.match(txt, /^User-agent: \*\nAllow: \/\n/);
  for (const p of ["/settings", "/u/myProfile", "/csp-report"]) assert.ok(txt.includes(`Disallow: ${p}\n`), `Disallow ${p}`);
  assert.ok(!/Disallow: \/login|Disallow: \/register|Disallow: \/post|Disallow: \/blog|Disallow: \/u\/\n|Disallow: \/\n/.test(txt), "không chặn trang cần lập chỉ mục/cần thấy noindex");
  assert.match(txt, /Sitemap: https:\/\/twelve\.example\/sitemap\.xml\n$/);
});

// ------------------------------------------------------------ v2.5.1.1: thẻ xác thực Google Search Console
const GSC_TOKEN = "xIyQYgOdTVuErxEiPFCfbG9LQRS1WJE_-PpELCCnzJQ";
const GSC_TAG = `<meta name="google-site-verification" content="${GSC_TOKEN}" />`;

test("thẻ google-site-verification có ở mọi trang SSR (đúng 1 lần, trong <head>) và cùng mã với frontend/index.html", async (t) => {
  const { server, base } = await listen(buildApp());
  t.after(() => server.close());
  for (const url of ["/__ssr/home", "/__ssr/blog", "/post/p2", "/blog/b1", "/u/@annguyen", "/trending?tab=hashtag&hashtag=%23a"]) {
    const html = await (await fetch(`${base}${url}`, { headers: BOT })).text();
    assert.equal(html.split(GSC_TAG).length - 1, 1, `${url}: đúng 1 thẻ xác thực`);
    assert.ok(html.indexOf(GSC_TAG) < html.indexOf("</head>"), `${url}: thẻ nằm trong <head>`);
  }
  // Bản SPA (index.html) là nơi Google-Site-Verification/1.0 nhận ở "/" — hai nơi phải cùng mã. Bỏ qua nếu backend được tách riêng khỏi frontend.
  const fs = require("node:fs");
  const indexHtml = path.join(__dirname, "../../frontend/index.html");
  if (fs.existsSync(indexHtml)) {
    const spa = fs.readFileSync(indexHtml, "utf8");
    assert.equal(spa.split(GSC_TAG).length - 1, 1, "index.html có đúng 1 thẻ cùng mã");
  }
});
