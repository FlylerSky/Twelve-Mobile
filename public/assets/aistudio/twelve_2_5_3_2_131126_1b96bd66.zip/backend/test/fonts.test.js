// v2.0.8 — font chữ server (#1.1): kiểm tra link, file, phục vụ file, phân quyền route admin.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const http = require("node:http");
const express = require("express");

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "fonts-"));
fs.writeFileSync(path.join(tmp, "dep.woff2"), Buffer.from("wOF2-fake-bytes"));
fs.writeFileSync(path.join(tmp, "doc.txt"), "not a font");
fs.writeFileSync(path.join(tmp, "unlisted.woff2"), "x");
process.env.FONTS_DIR = tmp;

const store = {};
const fbPath = require.resolve("../src/config/firebase");
require.cache[fbPath] = {
  id: fbPath, filename: fbPath, loaded: true,
  exports: {
    // v2.5.3 [TW-09]: PUT /fonts giờ ghi cấu hình + nhật ký (configAudit) trong MỘT batch ⇒ mock cần `batch()`, `doc()` không id (id tự sinh) và `ref.path`.
    db: {
      collection: (c) => ({ doc: (id) => { const key = `${c}/${id === undefined ? "auto" + Object.keys(store).length : id}`; return {
        path: key,
        get: async () => ({ exists: key in store, data: () => store[key] }),
        set: async (d) => { store[key] = d; },
      }; } }),
      batch: () => { const ops = []; return { set: (r, d) => ops.push(() => { store[r.path] = d; }), commit: async () => ops.forEach((f) => f()) }; },
    },
    admin: { firestore: { FieldValue: { serverTimestamp: () => ({ ts: true }) } } },
    auth: {},
  },
};
const ctrl = require("../src/controllers/fonts.controller");
const { validateFontUrl, normalizeFontsInput, toPublicFont } = ctrl.__test;

test("validateFontUrl", () => {
  assert.equal(validateFontUrl("https://cdn.example.com/a/b.woff2").format, "woff2");
  assert.equal(validateFontUrl("https://cdn.example.com/a/b.otf?v=2").format, "opentype");
  assert.equal(validateFontUrl("https://cdn.example.com/font-no-ext").format, null);
  for (const bad of [
    "", "http://cdn.example.com/a.woff2", "https://user:pw@cdn.example.com/a.woff2", "https://localhost/a.woff2",
    "https://127.0.0.1/a.woff2", "https://[::1]/a.woff2", "https://intranet/a.woff2", "javascript:alert(1)",
    "data:font/woff2;base64,AAAA", "https://fonts.googleapis.com/css2?family=Roboto", "https://cdn.example.com/s.css",
    "https://cdn.example.com/a.exe", "https://cdn.example.com/" + "a".repeat(600) + ".woff2", "not a url",
  ]) {
    assert.ok(validateFontUrl(bad).error, `phải từ chối: ${bad.slice(0, 50)}`);
  }
});

test("normalizeFontsInput: hợp lệ, id tự sinh, mặc định độ đậm", () => {
  const r = normalizeFontsInput([
    { label: "  Font  A ", kind: "url", url: "https://cdn.example.com/a.woff2" },
    { label: "Font B", kind: "file", file: "dep.woff2", weight: "400", note: "ghi chú" },
  ]);
  assert.equal(r.error, undefined);
  assert.match(r.fonts[0].id, /^srv-[0-9a-f]{8}$/);
  assert.equal(r.fonts[0].label, "Font A");
  assert.equal(r.fonts[0].weight, "100 900");
  assert.equal(r.fonts[1].weight, "400");
  assert.notEqual(r.fonts[0].id, r.fonts[1].id);
});

test("normalizeFontsInput: từ chối dữ liệu xấu", () => {
  const bad = [
    [{ label: "", kind: "url", url: "https://cdn.example.com/a.woff2" }],
    [{ label: "x", kind: "khac", url: "https://cdn.example.com/a.woff2" }],
    [{ label: "x", kind: "file", file: "../../etc/passwd" }],
    [{ label: "x", kind: "file", file: "khong-ton-tai.woff2" }],
    [{ label: "x", kind: "file", file: "doc.txt" }],
    [{ label: "x", kind: "url", url: "https://cdn.example.com/a.woff2", weight: "bold" }],
    [{ label: "x", kind: "url", url: "https://cdn.example.com/a.woff2", id: "../x" }],
    [{ label: "a", kind: "url", url: "https://cdn.example.com/a.woff2" }, { label: "b", kind: "url", url: "https://cdn.example.com/a.woff2" }],
    [{ label: "a", kind: "file", file: "dep.woff2" }, { label: "b", kind: "file", file: "dep.woff2" }],
    Array.from({ length: 21 }, (_, i) => ({ label: `f${i}`, kind: "url", url: `https://cdn.example.com/${i}.woff2` })),
    "khong-phai-mang",
  ];
  bad.forEach((b, i) => assert.ok(normalizeFontsInput(b).error, `ca xấu #${i} phải bị từ chối`));
});

test("toPublicFont: file mất => null; URL hỏng trong DB => null", () => {
  assert.equal(toPublicFont({ id: "srv-1", label: "x", kind: "file", file: "mat.woff2" }), null);
  assert.equal(toPublicFont({ id: "srv-1", label: "x", kind: "url", url: "http://insecure.example.com/a.woff2" }), null);
  const f = toPublicFont({ id: "srv-2", label: "ok", kind: "file", file: "dep.woff2", weight: "400" });
  assert.deepEqual({ url: f.url, relative: f.relative, format: f.format, weight: f.weight }, { url: "/fonts/files/dep.woff2", relative: true, format: "woff2", weight: "400" });
});

function listen(app) {
  return new Promise((r) => { const s = http.createServer(app).listen(0, () => r({ s, base: `http://127.0.0.1:${s.address().port}` })); });
}

test("API: PUT admin -> GET công khai -> phục vụ file", async (t) => {
  const app = express();
  app.use(express.json());
  // Mô phỏng requireSA: header x-sa = 1
  const adminRouter = express.Router();
  adminRouter.use((req, res, next) => (req.headers["x-sa"] === "1" ? ((req.authUid = "sa1"), next()) : res.status(403).json({ error: "forbidden" })));
  adminRouter.get("/fonts", ctrl.getFontsSettings);
  adminRouter.put("/fonts", ctrl.updateFontsSettings);
  app.use("/api/admin", adminRouter);
  app.use("/api/fonts", require("../src/routes/fonts.routes"));
  const { s, base } = await listen(app);
  t.after(() => s.close());

  // Công khai khi chưa có gì
  let r = await fetch(`${base}/api/fonts`);
  assert.deepEqual(await r.json(), { fonts: [] });

  // Không phải SA => 403
  assert.equal((await fetch(`${base}/api/admin/fonts`)).status, 403);

  // File chưa được thêm vào danh sách => 404 dù có trên đĩa
  assert.equal((await fetch(`${base}/api/fonts/files/dep.woff2`)).status, 404);

  // Admin thấy các file khả dụng (chỉ file font hợp lệ)
  let a = await (await fetch(`${base}/api/admin/fonts`, { headers: { "x-sa": "1" } })).json();
  assert.deepEqual(a.availableFiles.map((f) => f.name).sort(), ["dep.woff2", "unlisted.woff2"]);

  // Lưu danh sách
  const put = await fetch(`${base}/api/admin/fonts`, {
    method: "PUT", headers: { "x-sa": "1", "content-type": "application/json" },
    body: JSON.stringify({ fonts: [
      { label: "Từ CDN", kind: "url", url: "https://cdn.example.com/a.woff2" },
      { label: "Từ server", kind: "file", file: "dep.woff2" },
    ] }),
  });
  assert.equal(put.status, 200);
  const saved = await put.json();
  assert.equal(saved.fonts.length, 2);

  // Công khai thấy ngay (cache đã bị vô hiệu)
  r = await fetch(`${base}/api/fonts`);
  const pub = (await r.json()).fonts;
  assert.equal(pub.length, 2);
  assert.equal(pub[1].url, "/fonts/files/dep.woff2");
  assert.ok(!("file" in pub[1]) && !("kind" in pub[1]), "không lộ field nội bộ");

  // Phục vụ file đã thêm: đúng loại, CORS mở, cache; file chưa thêm / không phải font / traversal => 404
  const f = await fetch(`${base}/api/fonts/files/dep.woff2`);
  assert.equal(f.status, 200);
  assert.equal(f.headers.get("content-type"), "font/woff2");
  assert.equal(f.headers.get("access-control-allow-origin"), "*");
  assert.equal(f.headers.get("cross-origin-resource-policy"), "cross-origin");
  assert.equal(Buffer.from(await f.arrayBuffer()).toString(), "wOF2-fake-bytes");
  for (const p of ["unlisted.woff2", "doc.txt", "..%2F..%2Fetc%2Fpasswd", "%2e%2e%2fdep.woff2", "dep.woff2%00.txt", ".hidden"]) {
    assert.equal((await fetch(`${base}/api/fonts/files/${p}`)).status, 404, p);
  }

  // Input xấu => 400 và KHÔNG ghi đè dữ liệu cũ
  const bad = await fetch(`${base}/api/admin/fonts`, {
    method: "PUT", headers: { "x-sa": "1", "content-type": "application/json" },
    body: JSON.stringify({ fonts: [{ label: "x", kind: "url", url: "http://insecure.example.com/a.woff2" }] }),
  });
  assert.equal(bad.status, 400);
  assert.equal((await (await fetch(`${base}/api/fonts`)).json()).fonts.length, 2);

  // File bị xoá khỏi đĩa => biến mất khỏi danh sách công khai và không còn được phục vụ
  fs.unlinkSync(path.join(tmp, "dep.woff2"));
  ctrl.__test.invalidateCache();
  assert.equal((await (await fetch(`${base}/api/fonts`)).json()).fonts.length, 1);
  assert.equal((await fetch(`${base}/api/fonts/files/dep.woff2`)).status, 404);
  a = await (await fetch(`${base}/api/admin/fonts`, { headers: { "x-sa": "1" } })).json();
  assert.equal(a.fonts[1].fileMissing, true);
  assert.equal(a.fonts[1].visible, false);
  assert.match(a.fonts[1].hiddenReason, /backend\/fonts/);
  assert.equal(a.visibleCount, 1);
});
