// v2.5.2 — Hoàn thiện trang Profile: Tiểu sử (bio), "Thông tin mở rộng" (hộp Xem thêm) + thành tích, Khách ghé thăm, tab Blog, SSR.
// Dùng Firestore/Auth GIẢ trong bộ nhớ + Express thật (không cần mạng hay service account).
// Chạy: node --test test/profile-252.test.js
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const path = require("node:path");
const express = require("express");

const { install } = require("./helpers/fakeFirebase");
const nowSec = () => Math.floor(Date.now() / 1000);
const fb = install({
  tokens: { tA: "uA", tB: "uB", tC: "uC", tP: "uP" },
  authTimes: { tA: nowSec() - 10, tB: nowSec() - 10, tC: nowSec() - 10, tP: nowSec() - 10 },
});
const S = fb.store;

process.env.FRONTEND_URL = "https://twelve.example";
process.env.SSR_PROXY_SECRET = "top-secret";
delete process.env.SITE_LOGO_URL;

const helpers = require("../src/utils/helpers");
const limiters = require("../src/middleware/rateLimiters");
const extras = require("../src/utils/profileExtras");
const { cleanBio, charLength } = require("../src/utils/input");
const { PROFILE } = require("../src/utils/constants");
const visitors = require("../src/services/profileVisitors");
const achievements = require("../src/services/achievements");

const app = express();
app.set("views", path.join(__dirname, "../src/views"));
app.set("view engine", "ejs");
app.use((req, res, next) => {
  res.locals.cspNonce = "nonce123";
  next();
});
app.use(express.json());
app.use("/api/users", require("../src/routes/users.routes"));
app.use("/", require("../src/routes/ssr.routes"));
let base;
let server;
test.before(async () => {
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

const call = async (method, url, token, body) => {
  const res = await fetch(base + url, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json = null;
  try {
    json = await res.json();
  } catch (_e) {
    /* không có body */
  }
  return { status: res.status, body: json, headers: res.headers };
};
const BOT = { "x-twelve-ssr-secret": "top-secret", "x-twelve-client-ip": "9.9.9.9", "user-agent": "Googlebot/2.1" };
const ssr = async (url) => (await fetch(base + url, { headers: BOT })).text();
const jsonLdBlocks = (html) => [...html.matchAll(/<script type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)].map((m) => JSON.parse(m[1]));

const reset = () => {
  for (const key of ["uid:uA", "uid:uB", "uid:uC", "uid:uP", "ip:127.0.0.1", "ip:::ffff:127.0.0.1", "ip:::1"]) {
    for (const l of Object.values(limiters)) if (l && typeof l.resetKey === "function") l.resetKey(key);
  }
  Object.keys(S).forEach((k) => delete S[k]);
  achievements.resetAchievementsCache();
};
const seedUser = (uid, over = {}) => {
  const tagName = over.tagName !== undefined ? over.tagName : `tag_${uid.toLowerCase()}`;
  S[`users/${uid}`] = {
    uid, displayName: `Tên ${uid}`, tagName, status: "active", accountGroup: "RA", accountRole: "user", country: "VN",
    email: `${uid.toLowerCase()}@x.com`, accountScore: 0, createdAt: new Date("2026-01-01T00:00:00Z"), ...over,
  };
  if (tagName) S[`tagNames/${tagName}`] = { uid };
};
const seedBlog = (id, authorUid, over = {}) => {
  S[`blogs/${id}`] = {
    id, authorUid, title: `Blog ${id}`, contentHtml: "<p>x</p>", excerpt: "tóm tắt", hashtags: [], hashtagsLower: [], isPublished: true,
    likeCount: 0, dislikeCount: 0, commentCount: 0, viewCount: 0, aiViewCount: 0, shareCount: 0, createdAt: new Date("2026-03-01T00:00:00Z"), ...over,
  };
};
const seedWeek = (weekCode, top10, over = {}) => {
  S[`weeklyLeaderboards/${weekCode}`] = { weekCode, top10, totalParticipants: 20, finalizedAt: new Date("2026-06-01T00:00:00Z"), ...over };
};
const entry = (uid, rank, weeklyGrowth = 10) => ({ rank, uid, displayName: uid, weeklyGrowth });

// ============================================================ Tiểu sử (bio)
test("cleanBio: chuẩn hoá xuống dòng, gộp khoảng trắng/dòng trống, bỏ bidi + ký tự điều khiển, GIỮ emoji ghép (ZWJ); rỗng hợp lệ", () => {
  assert.equal(cleanBio("  Xin chào  \r\n\r\n\r\n\r\nTôi là   Lan\t\u202e\u200b "), "Xin chào\n\nTôi là Lan");
  assert.equal(cleanBio("a\u2028b\u0000c"), "a\nb c");
  assert.equal(cleanBio("   "), "");
  assert.equal(cleanBio("👨‍👩‍👧 nhà"), "👨‍👩‍👧 nhà", "ZWJ của emoji ghép không bị coi là ký tự vô hình");
  assert.equal(charLength("😀😀"), 2, "đếm theo code point, không theo đơn vị UTF-16");
});

test("bio: PATCH /me lưu đã làm sạch; GET /:uid và /by-tag trả `bio`; xoá bằng chuỗi rỗng", async () => {
  reset(); seedUser("uA");
  const r = await call("PATCH", "/api/users/me", "tA", { bio: "  Xin chào\r\n\r\n\r\n\r\nMình là A  " });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(S["users/uA"].bio, "Xin chào\n\nMình là A");
  assert.equal((await call("GET", "/api/users/uA")).body.user.bio, "Xin chào\n\nMình là A");
  assert.equal((await call("GET", "/api/users/by-tag/tag_ua")).body.user.bio, "Xin chào\n\nMình là A");
  assert.equal((await call("PATCH", "/api/users/me", "tA", { bio: "" })).status, 200);
  assert.equal(S["users/uA"].bio, "");
  assert.equal((await call("GET", "/api/users/uA")).body.user.bio, "", "hồ sơ chưa có bio => chuỗi rỗng, không undefined");
});

test("bio: quá dài / quá nhiều dòng / sai kiểu => 400, không ghi gì", async () => {
  reset(); seedUser("uA", { bio: "cũ" });
  const long = await call("PATCH", "/api/users/me", "tA", { bio: "a".repeat(PROFILE.BIO_MAX + 1) });
  assert.equal(long.status, 400);
  assert.match(JSON.stringify(long.body), /300 ký tự/);
  const ok = await call("PATCH", "/api/users/me", "tA", { bio: "a".repeat(PROFILE.BIO_MAX) });
  assert.equal(ok.status, 200, "đúng bằng giới hạn thì được");
  S["users/uA"].bio = "cũ";
  const lines = await call("PATCH", "/api/users/me", "tA", { bio: Array.from({ length: PROFILE.BIO_MAX_LINES + 1 }, (_, i) => `d${i}`).join("\n") });
  assert.equal(lines.status, 400);
  assert.match(JSON.stringify(lines.body), /6 dòng/);
  for (const bad of [123, ["x"], { a: 1 }, null]) assert.equal((await call("PATCH", "/api/users/me", "tA", { bio: bad })).status, 400, JSON.stringify(bad));
  assert.equal(S["users/uA"].bio, "cũ", "request bị từ chối không ghi gì");
  // 300 emoji đơn (mỗi cái 2 đơn vị UTF-16) vẫn nằm trong giới hạn vì đếm theo code point
  assert.equal((await call("PATCH", "/api/users/me", "tA", { bio: "😀".repeat(PROFILE.BIO_MAX) })).status, 200);
});

test("bio: HTML/script chỉ là chữ (lưu nguyên văn, KHÔNG diễn giải) và không có bio trong `author` của thẻ bài (toPublicUser)", async () => {
  reset(); seedUser("uA");
  const payload = '<img src=x onerror=alert(1)> <script>alert(1)</script>';
  assert.equal((await call("PATCH", "/api/users/me", "tA", { bio: payload })).status, 200);
  assert.equal(S["users/uA"].bio, payload, "lưu chữ thuần; việc thoát ký tự là của nơi hiển thị (React text / EJS <%= %>)");
  assert.ok(!("bio" in helpers.toPublicUser({ uid: "uA", displayName: "A", bio: "x" })), "toPublicUser (author của từng thẻ) không gửi bio");
  assert.equal(helpers.toPublicProfile({ uid: "uA", displayName: "A" }).bio, "");
});

// ============================================================ Thông tin mở rộng: cờ
test("profileExtras: mặc định bật thứ vốn đã công khai, TẮT ngày sinh/giới tính/trạng thái/UID; giá trị hỏng quay về mặc định", () => {
  assert.deepEqual(extras.resolveExtras(undefined), extras.EXTRA_DEFAULTS);
  for (const k of ["birthday", "gender", "status", "uid"]) assert.equal(extras.EXTRA_DEFAULTS[k], false, `${k} mặc định TẮT`);
  for (const k of ["displayName", "accountGroup", "accountRole", "createdAt", "achievements"]) assert.equal(extras.EXTRA_DEFAULTS[k], true, `${k} mặc định bật`);
  const r = extras.resolveExtras({ birthday: "true", gender: 1, uid: null, status: true, rac: true });
  assert.equal(r.birthday, false, "chuỗi 'true' không phải boolean => mặc định, không bật nhầm");
  assert.equal(r.gender, false);
  assert.equal(r.status, true);
  assert.ok(!("rac" in r), "khoá lạ không lọt vào kết quả");
  assert.deepEqual(extras.EXTRA_KEYS.slice().sort(), Object.keys(extras.EXTRA_DEFAULTS).sort(), "danh sách khoá và bảng mặc định cùng một tập");
});

test("CHỐT CHẶN: tập khoá SSR không bao giờ chứa mục nhạy cảm (birthday/gender/status/uid) và describeSsrExtras không in chúng kể cả khi được đưa vào", () => {
  for (const k of ["birthday", "gender", "status", "uid"]) assert.ok(!extras.SSR_EXTRA_KEYS.includes(k), `SSR_EXTRA_KEYS không được có ${k}`);
  for (const k of extras.SSR_EXTRA_KEYS) assert.ok(extras.EXTRA_KEYS.includes(k), `${k} phải là khoá đã biết`);
  const rows = extras.describeSsrExtras({ displayName: "An", birthday: "2000-01-31", gender: "female", status: "active", uid: "uA" }, null);
  assert.deepEqual(rows, [{ label: "Tên hiển thị", value: "An" }]);
  // buildExtraFields với `only` bỏ khoá ngoài tập cho phép dù cờ bật
  const all = Object.fromEntries(extras.EXTRA_KEYS.map((k) => [k, true]));
  const f = extras.buildExtraFields({ uid: "uA", displayName: "An", birthday: "2000-01-31", gender: "male", status: "active", accountGroup: "RA", accountRole: "user" }, all, extras.SSR_EXTRA_KEYS);
  assert.deepEqual(Object.keys(f).sort(), ["accountGroup", "accountRole", "displayName"]);
});

test("PUT /me/extras: cần đăng nhập; chỉ nhận khoá đã biết + boolean; gộp từng phần không ghi đè nhau", async () => {
  reset(); seedUser("uA");
  assert.equal((await call("PUT", "/api/users/me/extras", null, { extras: { birthday: true } })).status, 401);
  for (const bad of [undefined, null, [], "x", {}, { khongco: true }, { birthday: "true" }, { birthday: 1 }, { birthday: true, uid: "x" }]) {
    const r = await call("PUT", "/api/users/me/extras", "tA", { extras: bad });
    assert.equal(r.status, 400, JSON.stringify(bad));
  }
  assert.equal(S["users/uA"].profileExtras, undefined, "request lỗi không ghi gì (kể cả khi chỉ một khoá trong đó sai)");

  const r1 = await call("PUT", "/api/users/me/extras", "tA", { extras: { birthday: true } });
  assert.equal(r1.status, 200);
  assert.equal(r1.body.profileExtras.birthday, true);
  assert.equal(r1.body.profileExtras.displayName, true, "trả cờ ĐÃ PHÂN GIẢI (đủ mọi khoá)");
  const r2 = await call("PUT", "/api/users/me/extras", "tA", { extras: { gender: true, achievements: false } });
  assert.equal(r2.status, 200);
  assert.deepEqual(S["users/uA"].profileExtras, { birthday: true, gender: true, achievements: false }, "lần sau không làm mất lần trước; chỉ lưu khoá đã chỉnh");
  assert.equal(r2.body.profileExtras.birthday, true);
});

test("PUT /me/extras: tài khoản không active => 403 và không ghi", async () => {
  reset(); seedUser("uP", { status: "pending" });
  const r = await call("PUT", "/api/users/me/extras", "tP", { extras: { birthday: true } });
  assert.ok([401, 403].includes(r.status), `pending bị chặn (${r.status})`);
  assert.equal(S["users/uP"].profileExtras, undefined);
});

// ============================================================ GET /:uid/extra-info
test("extra-info mặc định: có tên/nhóm/vai trò/ngày tham gia + thành tích; KHÔNG có ngày sinh/giới tính/trạng thái/UID dù hồ sơ có dữ liệu", async () => {
  reset(); seedUser("uA", { birthday: "2000-01-31", gender: "female", accountGroup: "SA", accountRole: "admin" });
  const r = await call("GET", "/api/users/uA/extra-info");
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual(Object.keys(r.body.fields).sort(), ["accountGroup", "accountRole", "createdAt", "displayName"]);
  assert.equal(r.body.fields.accountGroup, "SA");
  assert.equal(r.body.fields.createdAt, "2026-01-01T00:00:00.000Z");
  assert.ok(r.body.achievements, "thành tích mặc định bật");
  const dump = JSON.stringify(r.body);
  for (const secret of ["2000-01-31", "female", "a@x.com", "ua@x.com"]) assert.ok(!dump.includes(secret), `không lộ ${secret}`);
  assert.equal(r.headers.get("cache-control"), "no-store");
});

test("extra-info + SSR: `createdAt` của hồ sơ THẬT là chuỗi ISO (auth.controller ghi new Date().toISOString()), không phải Timestamp — vẫn hiện đúng", async () => {
  reset(); seedUser("uA", { tagName: "an_nguyen", createdAt: "2026-03-04T05:06:07.000Z" });
  assert.equal((await call("GET", "/api/users/uA/extra-info")).body.fields.createdAt, "2026-03-04T05:06:07.000Z");
  const html = await ssr("/u/@an_nguyen");
  assert.match(html, /Tham gia từ [^<\n]*2026/);
  assert.ok(!html.includes("[object Object]"));
});

test("extra-info: bật mục nào thì mục đó MỚI xuất hiện (backend áp dụng, không chỉ ẩn ở giao diện); tắt lại là biến mất ngay", async () => {
  reset(); seedUser("uA", { birthday: "2000-01-31", gender: "female", status: "active" });
  await call("PUT", "/api/users/me/extras", "tA", { extras: { birthday: true, gender: true, status: true, uid: true } });
  const on = (await call("GET", "/api/users/uA/extra-info")).body;
  assert.equal(on.fields.birthday, "2000-01-31");
  assert.equal(on.fields.gender, "female");
  assert.equal(on.fields.status, "active");
  assert.equal(on.fields.uid, "uA");
  await call("PUT", "/api/users/me/extras", "tA", { extras: { birthday: false, gender: false, displayName: false, achievements: false } });
  const off = (await call("GET", "/api/users/uA/extra-info")).body;
  assert.ok(!("birthday" in off.fields) && !("gender" in off.fields) && !("displayName" in off.fields));
  assert.equal(off.achievements, null, "tắt thành tích => null, backend không tính/gửi");
  assert.ok(!JSON.stringify(off).includes("2000-01-31"));
  assert.equal(off.fields.uid, "uA", "mục khác giữ nguyên");
});

test("extra-info: mục bật nhưng hồ sơ không có/sai dữ liệu thì bỏ qua (không in null/undefined/giá trị lạ)", async () => {
  reset(); seedUser("uA", { birthday: "không-phải-ngày", gender: "alien", accountRole: undefined });
  await call("PUT", "/api/users/me/extras", "tA", { extras: { birthday: true, gender: true } });
  const r = (await call("GET", "/api/users/uA/extra-info")).body;
  assert.ok(!("birthday" in r.fields) && !("gender" in r.fields) && !("accountRole" in r.fields));
});

test("extra-info: người dùng không tồn tại / pending / đang xoá / hồ sơ ma / uid có '/' => 404; suspended vẫn xem được", async () => {
  reset();
  seedUser("uP", { status: "pending" }); seedUser("uD", { status: "deleting" }); seedUser("uG", { status: undefined }); seedUser("uS", { status: "suspended" });
  for (const uid of ["khongco", "uP", "uD", "uG", "a%2Fb"]) assert.equal((await call("GET", `/api/users/${uid}/extra-info`)).status, 404, uid);
  assert.equal((await call("GET", "/api/users/uS/extra-info")).status, 200);
});

// ============================================================ Thành tích (weeklyLeaderboards)
test("achievements: tổng hợp từ các tuần đã chốt — số lần top 10/top 3/hạng 1, tuần tốt nhất, tuần gần đây (mới nhất trước), bỏ dữ liệu hỏng", async () => {
  reset(); seedUser("uA", { accountScore: 321 });
  seedWeek("1.1.01.2026", [entry("uA", 1, 50), entry("uB", 2)]);
  seedWeek("2.2.01.2026", [entry("uB", 1), entry("uA", 3, 30)]);
  seedWeek("3.3.01.2026", [entry("uC", 1), entry("uA", 7, 5)]);
  seedWeek("4.4.01.2026", [entry("uC", 1)]);
  S["weeklyLeaderboards/hong"] = { weekCode: "hong" }; // thiếu top10 => bỏ qua, không làm sập
  S["weeklyLeaderboards/hong2"] = { weekCode: "9.9.09.2026", top10: [null, { uid: 5 }, { uid: "uA" }, { uid: "uA", rank: "1" }] };
  const a = await achievements.getUserAchievements("uA", { accountScore: 321 });
  assert.equal(a.accountScore, 321);
  assert.equal(a.weekly.weeksRecorded, 5, "4 tuần hợp lệ + 1 tuần có top10 nhưng toàn mục hỏng; tuần thiếu top10 không tính");
  assert.equal(a.weekly.top10Count, 3);
  assert.equal(a.weekly.top3Count, 2);
  assert.equal(a.weekly.firstPlaceCount, 1);
  assert.deepEqual(a.weekly.best, { weekCode: "1.1.01.2026", rank: 1, weeklyGrowth: 50 });
  assert.deepEqual(a.weekly.recent.map((w) => w.weekCode), ["3.3.01.2026", "2.2.01.2026", "1.1.01.2026"], "tuần mới nhất trước (theo số tuần, không theo thứ tự chuỗi)");
  const none = await achievements.getUserAchievements("uNoBody", {});
  assert.deepEqual(none.weekly, { weeksRecorded: 5, top10Count: 0, top3Count: 0, firstPlaceCount: 0, best: null, recent: [] });
  assert.equal(none.accountScore, 0);
});

test("achievements: sắp tuần theo SỐ (tuần 10 mới hơn tuần 9) và giới hạn số tuần liệt kê; có cache (không quét lại mỗi lần)", async () => {
  reset();
  for (let n = 1; n <= 12; n++) seedWeek(`${n}.1.01.2026`, [entry("uA", 4)]);
  const a = await achievements.getUserAchievements("uA");
  assert.equal(a.weekly.top10Count, 12);
  assert.equal(a.weekly.recent.length, PROFILE.ACHIEVEMENT_RECENT_WEEKS);
  assert.equal(a.weekly.recent[0].weekCode, "12.1.01.2026");
  assert.equal(a.weekly.recent[1].weekCode, "11.1.01.2026");
  assert.equal(achievements.weekNumber("10.2.03.2026") > achievements.weekNumber("9.1.03.2026"), true);
  assert.equal(achievements.weekNumber("abc"), 0);
  // cache: thêm tuần mới vào "database" — chưa thấy cho tới khi cache hết hạn/được xoá
  seedWeek("13.1.01.2026", [entry("uA", 1)]);
  assert.equal((await achievements.getUserAchievements("uA")).weekly.top10Count, 12, "còn trong cache");
  achievements.resetAchievementsCache();
  assert.equal((await achievements.getUserAchievements("uA")).weekly.top10Count, 13);
});

test("extra-info: thành tích đi kèm khi bật, lấy điểm tài khoản từ hồ sơ", async () => {
  reset(); seedUser("uA", { accountScore: 77 });
  seedWeek("5.1.02.2026", [entry("uA", 2, 12)]);
  const r = (await call("GET", "/api/users/uA/extra-info")).body;
  assert.equal(r.achievements.accountScore, 77);
  assert.equal(r.achievements.weekly.top10Count, 1);
  assert.equal(r.achievements.weekly.best.rank, 2);
});

// ============================================================ Khách ghé thăm
test("visit: cần đăng nhập; chủ hồ sơ không tồn tại/không công khai => 404 và KHÔNG tạo document; tự xem mình => bỏ qua", async () => {
  reset(); seedUser("uA"); seedUser("uB");
  assert.equal((await call("POST", "/api/users/uA/visit", null)).status, 401, "khách ẩn danh không để lại dấu");
  assert.equal((await call("POST", "/api/users/khongco/visit", "tB")).status, 404);
  seedUser("uP", { status: "pending" }); seedUser("uD", { status: "deleting" });
  assert.equal((await call("POST", "/api/users/uP/visit", "tB")).status, 404);
  assert.equal((await call("POST", "/api/users/uD/visit", "tB")).status, 404);
  assert.equal((await call("POST", "/api/users/a%2Fb/visit", "tB")).status, 404);
  const self = await call("POST", "/api/users/uA/visit", "tA");
  assert.equal(self.status, 200);
  assert.equal(self.body.recorded, false);
  assert.ok(!Object.keys(S).some((k) => k.startsWith("profileVisitors/")), "không có document nào được tạo");
});

test("visit: ghi người ghé; danh sách của chủ: mới nhất trước, KHÔNG TRÙNG (vào lại thì lên đầu), có tên/tag/huy hiệu/thời gian", async () => {
  reset();
  seedUser("uA"); seedUser("uB", { displayName: "Bình", accountGroup: "SA" }); seedUser("uC", { displayName: "Chi", accountRole: "pro_user" });
  assert.equal((await call("POST", "/api/users/uA/visit", "tB")).body.recorded, true);
  assert.equal((await call("POST", "/api/users/uA/visit", "tC")).body.recorded, true);
  let list = (await call("GET", "/api/users/me/visitors", "tA")).body;
  assert.deepEqual(list.visitors.map((v) => v.uid), ["uC", "uB"], "người ghé gần nhất trên cùng");
  assert.equal(list.max, 50);
  const b = list.visitors[1];
  assert.equal(b.displayName, "Bình");
  assert.equal(b.tagName, "@tag_ub");
  assert.ok(Array.isArray(b.badges) && b.badges.includes("sa"), "huy hiệu tài khoản");
  assert.match(b.visitedAt, /^\d{4}-\d{2}-\d{2}T/);
  assert.ok(!JSON.stringify(list).includes("@x.com"), "không lộ email của khách");

  // B vào lại (không còn đứng đầu) => lên đầu, KHÔNG nhân đôi
  assert.equal((await call("POST", "/api/users/uA/visit", "tB")).body.recorded, true);
  list = (await call("GET", "/api/users/me/visitors", "tA")).body;
  assert.deepEqual(list.visitors.map((v) => v.uid), ["uB", "uC"]);
  // B F5 ngay (đã đứng đầu, < VISIT_REFRESH_MS) => không ghi lại
  assert.equal((await call("POST", "/api/users/uA/visit", "tB")).body.recorded, false);
  assert.equal(S["profileVisitors/uA"].visitors.length, 2);
  assert.deepEqual(Object.keys(S["profileVisitors/uA"].visitors[0]).sort(), ["at", "uid"], "chỉ lưu uid + thời điểm — không nhân bản dữ liệu cá nhân");
});

test("visit (service): người đứng đầu vào lại SAU VISIT_REFRESH_MS thì được cập nhật thời gian; trước đó thì không", async () => {
  reset(); seedUser("uA"); seedUser("uB");
  const t0 = 1_800_000_000_000;
  assert.deepEqual(await visitors.recordVisit("uA", "uB", t0), { recorded: true });
  assert.deepEqual(await visitors.recordVisit("uA", "uB", t0 + PROFILE.VISIT_REFRESH_MS - 1), { recorded: false, reason: "recent" });
  assert.deepEqual(await visitors.recordVisit("uA", "uB", t0 + PROFILE.VISIT_REFRESH_MS), { recorded: true });
  assert.deepEqual(S["profileVisitors/uA"].visitors, [{ uid: "uB", at: t0 + PROFILE.VISIT_REFRESH_MS }]);
  assert.deepEqual(await visitors.recordVisit("uA", "uA", t0), { recorded: false, reason: "self" });
});

test("visit (service): chỉ giữ 50 người gần nhất — người cũ nhất bị loại, thứ tự mới → cũ", async () => {
  reset(); seedUser("uA");
  const t0 = 1_800_000_000_000;
  for (let i = 0; i < 60; i++) await visitors.recordVisit("uA", `v${i}`, t0 + i * 1000);
  const stored = S["profileVisitors/uA"].visitors;
  assert.equal(stored.length, PROFILE.VISITORS_MAX);
  assert.equal(stored[0].uid, "v59", "mới nhất đứng đầu");
  assert.equal(stored[49].uid, "v10", "v0..v9 đã bị loại");
  assert.equal(new Set(stored.map((e) => e.uid)).size, 50, "không trùng");
  // v10 (đang ở cuối) vào lại => lên đầu và vẫn đủ 50, không ai khác bị loại
  await visitors.recordVisit("uA", "v10", t0 + 99_000);
  const after = S["profileVisitors/uA"].visitors;
  assert.equal(after.length, 50);
  assert.equal(after[0].uid, "v10");
  assert.equal(after.filter((e) => e.uid === "v10").length, 1);
  assert.equal(after[49].uid, "v11");
});

test("visit (service): chủ hồ sơ đã bị xoá/đang xoá/pending/ma => không dựng lại document (không để lại dữ liệu mồ côi)", async () => {
  reset(); seedUser("uD", { status: "deleting" }); seedUser("uG", { status: undefined });
  for (const owner of ["uD", "uG", "khongco"]) {
    assert.deepEqual(await visitors.recordVisit(owner, "uB"), { recorded: false, reason: "owner-unavailable" }, owner);
    assert.equal(S[`profileVisitors/${owner}`], undefined);
  }
  assert.deepEqual(await visitors.recordVisit("a/b", "uB"), { recorded: false, reason: "owner-unavailable" }, "id lạ không chạm Firestore");
});

test("visitors: khách đã xoá tài khoản/hồ sơ ma/pending bị LỌC khi đọc; khách suspended vẫn hiện; dữ liệu hỏng không làm sập", async () => {
  reset(); seedUser("uA"); seedUser("uB"); seedUser("uS", { status: "suspended" }); seedUser("uP", { status: "pending" });
  S["profileVisitors/uA"] = {
    visitors: [{ uid: "uB", at: 5 }, { uid: "daXoa", at: 4 }, { uid: "uP", at: 3 }, { uid: "uS", at: 2 }, { uid: "uB", at: 1 }, null, { uid: "a/b", at: 1 }, { uid: "uS", at: "x" }, { at: 3 }],
  };
  const list = (await call("GET", "/api/users/me/visitors", "tA")).body.visitors;
  assert.deepEqual(list.map((v) => v.uid), ["uB", "uS"]);
  S["profileVisitors/uA"] = { visitors: "hỏng" };
  assert.deepEqual((await call("GET", "/api/users/me/visitors", "tA")).body.visitors, []);
});

test("visitors: CHỈ chủ hồ sơ xem — cần đăng nhập, uid lấy từ token (query/param không đổi được), người khác chỉ thấy danh sách của chính họ", async () => {
  reset(); seedUser("uA"); seedUser("uB"); seedUser("uC");
  await call("POST", "/api/users/uA/visit", "tB");
  assert.equal((await call("GET", "/api/users/me/visitors", null)).status, 401);
  const asC = await call("GET", "/api/users/me/visitors?uid=uA&owner=uA", "tC");
  assert.deepEqual(asC.body.visitors, [], "C không thấy khách của A dù cố chỉ định uid");
  assert.equal((await call("GET", "/api/users/me/visitors", "tA")).body.visitors.length, 1);
  // /:uid/visitors KHÔNG tồn tại: không có cách xem danh sách khách của người khác
  assert.equal((await call("GET", "/api/users/uA/visitors", "tC")).status, 404);
  assert.equal((await call("GET", "/api/users/uA", null)).body.user.visitors, undefined, "hồ sơ công khai không kèm khách ghé thăm");
  assert.equal((await call("GET", "/api/users/me/visitors", "tA")).headers.get("cache-control"), "no-store");
});

test("xoá tài khoản: bước residual xoá luôn danh sách khách ghé thăm của uid đó (không để lại dữ liệu mồ côi)", async () => {
  reset(); seedUser("uA");
  await visitors.recordVisit("uA", "uB");
  assert.ok(S["profileVisitors/uA"]);
  const { STEPS } = require("../src/services/accountDeletion");
  await STEPS.find((s) => s.name === "residual").run("uA");
  assert.equal(S["profileVisitors/uA"], undefined);
});

// ============================================================ Tab Blog
test("GET /:uid/blogs: chỉ blog ĐÃ XUẤT BẢN của CHÍNH người đó, mới nhất trước, đúng dạng thẻ, không có isPinned; ai cũng xem được", async () => {
  reset(); seedUser("uA", { accountGroup: "SA" }); seedUser("uB", { accountGroup: "SA" });
  seedBlog("b1", "uA", { createdAt: new Date("2026-03-01T00:00:00Z"), likeCount: 3 });
  seedBlog("b2", "uA", { createdAt: new Date("2026-05-01T00:00:00Z"), hashtags: ["#a"], hashtagsLower: ["#a"] });
  seedBlog("bNhap", "uA", { isPublished: false, title: "BẢN NHÁP BÍ MẬT", createdAt: new Date("2026-06-01T00:00:00Z") });
  seedBlog("bKhac", "uB", { title: "Blog người khác" });
  const r = await call("GET", "/api/users/uA/blogs");
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual(r.body.blogs.map((b) => b.id), ["b2", "b1"]);
  assert.equal(r.body.blogs[0].author.uid, "uA");
  assert.equal(r.body.blogs[1].likeCount, 3);
  assert.ok(r.body.blogs.every((b) => !("isPinned" in b)), "blog không ghim được");
  assert.ok(r.body.blogs.every((b) => b.myReaction === null && b.excerpt && b.createdAt));
  assert.ok(!JSON.stringify(r.body).includes("BẢN NHÁP") && !JSON.stringify(r.body).includes("người khác"));
  assert.equal(r.body.nextCursor, "b1");
});

test("GET /:uid/blogs: myReaction của người xem; cả chính tác giả cũng KHÔNG thấy bản nháp; người không tồn tại/pending => 404; cursor sai => 400", async () => {
  reset(); seedUser("uA", { accountGroup: "SA" }); seedUser("uB"); seedUser("uP", { status: "pending", accountGroup: "SA" });
  seedBlog("b1", "uA");
  seedBlog("bNhap", "uA", { isPublished: false });
  S["blogs/b1/reactions/uB"] = { type: "like" };
  const asB = await call("GET", "/api/users/uA/blogs", "tB");
  assert.equal(asB.body.blogs[0].myReaction, "like");
  const asOwner = await call("GET", "/api/users/uA/blogs", "tA");
  assert.deepEqual(asOwner.body.blogs.map((b) => b.id), ["b1"], "bản nháp không hiện ở hồ sơ, kể cả với chủ");
  assert.equal((await call("GET", "/api/users/khongco/blogs")).status, 404);
  assert.equal((await call("GET", "/api/users/uP/blogs")).status, 404);
  assert.equal((await call("GET", "/api/users/uA/blogs?cursor=a%2Fb")).status, 400);
  assert.equal((await call("GET", "/api/users/uA/blogs?cursor=bNhap")).status, 200, "cursor là blog nháp/khác tác giả không dùng được để dò, chỉ bị bỏ qua");
  const empty = (await call("GET", "/api/users/uB/blogs")).body;
  assert.deepEqual(empty, { blogs: [], nextCursor: null });
});

// ============================================================ SSR
test("SSR hồ sơ: hiện Tiểu sử (thoát HTML), mô tả meta + Person.description chứa bio", async () => {
  reset();
  seedUser("uA", { tagName: "an_nguyen", displayName: "An", bio: 'Dev <script>alert(1)</script>\nThích "cà phê" & mèo' });
  const html = await ssr("/u/@an_nguyen");
  assert.ok(!html.includes("<script>alert(1)</script>"), "bio không được thành thẻ script");
  assert.match(html, /<p class="profile-bio">Dev &lt;script&gt;alert\(1\)&lt;\/script&gt;\nThích &#34;cà phê&#34; &amp; mèo<\/p>/);
  const desc = html.match(/<meta name="description" content="([^"]*)"/)[1];
  assert.ok(desc.startsWith("Hồ sơ An (@an_nguyen) trên Twelve. Dev"), desc);
  assert.ok(desc.length <= 160);
  const person = jsonLdBlocks(html)[0].mainEntity;
  assert.equal(person.description, 'Dev <script>alert(1)</script> Thích "cà phê" & mèo', "JSON-LD là dữ liệu (an toàn nhờ safeJsonForScript), bio gộp 1 dòng");
  assert.ok(!html.includes("</script><script>alert"), "JSON-LD không thể thoát khỏi thẻ script");
});

test("SSR hồ sơ: tài khoản SA có mục 'Bài Blog' (chỉ blog đã xuất bản của họ) + ItemList; tài khoản thường thì KHÔNG dù có blog", async () => {
  reset();
  seedUser("uA", { tagName: "sa_user", accountGroup: "SA", displayName: "Quản" });
  seedUser("uB", { tagName: "ra_user", accountGroup: "RA" });
  seedBlog("b1", "uA", { title: "Blog công khai của SA" });
  seedBlog("bNhap", "uA", { title: "NHÁP CỦA SA", isPublished: false });
  seedBlog("bRA", "uB", { title: "Blog cũ của RA" });
  const sa = await ssr("/u/@sa_user");
  assert.match(sa, /<h2>Bài Blog<\/h2>/);
  assert.match(sa, /href="https:\/\/twelve\.example\/blog\/b1"[^>]*>Blog công khai của SA</);
  assert.ok(!sa.includes("NHÁP CỦA SA"));
  assert.ok(!sa.includes("Chưa có bài viết công khai"), "có blog thì không báo 'chưa có bài'");
  const blocks = jsonLdBlocks(sa);
  assert.deepEqual(blocks.map((b) => b["@type"]), ["ProfilePage", "BreadcrumbList", "ItemList"]);
  assert.equal(blocks[2].name, "Bài Blog của Quản");
  assert.equal(blocks[2].itemListElement[0].url, "https://twelve.example/blog/b1");
  assert.match(sa, /<meta name="robots" content="index/, "có nội dung (blog) => cho index dù chưa có bài thường");
  const ra = await ssr("/u/@ra_user");
  assert.ok(!ra.includes("Bài Blog") && !ra.includes("Blog cũ của RA"));
  assert.match(ra, /noindex/);
});

test("SSR hồ sơ: Thông tin mở rộng — chỉ mục không nhạy cảm; ngày sinh/giới tính/trạng thái/UID KHÔNG BAO GIỜ lên SSR dù đã bật", async () => {
  reset();
  seedUser("uA", { tagName: "an_nguyen", accountGroup: "SA", accountRole: "admin", birthday: "2000-01-31", gender: "female", profileExtras: { birthday: true, gender: true, status: true, uid: true } });
  const html = await ssr("/u/@an_nguyen");
  assert.match(html, /<dt>Nhóm tài khoản<\/dt>\s*<dd>Tài khoản cấp cao \(SA\)<\/dd>/);
  assert.match(html, /<dt>Vai trò<\/dt>\s*<dd>Quản trị viên<\/dd>/);
  assert.match(html, /Tham gia từ [^<\n]*2026/);
  for (const secret of ["2000-01-31", "31/01/2000", "female", "Giới tính", "Ngày sinh", "Trạng thái", "UID", "ua@x.com"]) assert.ok(!html.includes(secret), `SSR không in ${secret}`);
  assert.ok(!/>uA</.test(html), "UID không xuất hiện như một giá trị hiển thị");
});

test("SSR hồ sơ: công tắc ngày tham gia / nhóm / vai trò / tên được tôn trọng; tắt ngày tham gia => không 'Tham gia từ', không dateCreated", async () => {
  reset();
  seedUser("uA", { tagName: "an_nguyen", accountGroup: "SA", accountRole: "admin", profileExtras: { createdAt: false, accountRole: false, displayName: false } });
  const html = await ssr("/u/@an_nguyen");
  assert.ok(!html.includes("Tham gia từ"));
  assert.equal(jsonLdBlocks(html)[0].dateCreated, undefined);
  assert.ok(!html.includes("<dt>Vai trò</dt>") && !html.includes("<dt>Tên hiển thị</dt>"));
  assert.match(html, /<dt>Nhóm tài khoản<\/dt>/, "mục còn bật vẫn hiện");
  assert.ok(!html.includes("[object Object]"));
});

test("SSR hồ sơ: thành tích tuần hiện khi chủ bật + có thành tích; tắt thì không có; lỗi đọc thành tích không làm hỏng trang", async () => {
  reset();
  seedUser("uA", { tagName: "an_nguyen", accountScore: 120 });
  seedWeek("1.1.01.2026", [entry("uA", 1, 40)]);
  seedWeek("2.2.01.2026", [entry("uA", 3, 20)]);
  let html = await ssr("/u/@an_nguyen");
  assert.match(html, /<dt>Điểm tài khoản<\/dt>\s*<dd>120<\/dd>/);
  assert.match(html, /Vào top 10 tăng điểm 2 tuần \(1 lần hạng 1, 2 lần trong top 3\)/);
  assert.match(html, /Hạng 1 — tuần 1\.1\.01\.2026/);

  S["users/uA"].profileExtras = { achievements: false };
  html = await ssr("/u/@an_nguyen");
  assert.ok(!html.includes("Thành tích tuần") && !html.includes("Điểm tài khoản"));

  S["users/uA"].profileExtras = {};
  achievements.resetAchievementsCache();
  const realGet = fb.db.collection;
  fb.db.collection = (name) => {
    if (name === "weeklyLeaderboards") throw new Error("boom");
    return realGet(name);
  };
  try {
    const res = await fetch(base + "/u/@an_nguyen", { headers: BOT });
    assert.equal(res.status, 200, "lỗi phần phụ không làm 500 cả trang hồ sơ");
    assert.ok(!(await res.text()).includes("Thành tích tuần"));
  } finally {
    fb.db.collection = realGet;
  }
});

test("SSR hồ sơ: hồ sơ không có bio/blog/mở rộng vẫn render bình thường (không in 'undefined'/'null')", async () => {
  reset(); seedUser("uA", { tagName: "an_nguyen", profileExtras: { displayName: false, accountGroup: false, accountRole: false, createdAt: false, achievements: false } });
  const html = await ssr("/u/@an_nguyen");
  assert.ok(!html.includes('<p class="profile-bio"') && !html.includes('<dl class="profile-extra"'), "không in khối rỗng (tên lớp CSS vẫn nằm trong <style>)");
  assert.ok(!/undefined|>null</.test(html));
  assert.match(html, /Chưa có bài viết công khai/);
});

test("route: Tag Name trùng tên đường dẫn con MỚI (blogs, extra-info, visit, visitors) vẫn tra đúng hồ sơ, không bị route phụ nuốt", async () => {
  reset();
  seedUser("uA", { tagName: "blogs" }); seedUser("uB", { tagName: "extra_info" }); seedUser("uC", { tagName: "visitors" });
  assert.equal((await call("GET", "/api/users/by-tag/blogs")).body.user.uid, "uA");
  assert.equal((await call("GET", "/api/users/by-tag/extra_info")).body.user.uid, "uB");
  assert.equal((await call("GET", "/api/users/by-tag/visitors")).body.user.uid, "uC");
  // và đường dẫn con thật vẫn hoạt động theo uid
  assert.equal((await call("GET", "/api/users/uA/blogs")).status, 200);
  assert.equal((await call("GET", "/api/users/uA/extra-info")).status, 200);
});

// ============================================================ Hạ tầng
test("firestore.rules chặn hoàn toàn profileVisitors; module gỡ lỗi kiểm cả collection này", () => {
  const fs = require("node:fs");
  const rules = fs.readFileSync(path.join(__dirname, "../firestore.rules"), "utf8");
  assert.match(rules, /match \/profileVisitors\/\{uid\}\s*\{\s*allow read, write: if false;/);
  assert.match(fs.readFileSync(path.join(__dirname, "../src/debug/modules/rules-private-collections.js"), "utf8"), /"profileVisitors"/);
});
