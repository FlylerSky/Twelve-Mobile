// v2.5.3 — kiểm thử bản vá theo "Báo cáo bảo mật tổng hợp cuối v2.5.2" — ĐỢT 4: TW-08 (dọn pending theo lịch), TW-09 (route ghi của SA đòi nhập lại mật khẩu + nhật ký thay đổi),
// TW-14 (authorUid null/không hợp lệ không còn làm 500), TW-25 (updateMe một lần ghi; syncActivation có điều kiện trạng thái). Phần frontend (TW-11) nằm ở frontend/src/**/__tests__.
// Firestore/Auth GIẢ + Express thật; không cần mạng.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const http = require("node:http");
const express = require("express");

const { install } = require("./helpers/fakeFirebase");
const nowSec = () => Math.floor(Date.now() / 1000);
const fb = install({
  tokens: { tSA: "uSA", tSAold: "uSA", tU: "uU" },
  authTimes: { tSA: nowSec() - 10, tSAold: nowSec() - 3600, tU: nowSec() - 10 },
});
const S = fb.store;
const reset = () => Object.keys(S).forEach((k) => delete S[k]);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const mockRes = () => {
  const r = { statusCode: 200, body: null };
  r.status = (c) => ((r.statusCode = c), r);
  r.json = (b) => ((r.body = b), r);
  r.set = () => r;
  return r;
};
const seedUsers = () => {
  S["users/uSA"] = { uid: "uSA", displayName: "SA", tagName: "sa_user", status: "active", accountGroup: "SA", accountRole: "admin" };
  S["users/uU"] = { uid: "uU", displayName: "U", tagName: "plain_user", status: "active", accountGroup: "RA", accountRole: "user" };
};
require("../src/utils/asyncErrors").installAsyncErrorForwarding();

const day = 86400000;
const isoAgo = (d) => new Date(Date.now() - d * day).toISOString();
const pending = require("../src/services/pendingCleanup");
const withEnv = async (vars, fn) => {
  const old = {};
  for (const [k, v] of Object.entries(vars)) { old[k] = process.env[k]; if (v === undefined) delete process.env[k]; else process.env[k] = v; }
  try { return await fn(); } finally { for (const [k, v] of Object.entries(old)) { if (v === undefined) delete process.env[k]; else process.env[k] = v; } }
};
const quietLog = async (fn) => {
  const logs = [];
  const orig = { log: console.log, error: console.error };
  console.log = (...a) => logs.push(a.join(" "));
  console.error = (...a) => logs.push(a.join(" "));
  try { return { result: await fn(), logs }; } finally { console.log = orig.log; console.error = orig.error; }
};

// ============================================================ TW-08 — dọn pending theo lịch
test("TW-08: hạn mặc định 7 ngày (trước là 14), đổi được bằng PENDING_MAX_AGE_DAYS và bị kẹp 1–90; cấu hình sweeper có giá trị mặc định an toàn", async () => {
  await withEnv({ PENDING_MAX_AGE_DAYS: undefined, PENDING_SWEEPER: undefined, PENDING_SWEEP_INTERVAL_MIN: undefined, PENDING_SWEEP_MAX_PER_RUN: undefined }, () => {
    assert.equal(pending.pendingMaxAgeDays(), 7);
    assert.equal(pending.DEFAULT_MAX_AGE_DAYS, 7);
    assert.equal(pending.pendingSweeperEnabled(), true, "bật mặc định");
    assert.equal(pending.sweepIntervalMs(), 6 * 3600 * 1000);
    assert.equal(pending.sweepMaxPerRun(), 500);
  });
  await withEnv({ PENDING_MAX_AGE_DAYS: "3" }, () => assert.equal(pending.pendingMaxAgeDays(), 3));
  await withEnv({ PENDING_MAX_AGE_DAYS: "0" }, () => assert.equal(pending.pendingMaxAgeDays(), 1));
  await withEnv({ PENDING_MAX_AGE_DAYS: "9999" }, () => assert.equal(pending.pendingMaxAgeDays(), 90));
  await withEnv({ PENDING_MAX_AGE_DAYS: "abc" }, () => assert.equal(pending.pendingMaxAgeDays(), 7));
  await withEnv({ PENDING_SWEEP_INTERVAL_MIN: "1" }, () => assert.equal(pending.sweepIntervalMs(), 15 * 60 * 1000, "không cho quét dày hơn 15 phút"));
  await withEnv({ PENDING_SWEEP_MAX_PER_RUN: "999999" }, () => assert.equal(pending.sweepMaxPerRun(), 5000));
  await withEnv({ PENDING_SWEEPER: "OFF" }, () => assert.equal(pending.pendingSweeperEnabled(), false));
});

test("TW-08: ranh giới hạn — pending 8 ngày bị chọn, 6 ngày còn mới; đã xác minh email / thiếu ngày / không phải pending thì không đụng", async () => {
  reset();
  S["users/old8"] = { status: "pending", email: "a@x.com", tagName: "old8", createdAt: isoAgo(8) };
  S["users/young6"] = { status: "pending", email: "b@x.com", tagName: "young6", createdAt: isoAgo(6) };
  S["users/ver"] = { status: "pending", email: "c@x.com", tagName: "ver", createdAt: isoAgo(30) };
  S["users/nodate"] = { status: "pending", email: "d@x.com", tagName: "nodate" };
  S["users/act"] = { status: "active", email: "e@x.com", tagName: "act", createdAt: isoAgo(400) };
  fb.authUsers.set("old8", { uid: "old8", emailVerified: false });
  fb.authUsers.set("ver", { uid: "ver", emailVerified: true });
  const r = await pending.cleanupExpiredPending({ apply: false });
  assert.deepEqual(r.expired.map((e) => e.uid), ["old8"]);
  assert.deepEqual([r.skippedYoung, r.skippedVerified, r.skippedNoDate], [1, 1, 1]);
  assert.equal(r.truncated, false);
  // với hạn 14 ngày cũ thì old8 chưa bị chọn — chứng tỏ giá trị mặc định đã thật sự đổi
  const old = await pending.cleanupExpiredPending({ apply: false, maxAgeDays: 14 });
  assert.deepEqual(old.expired, []);
});

test("TW-08: quét THEO TRANG — pending cũ nằm sau hàng trăm hồ sơ mới vẫn được tìm thấy (trước: SCAN_LIMIT 2000 cứng che mất); chạm trần quét thì báo truncated", async () => {
  reset();
  for (let i = 0; i < 130; i++) S[`users/a${String(i).padStart(4, "0")}`] = { status: "pending", email: `y${i}@x.com`, tagName: `y${i}`, createdAt: isoAgo(1) };
  for (let i = 0; i < 5; i++) { S[`users/z${i}`] = { status: "pending", email: `o${i}@x.com`, tagName: `o${i}`, createdAt: isoAgo(20) }; fb.authUsers.set(`z${i}`, { uid: `z${i}`, emailVerified: false }); }
  const r = await pending.cleanupExpiredPending({ apply: false, pageSize: 50 });
  assert.equal(r.scanned, 135, "quét đủ qua nhiều trang, không bỏ sót/không lặp");
  assert.deepEqual(r.expired.map((e) => e.uid).sort(), ["z0", "z1", "z2", "z3", "z4"]);
  assert.equal(r.skippedYoung, 130);
  assert.equal(r.truncated, false);
  const capped = await pending.cleanupExpiredPending({ apply: false, pageSize: 50, maxScan: 100 });
  assert.equal(capped.scanned, 100);
  assert.equal(capped.truncated, true, "chạm trần quét phải báo để lượt sau tiếp tục");
  assert.equal(capped.expired.length, 0, "5 hồ sơ cũ nằm ngoài 100 hồ sơ đầu");
  assert.ok(pending.MAX_SCAN > 2000 && pending.PAGE_SIZE <= 500);
});

test("TW-08: sweepOnce xếp hàng xoá thật, có TRẦN số tài khoản mỗi lượt (PENDING_SWEEP_MAX_PER_RUN); lượt sau xử lý tiếp phần còn lại", async () => {
  reset(); seedUsers();
  for (let i = 0; i < 8; i++) { S[`users/p${i}`] = { status: "pending", email: `p${i}@x.com`, tagName: `p${i}`, createdAt: isoAgo(10) }; fb.authUsers.set(`p${i}`, { uid: `p${i}`, emailVerified: false }); }
  await withEnv({ PENDING_SWEEP_MAX_PER_RUN: "3" }, async () => {
    const { result: r1, logs } = await quietLog(() => pending.sweepOnce());
    assert.equal(r1.queued, 3);
    assert.equal(r1.truncated, true);
    assert.equal(Object.keys(S).filter((k) => k.startsWith("accountDeletions/")).length, 3);
    assert.equal(Object.values(S).filter((u) => u.status === "deleting").length, 3);
    assert.ok(logs.some((l) => /pending-sweeper/.test(l) && /còn nữa/.test(l)), "nhật ký nói rõ còn phần chưa xử lý");
    const r2 = (await quietLog(() => pending.sweepOnce())).result;
    assert.equal(r2.queued, 3, "lượt sau không xét lại các hồ sơ đã `deleting`");
    const r3 = (await quietLog(() => pending.sweepOnce())).result;
    assert.equal(r3.queued, 2);
    assert.equal(r3.truncated, false);
  });
  assert.equal(S["users/uSA"].status, "active", "tài khoản active không bị đụng");
});

test("TW-08: nhật ký của sweeper chỉ có SỐ LƯỢNG — không email, uid hay Tag Name", async () => {
  reset();
  S["users/secretUid123"] = { status: "pending", email: "victim.person@example.com", tagName: "secret_tag", createdAt: isoAgo(30) };
  fb.authUsers.set("secretUid123", { uid: "secretUid123", emailVerified: false });
  const { logs } = await quietLog(() => pending.sweepOnce());
  assert.ok(logs.length >= 1);
  const all = logs.join("\n");
  assert.ok(!/secretUid123|victim\.person|example\.com|secret_tag/.test(all), all);
});

test("TW-08: lỗi khi quét không làm sập tiến trình (sweepOnce nuốt lỗi + ghi log, không PII); hai lượt chồng nhau → lượt sau bị bỏ", async () => {
  reset();
  S["users/e1"] = { status: "pending", email: "e1@x.com", tagName: "e1", createdAt: isoAgo(30) };
  const origGetUser = fb.auth.getUser;
  fb.auth.getUser = async () => { throw Object.assign(new Error("boom: auth down"), { code: "auth/internal-error" }); };
  try {
    // (a) Firebase Auth lỗi: từ bản rà soát độc lập, lỗi riêng từng hồ sơ KHÔNG huỷ cả lượt — lượt vẫn hoàn tất, hồ sơ không chắc chắn thì không xoá.
    const { result } = await quietLog(() => pending.sweepOnce());
    assert.ok(result && result.skippedError === 1 && result.queued === 0, JSON.stringify(result));
  } finally { fb.auth.getUser = origGetUser; }
  assert.equal(S["users/e1"].status, "pending", "lỗi ⇒ không xoá gì");
  // (b) Firestore lỗi ở tầng quét: sweepOnce nuốt lỗi, trả null, log có nguyên nhân nhưng không PII.
  const origCol = fb.db.collection;
  fb.db.collection = (n, ...r) => { if (n === "users") throw new Error("boom: firestore down"); return origCol.call(fb.db, n, ...r); };
  try {
    const { result, logs } = await quietLog(() => pending.sweepOnce());
    assert.equal(result, null);
    assert.ok(logs.some((l) => /pending-sweeper\] lỗi/.test(l) && /firestore down/.test(l)));
    assert.ok(!logs.some((l) => /e1@x\.com/.test(l)), "log không chứa email");
  } finally { fb.db.collection = origCol; }

  // chồng lượt
  fb.authUsers.set("e1", { uid: "e1", emailVerified: false });
  // Giữ MỌI lời gọi getUser (quét + kiểm lại trước khi xoá đều gọi) cho tới khi `release()`; sau đó chạy bình thường.
  let held = true;
  const waiters = [];
  const release = () => { held = false; waiters.splice(0).forEach((f) => f()); };
  fb.auth.getUser = (...a) => (held ? new Promise((res) => waiters.push(() => res(origGetUser(...a)))) : origGetUser(...a));
  try {
    const first = quietLog(() => pending.sweepOnce());
    await sleep(30);
    const second = (await quietLog(() => pending.sweepOnce())).result;
    assert.equal(second, null, "đang chạy ⇒ không chạy chồng");
    release();
    assert.ok((await first).result);
  } finally { fb.auth.getUser = origGetUser; }
});

test("TW-08: startPendingSweeper — PENDING_SWEEPER=off tắt hẳn; bật thì tự chạy sau thời gian chờ và dừng được; timer không giữ tiến trình sống", async () => {
  reset();
  await withEnv({ PENDING_SWEEPER: "off" }, () => assert.equal(pending.startPendingSweeper({ bootDelayMs: 5 }), false));
  S["users/b1"] = { status: "pending", email: "b1@x.com", tagName: "b1", createdAt: isoAgo(30) };
  fb.authUsers.set("b1", { uid: "b1", emailVerified: false });
  await sleep(40);
  assert.equal(S["users/b1"].status, "pending", "đã tắt thì không tự chạy");
  await withEnv({ PENDING_SWEEPER: undefined }, async () => {
    assert.equal(pending.startPendingSweeper({ bootDelayMs: 10, intervalMs: 3600000 }), true);
    await quietLog(() => sleep(150));
    // quy trình xoá bền vững chạy nền: tới lúc kiểm tra hồ sơ hoặc đang `deleting` hoặc đã xoá xong — cả hai đều chứng tỏ sweeper đã tự xếp hàng
    assert.ok(!S["users/b1"] || S["users/b1"].status === "deleting", "sweeper tự xếp hàng xoá sau thời gian chờ");
    pending.stopPendingSweeper();
  });
  // server.js đã gắn sweeper (đọc mã nguồn: không bắt buộc khởi động server thật trong test)
  const server = fs.readFileSync(path.join(__dirname, "..", "server.js"), "utf8");
  assert.match(server, /pendingCleanup"\)\.startPendingSweeper\(\)/);
});

// ============================================================ TW-09 — route ghi của SA + nhật ký
const app = express();
app.use(express.json());
app.use("/api/admin", require("../src/routes/admin.routes"));
let server; let base;
test.before(async () => { server = http.createServer(app); await new Promise((r) => server.listen(0, "127.0.0.1", r)); base = `http://127.0.0.1:${server.address().port}`; });
test.after(() => server.close());
const call = async (method, url, token, body) => {
  const res = await fetch(base + url, { method, headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(body ? { "content-type": "application/json" } : {}) }, body: body ? JSON.stringify(body) : undefined });
  let b = null; try { b = await res.json(); } catch (_e) { /* không có thân */ }
  return { status: res.status, body: b };
};
const auditEntries = () => Object.entries(S).filter(([k]) => k.startsWith("configAudit/")).map(([, v]) => v).sort((a, b) => a.atMs - b.atMs || a.action.localeCompare(b.action));

test("TW-09: mọi route GHI của router admin đều đòi requireRecentAuth (kiểm cấu trúc router — thêm route ghi mới mà quên cổng này sẽ đỏ)", () => {
  const router = require("../src/routes/admin.routes");
  const rows = [];
  for (const layer of router.stack) {
    if (!layer.route) continue;
    const methods = Object.keys(layer.route.methods).filter((m) => layer.route.methods[m]);
    const writes = methods.filter((m) => m !== "get" && m !== "head");
    if (!writes.length) continue;
    const gated = layer.route.stack.some((h) => h.handle && h.handle.name === "recentAuthGate");
    rows.push({ route: `${writes.join(",").toUpperCase()} ${layer.route.path}`, gated });
  }
  assert.ok(rows.length >= 4, JSON.stringify(rows));
  assert.deepEqual(rows.filter((r) => !r.gated), [], "route ghi thiếu requireRecentAuth");
  for (const want of ["PUT /embed-domains", "PUT /fonts", "DELETE /csp-reports"]) assert.ok(rows.some((r) => r.route === want), want);
});

test("TW-09: PUT /embed-domains — phiên cũ 403 REAUTH_REQUIRED và KHÔNG ghi gì; phiên vừa xác thực 200, cấu hình + nhật ký ghi cùng lúc, diff đúng", async () => {
  reset(); seedUsers();
  const before = { ...S };
  const stale = await call("PUT", "/api/admin/embed-domains", "tSAold", { enabled: true, domains: [{ domain: "example.org" }] });
  assert.equal(stale.status, 403); assert.equal(stale.body.code, "REAUTH_REQUIRED");
  assert.deepEqual(S["config/embedDomains"], undefined);
  assert.equal(auditEntries().length, 0);
  assert.deepEqual(Object.keys(S).sort(), Object.keys(before).sort());

  const user = await call("PUT", "/api/admin/embed-domains", "tU", { enabled: true, domains: [] });
  assert.equal(user.status, 403); assert.notEqual(user.body.code, "REAUTH_REQUIRED", "không phải SA bị chặn ở bước quyền trước");

  const ok = await call("PUT", "/api/admin/embed-domains", "tSA", { enabled: true, domains: [{ domain: "example.org" }, { domain: "videos.example.net/path1" }] });
  assert.equal(ok.status, 200);
  assert.ok(S["config/embedDomains"]);
  let log = auditEntries();
  assert.equal(log.length, 1);
  assert.equal(log[0].action, "embed-domains.update");
  assert.equal(log[0].byUid, "uSA");
  assert.ok(Number.isFinite(log[0].atMs) && /^\d{4}-/.test(log[0].at));
  assert.ok(log[0].diff.domains.added.items.includes("example.org"));
  assert.ok(log[0].diff.domains.added.items.includes("videos.example.net/path1"));
  assert.equal(log[0].diff.domains.removed.count, 7, "7 domain mặc định bị bỏ so với cấu hình trước (mặc định)");

  await sleep(5);
  const second = await call("PUT", "/api/admin/embed-domains", "tSA", { enabled: false, domains: [{ domain: "example.org" }] });
  assert.equal(second.status, 200);
  log = auditEntries();
  assert.equal(log.length, 2, "mỗi lần sửa một mục — KHÔNG ghi đè mục trước");
  assert.deepEqual(log[1].diff.enabled, { from: true, to: false });
  assert.deepEqual(log[1].diff.domains.removed.items, ["videos.example.net/path1"]);
  assert.equal(log[1].diff.domains.added.count, 0);
  // Không lưu thứ nhạy cảm
  assert.ok(!/token|email|password|authorization/i.test(JSON.stringify(log)));
});

test("TW-09: PUT /fonts — phiên cũ 403; phiên mới 200 + nhật ký ghi font thêm/đổi nguồn/bỏ", async () => {
  reset(); seedUsers();
  const stale = await call("PUT", "/api/admin/fonts", "tSAold", { fonts: [{ label: "A", kind: "url", url: "https://cdn.example.com/a.woff2" }] });
  assert.equal(stale.status, 403); assert.equal(stale.body.code, "REAUTH_REQUIRED");
  assert.equal(S["config/fonts"], undefined);
  assert.equal(auditEntries().length, 0);

  const put1 = await call("PUT", "/api/admin/fonts", "tSA", { fonts: [{ label: "A", kind: "url", url: "https://cdn.example.com/a.woff2" }, { label: "B", kind: "url", url: "https://cdn.example.com/b.woff2" }] });
  assert.equal(put1.status, 200);
  const ids = put1.body.fonts.map((f) => f.id);
  await sleep(5);
  // đổi NGUỒN của font A (cùng id) sang máy chủ khác + bỏ font B + thêm C — đúng kịch bản "thêm font từ máy chủ ngoài" trong báo cáo
  const put2 = await call("PUT", "/api/admin/fonts", "tSA", { fonts: [{ id: ids[0], label: "A", kind: "url", url: "https://evil.example.org/a.woff2" }, { label: "C", kind: "url", url: "https://cdn.example.com/c.woff2" }] });
  assert.equal(put2.status, 200);
  const log = auditEntries();
  assert.equal(log.length, 2);
  assert.equal(log[1].action, "fonts.update");
  assert.equal(log[1].byUid, "uSA");
  assert.equal(log[1].diff.changed.count, 1);
  assert.match(log[1].diff.changed.items[0], /evil\.example\.org/, "đổi nguồn của font có sẵn phải lộ trong nhật ký");
  assert.equal(log[1].diff.removed.count, 1);
  assert.equal(log[1].diff.added.count, 1);
  // input xấu → 400, KHÔNG ghi nhật ký
  const bad = await call("PUT", "/api/admin/fonts", "tSA", { fonts: [{ label: "x", kind: "url", url: "http://insecure.example.com/a.woff2" }] });
  assert.equal(bad.status, 400);
  assert.equal(auditEntries().length, 2);
});

test("TW-09: DELETE /csp-reports — phiên cũ 403 và bảng không bị xoá; phiên mới ghi nhật ký TRƯỚC khi xoá; ghi nhật ký lỗi ⇒ 500 và KHÔNG xoá", async () => {
  reset(); seedUsers();
  const csp = require("../src/controllers/csp.controller");
  csp.__test.reset({}, { json() {} });
  csp.receiveCspReport({ body: { "csp-report": { "document-uri": "https://twelve.test/", "effective-directive": "script-src", "blocked-uri": "https://x.example/y.js" } }, ip: "198.51.100.7" }, { status() { return { end() {} }; } });
  assert.equal(csp.__test.entries.size, 1);

  const stale = await call("DELETE", "/api/admin/csp-reports", "tSAold");
  assert.equal(stale.status, 403); assert.equal(stale.body.code, "REAUTH_REQUIRED");
  assert.equal(csp.__test.entries.size, 1, "bằng chứng còn nguyên");

  const configAudit = require("../src/services/configAudit");
  const origRecord = configAudit.record;
  configAudit.record = async () => { throw new Error("firestore down"); };
  try {
    const { result: failed } = await quietLog(() => call("DELETE", "/api/admin/csp-reports", "tSA"));
    assert.equal(failed.status, 500);
    assert.equal(csp.__test.entries.size, 1, "không ghi được nhật ký ⇒ không xoá (không có thay đổi 'không để lại dấu')");
  } finally { configAudit.record = origRecord; }

  const ok = await call("DELETE", "/api/admin/csp-reports", "tSA");
  assert.equal(ok.status, 200); assert.deepEqual(ok.body, { ok: true });
  assert.equal(csp.__test.entries.size, 0);
  const log = auditEntries();
  assert.equal(log.length, 1);
  assert.equal(log[0].action, "csp-reports.reset");
  assert.equal(log[0].byUid, "uSA");
  assert.equal(log[0].diff.clearedKeys, 1);
  assert.equal(log[0].diff.clearedTotal, 1);
});

test("TW-09: route ĐỌC của SA không đổi (phiên cũ vẫn xem được); GET /config-audit chỉ SA, mới nhất trước, có giới hạn", async () => {
  reset(); seedUsers();
  for (let i = 0; i < 5; i++) S[`configAudit/e${i}`] = { v: 1, action: "fonts.update", byUid: "uSA", atMs: 1000 + i, at: new Date(1000 + i).toISOString(), diff: {} };
  assert.equal((await call("GET", "/api/admin/embed-domains", "tSAold")).status, 200);
  assert.equal((await call("GET", "/api/admin/fonts", "tSAold")).status, 200);
  assert.equal((await call("GET", "/api/admin/config-audit")).status, 401);
  assert.equal((await call("GET", "/api/admin/config-audit", "tU")).status, 403);
  const r = await call("GET", "/api/admin/config-audit?limit=3", "tSAold");
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.entries.map((e) => e.atMs), [1004, 1003, 1002]);
  const all = await call("GET", "/api/admin/config-audit?limit=abc", "tSA");
  assert.equal(all.body.entries.length, 5, "limit rác ⇒ mặc định 50");
});

test("TW-09: diff có giới hạn — danh sách dài bị cắt ở MAX_ITEMS, chuỗi bị cắt ở MAX_STR; rules chặn configAudit với Client SDK", () => {
  const { diffEmbedDomains, MAX_ITEMS, MAX_STR } = require("../src/services/configAudit");
  const many = Array.from({ length: 500 }, (_, i) => ({ domain: `d${i}.example.com`, path: "p".repeat(400) }));
  const d = diffEmbedDomains({ enabled: true, domains: [] }, { enabled: true, domains: many });
  assert.equal(d.domains.added.count, 500);
  assert.equal(d.domains.added.items.length, MAX_ITEMS);
  assert.ok(d.domains.added.items.every((s) => s.length <= MAX_STR));
  const rules = fs.readFileSync(path.join(__dirname, "..", "firestore.rules"), "utf8").replace(/\/\/[^\n]*/g, "");
  const header = "match /configAudit/{entryId} {";
  const i = rules.indexOf(header);
  assert.ok(i !== -1);
  assert.match(rules.slice(i + header.length, rules.indexOf("}", i + header.length)), /allow\s+read\s*,\s*write\s*:\s*if\s+false\s*;/);
});

// ============================================================ TW-14 — authorUid null/không hợp lệ
test("TW-14: attachAuthors — authorUid null/số/chuỗi có '/'/id dành riêng KHÔNG làm ném lỗi; tác giả hợp lệ vẫn được gắn", async () => {
  reset(); seedUsers();
  const { attachAuthors } = require("../src/utils/authors");
  const items = [{ id: 1, authorUid: "uSA" }, { id: 2, authorUid: null }, { id: 3, authorUid: undefined }, { id: 4, authorUid: 42 }, { id: 5, authorUid: "a/b" }, { id: 6, authorUid: ".." }, { id: 7, authorUid: "" }, { id: 8, authorUid: {} }, { id: 9, authorUid: "uU" }];
  const out = await attachAuthors(items);
  assert.equal(out.length, 9);
  assert.equal(out[0].author.uid, "uSA");
  assert.equal(out[8].author.uid, "uU");
  for (const i of [1, 2, 3, 4, 5, 6, 7]) assert.equal(out[i].author, null, `item ${items[i].id}`);
  assert.deepEqual(await attachAuthors([{ authorUid: null }]), [{ authorUid: null, author: null }]);
});

test("TW-14: listComments — một bình luận di trú có authorUid null không làm cả trang trả 500", async () => {
  reset(); seedUsers();
  S["posts/p1"] = { authorUid: "uSA", status: "published" };
  S["posts/p1/comments/c1"] = { id: "c1", authorUid: "uSA", content: "bình thường", createdAt: "2026-01-01T00:00:00.000Z" };
  S["posts/p1/comments/c2"] = { id: "c2", authorUid: null, content: "di trú", createdAt: "2026-01-02T00:00:00.000Z" };
  S["posts/p1/comments/c3"] = { id: "c3", authorUid: "x/y", content: "rác", createdAt: "2026-01-03T00:00:00.000Z" };
  const { listComments } = require("../src/controllers/comments.controller");
  const res = mockRes();
  await listComments("posts")({ params: { id: "p1" }, query: {} }, res);
  assert.equal(res.statusCode, 200, JSON.stringify(res.body));
  assert.equal(res.body.comments.length, 3);
  assert.equal(res.body.comments[0].author.uid, "uSA");
  assert.equal(res.body.comments[1].author, null);
  assert.equal(res.body.comments[2].author, null);
});

// ============================================================ TW-25
test("TW-25: updateMe — MỘT lần update (gồm isFirstLogin:false khi setup lần đầu); không đặt cờ khi không phải lần đầu", async () => {
  reset(); seedUsers();
  const { updateMe } = require("../src/controllers/users.controller");
  const writes = [];
  const origCollection = fb.db.collection;
  fb.db.collection = (c) => {
    const col = origCollection(c);
    const origDoc = col.doc;
    col.doc = (id) => { const ref = origDoc(id); const upd = ref.update; ref.update = async (d) => { writes.push({ path: ref.path, keys: Object.keys(d) }); return upd(d); }; return ref; };
    return col;
  };
  try {
    S["users/uFirst"] = { uid: "uFirst", status: "active", isFirstLogin: true, displayName: "Cũ" };
    let res = mockRes();
    await updateMe({ authUid: "uFirst", authUser: S["users/uFirst"], body: { displayName: "Mới", bio: "xin chào" } }, res);
    assert.equal(res.statusCode, 200);
    assert.equal(writes.length, 1, "đúng một lần ghi");
    assert.deepEqual(writes[0].keys.sort(), ["bio", "displayName", "isFirstLogin"]);
    assert.equal(S["users/uFirst"].isFirstLogin, false);
    assert.equal(S["users/uFirst"].displayName, "Mới");

    writes.length = 0;
    S["users/uOld"] = { uid: "uOld", status: "active", isFirstLogin: false, displayName: "Cũ" };
    res = mockRes();
    await updateMe({ authUid: "uOld", authUser: S["users/uOld"], body: { displayName: "Khác" } }, res);
    assert.equal(res.statusCode, 200);
    assert.deepEqual(writes.map((w) => w.keys), [["displayName"]]);

    writes.length = 0;
    res = mockRes();
    await updateMe({ authUid: "uOld", authUser: S["users/uOld"], body: {} }, res);
    assert.equal(res.statusCode, 400);
    assert.equal(writes.length, 0);
  } finally { fb.db.collection = origCollection; }
});

test("TW-25: syncActivation — chỉ chuyển pending → active; suspended/deleting/hồ sơ ma KHÔNG bị lật (kể cả khi req.authUser đã cũ — mô phỏng khoá tài khoản giữa middleware và lúc ghi)", async () => {
  reset();
  const { syncActivation } = require("../src/controllers/auth.controller");
  const run = async (uid, status) => {
    S[`users/${uid}`] = status === undefined ? { uid } : { uid, status };
    fb.authUsers.set(uid, { uid, emailVerified: true });
    const res = mockRes();
    // req.authUser mang trạng thái CŨ (pending) trong khi Firestore đã đổi — handler không được tin nó
    await syncActivation({ authUid: uid, authUser: { uid, status: "pending" } }, res);
    return res;
  };
  let r = await run("p1", "pending");
  assert.equal(r.statusCode, 200); assert.equal(r.body.status, "active"); assert.equal(S["users/p1"].status, "active");
  r = await run("a1", "active");
  assert.equal(r.statusCode, 200); assert.match(r.body.message, /đã active/);
  r = await run("s1", "suspended");
  assert.equal(r.statusCode, 403); assert.equal(r.body.code, "ACCOUNT_SUSPENDED"); assert.equal(S["users/s1"].status, "suspended");
  r = await run("d1", "deleting");
  assert.equal(r.statusCode, 403); assert.equal(r.body.code, "ACCOUNT_DELETING"); assert.equal(S["users/d1"].status, "deleting");
  r = await run("g1", undefined);
  assert.equal(r.statusCode, 403); assert.equal(S["users/g1"].status, undefined, "hồ sơ ma không bị kích hoạt");
  // chưa xác minh email → vẫn 400 như cũ
  S["users/n1"] = { uid: "n1", status: "pending" }; fb.authUsers.set("n1", { uid: "n1", emailVerified: false });
  const res = mockRes(); await syncActivation({ authUid: "n1", authUser: S["users/n1"] }, res);
  assert.equal(res.statusCode, 400); assert.equal(S["users/n1"].status, "pending");
  // hồ sơ không tồn tại → 404
  fb.authUsers.set("ghost", { uid: "ghost", emailVerified: true });
  const res404 = mockRes(); await syncActivation({ authUid: "ghost", authUser: {} }, res404);
  assert.equal(res404.statusCode, 404);
});

// ============================================================ Sau rà soát độc lập (v2.5.3): sweeper `pending` chặt hơn
const deletionSvc = require("../src/services/accountDeletion");
const withAuthGetUser = async (wrapper, fn) => {
  const orig = fb.auth.getUser;
  fb.auth.getUser = wrapper(orig);
  try { return await fn(); } finally { fb.auth.getUser = orig; }
};

test("rà soát: requestDeletion({onlyIfStatus}) — hồ sơ đã đổi trạng thái thì KHÔNG bị lật sang deleting và không có sổ xoá; đúng trạng thái thì xếp hàng; không tuỳ chọn = hành vi cũ", async () => {
  reset();
  S["users/uAct"] = { uid: "uAct", status: "active", email: "a@x.com", tagName: "uact" };
  S["users/uPen"] = { uid: "uPen", status: "pending", email: "b@x.com", tagName: "upen" };
  S["users/uOld"] = { uid: "uOld", status: "active", email: "c@x.com", tagName: "uold" };
  assert.equal(await deletionSvc.requestDeletion("uAct", { onlyIfStatus: "pending" }), false);
  assert.equal(S["users/uAct"].status, "active");
  assert.ok(!S["accountDeletions/uAct"], "không tạo sổ xoá cho hồ sơ đã active");
  assert.equal(await deletionSvc.requestDeletion("uPen", { onlyIfStatus: "pending" }), true);
  assert.ok(S["accountDeletions/uPen"] || !S["users/uPen"] || S["users/uPen"].status === "deleting", "đã xếp hàng (có thể đã xử lý xong ngay)");
  assert.equal(await deletionSvc.requestDeletion("uOld"), true, "không có tuỳ chọn = hành vi cũ (người dùng tự xoá tài khoản)");
  await sleep(50);
});

test("rà soát: RACE — người dùng được kích hoạt SAU khi sweeper kiểm lại xong và TRƯỚC transaction xếp hàng xoá ⇒ KHÔNG bị xoá (bản đầu của 2.5.3 sẽ lật active → deleting)", async () => {
  reset();
  S["users/racer"] = { uid: "racer", status: "pending", email: "r@x.com", tagName: "racer", createdAt: isoAgo(10) };
  fb.authUsers.set("racer", { uid: "racer", emailVerified: false });
  // Mô phỏng syncActivation chen vào đúng khe: ngay trước transaction đầu tiên của requestDeletion (sau khi mọi bước kiểm lại của sweeper đã qua).
  const origTx = fb.db.runTransaction;
  let flipped = 0;
  fb.db.runTransaction = (fn, ...rest) => { if (!flipped++) S["users/racer"].status = "active"; return origTx.call(fb.db, fn, ...rest); };
  let r;
  try { r = await quietLog(() => pending.cleanupExpiredPending({ apply: true })); } finally { fb.db.runTransaction = origTx; }
  assert.equal(flipped, 1, "transaction xếp hàng đã chạy đúng một lần");
  assert.equal(r.result.queued, 0);
  assert.equal(r.result.skippedLate, 1);
  assert.equal(S["users/racer"].status, "active");
  assert.ok(!S["accountDeletions/racer"]);
});

test("rà soát: createdAt không phải chuỗi ISO (năm trần '2020', số nhỏ, mili-giây, đối tượng Timestamp) bị BỎ QUA chứ không bị coi là 'rất cũ'; ISO hợp lệ vẫn được chọn", async () => {
  reset();
  S["users/iso8"] = { status: "pending", email: "a@x.com", tagName: "iso8", createdAt: isoAgo(8) };
  S["users/y2020"] = { status: "pending", email: "b@x.com", tagName: "y2020", createdAt: "2020" };
  S["users/n5"] = { status: "pending", email: "c@x.com", tagName: "n5", createdAt: 5 };
  S["users/ms"] = { status: "pending", email: "d@x.com", tagName: "ms", createdAt: 1700000000000 };
  S["users/ts"] = { status: "pending", email: "e@x.com", tagName: "ts", createdAt: { _seconds: 1700000000, _nanoseconds: 0 } };
  const r = await pending.cleanupExpiredPending({ apply: false });
  assert.deepEqual(r.expired.map((e) => e.uid), ["iso8"]);
  assert.equal(r.skippedNoDate, 4);
});

test("rà soát: lỗi Auth tạm thời với MỘT hồ sơ chỉ bỏ qua hồ sơ đó (không xoá, không huỷ cả lượt quét); hồ sơ khác vẫn được xử lý", async () => {
  reset();
  S["users/a1"] = { status: "pending", email: "a@x.com", tagName: "a1", createdAt: isoAgo(9) };
  S["users/a2"] = { status: "pending", email: "b@x.com", tagName: "a2", createdAt: isoAgo(9) };
  const r = await withAuthGetUser((orig) => async (uid) => {
    if (uid === "a1") throw Object.assign(new Error("quota exceeded"), { code: "auth/quota-exceeded" });
    return orig(uid);
  }, () => quietLog(() => pending.cleanupExpiredPending({ apply: true })));
  assert.deepEqual(r.result.expired.map((e) => e.uid), ["a2"]);
  assert.equal(r.result.skippedError, 1);
  assert.equal(S["users/a1"].status, "pending", "không chắc ⇒ không xoá");
  await sleep(50);
});
