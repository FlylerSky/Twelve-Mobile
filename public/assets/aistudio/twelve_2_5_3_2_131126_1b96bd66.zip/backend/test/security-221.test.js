// v2.2.1 — Hồi quy cho báo cáo kiểm tra bảo mật độc lập Twelve 2.2.0 (A-01 … A-06).
// Chạy: node --test test/security-221.test.js
// Dùng Firestore/Auth/Cloudinary GIẢ (test/helpers/fakeFirebase.js) — KHÔNG chạm dịch vụ thật. Firestore giả mô phỏng đúng SDK thật ở chỗ
// `doc("a/b")` ném lỗi đồng bộ (đây là gốc của A-01).
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const path = require("node:path");
const { spawn } = require("node:child_process");
const express = require("express");

const { install } = require("./helpers/fakeFirebase");
const nowSec = () => Math.floor(Date.now() / 1000);
const fb = install({
  tokens: { tA: "uA", tSA: "uSA", tB: "uB" },
  authTimes: { tA: nowSec() - 10, tSA: nowSec() - 10, tB: nowSec() - 10 },
});
const S = fb.store;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---- Cloudinary giả (đặt TRƯỚC khi nạp assets.service) ----
const cloudinaryPath = require.resolve(path.join(__dirname, "../src/config/cloudinary.js"));
require.cache[cloudinaryPath] = {
  id: cloudinaryPath, filename: cloudinaryPath, loaded: true,
  exports: {
    config: () => ({ cloud_name: "demo", api_key: "k", api_secret: "s" }),
    uploader: { destroy: async () => ({}) },
    api: { delete_resources_by_prefix: async () => ({}), delete_resources: async () => ({}) },
  },
};

// ---- "Giữ chân" request giữa middleware và bước ghi (mô phỏng request đã qua requireAuth nhưng chậm) ----
let gate = Promise.resolve();
const userPrivate = require("../src/services/userPrivate");
const origWriteRealName = userPrivate.writeRealName;
userPrivate.writeRealName = async (...a) => { await gate; return origWriteRealName(...a); };
const cp = require("../src/services/contentPipeline");
cp.processContentHtml = async () => { await gate; return { html: "<p>x</p>", excerpt: "x" }; };

const { installAsyncErrorForwarding, createRejectionGuard } = require("../src/utils/asyncErrors");
installAsyncErrorForwarding();

const deletion = require("../src/services/accountDeletion");
const { __test: D } = deletion;
const authCtrl = require("../src/controllers/auth.controller");
const limiters = require("../src/middleware/rateLimiters");

const app = express();
app.use(express.json());
app.use("/api/users", require("../src/routes/users.routes"));
app.use("/api/posts", require("../src/routes/posts.routes"));
app.use("/api/blogs", require("../src/routes/blog.routes"));
app.get("/__boom", async () => { throw new Error("boom từ handler async"); });
app.use((err, req, res, next) => { // giống error handler tập trung của server.js
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({ error: "Lỗi máy chủ nội bộ." });
});
let server; let base;
test.before(async () => { server = http.createServer(app); await new Promise((r) => server.listen(0, r)); base = `http://127.0.0.1:${server.address().port}`; });
test.after(() => server.close());

const call = async (method, url, token, body) => {
  const res = await fetch(base + url, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json = null;
  try { json = await res.json(); } catch (_e) { /* không có body */ }
  return { status: res.status, body: json };
};
// Gửi đường dẫn NGUYÊN VĂN (fetch/WHATWG URL tự gộp `%2E%2E` thành ".." và bỏ đoạn đường dẫn — sẽ che mất request thật).
const rawCall = (method, rawPath, token, body) => new Promise((resolve, reject) => {
  const payload = body === undefined ? null : JSON.stringify(body);
  const req = http.request({ host: "127.0.0.1", port: server.address().port, path: rawPath, method, headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(payload ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(payload) } : {}) } }, (res) => {
    let data = ""; res.on("data", (c) => (data += c)); res.on("end", () => resolve({ status: res.statusCode, body: data }));
  });
  req.on("error", reject);
  if (payload) req.write(payload);
  req.end();
});
const mockRes = () => { const r = { statusCode: 200, body: null, sentAt: null }; r.status = (c) => ((r.statusCode = c), r); r.json = (b) => ((r.body = b), (r.sentAt = Date.now()), r); return r; };

const seedUser = (uid, over = {}) => {
  S[`users/${uid}`] = { uid, displayName: `Tên ${uid}`, tagName: `tag_${uid.toLowerCase()}`, status: "active", accountGroup: "RA", accountRole: "user", country: "VN", email: `${uid.toLowerCase()}@x.com`, postsScoreSum: 0, positiveScore: 0, accountScore: 0, ...over };
  S[`tagNames/tag_${uid.toLowerCase()}`] = { uid };
};
const reset = () => {
  for (const uid of ["uA", "uB", "uSA"]) {
    limiters.sensitiveAccountLimiter.resetKey(`uid:${uid}`);
    limiters.accountDeleteLimiter.resetKey(`uid:${uid}`);
  }
  Object.keys(S).forEach((k) => delete S[k]);
  fb.authUsers.clear();
  gate = Promise.resolve();
  D.reset();
  D.CFG.VERIFY_DELAY_MS = 0;
  require("../src/middleware/auth").__test.clearRevokeCache();
};
const quiet = async (fn) => { const e = console.error; console.error = () => {}; try { return await fn(); } finally { console.error = e; } };

// =========================================================== A-01
test("A-01: isSafeDocId chỉ nhận id dạng uid/id tự sinh của Firestore", () => {
  const { isSafeDocId } = require("../src/utils/input");
  for (const ok of ["abc", "A1b2C3", "uid_ok-1", "x".repeat(128)]) assert.equal(isSafeDocId(ok), true, ok);
  for (const bad of ["a/b", "a/b/c", "..", ".", "", "__x__", "a b", "a%2Fb", "x".repeat(129), null, undefined, 5, {}, ["a"], "a\\b"]) assert.equal(isSafeDocId(bad), false, String(bad));
});

test("A-01: id chứa %2F (cả dạng 'a/b' lẻ lẫn 'a/b/c' trỏ vào tài liệu lồng nhau) => 404 ở MỌI route có :uid/:id/:commentId, không có 500, không sập", async () => {
  reset(); seedUser("uA", { displayName: "A" });
  S["posts/p1"] = { id: "p1", authorUid: "uA", title: "t", contentHtml: "<p>x</p>", likeCount: 0, dislikeCount: 0, commentCount: 0, viewCount: 0 };
  S["users/uA/positiveScoreLogs/l1"] = { delta: 1, secret: "audit" };
  const bad = ["a%2Fb", "a%2Fb%2Fc", "uA%2FpositiveScoreLogs%2Fl1", "%2E%2E", "__x__", "a%5Cb"];
  const routes = [
    ["GET", (x) => `/api/users/${x}`],
    ["GET", (x) => `/api/posts/${x}`],
    ["GET", (x) => `/api/blogs/${x}`],
    ["GET", (x) => `/api/posts/${x}/comments`],
    ["POST", (x) => `/api/posts/${x}/share`],
    ["POST", (x) => `/api/posts/${x}/react`, "tA"],
    ["PATCH", (x) => `/api/posts/p1/comments/${x}`, "tA"],
    ["DELETE", (x) => `/api/posts/p1/comments/${x}`, "tA"],
    ["PATCH", (x) => `/api/posts/${x}`, "tA"],
    ["DELETE", (x) => `/api/posts/${x}`, "tA"],
  ];
  for (const [method, mk, tok] of routes) {
    for (const x of bad) {
      const r = await rawCall(method, mk(x), tok, method === "GET" || method === "DELETE" ? undefined : { type: "like", content: "hi" });
      assert.equal(r.status, 404, `${method} ${mk(x)} => ${r.status}`);
    }
  }
  const ok = await call("GET", "/api/users/uA");
  assert.equal(ok.status, 200);
  assert.equal(ok.body.user.displayName, "A");
});

test("A-01: handler async ném lỗi => đi vào error handler (500) chứ KHÔNG thành unhandledRejection", async () => {
  let rejections = 0;
  const onRej = () => { rejections++; };
  process.on("unhandledRejection", onRej);
  try {
    const r = await quiet(() => call("GET", "/__boom"));
    await sleep(50);
    assert.equal(r.status, 500);
    assert.equal(rejections, 0, "không còn unhandledRejection do handler async");
  } finally { process.off("unhandledRejection", onRej); }
});

test("A-01: createRejectionGuard — lẻ tẻ chỉ ghi log, dồn dập vượt ngưỡng mới yêu cầu thoát", () => {
  let exited = 0; let t = 1000; const logs = [];
  const guard = createRejectionGuard({ limit: 3, windowMs: 1000, onExceed: () => exited++, log: (...a) => logs.push(a), now: () => t });
  guard(new Error("1")); guard(new Error("2")); guard(new Error("3"));
  assert.equal(exited, 0, "đúng ngưỡng vẫn chưa thoát");
  guard(new Error("4"));
  assert.equal(exited, 1, "vượt ngưỡng => thoát để process manager khởi động lại");
  t += 5000; exited = 0;
  guard(new Error("5"));
  assert.equal(exited, 0, "hết cửa sổ thời gian => đếm lại từ đầu");
  assert.ok(logs.length >= 5);
});

test("A-01: server.js THẬT — GET /api/users/a%2Fb trả 404 và tiến trình VẪN SỐNG (trước đây thoát với exit code 1)", async () => {
  const port = 19000 + Math.floor(Math.random() * 500);
  const child = spawn(process.execPath, ["-r", "./test/helpers/preload-fake.js", "server.js"], {
    cwd: path.join(__dirname, ".."),
    env: { ...process.env, PORT: String(port), NODE_ENV: "development", SANITIZE_WORKER: "off", CORS_ORIGIN: "" },
    stdio: "ignore",
  });
  let exitCode = null;
  child.on("exit", (c) => { exitCode = c; });
  const get = async (p) => { try { const r = await fetch(`http://127.0.0.1:${port}${p}`); return r.status; } catch (e) { return `ERR:${e.cause?.code || e.message}`; } };
  try {
    let up = false;
    for (let i = 0; i < 80 && !up; i++) { if ((await get("/health")) === 200) up = true; else await sleep(100); }
    assert.ok(up, "server khởi động được với Firestore giả");
    assert.equal(await get("/api/users/a%2Fb"), 404);
    assert.equal(await get("/api/users/a%2Fb%2Fc"), 404);
    assert.equal(await get("/post/a%2Fb"), 404);
    assert.equal(await get("/u/a%2Fb"), 404);
    await sleep(300);
    assert.equal(exitCode, null, "tiến trình không được thoát");
    assert.equal(await get("/health"), 200, "dịch vụ vẫn phục vụ bình thường sau các request độc hại");
  } finally { child.kill(); }
});

// =========================================================== A-02
test("A-02 / T-220-01: PUT real-name đã qua middleware nhưng xoá tài khoản chạy xong trước lúc ghi => 403, KHÔNG dựng lại userPrivate", async () => {
  reset(); seedUser("uA"); S["userPrivate/uA"] = { fullName: "Nguyễn Văn A" }; fb.authUsers.set("uA", { uid: "uA", email: "ua@x.com" });
  let release; gate = new Promise((r) => (release = r));
  const pending = call("PUT", "/api/users/me/real-name", "tA", { fullName: "TEN-MUON" });
  await sleep(80);
  await deletion.requestDeletion("uA");
  await D.processOne("uA");
  assert.equal(S["users/uA"], undefined);
  assert.equal(S["userPrivate/uA"], undefined);
  release(); gate = Promise.resolve();
  const r = await quiet(() => pending);
  assert.equal(r.status, 403);
  assert.equal(r.body.code, "ACCOUNT_NOT_ACTIVE");
  assert.equal(S["userPrivate/uA"], undefined, "tên thật không được dựng lại sau khi xoá");
  assert.equal(S["users/uA"], undefined);
});

test("A-02: tài khoản đang `deleting` (chưa xoá xong hồ sơ) cũng không ghi được tên thật", async () => {
  reset(); seedUser("uA", { status: "deleting" });
  await assert.rejects(() => origWriteRealName("uA", "X"), (e) => e.code === "ACCOUNT_NOT_ACTIVE");
  assert.equal(S["userPrivate/uA"], undefined);
});

test("A-02: ghi tên thật bình thường vẫn chạy (và dọn fullName cũ trong users/{uid})", async () => {
  reset(); seedUser("uA", { fullName: "Cũ Legacy" });
  const r = await call("PUT", "/api/users/me/real-name", "tA", { fullName: "Tên Mới" });
  assert.equal(r.status, 200);
  assert.equal(S["userPrivate/uA"].fullName, "Tên Mới");
  assert.equal(S["users/uA"].fullName, undefined);
});

test("A-02 / PoC-2: POST /api/posts bị kẹt rồi xoá tài khoản xong => 403, không có bài mồ côi, không có hồ sơ 'ma', trang công khai 404", async () => {
  reset(); seedUser("uA"); fb.authUsers.set("uA", { uid: "uA", email: "ua@x.com" });
  let release; gate = new Promise((r) => (release = r));
  const pending = call("POST", "/api/posts", "tA", { title: "Bài đăng muộn", contentHtml: "<p>x</p>" });
  await sleep(80);
  await deletion.requestDeletion("uA");
  await D.processOne("uA");
  release(); gate = Promise.resolve();
  const r = await quiet(() => pending);
  assert.equal(r.status, 403);
  assert.deepEqual(Object.keys(S).filter((k) => /^posts\/[^/]+$/.test(k)), [], "không còn bài của tài khoản đã xoá");
  assert.equal(S["users/uA"], undefined, "không dựng lại hồ sơ ma");
  assert.equal((await call("GET", "/api/users/uA")).status, 404);
});

test("A-02: đăng bài bình thường vẫn chạy: bài được tạo + cộng 1 điểm tích cực + log", async () => {
  reset(); seedUser("uA");
  const r = await call("POST", "/api/posts", "tA", { title: "Bài thường", contentHtml: "<p>x</p>" });
  assert.equal(r.status, 201);
  assert.ok(S[`posts/${r.body.postId}`]);
  assert.equal(S["users/uA"].positiveScore, 1);
  assert.ok(Object.keys(S).some((k) => k.startsWith("users/uA/positiveScoreLogs/")));
});

test("A-02: react / addComment của người đã bị xoá (token còn hạn) => 403, không dựng hồ sơ ma", async () => {
  reset(); seedUser("uB");
  S["posts/p1"] = { id: "p1", authorUid: "uB", title: "t", contentHtml: "<p>x</p>", likeCount: 0, dislikeCount: 0, commentCount: 0, viewCount: 0, externalPostScore: 0 };
  const { react } = require("../src/controllers/reactions.controller");
  const comments = require("../src/controllers/comments.controller");
  // uGone: không có hồ sơ (đã xoá) nhưng request đã qua middleware
  const r1 = mockRes();
  await quiet(() => react("posts")({ authUid: "uGone", body: { type: "like" }, params: { id: "p1" }, authUser: {} }, r1));
  assert.equal(r1.statusCode, 403);
  const r2 = mockRes();
  await quiet(() => comments.addComment("posts")({ authUid: "uGone", body: { content: "hi" }, params: { id: "p1" }, authUser: {} }, r2));
  assert.equal(r2.statusCode, 403);
  assert.equal(S["users/uGone"], undefined);
  assert.equal(S["posts/p1"].likeCount, 0);
  assert.ok(!Object.keys(S).some((k) => k.includes("/comments/") || k.includes("/reactions/")));
  // người dùng còn active thì bình thường
  seedUser("uA");
  const r3 = mockRes();
  await react("posts")({ authUid: "uA", body: { type: "like" }, params: { id: "p1" }, authUser: {} }, r3);
  assert.equal(r3.statusCode, 200);
  assert.equal(S["users/uA"].positiveScore, 1);
});

test("A-02: SA xoá bình luận (còn lại có chủ đích) của tài khoản ĐÃ XOÁ => xoá được, KHÔNG dựng lại hồ sơ ma của người đó; tác giả còn sống vẫn bị trừ điểm", async () => {
  reset(); seedUser("uB"); seedUser("uSA", { accountGroup: "SA" }); seedUser("uA", { positiveScore: 5, accountScore: 5 });
  S["posts/p1"] = { id: "p1", authorUid: "uB", title: "t", contentHtml: "<p>x</p>", likeCount: 0, dislikeCount: 0, commentCount: 2, viewCount: 0, externalPostScore: 6 };
  S["posts/p1/comments/cGone"] = { id: "cGone", authorUid: "uGone", content: "bình luận của người đã xoá", scored: true };
  S["posts/p1/comments/cA"] = { id: "cA", authorUid: "uA", content: "bình luận còn sống", scored: true };
  const { deleteComment } = require("../src/controllers/comments.controller");
  const del = async (cid) => { const res = mockRes(); await deleteComment("posts")({ authUid: "uSA", authUser: { accountGroup: "SA" }, params: { id: "p1", commentId: cid } }, res); return res; };
  const r1 = await del("cGone");
  assert.equal(r1.statusCode, 200);
  assert.equal(S["posts/p1/comments/cGone"], undefined);
  assert.equal(S["users/uGone"], undefined, "không dựng lại hồ sơ ma");
  assert.ok(!Object.keys(S).some((k) => k.startsWith("users/uGone/")), "không để log điểm mồ côi");
  const r2 = await del("cA");
  assert.equal(r2.statusCode, 200);
  assert.equal(S["users/uA"].positiveScore, 4, "tác giả còn sống vẫn bị trừ 1 điểm như trước");
});

test("A-02: hồ sơ 'ma' (chỉ có điểm số, không có status) không hiện thành trang công khai '@undefined' và không được gắn làm tác giả", async () => {
  reset(); seedUser("uB");
  S["users/uGhost"] = { positiveScore: -1, accountScore: -1 };
  assert.equal((await call("GET", "/api/users/uGhost")).status, 404);
  const { attachAuthors } = require("../src/utils/authors");
  const out = await attachAuthors([{ id: "1", authorUid: "uGhost" }, { id: "2", authorUid: "uB" }]);
  assert.equal(out[0].author, null);
  assert.equal(out[1].author.uid, "uB");
});

test("A-02: bước VERIFY — hồ sơ vừa xoá chưa dọn sổ ngay; ghi muộn (userPrivate + hồ sơ ma + bài mồ côi) bị dọn khi tới hạn rồi sổ mới được xoá", async () => {
  reset(); seedUser("uA"); fb.authUsers.set("uA", { uid: "uA", email: "ua@x.com" });
  S["userPrivate/uA"] = { fullName: "A" };
  D.CFG.VERIFY_DELAY_MS = 60 * 1000;
  await deletion.requestDeletion("uA");
  const done = await D.processOne("uA");
  assert.equal(done, false, "chưa hoàn tất: đang chờ cửa sổ verify");
  assert.equal(S["users/uA"], undefined);
  const ledger = S["accountDeletions/uA"];
  assert.ok(ledger, "sổ theo dõi còn đó");
  assert.equal(ledger.status, "waiting_verify");
  assert.equal(ledger.step, "verify");
  assert.ok(ledger.nextAttemptAtMs > Date.now() + 30 * 1000);
  assert.equal(ledger.leaseOwner, null);

  // Ghi muộn từ request bị kẹt:
  S["userPrivate/uA"] = { fullName: "TEN-MUON" };
  S["users/uA"] = { positiveScore: 1, accountScore: 1 };
  S["users/uA/positiveScoreLogs/l1"] = { delta: 1 };
  S["posts/late1"] = { id: "late1", authorUid: "uA", title: "muộn" };

  // Chưa tới hạn: processOne lại vẫn chỉ chờ (không verify sớm)
  assert.equal(await D.processOne("uA"), false);
  assert.ok(S["userPrivate/uA"], "chưa tới hạn thì chưa dọn");

  // Tới hạn:
  S["accountDeletions/uA"].verifyAfterMs = Date.now() - 1; S["accountDeletions/uA"].nextAttemptAtMs = 0;
  assert.equal(await D.processOne("uA"), true);
  assert.equal(S["userPrivate/uA"], undefined);
  assert.equal(S["users/uA"], undefined);
  assert.ok(!Object.keys(S).some((k) => k.startsWith("users/uA/")), "subcollection của hồ sơ ma cũng bị dọn");
  assert.equal(S["posts/late1"], undefined);
  assert.equal(S["accountDeletions/uA"], undefined, "xong hết mới xoá sổ");
});

test("A-02: verify sạch (không có gì bị ghi muộn) => hoàn tất ngay khi tới hạn, không rewind", async () => {
  reset(); seedUser("uA"); fb.authUsers.set("uA", { uid: "uA", email: "ua@x.com" });
  D.CFG.VERIFY_DELAY_MS = 60 * 1000;
  await deletion.requestDeletion("uA");
  await D.processOne("uA");
  S["accountDeletions/uA"].verifyAfterMs = Date.now() - 1; S["accountDeletions/uA"].nextAttemptAtMs = 0;
  assert.equal(await D.processOne("uA"), true);
  assert.equal(S["accountDeletions/uA"], undefined);
});

test("A-02: scripts — quét hồ sơ ma / userPrivate mồ côi chỉ đụng thứ đúng là rác (dry-run mặc định)", async () => {
  reset();
  const realGetUser = fb.auth.getUser;
  fb.auth.getUser = async (uid) => { if (fb.authUsers.has(uid)) return fb.authUsers.get(uid); throw Object.assign(new Error("nf"), { code: "auth/user-not-found" }); };
  try {
    seedUser("uLive"); fb.authUsers.set("uLive", { uid: "uLive" });
    S["userPrivate/uLive"] = { fullName: "Người thật" };
    S["users/uGhost"] = { positiveScore: -1, accountScore: -1 };
    S["users/uGhost/positiveScoreLogs/l1"] = { delta: -1 };
    S["userPrivate/uGhost"] = { fullName: "ma" };
    S["userPrivate/uStray"] = { fullName: "mồ côi" };
    S["users/uAuthStill"] = { positiveScore: 1 }; fb.authUsers.set("uAuthStill", { uid: "uAuthStill" }); // còn tài khoản Auth => KHÔNG phải ma
    const { purgeGhosts } = require("../src/services/ghostCleanup");
    const dry = await purgeGhosts({ apply: false });
    assert.deepEqual(dry.ghostProfiles.map((g) => g.uid), ["uGhost"]);
    assert.deepEqual(dry.strayPrivate.map((g) => g.uid).sort(), ["uGhost", "uStray"]);
    assert.equal(dry.deleted, 0);
    assert.ok(S["users/uGhost"], "dry-run không xoá gì");
    const run = await purgeGhosts({ apply: true });
    assert.equal(run.deleted, 3);
    assert.equal(S["users/uGhost"], undefined);
    assert.ok(!Object.keys(S).some((k) => k.startsWith("users/uGhost/")));
    assert.equal(S["userPrivate/uStray"], undefined);
    assert.ok(S["users/uLive"] && S["userPrivate/uLive"] && S["users/uAuthStill"], "người thật và tài khoản còn Auth không bị đụng");
  } finally { fb.auth.getUser = realGetUser; }
});

// =========================================================== A-03
test("A-03: quên mật khẩu — trả lời NGAY, cùng mã/cùng nội dung/cùng thời gian cho email có/không có tài khoản, kể cả khi Firebase chậm hoặc lỗi", async () => {
  reset();
  process.env.FIREBASE_WEB_API_KEY = "demo-key";
  authCtrl.__test.forgotByEmail.clear();
  S["users/uF"] = { uid: "uF", status: "active" };
  fb.authUsers.set("uF", { uid: "uF", email: "real@example.org" });
  let outbound = 0; let mode = "ok";
  const realFetch = global.fetch;
  global.fetch = async (url) => {
    if (!String(url).includes("identitytoolkit")) return realFetch(url);
    outbound++; await sleep(250); // độ trễ mạng tới Firebase
    return mode === "ok" ? { ok: true, status: 200, json: async () => ({}) } : { ok: false, status: 400, json: async () => ({ error: { message: "TOO_MANY_ATTEMPTS_TRY_LATER" } }) };
  };
  const run = async (email) => {
    const res = mockRes();
    const t0 = Date.now();
    const finished = authCtrl.forgotPassword({ body: { email }, headers: {} }, res);
    await sleep(0);
    const answeredAfter = res.sentAt ? res.sentAt - t0 : Infinity;
    await finished; // chờ nốt phần việc nền để kiểm tra tác dụng phụ
    return { ms: answeredAfter, code: res.statusCode, msg: res.body && (res.body.message || res.body.error) };
  };
  try {
    const known = await run("real@example.org");
    const unknown = await run("nobody@example.org");
    assert.equal(known.code, 200); assert.equal(unknown.code, 200);
    assert.equal(known.msg, unknown.msg);
    assert.ok(known.ms < 100 && unknown.ms < 100, `phản hồi phải tức thì (có TK: ${known.ms} ms, không có: ${unknown.ms} ms)`);
    assert.equal(outbound, 1, "chỉ email có tài khoản mới thật sự gọi Firebase (ở nền)");
    mode = "err";
    fb.authUsers.set("uF2", { uid: "uF2", email: "real2@example.org" }); S["users/uF2"] = { uid: "uF2", status: "active" };
    const known2 = await quiet(() => run("real2@example.org"));
    const unknown2 = await run("nobody2@example.org");
    assert.equal(known2.code, 200, "Firebase lỗi/quá tải không còn lộ qua mã 429/502");
    assert.equal(unknown2.code, 200);
    assert.equal(known2.msg, unknown2.msg);
    // lỗi cấu hình (không phụ thuộc email) vẫn 503
    delete process.env.FIREBASE_WEB_API_KEY;
    const res = mockRes(); await authCtrl.forgotPassword({ body: { email: "real@example.org" }, headers: {} }, res);
    assert.equal(res.statusCode, 503);
  } finally { global.fetch = realFetch; delete process.env.FIREBASE_WEB_API_KEY; }
});

// =========================================================== A-04
test("A-04: Tag Name dành riêng — chặn cả biến thể (gạch dưới, số đuôi), không chặn tên bình thường", () => {
  const { isReservedTagName, isValidTagName } = require("../src/utils/helpers");
  for (const t of ["admin", "twelve", "support", "moderator", "official", "security", "@Admin", "admin_", "_admin", "admin2", "twelve_support", "tw_elve", "support24", "administrator_vn"]) {
    assert.equal(isReservedTagName(t), true, t);
    assert.equal(isValidTagName(t), true, `${t} vẫn đúng ĐỊNH DẠNG (chỉ bị chặn vì dành riêng)`);
  }
  for (const t of ["minh_anh", "twelvefan_vn", "an", "nguyen123", "adminton", "helpful"]) assert.equal(isReservedTagName(t), false, t);
  process.env.RESERVED_TAG_NAMES_EXTRA = "ceo, Founder_";
  try { assert.equal(isReservedTagName("founder"), true); assert.equal(isReservedTagName("ceo7"), true); } finally { delete process.env.RESERVED_TAG_NAMES_EXTRA; }
  assert.equal(isReservedTagName("founder"), false);
});

test("A-04: đăng ký / check-tagname / đổi tag đều chặn tag dành riêng (SA được đặt)", async () => {
  reset(); seedUser("uA"); seedUser("uSA", { accountGroup: "SA" });
  // check-tagname
  const chk = mockRes(); await authCtrl.checkTagName({ query: { tag: "admin" } }, chk);
  assert.deepEqual(chk.body, { available: false, reserved: true });
  const chk2 = mockRes(); await authCtrl.checkTagName({ query: { tag: "ten_la_doi" } }, chk2);
  assert.equal(chk2.body.available, true);
  // đăng ký
  const reg = mockRes();
  await authCtrl.register({ body: { fullName: "N", displayName: "D", tagName: "Twelve_Support", birthday: "2000-01-01", gender: "male", country: "VN", email: "new@x.com", password: "12345678" } }, reg);
  assert.equal(reg.statusCode, 409);
  assert.equal(fb.authUsers.size, 0, "chặn TRƯỚC khi tạo tài khoản Firebase Auth");
  // đổi tag
  const a = await call("PUT", "/api/users/me/tag-name", "tA", { tagName: "admin" });
  assert.equal(a.status, 409);
  assert.equal(S["users/uA"].tagName, "tag_ua", "không đổi");
  const okTag = await call("PUT", "/api/users/me/tag-name", "tA", { tagName: "minh_anh" });
  assert.equal(okTag.status, 200);
  const sa = await call("PUT", "/api/users/me/tag-name", "tSA", { tagName: "admin" });
  assert.equal(sa.status, 200, "SA được đặt tag dành riêng");
  assert.equal(S["users/uSA"].tagName, "admin");
});

test("A-04: dọn tài khoản pending quá hạn — chỉ chọn pending cũ, chưa xác minh email; đã xác minh/còn mới/đang hoạt động bị bỏ qua; dry-run không xoá", async () => {
  reset();
  const day = 86400000; const iso = (d) => new Date(Date.now() - d * day).toISOString();
  S["users/pOld"] = { uid: "pOld", status: "pending", email: "old@x.com", tagName: "pold", createdAt: iso(30) };
  S["users/pVerified"] = { uid: "pVerified", status: "pending", email: "v@x.com", tagName: "pver", createdAt: iso(30) };
  S["users/pYoung"] = { uid: "pYoung", status: "pending", email: "y@x.com", tagName: "pyoung", createdAt: iso(2) };
  S["users/pNoDate"] = { uid: "pNoDate", status: "pending", email: "n@x.com", tagName: "pnodate" };
  S["users/aOld"] = { uid: "aOld", status: "active", email: "a@x.com", tagName: "aold", createdAt: iso(300) };
  S["tagNames/pold"] = { uid: "pOld" };
  fb.authUsers.set("pOld", { uid: "pOld", email: "old@x.com", emailVerified: false });
  fb.authUsers.set("pVerified", { uid: "pVerified", email: "v@x.com", emailVerified: true });
  const { cleanupExpiredPending } = require("../src/services/pendingCleanup");
  const dry = await cleanupExpiredPending({ apply: false });
  assert.deepEqual(dry.expired.map((e) => e.uid), ["pOld"]);
  assert.deepEqual([dry.skippedVerified, dry.skippedYoung, dry.skippedNoDate], [1, 1, 1]);
  assert.equal(S["users/pOld"].status, "pending", "dry-run không đụng gì");
  assert.equal(S["accountDeletions/pOld"], undefined);
  const run = await cleanupExpiredPending({ apply: true });
  assert.equal(run.queued, 1);
  assert.equal(S["users/pOld"].status, "deleting");
  assert.ok(S["accountDeletions/pOld"]);
  assert.equal(S["users/pVerified"].status, "pending");
  assert.equal(S["users/aOld"].status, "active");
  // quy trình xoá bền vững lo phần còn lại (giải phóng tag + tài khoản Auth)
  await D.processOne("pOld");
  assert.equal(S["tagNames/pold"], undefined);
  assert.equal(S["users/pOld"], undefined);
  assert.equal(fb.authUsers.has("pOld"), false);
});

// =========================================================== A-05
test("A-05: bơm báo cáo CSP nhiễu KHÔNG đẩy được vi phạm thật ra khỏi bảng; họ script-src có chỗ dự trữ; có bộ đếm tràn", async () => {
  const csp = require("../src/controllers/csp.controller");
  csp.__test.reset({}, { json() {} });
  // v2.2.2: mỗi nguồn gửi (IP) chỉ tạo tối đa 10 khoá mới, nên để làm đầy bảng phải mô phỏng kẻ tấn công PHÂN TÁN (mỗi IP 10 khoá).
  const send = (body, ip) => csp.receiveCspReport({ body, ip }, { status() { return { end() {} }; } });
  send({ "csp-report": { "document-uri": "https://twelve.test/", "effective-directive": "script-src", "blocked-uri": "https://real-problem.example/x.js" } }, "198.51.100.1"); // (IP này có thể trùng ô với một IP nhiễu — vô hại: khoá thật được ghi TRƯỚC khi nhiễu bắt đầu)
  // Chọn IP có ô băm KHÁC NHAU (muối ngẫu nhiên theo tiến trình nên hai IP hiếm khi trùng ô) để kết quả xác định.
  const ips = []; const usedBuckets = new Set();
  for (let n = 0; ips.length < 41; n++) { const ip = `10.1.${Math.floor(n / 250)}.${(n % 250) + 1}`; const b = csp.__test.reporterBucket(ip); if (!usedBuckets.has(b)) { usedBuckets.add(b); ips.push(ip); } }
  for (let i = 0; i < 400; i++) send({ "csp-report": { "document-uri": `https://twelve.test/p${i}`, "effective-directive": "img-src", "blocked-uri": `https://noise${i}.example/a.png` } }, ips[Math.floor(i / 10)]);
  const keys = [...csp.__test.entries.keys()];
  assert.ok(keys.some((k) => k.includes("real-problem")), "vi phạm thật vẫn còn trong bảng");
  assert.ok(csp.__test.entries.size <= 300);
  // bảng đã đầy bởi nhiễu img-src, nhưng vi phạm script-src MỚI vẫn được ghi (chỗ dự trữ)
  send({ "csp-report": { "document-uri": "https://twelve.test/", "effective-directive": "script-src-elem", "blocked-uri": "https://another-real.example/y.js" } }, ips[40]);
  assert.ok([...csp.__test.entries.keys()].some((k) => k.includes("another-real")));
  // nhiễu img-src mới thì vào bộ đếm tràn
  assert.ok(csp.__test.state.overflow > 0);
  const out = mockRes(); csp.getCspReports({}, out);
  assert.ok(out.body.overflow > 0 && out.body.droppedKeys > 0);
  // khoá không còn chứa đường dẫn tài liệu: cùng (chỉ thị, nguồn) ở nhiều trang => 1 khoá
  csp.__test.reset({}, { json() {} });
  for (let i = 0; i < 50; i++) send({ "csp-report": { "document-uri": `https://twelve.test/post/${i}x/extra`, "effective-directive": "img-src", "blocked-uri": "https://same.example/a.png" } });
  assert.equal(csp.__test.entries.size, 1);
  assert.equal([...csp.__test.entries.values()][0].count, 50);
  csp.__test.reset({}, { json() {} });
});

// =========================================================== A-06
test("A-06: bộ lọc style — chữ ẩn / margin âm / padding khổng lồ bị loại; giá trị hợp lý (Quill) vẫn giữ; XSS vẫn bị chặn", () => {
  const { sanitizeHtml } = require("../src/services/sanitize.service");
  const gone = [
    "font-size:0px", "font-size:0", "font-size:2px", "font-size:1000px", "font-size:calc(0px)", "color:transparent", "color: rgba(0,0,0,0)", "color:rgba(10, 10, 10, 0.02)",
    "margin-left:-9999px", "margin-right:-1px", "padding-left:99999px", "padding-right:100em", "line-height:0", "line-height:0px", "line-height:500",
  ];
  for (const st of gone) {
    const out = sanitizeHtml(`<p style="${st}">chữ</p>`);
    assert.ok(!/style=/.test(out), `${st} phải bị loại, nhận: ${out}`);
    assert.ok(out.includes("chữ"));
  }
  const kept = ["font-size: 24px", "font-size: 0.75em", "font-size: 2.5em", "font-size: large", "color: #ff0000", "color: rgb(10, 20, 30)", "color: rgba(10,20,30,0.8)", "background-color: transparent", "padding-left: 3em", "margin-left: 40px", "margin-left: auto", "padding-left: 0", "line-height: 1.5", "line-height: normal", "text-align: center"];
  for (const st of kept) {
    const out = sanitizeHtml(`<p style="${st}">chữ</p>`);
    assert.ok(out.includes(st.split(":")[0]), `${st} phải được giữ, nhận: ${out}`);
  }
  // XSS vẫn chặn
  const x = sanitizeHtml('<p style="color:red;background:url(javascript:alert(1));position:fixed" onclick="alert(1)">a</p><script>alert(1)</script><img src=x onerror=alert(1)>');
  assert.ok(!/script|onerror|onclick|url\(|position/i.test(x), x);
});
