// v2.0.10 — kiểm thử bản vá theo Báo cáo bảo mật Phiên 1 (Backend): F1–F10.
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const express = require("express");

process.env.SHARE_LINK_SECRET = "test-share-secret";
process.env.FRONTEND_URL = "https://twelve.example";
const { install } = require("./helpers/fakeFirebase");
const fb = install({ tokens: { act: "u_act", pend: "u_pend", susp: "u_susp", sharer: "u_sharer", auth: "u_author" } });
const S = fb.store;
const ts = { toMillis: () => 1 };

const resetData = () => {
  Object.keys(S).forEach((k) => delete S[k]);
  const act = (extra = {}) => ({ status: "active", accountGroup: "RA", positiveScore: 0, postsScoreSum: 0, displayName: "x", tagName: "x", ...extra });
  S["users/u_act"] = act();
  S["users/u_sharer"] = act();
  S["users/u_author"] = act();
  S["users/u_pend"] = act({ status: "pending" });
  S["users/u_susp"] = act({ status: "suspended" });
  S["posts/p1"] = { id: "p1", authorUid: "u_author", title: "Bài", contentHtml: "<p>a</p>", excerpt: "a", hashtags: [], createdAt: ts, likeCount: 0, dislikeCount: 0, commentCount: 0, viewCount: 0, shareCount: 0, externalPostScore: 0 };
};
const mockRes = () => {
  const r = { statusCode: 200, body: null, headers: {} };
  r.status = (c) => ((r.statusCode = c), r);
  r.json = (b) => ((r.body = b), r);
  r.set = (k, v) => ((r.headers[k] = v), r);
  return r;
};
const listen = (app) => new Promise((r) => { const s = http.createServer(app).listen(0, () => r({ s, base: `http://127.0.0.1:${s.address().port}` })); });

// ---------------------------------------------------------------- F1
const { CONTENT_LIMITS } = require("../src/utils/constants");
const pipeline = require("../src/services/contentPipeline");

test("F1: assessHtml chặn đúng các PoC (thẻ lạ, bảng, lồng sâu, quá dài, quá nhiều ảnh) mà vẫn nhận bài thật", () => {
  const bad = {
    "PoC báo cáo <b>×16000": "<b>a</b>".repeat(16000),
    "bảng 2000 hàng": "<table>" + "<tr><td>a</td><td>b</td></tr>".repeat(2000) + "</table>",
    "div lồng 2000": "<div>".repeat(2000) + "a" + "</div>".repeat(2000),
    "quá dài": "<p>" + "a".repeat(CONTENT_LIMITS.HTML_MAX_CHARS) + "</p>",
    "5000 ảnh": '<img src="https://res.cloudinary.com/x/a.png">'.repeat(4990),
    "né heuristic bằng title=\">\"": '<b title=">">a</b>'.repeat(4000),
    "nhiều '<' không đóng": "<".repeat(20000),
  };
  for (const [name, html] of Object.entries(bad)) assert.equal(pipeline.assessHtml(html).ok, false, name);
  assert.equal(pipeline.assessHtml(123).code, "CONTENT_INVALID");
  const para = '<p>Đoạn <strong>đậm</strong>, <em>nghiêng</em> và <a href="https://example.com">link</a>.</p>';
  const article = ("<h2>Tiêu đề</h2>" + para + "<ul><li>a</li><li>b</li></ul><blockquote>q</blockquote>").repeat(300);
  assert.equal(pipeline.assessHtml(article).ok, true, "bài dài thật (~90KB) phải được nhận");
  assert.equal(pipeline.assessHtml("<div>".repeat(99) + "a" + "</div>".repeat(99)).ok, true);
});

test("F1: processContentHtml sanitize đúng (XSS bị loại) và trả excerpt", async () => {
  const r = await pipeline.processContentHtml('<p onclick="x()">Xin chào <script>alert(1)</script><strong>bạn</strong></p><img src="javascript:alert(1)">');
  assert.ok(!/script|onclick|javascript:/i.test(r.html), r.html);
  assert.match(r.html, /<strong>bạn<\/strong>/);
  assert.equal(r.excerpt, "Xin chào bạn");
  assert.deepEqual(await pipeline.processContentHtml(""), { html: "", excerpt: "" });
});

test("F1: timeout cứng — việc nặng bị huỷ, event loop chính KHÔNG bị chặn, worker tự dựng lại", async () => {
  const saved = CONTENT_LIMITS.SANITIZE_TIMEOUT_MS;
  await pipeline.processContentHtml("<p>khởi động worker</p>");
  CONTENT_LIMITS.SANITIZE_TIMEOUT_MS = 40;
  try {
    let ticks = 0;
    const iv = setInterval(() => ticks++, 10);
    const heavy = "<p>" + "<span>a</span>".repeat(4900) + "</p>"; // qua heuristic nhưng ~1 giây để sanitize
    assert.equal(pipeline.assessHtml(heavy).ok, true);
    const t0 = Date.now();
    await assert.rejects(pipeline.processContentHtml(heavy), (e) => e.code === "CONTENT_TOO_COMPLEX" && e.status === 422);
    const elapsed = Date.now() - t0;
    clearInterval(iv);
    assert.ok(elapsed < 600, `phải bị huỷ sớm, thực tế ${elapsed}ms`);
    assert.ok(ticks >= 3, `event loop phải còn chạy trong lúc worker bận (ticks=${ticks})`);
  } finally {
    CONTENT_LIMITS.SANITIZE_TIMEOUT_MS = saved;
  }
  const again = await pipeline.processContentHtml("<p>vẫn dùng được sau khi huỷ</p>");
  assert.match(again.html, /vẫn dùng được/);
});

test("F1: createPost/updatePost trả 422 cho payload độc hại và KHÔNG tạo bài; 400 cho sai kiểu", async () => {
  resetData();
  const { createPost, updatePost } = require("../src/controllers/posts.controller");
  const reqOf = (body, params = {}) => ({ body, params, authUid: "u_act", authUser: { uid: "u_act", status: "active", accountGroup: "RA" } });
  let res = mockRes();
  const t0 = Date.now();
  await createPost(reqOf({ title: "Tiêu đề hợp lệ", contentHtml: "<b>a</b>".repeat(16000) }), res);
  assert.equal(res.statusCode, 422);
  assert.ok(Date.now() - t0 < 500, "bị từ chối ngay, không tốn CPU");
  assert.ok(!Object.keys(S).some((k) => /^posts\/auto/.test(k)), "không có bài nào được lưu");

  res = mockRes();
  await createPost(reqOf({ title: "Tiêu đề hợp lệ", contentHtml: { $ne: 1 } }), res);
  assert.equal(res.statusCode, 400);

  res = mockRes();
  await createPost(reqOf({ title: "Tiêu đề hợp lệ", contentHtml: "<p>Nội dung bình thường</p>" }), res);
  assert.equal(res.statusCode, 201);

  S["posts/p1"].authorUid = "u_act";
  res = mockRes();
  await updatePost(reqOf({ contentHtml: "<table>" + "<tr><td>a</td></tr>".repeat(2000) + "</table>" }, { id: "p1" }), res);
  assert.equal(res.statusCode, 422);
  assert.equal(S["posts/p1"].contentHtml, "<p>a</p>", "nội dung cũ giữ nguyên");
});

test("F1/F10: rescan embed không treo, tài liệu độc hại cũ chỉ bị tính 'failed', phần còn lại vẫn được xử lý", async () => {
  resetData();
  const sanitize = require("../src/services/sanitize.service");
  sanitize.setEmbedDomainsConfig({ enabled: true, domains: [{ domain: "youtube.com" }] });
  S["posts/bad"] = { authorUid: "u_act", contentHtml: "<b>a</b>".repeat(16000), excerpt: "x" };
  S["posts/needsfix"] = { authorUid: "u_act", contentHtml: '<p>giữ</p><img src="https://evil.example/x.png">', excerpt: "cũ" };
  S["posts/clean"] = { authorUid: "u_act", contentHtml: "<p>sạch</p>" };
  const ctrl = require("../src/controllers/embedDomains.controller");
  const t0 = Date.now();
  const out = await ctrl.__test.rescanContentForEmbedDomains();
  assert.ok(Date.now() - t0 < 5000);
  assert.equal(out.failed, 1);
  assert.equal(out.modified, 1);
  assert.ok(!S["posts/needsfix"].contentHtml.includes("evil.example"));
  assert.equal(S["posts/needsfix"].excerpt, "giữ");
});

// ---------------------------------------------------------------- F2
test("F2: avatar multipart — nhiều field text bị từ chối (400), ảnh hợp lệ vẫn nhận", async (t) => {
  const upload = require("../src/middleware/upload");
  const app = express();
  app.post("/avatar", upload.single("avatar"), (req, res) => res.json({ ok: true, size: req.file ? req.file.size : 0 }));
  app.use((err, req, res, next) => res.status(400).json({ code: err.code || err.message }));
  const { s, base } = await listen(app);
  t.after(() => s.close());
  const B = "----t";
  const field = (name, v) => `--${B}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${v}\r\n`;
  const send = (body) => fetch(base + "/avatar", { method: "POST", headers: { "content-type": `multipart/form-data; boundary=${B}` }, body });

  let r = await send(Array.from({ length: 70 }, (_, i) => field("f" + i, "x".repeat(900 * 1024))).join("") + `--${B}--\r\n`);
  assert.equal(r.status, 400);
  r = await send(Array.from({ length: 6 }, (_, i) => field("f" + i, "a")).join("") + `--${B}--\r\n`);
  assert.equal((await r.json()).code, "LIMIT_FIELD_COUNT");
  r = await send(field("a", "x".repeat(2000)) + `--${B}--\r\n`);
  assert.equal((await r.json()).code, "LIMIT_FIELD_VALUE");

  const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==", "base64");
  const body = Buffer.concat([Buffer.from(`--${B}\r\nContent-Disposition: form-data; name="avatar"; filename="a.png"\r\nContent-Type: image/png\r\n\r\n`), png, Buffer.from(`\r\n--${B}--\r\n`)]);
  r = await send(body);
  assert.deepEqual(await r.json(), { ok: true, size: png.length });
});

// ---------------------------------------------------------------- F4 (+ điểm xem)
const { optionalAuth } = require("../src/middleware/auth");
const { getPost } = require("../src/controllers/posts.controller");
const { signShareParams } = require("../src/utils/helpers");
const openPost = async (token, query = {}) => {
  const req = { headers: token ? { authorization: `Bearer ${token}` } : {}, params: { id: "p1" }, query, ip: "10.0.0.1", socket: { remoteAddress: "10.0.0.1" } };
  await new Promise((r) => optionalAuth(req, {}, r));
  const res = mockRes();
  await getPost(req, res);
  return { req, res };
};

test("F4: tài khoản pending/suspended mở link share hoặc xem bài KHÔNG sinh điểm; tài khoản active thì có", async () => {
  const share = { idu: "u_sharer", s: signShareParams("u_sharer", "posts", "p1") };

  resetData();
  for (const token of ["pend", "susp"]) {
    const { req, res } = await openPost(token, share);
    assert.equal(res.statusCode, 200);
    assert.equal(req.authUid, undefined, `${token}: bị coi như khách`);
  }
  assert.equal(S["users/u_sharer"].positiveScore, 0, "người chia sẻ không được cộng điểm từ tài khoản pending/suspended");
  assert.equal(S["users/u_pend"].positiveScore, 0);
  assert.equal(S["users/u_susp"].positiveScore, 0);
  assert.equal(S["posts/p1"].externalPostScore, 0);

  resetData();
  const { res } = await openPost("act", share);
  assert.equal(res.statusCode, 200);
  assert.equal(S["users/u_sharer"].positiveScore, 8, "đối chứng: người xem active => người chia sẻ +8");
  assert.equal(S["users/u_act"].positiveScore, 1, "đối chứng: người xem active được +1 điểm xem");
});

test("F4: nhiều tài khoản pending dùng chung IP không tạo ra nhiều lượt chia sẻ riêng biệt", async () => {
  resetData();
  const share = { idu: "u_sharer", s: signShareParams("u_sharer", "posts", "p1") };
  for (let i = 0; i < 5; i++) {
    S[`users/pend${i}`] = { status: "pending", accountGroup: "RA" };
    fb.tokens[`pend${i}`] = `pend${i}`;
    await openPost(`pend${i}`, share);
  }
  assert.equal(S["posts/p1"].shareCount, 1, "cùng 1 IP = 1 lượt, dù đổi tài khoản pending");
});

// ---------------------------------------------------------------- F6
test("F6: token bị thu hồi / tài khoản bị vô hiệu hoá bị từ chối; tra cứu có cache; lỗi tra cứu không làm sập request", async () => {
  resetData();
  const { requireAuth, __test } = require("../src/middleware/auth");
  const call = async (token) => {
    const req = { headers: { authorization: `Bearer ${token}` } };
    const res = mockRes();
    let nexted = false;
    await requireAuth(req, res, () => (nexted = true));
    return { res, nexted };
  };
  __test.clearRevokeCache();
  let r = await call("act");
  assert.equal(r.nexted, true);
  const before = fb.authCalls.getUser.length;
  await call("act"); await call("act");
  assert.equal(fb.authCalls.getUser.length, before, "lần gọi sau trong 60s dùng cache, không gọi thêm Firebase Auth");

  __test.clearRevokeCache();
  fb.userRecords.u_act = { tokensValidAfterTime: new Date(Date.now() + 60000).toUTCString() }; // token cấp TRƯỚC mốc thu hồi
  r = await call("act");
  assert.equal(r.nexted, false);
  assert.equal(r.res.statusCode, 401);
  assert.match(r.res.body.error, /thu hồi/);

  __test.clearRevokeCache();
  fb.userRecords.u_act = { tokensValidAfterTime: new Date(0).toUTCString(), disabled: true };
  assert.equal((await call("act")).res.statusCode, 401);

  __test.clearRevokeCache();
  delete fb.userRecords.u_act;
  const orig = fb.auth.getUser;
  fb.auth.getUser = async () => { throw new Error("mạng lỗi"); };
  const quiet = console.error; console.error = () => {};
  try { assert.equal((await call("act")).nexted, true, "fail-open: lỗi tra cứu không chặn người dùng"); } finally { console.error = quiet; fb.auth.getUser = orig; }
});

// ---------------------------------------------------------------- F7 / F9 / F8
const { registerValidators, updateMeValidators, realNameValidators } = require("../src/middleware/validators");
const { validationResult } = require("express-validator");
const runValidators = async (chains, body) => {
  const req = { body: { ...body }, headers: {} };
  for (const c of chains) await c.run(req);
  return { req, errors: validationResult(req).mapped() };
};
const input = require("../src/utils/input");

test("F7: displayName/fullName bị làm sạch ký tự bidi, rộng-0, điều khiển; kiểu sai bị từ chối", async () => {
  let { req, errors } = await runValidators(updateMeValidators, { displayName: "A\u202Eevil\u200B\u0000  tên\u2066x\u2069 ✔" });
  assert.equal(errors.displayName, undefined);
  assert.equal(req.body.displayName, "A evil tên x ✔");
  assert.ok(!/[\u202E\u200B\u2066\u0000]/.test(req.body.displayName));

  ({ req, errors } = await runValidators(updateMeValidators, { displayName: "Nguyễn Văn Ân" }));
  assert.equal(req.body.displayName, "Nguyễn Văn Ân", "tiếng Việt có dấu được giữ nguyên");

  ({ errors } = await runValidators(updateMeValidators, { displayName: "\u200B\u202E" }));
  assert.ok(errors.displayName, "chỉ gồm ký tự vô hình => rỗng => bị từ chối");
  for (const bad of [123, ["a"], { a: 1 }, true]) {
    assert.ok((await runValidators(updateMeValidators, { displayName: bad })).errors.displayName, JSON.stringify(bad));
    // v2.2.0: tên thật không còn đi qua PATCH /users/me — validator của nó nằm ở realNameValidators (PUT /users/me/real-name).
    assert.ok((await runValidators(realNameValidators, { fullName: bad })).errors.fullName, JSON.stringify(bad));
  }
  // ...và updateMeValidators không còn chấp nhận/xử lý fullName (controller từ chối hẳn field này).
  assert.equal((await runValidators(updateMeValidators, { fullName: 123 })).errors.fullName, undefined);
  // realNameValidators cũng làm sạch ký tự nguy hiểm như displayName.
  const rn = await runValidators(realNameValidators, { fullName: "Nguyễn\u202E Văn\u200B A" });
  assert.equal(rn.errors.fullName, undefined);
  assert.equal(rn.req.body.fullName, "Nguyễn Văn A");
  assert.equal(input.stripBidiAndInvisible("a\u202Eb\u200Bc\u200D👨\u200D👩"), "abc\u200D👨\u200D👩", "văn bản tự do giữ ZWJ cho emoji ghép");
});

test("F9: birthday nghiêm ngặt", () => {
  for (const ok of ["2000-02-29", "1900-01-01", "1999-12-31"]) assert.equal(input.validateBirthday(ok).ok, true, ok);
  for (const bad of ["2023-02-31", "2020-W01-1", "2020-001", "1999-12-31T00:00:00Z", "1899-12-31", "2999-01-01", "0000-01-01", "2001-13-01", "2001-1-1", "", null, 20000101, ["2000-01-01"]]) {
    assert.equal(input.validateBirthday(bad).ok, false, String(bad));
  }
  assert.equal(input.validateBirthday("2026-10-06", new Date("2026-10-05T10:00:00Z")).ok, false, "ngày mai bị từ chối");
});

test("F8: limit/cursor/comment sai kiểu => 400 (hoặc mặc định hợp lý), không còn 500", async () => {
  assert.equal(input.parseLimit("-5", 10, 30), 10);
  assert.equal(input.parseLimit("abc", 10, 30), 10);
  assert.equal(input.parseLimit(["5"], 10, 30), 10);
  assert.equal(input.parseLimit("1e9", 10, 30), 1);
  assert.equal(input.parseLimit("500", 10, 30), 30);
  assert.equal(input.parseLimit("7", 10, 30), 7);
  assert.equal(input.parseCursor(["a"]).ok, false);
  assert.equal(input.parseCursor({ a: 1 }).ok, false);
  assert.equal(input.parseCursor("a/b").ok, false);
  assert.equal(input.parseCursor("abc123").value, "abc123");

  resetData();
  const { listPosts } = require("../src/controllers/posts.controller");
  let res = mockRes();
  await listPosts({ query: { limit: "-5" }, headers: {} }, res);
  assert.equal(res.statusCode, 200);
  res = mockRes();
  await listPosts({ query: { cursor: ["x"] }, headers: {} }, res);
  assert.equal(res.statusCode, 400);

  const { addComment, editComment } = require("../src/controllers/comments.controller");
  const user = { authUid: "u_act", authUser: { uid: "u_act", status: "active", accountGroup: "RA" } };
  for (const content of [123, ["a"], { a: 1 }, true]) {
    res = mockRes();
    await addComment("posts")({ params: { id: "p1" }, body: { content }, ...user }, res);
    assert.equal(res.statusCode, 400, JSON.stringify(content));
    res = mockRes();
    await editComment("posts")({ params: { id: "p1", commentId: "c1" }, body: { content }, ...user }, res);
    assert.equal(res.statusCode, 400, JSON.stringify(content));
  }
});

// ---------------------------------------------------------------- F11 (phát sinh khi điều tra F5)
test("F11: avatar — file ASF dị dạng (từng làm file-type lặp vô hạn) bị từ chối ngay, không tới bộ phân tích", async () => {
  const { sniffImageMime } = require("../src/utils/input");
  const asf = (() => {
    const hdr = Buffer.alloc(30);
    Buffer.from("3026b2758e66cf11a6d900aa0062ce6c", "hex").copy(hdr, 0);
    hdr.writeBigUInt64LE(54n, 16); hdr.writeUInt32LE(1, 24);
    const sub = Buffer.alloc(24);
    Buffer.from("00112233445566778899aabbccddeeff", "hex").copy(sub, 0);
    return Buffer.concat([hdr, sub, Buffer.alloc(64)]);
  })();
  assert.equal(sniffImageMime(asf), null);
  assert.equal(sniffImageMime(Buffer.from("89504e470d0a1a0a0000000d49484452", "hex")), "image/png");
  assert.equal(sniffImageMime(Buffer.from("ffd8ffe000104a464946000101", "hex")), "image/jpeg");
  assert.equal(sniffImageMime(Buffer.concat([Buffer.from("RIFF"), Buffer.alloc(4), Buffer.from("WEBPVP8 ")])), "image/webp");
  assert.equal(sniffImageMime(Buffer.from("GIF89a000000000000")), null);
  assert.equal(sniffImageMime(Buffer.alloc(3)), null);

  process.env.CLOUDINARY_CLOUD_NAME = "c"; process.env.CLOUDINARY_API_KEY = "k"; process.env.CLOUDINARY_API_SECRET = "s";
  const cloudinary = require("../src/config/cloudinary");
  cloudinary.config({ cloud_name: "c", api_key: "k", api_secret: "s" });
  const { uploadAvatar } = require("../src/controllers/users.controller");
  const res = mockRes();
  const t0 = Date.now();
  await uploadAvatar({ authUid: "u_act", authUser: {}, file: { buffer: asf, size: asf.length, mimetype: "image/png" } }, res);
  assert.equal(res.statusCode, 400);
  assert.match(res.body.error, /không phải ảnh hợp lệ/);
  assert.ok(Date.now() - t0 < 1000);
});
