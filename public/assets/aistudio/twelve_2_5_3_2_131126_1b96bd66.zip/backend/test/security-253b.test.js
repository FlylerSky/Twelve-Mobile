// v2.5.3 — kiểm thử bản vá theo "Báo cáo bảo mật tổng hợp cuối v2.5.2" — ĐỢT 2–3: TW-02 (CSP của SPA), TW-06 (sanitizer: class/data/aria), TW-07 + TW-13 (firestore.rules), script re-sanitize.
// Đợt 4 (TW-08/09/11/14/25) nằm ở test/security-253c.test.js. Firestore GIẢ; không cần mạng.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");

const BACKEND = path.join(__dirname, "..");
const FRONTEND = path.join(BACKEND, "..", "frontend");
const haveFrontend = fs.existsSync(path.join(FRONTEND, "vercel.json"));

// ============================================================ TW-02 — CSP của SPA
const directives = (value) => {
  const out = {};
  for (const part of String(value).split(";")) {
    const [name, ...rest] = part.trim().split(/\s+/);
    if (name) out[name] = rest;
  }
  return out;
};
const cspHeaders = () => {
  const cfg = JSON.parse(fs.readFileSync(path.join(FRONTEND, "vercel.json"), "utf8"));
  const block = cfg.headers.find((h) => h.source === "/(.*)");
  const get = (key) => directives(block.headers.find((h) => h.key === key).value);
  return { enforced: get("Content-Security-Policy"), reportOnly: get("Content-Security-Policy-Report-Only") };
};

test("TW-02: CSP THỰC THI của SPA có script-src chặt + script-src-attr 'none' (không còn chỉ 4 directive)", { skip: !haveFrontend && "không có thư mục ../frontend" }, () => {
  const { enforced } = cspHeaders();
  assert.deepEqual(enforced["script-src"], ["'self'", "https://challenges.cloudflare.com"], "chỉ 'self' + Turnstile");
  assert.deepEqual(enforced["script-src-attr"], ["'none'"]);
  for (const d of ["object-src", "base-uri", "form-action", "frame-ancestors"]) assert.ok(enforced[d], `giữ nguyên directive cũ: ${d}`);
  const all = Object.values(enforced).flat();
  assert.ok(!all.includes("'unsafe-inline'") && !all.includes("'unsafe-eval'") && !all.includes("https:") && !all.includes("*"), "không có nguồn quá rộng trong policy thực thi");
  // Policy thực thi KHÔNG được dùng default-src: default-src 'self' sẽ chặn luôn img/font/connect/frame chưa được rà (đang ở Report-Only)
  assert.equal(enforced["default-src"], undefined);
});

test("TW-02: Report-Only không còn `https:` ở frame-src/img-src; frame-src phủ đủ DEFAULT_EMBED_DOMAINS + Turnstile (khớp getFrameSrcCspSources)", { skip: !haveFrontend && "không có thư mục ../frontend" }, () => {
  const { reportOnly } = cspHeaders();
  assert.ok(!reportOnly["frame-src"].includes("https:"), "frame-src không còn https: trần");
  assert.ok(!reportOnly["img-src"].includes("https:"), "img-src không còn https: trần");
  assert.ok(reportOnly["script-src-attr"] && reportOnly["script-src-attr"].includes("'none'"), "policy đầy đủ cũng có script-src-attr");
  assert.ok(reportOnly["frame-src"].includes("https://challenges.cloudflare.com"));

  const { DEFAULT_EMBED_DOMAINS, setEmbedDomainsConfig, getFrameSrcCspSources } = require("../src/services/sanitize.service");
  setEmbedDomainsConfig({ enabled: true, domains: DEFAULT_EMBED_DOMAINS });
  const expected = getFrameSrcCspSources();
  assert.ok(expected.length >= DEFAULT_EMBED_DOMAINS.length * 2);
  const missing = expected.filter((src) => !reportOnly["frame-src"].includes(src));
  assert.deepEqual(missing, [], "vercel.json lệch DEFAULT_EMBED_DOMAINS — chạy `npm run csp:sources` để lấy danh sách đúng");
  assert.ok(reportOnly["img-src"].includes("https://res.cloudinary.com"), "ảnh Cloudinary (avatar/bìa) vẫn được báo là hợp lệ");
});

test("TW-02: index.html của SPA không có script inline (điều kiện để enforce script-src 'self')", { skip: !haveFrontend && "không có thư mục ../frontend" }, () => {
  const html = fs.readFileSync(path.join(FRONTEND, "index.html"), "utf8");
  const scripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)];
  assert.ok(scripts.length >= 1);
  for (const [, attrs, body] of scripts) {
    assert.match(attrs, /\bsrc\s*=/, `script phải có src: <script${attrs}>`);
    assert.equal(body.trim(), "", "script có src không được kèm thân inline");
  }
  assert.ok(!/\son[a-z]+\s*=\s*["']/i.test(html), "không có trình xử lý sự kiện inline (script-src-attr 'none')");
  // Mọi nguồn script ngoài tên miền mình phải nằm trong policy thực thi
  const { enforced } = cspHeaders();
  for (const [, attrs] of scripts) {
    const src = /\bsrc\s*=\s*["']([^"']+)["']/.exec(attrs)[1];
    if (/^https?:\/\//i.test(src)) assert.ok(enforced["script-src"].some((o) => src.startsWith(o)), `${src} không nằm trong script-src`);
  }
});

test("TW-02: mã frontend chỉ nạp script ngoài từ nguồn đã có trong script-src (Turnstile)", { skip: !haveFrontend && "không có thư mục ../frontend" }, () => {
  const offenders = [];
  const loaders = [];
  const walk = (d) =>
    fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
      const p = path.join(d, e.name);
      if (e.isDirectory()) return walk(p);
      if (!/\.(jsx?|mjs)$/.test(e.name)) return;
      const src = fs.readFileSync(p, "utf8");
      if (/createElement\(\s*["']script["']\s*\)/.test(src)) loaders.push(path.relative(FRONTEND, p));
      if (/\beval\s*\(|new\s+Function\s*\(/.test(src.replace(/\/\/.*$/gm, "").replace(/\/\*[\s\S]*?\*\//g, ""))) offenders.push(path.relative(FRONTEND, p));
    });
  walk(path.join(FRONTEND, "src"));
  // v2.5.3.121126: `utils/appCheckGuard.js` nạp reCAPTCHA CHỈ khi đặt VITE_FIREBASE_APPCHECK_SITE_KEY (TW-04) — nguồn đó cố ý KHÔNG có trong `vercel.json` cho tới khi vận hành bật App Check
  // theo PATCH-25-NOTES.md mục 4; nếu thiếu CSP thì script bị chặn và guard bỏ qua App Check (không treo). Không thêm nơi tự nạp script nào khác mà chưa rà CSP.
  assert.deepEqual(loaders, ["src/components/TurnstileWidget.jsx", "src/utils/appCheckGuard.js"], "chỉ TurnstileWidget và appCheckGuard được tự nạp script — thêm nơi khác thì phải rà lại CSP");
  assert.deepEqual(
    (fs.readFileSync(path.join(FRONTEND, "src/utils/appCheckGuard.js"), "utf8").match(/https:\/\/[^"'\s)]+/g) || []).filter((u) => /\.js$/.test(u)).sort(),
    ["https://www.google.com/recaptcha/api.js", "https://www.google.com/recaptcha/enterprise.js"],
    "appCheckGuard chỉ được nạp script reCAPTCHA"
  );
  assert.deepEqual(offenders, [], "không dùng eval/new Function (script-src không có 'unsafe-eval')");
  const widget = fs.readFileSync(path.join(FRONTEND, "src/components/TurnstileWidget.jsx"), "utf8");
  assert.match(widget, /https:\/\/challenges\.cloudflare\.com\//);
});

// ============================================================ TW-06 — sanitizer
const { sanitizeHtml, filterClassValue, ALLOWED_CLASS_PATTERNS } = require("../src/services/sanitize.service");

// HTML do Quill 1.3.7 THẬT sinh ra (chạy trong jsdom với đủ định dạng của toolbar + indent/size/font/direction) — mọi lớp ở đây phải sống sót.
const QUILL_REAL_OUTPUT =
  '<h2>Tiêu đề</h2><p class="ql-align-center">Căn giữa</p><p class="ql-align-right">Căn phải</p><p class="ql-align-justify">Justify</p><p class="ql-indent-2">Thụt lề</p>' +
  '<p><strong class="ql-size-large" style="color: rgb(255, 0, 0); background-color: rgb(255, 255, 0);">Chữ to</strong></p><p><span class="ql-font-monospace">Font</span></p>' +
  '<p class="ql-direction-rtl ql-align-right">RTL</p><ol><li>mục 1</li></ol><ul><li>mục 2</li></ul><blockquote>trích dẫn</blockquote>' +
  '<pre class="ql-syntax" spellcheck="false">console.log(1)\n</pre>' +
  '<iframe class="ql-video" frameborder="0" allowfullscreen="true" src="https://www.youtube.com/embed/abcdef123"></iframe>' +
  '<p><img src="https://res.cloudinary.com/x/image/upload/a.png"><a href="https://example.com" rel="noopener noreferrer" target="_blank">link</a></p>';

const classesOf = (html) => [...html.matchAll(/class="([^"]*)"/g)].flatMap((m) => m[1].split(/\s+/)).filter(Boolean);

test("TW-06: HTML do Quill thật sinh ra — mọi lớp định dạng hợp lệ đều được GIỮ (không mất định dạng bài viết)", () => {
  const { setEmbedDomainsConfig, DEFAULT_EMBED_DOMAINS } = require("../src/services/sanitize.service");
  setEmbedDomainsConfig({ enabled: true, domains: [...DEFAULT_EMBED_DOMAINS, { domain: "res.cloudinary.com", path: "" }] });
  const out = sanitizeHtml(QUILL_REAL_OUTPUT);
  const before = [...new Set(classesOf(QUILL_REAL_OUTPUT))].sort();
  const after = [...new Set(classesOf(out))].sort();
  assert.deepEqual(after, before, "không lớp hợp lệ nào bị bỏ");
  assert.ok(before.length >= 9, "mẫu phủ đủ các họ lớp");
  assert.match(out, /<p class="ql-direction-rtl ql-align-right">/, "thứ tự nhiều lớp được giữ");
  assert.match(out, /style="[^"]*color/, "style màu chữ vẫn qua bộ lọc style (không đổi)");
});

test("TW-06: lớp tiện ích CSS của Quill dùng để GIẤU chữ bị bỏ (ql-hidden, ql-clipboard, ql-out-top/bottom…)", () => {
  const payload =
    '<p><span class="ql-hidden">chữ ẩn 1</span><span class="ql-clipboard">chữ ẩn 2</span><span class="ql-out-top">chữ ẩn 3</span><span class="ql-out-bottom">chữ ẩn 4</span></p>' +
    '<p class="ql-tooltip ql-editing ql-toolbar ql-picker ql-active ql-cursor ql-blank ql-snow ql-container ql-editor">x</p>';
  const out = sanitizeHtml(payload);
  assert.deepEqual(classesOf(out), [], `không còn lớp nào: ${out}`);
  assert.ok(!/class=/.test(out), "thuộc tính class rỗng bị xoá hẳn");
  for (const text of ["chữ ẩn 1", "chữ ẩn 2", "chữ ẩn 3", "chữ ẩn 4"]) assert.ok(out.includes(text), "nội dung chữ vẫn giữ nguyên — chỉ bỏ lớp, không xoá thẻ");
});

test("TW-06: filterClassValue — lẫn lớp hợp lệ + lạ chỉ giữ lớp hợp lệ; bỏ trùng; giới hạn số/độ dài token; không nhận biến thể lách", () => {
  assert.equal(filterClassValue("ql-align-center ql-hidden foo"), "ql-align-center");
  assert.equal(filterClassValue("ql-hidden"), "");
  assert.equal(filterClassValue("ql-align-center ql-align-center"), "ql-align-center");
  assert.equal(filterClassValue("  ql-video   ql-embed-webpage "), "ql-video ql-embed-webpage");
  assert.equal(filterClassValue(undefined), "");
  assert.equal(filterClassValue("ql-align-center".repeat(10)), "", "token quá dài bị bỏ");
  for (const evil of ["QL-HIDDEN", "ql-align-center2", "xql-syntax", "ql-syntax-hidden", "ql-align-", "ql-size-small;display:none", "ql-indent-9", "ql-indent-0", "ql-video​"]) {
    assert.equal(filterClassValue(evil), "", `phải bị bỏ: ${JSON.stringify(evil)}`);
  }
  // Allowlist là MẪU có neo ^…$ — kiểm tra tất cả mẫu đều neo hai đầu (tránh một mẫu lỏng làm thủng cả danh sách)
  for (const re of ALLOWED_CLASS_PATTERNS) assert.ok(re.source.startsWith("^") && re.source.endsWith("$"), String(re));
});

test("TW-06: data-* và aria-* bị bỏ; chỉ `data-list` hợp lệ trên li/ol/ul được giữ", () => {
  const out = sanitizeHtml(
    '<span data-x="1" data-twelve-media-src="https://evil.example/a.png" data-twelve-media-type="IMG" aria-label="ẩn" aria-hidden="true" role="presentation">a</span>' +
      '<ul><li data-list="bullet">b</li><li data-list="javascript:1">c</li></ul><span data-list="bullet">d</span>'
  );
  assert.ok(!/data-twelve|data-x|aria-|role=/.test(out), out);
  assert.match(out, /<li data-list="bullet">b<\/li>/);
  assert.match(out, /<li>c<\/li>/, "data-list sai giá trị bị bỏ");
  assert.match(out, /<span>d<\/span>/, "data-list trên thẻ khác li/ol/ul bị bỏ");
});

test("TW-06: không làm hỏng các bảo vệ cũ — on*/javascript:, iframe ngoài allowlist, ép sandbox/rel", () => {
  const { setEmbedDomainsConfig, DEFAULT_EMBED_DOMAINS } = require("../src/services/sanitize.service");
  setEmbedDomainsConfig({ enabled: true, domains: DEFAULT_EMBED_DOMAINS });
  const out = sanitizeHtml(
    '<p onclick="alert(1)" class="ql-align-center">a</p><a href="javascript:alert(1)">b</a><a href="https://example.com/x">c</a>' +
      '<iframe src="https://evil.example/x" class="ql-video"></iframe><iframe src="https://www.youtube.com/embed/abc" class="ql-video"></iframe>'
  );
  assert.ok(!/onclick|javascript:|evil\.example/.test(out), out);
  assert.match(out, /<p class="ql-align-center">a<\/p>/);
  assert.match(out, /rel="ugc nofollow noopener"/);
  assert.match(out, /sandbox="allow-scripts allow-same-origin allow-presentation"/);
  assert.equal((out.match(/<iframe/g) || []).length, 1);
});

// ============================================================ TW-07 + TW-13 — firestore.rules
const rules = fs.readFileSync(path.join(BACKEND, "firestore.rules"), "utf8").replace(/\/\/[^\n]*/g, "");
const ruleBlock = (header) => {
  const i = rules.indexOf(header);
  assert.ok(i !== -1, `thiếu khối rules: ${header}`);
  const start = i + header.length;
  return rules.slice(start, rules.indexOf("}", start));
};

test("TW-07: config/* bị khoá hoàn toàn (không còn cho đọc công khai); countries/* vẫn đọc công khai (đối chứng của module Gỡ lỗi)", () => {
  const cfg = ruleBlock("match /config/{docId} {");
  assert.match(cfg, /allow\s+read\s*,\s*write\s*:\s*if\s+false\s*;/);
  assert.ok(!/if\s+true/.test(cfg));
  assert.match(ruleBlock("match /countries/{docId} {"), /allow\s+read\s*:\s*if\s+true\s*;/);
});

test("TW-13: users/*/positiveScoreLogs bị khoá — chính chủ cũng không đọc được bằng Client SDK (lộ UID người mở link chia sẻ)", () => {
  const logs = ruleBlock("match /users/{uid}/positiveScoreLogs/{logId} {");
  assert.match(logs, /allow\s+read\s*,\s*write\s*:\s*if\s+false\s*;/);
  assert.ok(!/request\.auth/.test(logs));
  // users/{uid} vẫn cho chủ đọc hồ sơ của mình (AuthContext dùng onSnapshot)
  assert.match(ruleBlock("match /users/{uid} {"), /request\.auth\.uid\s*==\s*uid/);
});

test("TW-07/13: frontend không đọc config/* hay positiveScoreLogs bằng Client SDK (khoá rules không làm gãy giao diện)", { skip: !haveFrontend && "không có thư mục ../frontend" }, () => {
  const hits = [];
  const walk = (d) =>
    fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
      const p = path.join(d, e.name);
      if (e.isDirectory()) return walk(p);
      if (!/\.(jsx?|mjs)$/.test(e.name)) return;
      const src = fs.readFileSync(p, "utf8").replace(/\/\/.*$/gm, "").replace(/\/\*[\s\S]*?\*\//g, "");
      if (/positiveScoreLogs/.test(src)) hits.push(`${path.relative(FRONTEND, p)}: positiveScoreLogs`);
      if (/(?:doc|collection)\(\s*db\s*,\s*["']config["']/.test(src)) hits.push(`${path.relative(FRONTEND, p)}: config`);
    });
  walk(path.join(FRONTEND, "src"));
  assert.deepEqual(hits, []);
  // Các collection mà frontend đọc qua Client SDK phải còn được rules cho đọc
  const used = new Set();
  const hooks = ["hooks/useRealtimeDoc.js", "hooks/useNewContentBanner.js", "hooks/usePaginatedComments.js", "context/AuthContext.jsx"].map((f) => fs.readFileSync(path.join(FRONTEND, "src", f), "utf8")).join("\n");
  for (const m of hooks.matchAll(/(?:doc|collection)\(\s*db\s*,\s*["'`]([a-zA-Z]+)["'`]/g)) used.add(m[1]);
  for (const name of used) assert.ok(rules.includes(`match /${name}/`), `rules phải có khối cho ${name}`);
  assert.ok(!used.has("config"));
});

// ============================================================ script re-sanitize (dry-run mặc định)
const runResanitize = (extraArgs) => {
  const code = `
    const { install } = require("./test/helpers/fakeFirebase");
    const fb = install({ tokens: {} });
    fb.store["posts/p1"] = { contentHtml: '<p class="ql-align-center">ok</p><span class="ql-hidden" data-x="1">a</span><span class="ql-hidden">b</span>', excerpt: "old" };
    fb.store["posts/p2"] = { contentHtml: '<p class="ql-align-right">sạch</p>', excerpt: "sạch" };
    fb.store["blogs/b1"] = { contentHtml: '<p class="ql-clipboard">c</p>', excerpt: "old" };
    process.argv.push(...${JSON.stringify(extraArgs)});
    process.on("exit", () => console.log("STORE:" + JSON.stringify(fb.store)));
    require("./src/seed/resanitizeContent.js");
  `;
  const r = spawnSync(process.execPath, ["-e", code], { cwd: BACKEND, encoding: "utf8", timeout: 60000, env: { PATH: process.env.PATH, NODE_ENV: "test" } });
  const m = /STORE:(.*)$/m.exec(r.stdout);
  // Tách dòng STORE (dump dữ liệu để kiểm tra) khỏi phần log của script — tránh assert nhầm vào nội dung dump
  return { out: r.stdout.replace(/^STORE:.*$/m, ""), err: r.stderr, status: r.status, store: m ? JSON.parse(m[1]) : null };
};

test("script re-sanitize: DRY-RUN mặc định không ghi gì nhưng báo token class/data- bị bỏ; --apply mới ghi thật", () => {
  const dry = runResanitize([]);
  assert.equal(dry.status, 0, dry.err);
  assert.match(dry.out, /DRY-RUN/);
  assert.match(dry.out, /2 × ql-hidden/, "đếm đúng số lần xuất hiện");
  assert.match(dry.out, /1 × ql-clipboard/);
  assert.match(dry.out, /1 × data-x/);
  assert.ok(!/ql-align/.test(dry.out.split("Token `class` bị bỏ")[1] || ""), "lớp hợp lệ không bị liệt kê là bỏ");
  assert.match(dry.out, /sẽ cập nhật \(dry-run\) 2 document/);
  assert.match(dry.store["posts/p1"].contentHtml, /ql-hidden/, "dry-run không đổi dữ liệu");
  assert.equal(dry.store["posts/p1"].excerpt, "old");

  const applied = runResanitize(["--apply"]);
  assert.equal(applied.status, 0, applied.err);
  assert.match(applied.out, /đã cập nhật 2 document/);
  assert.ok(!/ql-hidden|data-x/.test(applied.store["posts/p1"].contentHtml));
  assert.match(applied.store["posts/p1"].contentHtml, /ql-align-center/);
  assert.equal(applied.store["posts/p1"].excerpt, "okab", "excerpt tính lại từ nội dung đã sạch");
  assert.ok(!/ql-clipboard/.test(applied.store["blogs/b1"].contentHtml));
  assert.equal(applied.store["posts/p2"].contentHtml, '<p class="ql-align-right">sạch</p>', "bài đã sạch không bị đụng");
});
