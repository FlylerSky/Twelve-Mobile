// Kiểm thử bản vá 2 (báo cáo 2): farm điểm bình luận, email, cache xếp hạng, xoá đệ quy, tìm tác giả,
// rel của link, hashtag không phân biệt hoa/thường, ảnh bìa, rescan nền. Firestore GIẢ in-memory.
const test = require("node:test");
const assert = require("node:assert/strict");

// ------------------------------------------------------------------ Firestore giả (có ghi + transaction)
const store = {}; // "col/id" -> data ; "col/id/sub/id2" -> data
const reads = { users: 0 };
const fv = { increment: (n) => ({ __inc: n }), serverTimestamp: () => ({ __ts: true }) };
function applyWrite(path, data, merge) {
  const cur = store[path] || {};
  const base = merge ? { ...cur } : {};
  for (const [k, v] of Object.entries(data)) {
    if (v && v.__inc !== undefined) base[k] = (cur[k] || 0) + v.__inc;
    else base[k] = v;
  }
  store[path] = base;
}
const snapOf = (path) => ({
  id: path.split("/").pop(),
  exists: path in store,
  data: () => store[path],
  get: (k) => (store[path] ? store[path][k] : undefined),
  ref: refOf(path),
});
function queryOf(colPath, filters = [], order = null, max = Infinity) {
  const q = {
    where: (field, op, value) => queryOf(colPath, [...filters, { field, op, value }], order, max),
    orderBy: (field, dir) => queryOf(colPath, filters, { field, dir }, max),
    limit: (n) => queryOf(colPath, filters, order, n),
    select: () => q,
    startAfter: () => q,
    async get() {
      if (colPath === "users") reads.users += 1;
      const depth = colPath.split("/").length + 1;
      let rows = Object.keys(store)
        .filter((p) => p.startsWith(colPath + "/") && p.split("/").length === depth)
        .map((p) => ({ p, v: store[p] }))
        .filter(({ v }) =>
          filters.every((f) => (f.op === "==" ? v[f.field] === f.value : (v[f.field] || []).includes(f.value)))
        );
      if (order) rows.sort((a, b) => (order.dir === "desc" ? -1 : 1) * ((a.v[order.field] || 0) - (b.v[order.field] || 0)));
      rows = rows.slice(0, max);
      return { docs: rows.map((r) => snapOf(r.p)), size: rows.length, empty: rows.length === 0 };
    },
  };
  return q;
}
function refOf(path) {
  return {
    path,
    id: path.split("/").pop(),
    get: async () => snapOf(path),
    set: async (d, o) => applyWrite(path, d, o && o.merge),
    update: async (d) => applyWrite(path, d, true),
    delete: async () => void delete store[path],
    collection: (name) => colOf(`${path}/${name}`),
    parent: { parent: null },
  };
}
let autoId = 0;
function colOf(colPath) {
  return Object.assign(queryOf(colPath), { doc: (id) => refOf(`${colPath}/${id || "auto" + ++autoId}`) });
}
const fakeDb = {
  collection: colOf,
  async getAll(...refs) { return refs.map((r) => snapOf(r.path)); },
  async runTransaction(fn) {
    const pending = [];
    const tx = {
      get: async (x) => (x.path !== undefined ? snapOf(x.path) : x.get()),
      set: (ref, d, o) => pending.push(() => applyWrite(ref.path, d, o && o.merge)),
      update: (ref, d) => pending.push(() => applyWrite(ref.path, d, true)),
      delete: (ref) => pending.push(() => delete store[ref.path]),
    };
    const out = await fn(tx);
    pending.forEach((f) => f());
    return out;
  },
  batch() {
    const ops = [];
    return { set: (r, d, o) => ops.push(() => applyWrite(r.path, d, o && o.merge)), update: (r, d) => ops.push(() => applyWrite(r.path, d, true)), delete: (r) => ops.push(() => delete store[r.path]), commit: async () => ops.forEach((f) => f()) };
  },
  async recursiveDelete(ref) {
    Object.keys(store).filter((p) => p === ref.path || p.startsWith(ref.path + "/")).forEach((p) => delete store[p]);
  },
};
const fakeAdmin = { firestore: { FieldValue: fv, FieldPath: { documentId: () => "__name__" } } };
const fbPath = require.resolve("../src/config/firebase");
require.cache[fbPath] = { id: fbPath, filename: fbPath, loaded: true, exports: { db: fakeDb, admin: fakeAdmin, auth: {} } };
process.env.FRONTEND_URL = "https://twelve.example";

const mockRes = () => {
  const r = { statusCode: 200, body: null, headers: {} };
  r.status = (c) => ((r.statusCode = c), r);
  r.json = (b) => ((r.body = b), r);
  r.set = (k, v) => ((r.headers[k] = v), r);
  return r;
};
const seed = () => {
  Object.keys(store).forEach((k) => delete store[k]);
  store["users/author"] = { uid: "author", displayName: "Tác Giả", tagName: "tacgia", status: "active", accountGroup: "USER", accountScore: 0, positiveScore: 0, postsScoreSum: 0 };
  store["users/fan"] = { uid: "fan", displayName: "Fan", tagName: "fan", status: "active", accountGroup: "USER", accountScore: 0, positiveScore: 0, postsScoreSum: 0 };
  store["posts/p1"] = { id: "p1", authorUid: "author", title: "Bài", commentCount: 0, externalPostScore: 0, hashtags: ["#Việt"], hashtagsLower: ["#việt"] };
};

test("1. farm điểm bằng bình luận: chỉ bình luận đầu tiên của mỗi (user, bài) có điểm; xoá hoàn đúng", async () => {
  seed();
  const { addComment, deleteComment } = require("../src/controllers/comments.controller");
  const add = addComment("posts");
  const fan = { authUid: "fan", authUser: { uid: "fan", accountGroup: "USER", status: "active" } };
  const ids = [];
  for (let i = 0; i < 5; i++) {
    const res = mockRes();
    await add({ params: { id: "p1" }, body: { content: `c${i}` }, ...fan }, res);
    assert.equal(res.statusCode, 201);
    ids.push(res.body.commentId);
  }
  assert.equal(store["posts/p1"].commentCount, 5, "cả 5 bình luận vẫn được đăng");
  assert.equal(store["posts/p1"].externalPostScore, 3, "chỉ +3 cho tác giả (không phải +15)");
  assert.equal(store["users/fan"].positiveScore, 1, "chỉ +1 cho người bình luận (không phải +5)");
  assert.equal(store[`posts/p1/comments/${ids[0]}`].scored, true);
  assert.equal(store[`posts/p1/comments/${ids[1]}`].scored, false);

  // Xoá bình luận KHÔNG có điểm: không hoàn điểm
  await deleteComment("posts")({ params: { id: "p1", commentId: ids[1] }, ...fan }, mockRes());
  assert.equal(store["posts/p1"].externalPostScore, 3);
  assert.equal(store["users/fan"].positiveScore, 1);
  // Xoá bình luận CÓ điểm: hoàn đúng
  await deleteComment("posts")({ params: { id: "p1", commentId: ids[0] }, ...fan }, mockRes());
  assert.equal(store["posts/p1"].externalPostScore, 0);
  assert.equal(store["users/fan"].positiveScore, 0);

  // Bình luận CŨ (không có field `scored`) vẫn được hoàn điểm khi xoá
  seed();
  store["posts/p1"].externalPostScore = 3; store["posts/p1"].commentCount = 1;
  store["users/fan"].positiveScore = 1;
  store["posts/p1/comments/old"] = { id: "old", authorUid: "fan", content: "cũ" };
  await deleteComment("posts")({ params: { id: "p1", commentId: "old" }, ...fan }, mockRes());
  assert.equal(store["posts/p1"].externalPostScore, 0);
  assert.equal(store["users/fan"].positiveScore, 0);

  // Tác giả tự bình luận: không điểm
  seed();
  const self = { authUid: "author", authUser: { uid: "author", accountGroup: "USER", status: "active" } };
  await add({ params: { id: "p1" }, body: { content: "tự" }, ...self }, mockRes());
  assert.equal(store["posts/p1"].externalPostScore, 0);
});

test("2. email: không còn bỏ dấu chấm / +tag của Gmail", async () => {
  const { validationResult } = require("express-validator");
  const { registerValidators } = require("../src/middleware/validators");
  const req = { body: { email: "  John.Doe+x@Gmail.com ", password: "x" }, headers: {} };
  for (const v of registerValidators.filter((x) => x.run)) await v.run(req);
  assert.equal(req.body.email, "john.doe+x@gmail.com");
  assert.equal(validationResult(req).mapped().email, undefined);
});

test("3. xếp hạng tuần: cache + single-flight (không quét users mỗi request)", async () => {
  seed();
  for (let i = 0; i < 30; i++) store[`users/u${i}`] = { displayName: `U${i}`, status: "active", accountGroup: "USER", accountScore: i, weeklySnapshot: { weekCode: require("../src/utils/weekCode").getWeekInfo().code, accountScoreAtStart: 0 } };
  store["config/trendingState"] = { lastFinalizedWeekCode: require("../src/utils/weekCode").getWeekInfo().code };
  const { getWeeklyRanking, getAllTimeRanking } = require("../src/controllers/trending.controller");
  reads.users = 0;
  const results = await Promise.all(Array.from({ length: 10 }, async () => { const r = mockRes(); await getWeeklyRanking({}, r); return r; }));
  assert.ok(results.every((r) => r.statusCode === 200 && r.body.ranking.length > 0));
  assert.equal(reads.users, 1, "10 request đồng thời chỉ quét users 1 lần");
  for (let i = 0; i < 5; i++) await getWeeklyRanking({}, mockRes());
  assert.equal(reads.users, 1, "request sau đó dùng cache");
  assert.equal(results[0].body.ranking[0].weeklyGrowth, 29);
  reads.users = 0;
  for (let i = 0; i < 5; i++) await getAllTimeRanking({}, mockRes());
  assert.equal(reads.users, 1);
});

test("4. xoá bài: comments/views/reactions bị dọn đệ quy", async () => {
  seed();
  store["posts/p1/comments/c1"] = { authorUid: "fan" };
  store["posts/p1/views/v1"] = {};
  store["posts/p1/reactions/fan"] = { type: "like" };
  store["posts/p2"] = { authorUid: "author" };
  store["posts/p2/comments/c9"] = {};
  const { purgeContentSubcollections } = require("../src/utils/cascade");
  await purgeContentSubcollections(fakeDb, fakeDb.collection("posts").doc("p1"));
  assert.ok(!Object.keys(store).some((k) => k.startsWith("posts/p1/")));
  assert.ok(store["posts/p2/comments/c9"], "bài khác không bị ảnh hưởng");
  // Fallback (SDK không có recursiveDelete)
  store["posts/p3/comments/c1"] = {};
  const noRec = { ...fakeDb, recursiveDelete: undefined };
  await purgeContentSubcollections(noRec, fakeDb.collection("posts").doc("p3"));
  assert.ok(!store["posts/p3/comments/c1"]);
});

test("5. giới hạn riêng cho tạo / sửa bài", async () => {
  const express = require("express");
  const http = require("node:http");
  delete require.cache[require.resolve("../src/middleware/rateLimiters")];
  const { postCreateLimiter } = require("../src/middleware/rateLimiters");
  const app = express();
  app.use((req, res, next) => { req.authUid = "u1"; next(); });
  app.post("/", postCreateLimiter, (req, res) => res.send("ok"));
  const server = http.createServer(app).listen(0);
  try {
    const base = `http://127.0.0.1:${server.address().port}`;
    let last;
    for (let i = 0; i < 21; i++) last = (await fetch(base, { method: "POST" })).status;
    assert.equal(last, 429);
  } finally { server.close(); }
});

test("6. rescan embed: chạy nền, phân trang, cập nhật excerpt, không chặn PUT", async () => {
  seed();
  const sanitize = require("../src/services/sanitize.service");
  sanitize.setEmbedDomainsConfig({ enabled: true, domains: [{ domain: "youtube.com" }] });
  store["posts/p1"].contentHtml = '<p>giữ</p><img src="https://evil.example/x.png"><iframe src="https://evil.example/f"></iframe>';
  store["posts/p1"].excerpt = "cũ";
  store["posts/p2"] = { authorUid: "author", contentHtml: "<p>sạch</p>" };
  store["blogs/b1"] = { authorUid: "author", contentHtml: '<p>b</p><iframe src="https://evil.example/f"></iframe>', isPublished: false };
  const ctrl = require("../src/controllers/embedDomains.controller");
  const out = await ctrl.__test.rescanContentForEmbedDomains();
  assert.equal(out.modified, 2);
  assert.equal(out.failed, 0);
  assert.ok(!store["posts/p1"].contentHtml.includes("evil.example"));
  assert.equal(store["posts/p1"].excerpt, "giữ");
  assert.ok(!store["blogs/b1"].contentHtml.includes("evil.example"));
  assert.equal(store["posts/p2"].contentHtml, "<p>sạch</p>");

  // API PUT trả NGAY running:true; trạng thái đọc được qua endpoint riêng
  store["users/sa"] = { accountGroup: "SA", status: "active" };
  const res = mockRes();
  await ctrl.updateEmbedDomainsSettings({ body: { enabled: true, domains: [{ domain: "youtube.com" }] }, authUid: "sa" }, res);
  assert.deepEqual(res.body.rescan, { running: true });
  await new Promise((r) => setTimeout(r, 300));
  const st = mockRes();
  await ctrl.getEmbedDomainsRescanStatus({}, st);
  assert.equal(st.body.running, false);
  assert.ok(st.body.rescan.scanned >= 3);
});

test("7. tìm kiếm theo tên tác giả giờ ra kết quả", async () => {
  seed();
  store["posts/p1"] = { ...store["posts/p1"], title: "Không liên quan", excerpt: "x", hashtags: [], authorUid: "author", createdAt: 1, likeCount: 0, dislikeCount: 0, commentCount: 0, viewCount: 0, shareCount: 0 };
  store["posts/p2"] = { title: "Cũng thế", excerpt: "y", hashtags: [], authorUid: "fan", createdAt: 2, likeCount: 0, dislikeCount: 0, commentCount: 0, viewCount: 0, shareCount: 0 };
  const { searchTrending } = require("../src/controllers/trending.controller");
  const res = mockRes();
  await searchTrending({ query: { q: "tác giả", type: "post" }, authUid: null }, res);
  assert.equal(res.statusCode, 200);
  assert.equal(res.body.posts.length, 1, "tìm theo displayName tác giả");
  const byTag = mockRes();
  await searchTrending({ query: { q: "@fan", type: "post" }, authUid: null }, byTag);
  assert.equal(byTag.body.posts.length, 1, "tìm theo @tagName");
});

test("8. hashtag không phân biệt hoa/thường + 404 khi trống", async () => {
  seed();
  store["posts/p1"].createdAt = { toMillis: () => 1 };
  const express = require("express");
  const http = require("node:http");
  const path = require("node:path");
  const app = express();
  app.set("views", path.join(__dirname, "../src/views"));
  app.set("view engine", "ejs");
  app.use((req, res, next) => { res.locals.cspNonce = "n"; next(); });
  delete require.cache[require.resolve("../src/routes/ssr.routes")];
  app.use("/", require("../src/routes/ssr.routes"));
  const server = http.createServer(app).listen(0);
  try {
    const base = `http://127.0.0.1:${server.address().port}`;
    const upper = await fetch(`${base}/trending?tab=hashtag&hashtag=${encodeURIComponent("#VIỆT")}`);
    const lower = await fetch(`${base}/trending?tab=hashtag&hashtag=${encodeURIComponent("#việt")}`);
    const hu = await upper.text(), hl = await lower.text();
    assert.equal(upper.status, 200);
    assert.ok(hu.includes("Bài") && hl.includes("Bài"));
    const canon = (h) => h.match(/<link rel="canonical" href="([^"]+)"/)[1];
    assert.equal(canon(hu), canon(hl), "một URL canonical duy nhất");
    const empty = await fetch(`${base}/trending?tab=hashtag&hashtag=${encodeURIComponent("#khongco")}`);
    assert.equal(empty.status, 404);
    assert.match(await empty.text(), /noindex/);
  } finally { server.close(); }
});

test("9. link của người dùng bị ép rel", () => {
  const { sanitizeHtml } = require("../src/services/sanitize.service");
  const out = sanitizeHtml('<a href="https://evil.com" target="_blank" rel="dofollow">x</a><a href="/post/1" rel="me">y</a><a name="z">w</a>');
  assert.match(out, /href="https:\/\/evil\.com"[^>]*rel="ugc nofollow noopener"/);
  assert.match(out, /href="\/post\/1"[^>]*rel="noopener"/);
  assert.ok(!/dofollow/.test(out) && !/rel="me"/.test(out));
});

test("10. ảnh bìa phải thuộc domain được phép (ảnh cũ không đổi thì được giữ)", () => {
  const { setEmbedDomainsConfig } = require("../src/services/sanitize.service");
  const { validateCoverImageUrl } = require("../src/utils/helpers");
  setEmbedDomainsConfig({ enabled: true, domains: [{ domain: "res.cloudinary.com", path: "mine" }] });
  assert.equal(validateCoverImageUrl("https://res.cloudinary.com/mine/a.png"), null);
  assert.match(validateCoverImageUrl("https://evil.example/a.png"), /domain/);
  assert.match(validateCoverImageUrl("http://res.cloudinary.com/mine/a.png"), /https/);
  assert.equal(validateCoverImageUrl("https://old.example/a.png", "https://old.example/a.png"), null, "không đổi thì không chặn");
  assert.equal(validateCoverImageUrl(""), null);
});
