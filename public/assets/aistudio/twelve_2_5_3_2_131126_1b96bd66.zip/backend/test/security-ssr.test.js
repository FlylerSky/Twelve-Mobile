// Kiểm thử bản vá v2.0.4 (báo cáo 1): blog nháp, bơm view, rate-limit, SSR/SEO.
// Dùng Firestore GIẢ (in-memory) + Express thật — không cần mạng hay service account.
const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");
const http = require("node:http");
const express = require("express");

// ------------------------------------------------------------ Firestore giả
const ts = (iso) => {
  const d = new Date(iso);
  return { toMillis: () => d.getTime(), toDate: () => d, _seconds: Math.floor(d.getTime() / 1000) };
};
const DATA = {
  users: {
    u1: { uid: "u1", displayName: "An", tagName: "annguyen", status: "active", accountGroup: "USER", accountRole: "user", createdAt: ts("2026-01-01") },
    u2: { uid: "u2", displayName: "Binh", tagName: "binh", status: "pending", accountGroup: "USER", accountRole: "user" },
    u3: { uid: "u3", displayName: "Chi", tagName: "chi", status: "suspended", accountGroup: "USER", accountRole: "user" },
    u4: { uid: "u4", displayName: "Dung", tagName: "dung", status: "active", accountGroup: "USER", accountRole: "user" },
  },
  // v2.4.2.1: URL hồ sơ là /u/@<tag> — Tag Name tra qua collection `tagNames` (doc id = tag, giá trị { uid }).
  tagNames: {
    annguyen: { uid: "u1" },
    binh: { uid: "u2" },
    chi: { uid: "u3" },
    dung: { uid: "u4" },
  },
  posts: {
    p1: { id: "p1", authorUid: "u1", title: "Bài một", contentHtml: "<p>Nội dung</p>", excerpt: "Nội dung", hashtags: ["#a"], createdAt: ts("2026-03-01"), viewCount: 5 },
    p2: { id: "p2", authorUid: "u1", title: "Bài hai", contentHtml: "<p>Hai</p>", excerpt: "Hai", hashtags: ["#a"], createdAt: ts("2026-04-01") },
  },
  blogs: {
    b1: { id: "b1", authorUid: "u1", title: "Blog xuất bản", contentHtml: "<p>B</p>", excerpt: "B", hashtags: ["#a"], isPublished: true, createdAt: ts("2026-02-01") },
    b2: { id: "b2", authorUid: "u1", title: "BLOG NHÁP BÍ MẬT", contentHtml: "<p>secret</p>", excerpt: "secret", hashtags: ["#a", "#solo"], isPublished: false, createdAt: ts("2026-05-01") },
  },
};
let txCount = 0;
let reads = 0;
const matches = (row, f) =>
  f.op === "==" ? row[f.field] === f.value : f.op === "array-contains" ? (row[f.field] || []).includes(f.value) : false;
function makeQuery(name, filters = [], order = null, max = Infinity) {
  const q = {
    where: (field, op, value) => makeQuery(name, [...filters, { field, op, value }], order, max),
    orderBy: (field, dir) => makeQuery(name, filters, { field, dir }, max),
    limit: (n) => makeQuery(name, filters, order, n),
    select: () => q,
    async get() {
      reads += 1;
      let rows = Object.entries(DATA[name] || {}).map(([id, v]) => ({ id, v })).filter(({ v }) => filters.every((f) => matches(v, f)));
      if (order) rows.sort((a, b) => (order.dir === "desc" ? -1 : 1) * (a.v[order.field].toMillis() - b.v[order.field].toMillis()));
      rows = rows.slice(0, max);
      return { docs: rows.map(({ id, v }) => ({ id, exists: true, data: () => v, get: (k) => v[k] })), size: rows.length };
    },
  };
  return q;
}
const fakeDb = {
  collection(name) {
    return Object.assign(makeQuery(name), {
      doc(id) {
        return {
          id,
          async get() {
            const v = (DATA[name] || {})[id];
            return { id, exists: !!v, data: () => v, get: (k) => v && v[k] };
          },
          async update() {},
          collection: () => ({ doc: () => ({ get: async () => ({ exists: false, data: () => ({}) }) }) }),
          __col: name,
        };
      },
    });
  },
  async getAll(...refs) {
    reads += 1;
    return refs
      .filter((r) => r && r.__col)
      .map((r) => {
        const v = (DATA[r.__col] || {})[r.id];
        return { id: r.id, exists: !!v, get: (k) => v && v[k] };
      });
  },
  async runTransaction(fn) {
    txCount += 1;
    return fn({ get: async () => ({ exists: false, data: () => ({}) }), set() {}, update() {} });
  },
  batch: () => ({ set() {}, update() {}, commit: async () => {} }),
};
const fakeAdmin = { firestore: { FieldValue: { increment: (n) => ({ n }), serverTimestamp: () => ({}) } } };

const fbPath = require.resolve("../src/config/firebase");
require.cache[fbPath] = { id: fbPath, filename: fbPath, loaded: true, exports: { db: fakeDb, admin: fakeAdmin, auth: {} } };

process.env.FRONTEND_URL = "https://twelve.example";
process.env.SSR_PROXY_SECRET = "top-secret";

function buildApp() {
  const app = express();
  app.set("views", path.join(__dirname, "../src/views"));
  app.set("view engine", "ejs");
  app.use((req, res, next) => {
    res.locals.cspNonce = "nonce123";
    next();
  });
  app.use("/", require("../src/routes/ssr.routes"));
  return app;
}
function listen(app) {
  return new Promise((resolve) => {
    const server = http.createServer(app).listen(0, () => resolve({ server, base: `http://127.0.0.1:${server.address().port}` }));
  });
}
const TRUSTED = { "x-twelve-ssr-secret": "top-secret", "x-twelve-client-ip": "9.9.9.9", "user-agent": "Googlebot/2.1" };

test("SSR", async (t) => {
  const { server, base } = await listen(buildApp());
  t.after(() => server.close());
  const get = (p, headers = {}, extra = {}) => fetch(base + p, { headers, ...extra });

  await t.test("blog NHÁP => 404, không lộ nội dung", async () => {
    const r = await get("/blog/b2", TRUSTED);
    assert.equal(r.status, 404);
    assert.ok(!(await r.text()).includes("BÍ MẬT"));
  });

  await t.test("blog đã xuất bản => 200, canonical + JSON-LD hợp lệ, không còn biến toàn cục chết", async () => {
    const r = await get("/blog/b1", TRUSTED);
    assert.equal(r.status, 200);
    const html = await r.text();
    assert.match(html, /<link rel="canonical" href="https:\/\/twelve\.example\/blog\/b1"/);
    assert.match(html, /<title>Blog xuất bản \| Twelve Blog<\/title>/);
    assert.ok(!html.includes("__TWELVE_SSR"));
    assert.ok(!html.includes("additionalProperty"));
    assert.match(html, /og-default\.png/); // ảnh OG mặc định khi không có ảnh bìa
    assert.match(html, /summary_large_image/);
    assert.match(html, /\?spa=1/); // link "Mở bản đầy đủ" không vòng lặp
    assert.equal(r.headers.get("x-twelve-ssr-trusted"), "1");
  });

  await t.test("post: title/section đúng", async () => {
    const html = await (await get("/post/p1", TRUSTED)).text();
    assert.match(html, /<title>Bài một \| Twelve<\/title>/);
  });

  // v2.5.3 [TW-20]: content.ejs in HTML thô — bài cũ còn HTML nguy hiểm (lưu trước khi đổi bộ lọc) không được hiện ra ở SSR; bài sạch không bị đổi.
  await t.test("TW-20: SSR làm sạch lại HTML đã lưu có script/on*/javascript: trước khi in; bài sạch giữ nguyên", async () => {
    process.env.SANITIZE_WORKER = "off";
    DATA.posts.pDirty = { id: "pDirty", authorUid: "u1", title: "Bài cũ còn HTML dơ", contentHtml: '<p class="ql-align-center">phần lành</p><script>window.__pwn=1</script><img src="https://x.example/a.png" onerror="window.__pwn=2"><a href="javascript:alert(3)">link</a>', excerpt: "phần lành", hashtags: ["#a"], createdAt: ts("2026-05-02") };
    const origWarn = console.warn; console.warn = () => {};
    try {
      const html = await (await get("/post/pDirty", TRUSTED)).text();
      const body = html.slice(html.indexOf('class="post-content"'));
      assert.ok(body.includes("phần lành"), "phần hợp lệ vẫn hiện");
      assert.ok(!/window\.__pwn|onerror=|javascript:alert/.test(body), body.slice(0, 400));
      assert.match(body, /ql-align-center/);
      const clean = await (await get("/post/p1", TRUSTED)).text();
      assert.ok(clean.includes("<p>Nội dung</p>"), "bài sạch giữ nguyên");
    } finally { console.warn = origWarn; delete DATA.posts.pDirty; }
  });

  await t.test("hashtag: KHÔNG liệt kê blog nháp; sắp xếp mới nhất trước", async () => {
    const r = await get("/trending?tab=hashtag&hashtag=%23a", TRUSTED);
    const html = await r.text();
    assert.ok(!html.includes("BLOG NHÁP"));
    assert.ok(html.indexOf("Bài hai") < html.indexOf("Bài một"));
    assert.ok(html.includes("Blog xuất bản"));
    assert.ok(!/content="noindex/.test(html));
  });

  await t.test("hashtag chỉ có blog nháp => noindex (không soft-404)", async () => {
    const html = await (await get("/trending?tab=hashtag&hashtag=%23solo", TRUSTED)).text();
    assert.ok(!html.includes("BLOG NHÁP"));
    assert.match(html, /<meta name="robots" content="noindex, follow"/);
  });

  await t.test("profile: dùng field `status` — pending 404, suspended noindex + ẩn bài, active index (URL = /u/@<tag>)", async () => {
    assert.equal((await get("/u/@binh", TRUSTED)).status, 404);
    const sus = await (await get("/u/@chi", TRUSTED)).text();
    assert.match(sus, /content="noindex, nofollow"/);
    const ok = await (await get("/u/@annguyen", TRUSTED)).text();
    assert.match(ok, /content="index, follow/);
    assert.ok(ok.indexOf("Bài hai") < ok.indexOf("Bài một"));
    const empty = await (await get("/u/@dung", TRUSTED)).text();
    assert.match(empty, /content="noindex, follow"/);
  });

  await t.test("profile v2.4.2.1: canonical là /u/@<tag> — không còn UID trong canonical, JSON-LD hay link tác giả", async () => {
    const html = await (await get("/u/@annguyen", TRUSTED)).text();
    assert.match(html, /<link rel="canonical" href="https:\/\/twelve\.example\/u\/@annguyen"/);
    assert.ok(!html.includes("/u/u1"), "trang hồ sơ không được chứa URL /u/<UID>");
    const post = await (await get("/post/p1", TRUSTED)).text();
    assert.ok(post.includes("https://twelve.example/u/@annguyen"), "link tác giả trong bài viết = /u/@<tag>");
    assert.ok(!post.includes("/u/u1"), "link tác giả không được lộ UID");
  });

  await t.test("profile v2.4.2.1: link CŨ /u/<UID> => 301 sang /u/@<tag>; /u/@AnNguyen (chữ hoa) => 301 về dạng chuẩn", async () => {
    const legacy = await get("/u/u1", TRUSTED, { redirect: "manual" });
    assert.equal(legacy.status, 301);
    assert.equal(legacy.headers.get("location"), "https://twelve.example/u/@annguyen");

    const upper = await get("/u/@AnNguyen", TRUSTED, { redirect: "manual" });
    assert.equal(upper.status, 301);
    assert.equal(upper.headers.get("location"), "https://twelve.example/u/@annguyen");

    const encodedAt = await get("/u/%40ANNGUYEN", TRUSTED, { redirect: "manual" });
    assert.equal(encodedAt.status, 301);
    assert.equal(encodedAt.headers.get("location"), "https://twelve.example/u/@annguyen");
  });

  await t.test("profile v2.4.2.1: '@' là bắt buộc — tag KHÔNG có '@' và /u/myProfile KHÔNG phải URL hồ sơ công khai => 404 (không nhầm với route phụ)", async () => {
    for (const p of ["/u/annguyen", "/u/ANNGUYEN", "/u/myProfile", "/u/myprofile", "/u/@ab", "/u/@a-b", "/u/@"]) {
      const r = await get(p, TRUSTED, { redirect: "manual" });
      assert.equal(r.status, 404, p);
      assert.equal(r.headers.get("x-robots-tag"), "noindex", p);
    }
  });

  await t.test("profile v2.4.2.1: UID của hồ sơ pending/không tồn tại KHÔNG chuyển hướng (không lộ tag); tag lạ 404", async () => {
    assert.equal((await get("/u/u2", TRUSTED, { redirect: "manual" })).status, 404); // pending
    assert.equal((await get("/u/@khongco", TRUSTED, { redirect: "manual" })).status, 404);
    assert.equal((await get("/u/u9", TRUSTED, { redirect: "manual" })).status, 404);
    assert.equal((await get("/u/a%2Fb", TRUSTED, { redirect: "manual" })).status, 404);
  });

  await t.test("trang chủ / blog SSR: chỉ blog đã xuất bản", async () => {
    const home = await get("/__ssr/home", TRUSTED);
    assert.equal(home.status, 200);
    const blog = await (await get("/__ssr/blog", TRUSTED)).text();
    assert.ok(blog.includes("Blog xuất bản") && !blog.includes("BLOG NHÁP"));
  });

  await t.test("NODE_ENV=production: chỉ request có secret mới cộng view", async () => {
    const prev = process.env.NODE_ENV;
    process.env.NODE_ENV = "production";
    try {
      txCount = 0;
      const spoof = await get("/post/p1", { "user-agent": "Googlebot/2.1", "x-forwarded-for": "1.2.3.4" });
      assert.equal(spoof.status, 200);
      assert.equal(spoof.headers.get("x-twelve-ssr-trusted"), "0");
      await new Promise((r) => setTimeout(r, 50));
      assert.equal(txCount, 0, "request giả UA/XFF không được cộng view");

      const wrong = await get("/post/p1", { ...TRUSTED, "x-twelve-ssr-secret": "sai" });
      await new Promise((r) => setTimeout(r, 50));
      assert.equal(wrong.headers.get("x-twelve-ssr-trusted"), "0");
      assert.equal(txCount, 0);

      await get("/post/p1", TRUSTED);
      await new Promise((r) => setTimeout(r, 50));
      assert.ok(txCount >= 1, "request có secret đúng được cộng view");
    } finally {
      process.env.NODE_ENV = prev;
    }
  });
});

test("clientIp / viewerKey không tin header do client đặt", () => {
  const { getClientIp, isTrustedSsrProxy } = require("../src/utils/clientIp");
  const { viewerKeyFromRequest } = require("../src/utils/helpers");
  const mk = (headers, ip = "10.0.0.1") => ({ headers, ip, socket: { remoteAddress: ip } });

  const a = mk({ "x-forwarded-for": "1.1.1.1" });
  const b = mk({ "x-forwarded-for": "2.2.2.2" });
  assert.equal(viewerKeyFromRequest(a), viewerKeyFromRequest(b), "đổi X-Forwarded-For không được đổi viewerKey");

  const fakeHeader = mk({ "x-twelve-client-ip": "6.6.6.6" });
  assert.equal(isTrustedSsrProxy(fakeHeader), false);
  assert.equal(getClientIp(fakeHeader), "10.0.0.1");

  const real = mk({ "x-twelve-ssr-secret": "top-secret", "x-twelve-client-ip": "7.7.7.7" });
  assert.equal(getClientIp(real), "7.7.7.7");
  assert.notEqual(viewerKeyFromRequest(real), viewerKeyFromRequest(fakeHeader));

  const badIp = mk({ "x-twelve-ssr-secret": "top-secret", "x-twelve-client-ip": "<script>" });
  assert.equal(getClientIp(badIp), "10.0.0.1");
});

test("viewLimiter: UA 'Googlebot' giả + XFF ngẫu nhiên vẫn bị chặn ở 150 request", async (t) => {
  delete require.cache[require.resolve("../src/middleware/rateLimiters")];
  const { viewLimiter } = require("../src/middleware/rateLimiters");
  const app = express(); // không bật trust proxy => req.ip là địa chỉ socket (mô phỏng "sau LB đã ghi IP thật")
  app.get("/x", viewLimiter, (req, res) => res.send("ok"));
  const { server, base } = await listen(app);
  t.after(() => server.close());
  let last = 200;
  for (let i = 0; i < 151; i++) {
    const r = await fetch(base + "/x", { headers: { "user-agent": "Googlebot/2.1", "x-forwarded-for": `10.1.${i % 250}.${i % 200}` } });
    last = r.status;
  }
  assert.equal(last, 429);

  // Crawler ĐÃ XÁC THỰC qua middleware Vercel: hạn mức nới, nhưng khoá theo IP thật chuyển tiếp.
  const hdr = { "user-agent": "Googlebot/2.1", "x-twelve-ssr-secret": "top-secret", "x-twelve-client-ip": "8.8.8.8" };
  let ok = 0;
  for (let i = 0; i < 160; i++) ok += (await fetch(base + "/x", { headers: hdr })).status === 200 ? 1 : 0;
  assert.equal(ok, 160);
});

test("isHiddenDraft / canViewDraft", () => {
  const { isHiddenDraft, canViewDraft } = require("../src/utils/visibility");
  assert.equal(isHiddenDraft("blogs", { isPublished: false }), true);
  assert.equal(isHiddenDraft("blogs", {}), true);
  assert.equal(isHiddenDraft("blogs", { isPublished: true }), false);
  assert.equal(isHiddenDraft("posts", { isPublished: false }), false);
  const draft = { authorUid: "a1", isPublished: false };
  assert.equal(canViewDraft({}, draft), false);
  assert.equal(canViewDraft({ authUid: "x", authUser: { status: "active", accountGroup: "USER" } }, draft), false);
  assert.equal(canViewDraft({ authUid: "a1", authUser: { status: "active", accountGroup: "USER" } }, draft), true);
  assert.equal(canViewDraft({ authUid: "s", authUser: { status: "active", accountGroup: "SA" } }, draft), true);
  assert.equal(canViewDraft({ authUid: "s", authUser: { status: "suspended", accountGroup: "SA" } }, draft), false);
});

// ------------------------------------------------------------ Sitemap
test("sitemap: index + chunk, chỉ nội dung công khai, ?refresh=1 cần token", async (t) => {
  delete process.env.SITEMAP_REFRESH_TOKEN;
  delete require.cache[require.resolve("../src/controllers/seo.controller")];
  delete require.cache[require.resolve("../src/routes/seo.routes")];
  const app = express();
  app.use("/", require("../src/routes/seo.routes"));
  const { server, base } = await listen(app);
  t.after(() => server.close());

  const idx = await (await fetch(base + "/sitemap.xml")).text();
  assert.match(idx, /<sitemapindex/);
  assert.match(idx, /https:\/\/twelve\.example\/sitemap-1\.xml/);

  const chunkRes = await fetch(base + "/sitemap-1.xml");
  assert.equal(chunkRes.status, 200);
  const xml = await chunkRes.text();
  assert.ok(xml.includes("/post/p1") && xml.includes("/post/p2"));
  assert.ok(xml.includes("/blog/b1"), "blog đã xuất bản có trong sitemap");
  assert.ok(!xml.includes("/blog/b2"), "blog nháp KHÔNG có trong sitemap");
  assert.ok(xml.includes("https://twelve.example/u/@annguyen</loc>"), "tác giả active có bài — URL hồ sơ là /u/@<tag> (v2.4.2.1)");
  assert.ok(!xml.includes("/u/u1"), "sitemap không được lộ UID");
  assert.ok(!xml.includes("/u/@binh") && !xml.includes("/u/@chi") && !xml.includes("/u/u2") && !xml.includes("/u/u3"));
  assert.ok(xml.includes("hashtag=%23a"), "hashtag dùng >= 2 lần");
  assert.ok(!xml.includes("solo"), "hashtag chỉ có ở blog nháp không lọt vào");
  assert.match(xml, /<loc>https:\/\/twelve\.example\/<\/loc><lastmod>2026-04-01/, "lastmod trang chủ = bài mới nhất, không phải hôm nay");
  assert.equal((await fetch(base + "/sitemap-9.xml")).status, 404);

  const before = reads;
  await fetch(base + "/sitemap.xml?refresh=1"); // không token
  await fetch(base + "/sitemap.xml?refresh=1", { headers: { "x-sitemap-token": "doan" } }); // chưa cấu hình token
  assert.equal(reads, before, "refresh không token không được đọc Firestore");

  process.env.SITEMAP_REFRESH_TOKEN = "tok";
  await fetch(base + "/sitemap.xml?refresh=1", { headers: { "x-sitemap-token": "sai" } });
  assert.equal(reads, before, "token sai bị bỏ qua");
  await fetch(base + "/sitemap.xml?refresh=1", { headers: { "x-sitemap-token": "tok" } });
  assert.ok(reads > before, "token đúng ép dựng lại");
  const afterForce = reads;
  await fetch(base + "/sitemap.xml?refresh=1", { headers: { "x-sitemap-token": "tok" } }); // trong 60s
  assert.equal(reads, afterForce, "giới hạn tần suất ép dựng lại");
});

// ------------------------------------------------------------ API getBlog / comments / share
function mockRes() {
  const res = { statusCode: 200, body: null };
  res.status = (c) => ((res.statusCode = c), res);
  res.json = (b) => ((res.body = b), res);
  return res;
}

test("API: blog nháp 404 cho khách, xem được bởi tác giả/SA, không bị đếm view; bình luận + share cũng bị chặn", async () => {
  const blogCtrl = require("../src/controllers/blog.controller");
  const comments = require("../src/controllers/comments.controller");
  const { createShareLink } = require("../src/controllers/share.controller");

  let res = mockRes();
  await blogCtrl.getBlog({ params: { id: "b2" }, query: {}, headers: {} }, res);
  assert.equal(res.statusCode, 404);

  const stranger = { authUid: "u4", authUser: { uid: "u4", status: "active", accountGroup: "USER" } };
  res = mockRes();
  await blogCtrl.getBlog({ params: { id: "b2" }, query: {}, headers: {}, ...stranger }, res);
  assert.equal(res.statusCode, 404);

  txCount = 0;
  res = mockRes();
  await blogCtrl.getBlog({ params: { id: "b2" }, query: {}, headers: {}, authUid: "u1", authUser: { uid: "u1", status: "active", accountGroup: "USER" } }, res);
  assert.equal(res.statusCode, 200);
  assert.equal(res.body.blog.title, "BLOG NHÁP BÍ MẬT");
  assert.equal(txCount, 0, "xem trước bản nháp không cộng view");

  res = mockRes();
  await blogCtrl.getBlog({ params: { id: "b1" }, query: {}, headers: {} }, res);
  assert.equal(res.statusCode, 200);

  res = mockRes();
  await comments.listComments("blogs")({ params: { id: "b2" }, query: {} }, res);
  assert.equal(res.statusCode, 404);

  res = mockRes();
  await createShareLink("blogs", "/blog")({ params: { id: "b2" } }, res);
  assert.equal(res.statusCode, 404);
});
