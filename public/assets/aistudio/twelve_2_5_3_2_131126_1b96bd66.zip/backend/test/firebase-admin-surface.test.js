// v2.0.12 — Bảo vệ khi nâng firebase-admin (F5): kiểm tra BỀ MẶT API mà Twelve thực sự dùng trên chính thư viện đã cài
// (không phải bản giả), KHÔNG gọi mạng. Ghi chú: firebase-admin@14 bỏ hẳn `admin.firestore.*` / `admin.auth()` /
// `admin.credential` (chỉ còn API module `firebase-admin/firestore`…) nên nâng lên 14 mà chưa sửa mã sẽ làm test này FAIL.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { generateKeyPairSync } = require("node:crypto");

const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, "../node_modules/firebase-admin/package.json"), "utf8"));
const admin = require("firebase-admin");

test(`firebase-admin@${pkg.version}: API namespace mà Twelve dùng còn đầy đủ`, () => {
  const hint = `firebase-admin@${pkg.version} không còn API mà Twelve dùng (admin.firestore.FieldValue/FieldPath, admin.auth(), admin.credential). ` +
    "Nâng lên 14+ cần chuyển config/firebase.js và ~15 chỗ dùng admin.firestore.* sang API module (firebase-admin/firestore, /auth, /app).";
  assert.equal(typeof admin.initializeApp, "function", hint);
  assert.equal(typeof admin.credential && typeof admin.credential.cert, "function", hint);
  assert.equal(typeof admin.firestore, "function", hint);
  assert.equal(typeof admin.auth, "function", hint);
  assert.equal(typeof admin.firestore.FieldValue.increment, "function", hint);
  assert.equal(typeof admin.firestore.FieldValue.serverTimestamp, "function", hint);
  assert.equal(typeof admin.firestore.FieldPath.documentId, "function", hint);
  assert.ok(Array.isArray(admin.apps), hint);
});

test("khởi tạo bằng khoá service account (PEM) và các phương thức Twelve gọi đều tồn tại", () => {
  const { privateKey } = generateKeyPairSync("rsa", { modulusLength: 2048, privateKeyEncoding: { type: "pkcs8", format: "pem" }, publicKeyEncoding: { type: "spki", format: "pem" } });
  const app = admin.initializeApp(
    { credential: admin.credential.cert({ projectId: "demo-twelve", clientEmail: "x@demo-twelve.iam.gserviceaccount.com", privateKey }) },
    "surface-test"
  );
  const db = app.firestore();
  const auth = app.auth();
  for (const m of ["collection", "doc", "batch", "runTransaction", "getAll", "recursiveDelete", "collectionGroup", "settings"]) {
    assert.equal(typeof db[m], "function", `db.${m}`);
  }
  for (const m of ["verifyIdToken", "getUser", "getUserByEmail", "createUser", "deleteUser", "updateUser", "listUsers"]) {
    assert.equal(typeof auth[m], "function", `auth.${m}`);
  }
  db.settings({ ignoreUndefinedProperties: true });
});

test("mã nguồn Twelve không dùng API firebase-admin nào ngoài danh sách đã kiểm", () => {
  // Quét `admin.<x>` / `admin.firestore.<y>` trong src+scripts để phát hiện API mới chưa được kiểm ở trên.
  const known = new Set(["firestore", "auth", "credential", "initializeApp", "apps"]);
  const knownFs = new Set(["FieldValue", "FieldPath"]);
  const unknown = [];
  const walk = (dir) => fs.readdirSync(dir, { withFileTypes: true }).forEach((e) => {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) return walk(p);
    if (!e.name.endsWith(".js")) return;
    const text = fs.readFileSync(p, "utf8").replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");
    for (const m of text.matchAll(/\badmin\.firestore\.(\w+)/g)) if (!knownFs.has(m[1])) unknown.push(`${p}: admin.firestore.${m[1]}`);
    for (const m of text.matchAll(/\badmin\.(\w+)/g)) if (!known.has(m[1])) unknown.push(`${p}: admin.${m[1]}`);
  });
  walk(path.join(__dirname, "../src"));
  walk(path.join(__dirname, "../scripts"));
  assert.deepEqual(unknown, [], "API firebase-admin mới chưa được kiểm trong bề mặt trên");
});
