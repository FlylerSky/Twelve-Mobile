// v2.4.0 — Trang Profile: hệ huy hiệu, ảnh bìa (tải lên + URL ngoài), ghim bài lên Trang chủ hồ sơ, danh sách bài theo người dùng.
// Chạy: node --test test/profile-240.test.js
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const path = require("node:path");
const express = require("express");

const { install } = require("./helpers/fakeFirebase");
const nowSec = () => Math.floor(Date.now() / 1000);
const fb = install({
  tokens: { tA: "uA", tB: "uB", tSA: "uSA", tPend: "uPend" },
  authTimes: { tA: nowSec() - 10, tB: nowSec() - 10, tSA: nowSec() - 10, tPend: nowSec() - 10 },
});
const S = fb.store;

// ---- Cloudinary giả (đặt TRƯỚC khi nạp assets.service) ----
const cld = { calls: [], config: { cloud_name: "demo", api_key: "k", api_secret: "s" } };
const cloudinaryMock = {
  config: () => cld.config,
  uploader: {
    destroy: async (pid) => void cld.calls.push(["destroy", pid]),
    upload_stream: (opts, cb) => ({
      end: (buf) => {
        cld.calls.push(["upload", opts.public_id, buf.length, opts.overwrite, opts.transformation && opts.transformation[0]]);
        cb(null, {
          secure_url: `https://res.cloudinary.com/demo/image/upload/v7/${opts.public_id}.jpg`,
          public_id: opts.public_id,
          bytes: buf.length,
          format: "jpg",
          width: 1500,
          height: 500,
          version: 7,
        });
      },
    }),
  },
  api: {
    delete_resources_by_prefix: async (prefix) => void cld.calls.push(["prefix", prefix]) || {},
    delete_resources: async (ids) => void cld.calls.push(["ids", ids]) || {},
  },
};
const cloudinaryPath = require.resolve(path.join(__dirname, "../src/config/cloudinary.js"));
require.cache[cloudinaryPath] = { id: cloudinaryPath, filename: cloudinaryPath, loaded: true, exports: cloudinaryMock };

const badges = require("../src/utils/badges");
const helpers = require("../src/utils/helpers");
const sanitize = require("../src/services/sanitize.service");
const limiters = require("../src/middleware/rateLimiters");
const { PROFILE } = require("../src/utils/constants");

const app = express();
app.use(express.json());
app.use("/api/users", require("../src/routes/users.routes"));
app.use("/api/posts", require("../src/routes/posts.routes"));
let base;
let server;
test.before(async () => {
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

const call = async (method, url, token, body) => {
  const res = await fetch(base + url, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json = null;
  try { json = await res.json(); } catch (_e) { /* không có body */ }
  return { status: res.status, body: json };
};
// multipart: field "cover" với nội dung `bytes`, mime khai báo `type`
const uploadCover = async (token, bytes, type = "image/png", field = "cover", crop = undefined) => {
  const fd = new FormData();
  fd.append(field, new Blob([bytes], { type }), "cover.png");
  if (crop !== undefined) fd.append("crop", typeof crop === "string" ? crop : JSON.stringify(crop));
  const res = await fetch(base + "/api/users/me/cover", { method: "POST", headers: token ? { Authorization: `Bearer ${token}` } : {}, body: fd });
  let json = null;
  try { json = await res.json(); } catch (_e) { /* không có body */ }
  return { status: res.status, body: json };
};
// PNG 1x1 THẬT (file-type đọc cả cấu trúc chunk, không chỉ 8 byte đầu).
const PNG = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", "base64");

const reset = () => {
  for (const uid of ["uA", "uB", "uSA", "uPend"]) {
    limiters.pinLimiter.resetKey(`uid:${uid}`);
    limiters.coverUploadLimiter.resetKey(`uid:${uid}`);
    limiters.profileWriteLimiter.resetKey(`uid:${uid}`);
  }
  Object.keys(S).forEach((k) => delete S[k]);
  cld.calls.length = 0;
  cld.config = { cloud_name: "demo", api_key: "k", api_secret: "s" };
  sanitize.setEmbedDomainsConfig({ enabled: true, domains: [{ domain: "img.example.com", path: "" }] });
};
const seedUser = (uid, over = {}) => {
  S[`users/${uid}`] = { uid, displayName: `Tên ${uid}`, tagName: `tag_${uid.toLowerCase()}`, status: "active", accountGroup: "RA", accountRole: "user", country: "VN", accountScore: 0, ...over };
};
let seq = 0;
const seedPost = (id, authorUid, over = {}) => {
  S[`posts/${id}`] = { id, authorUid, title: `Bài ${id}`, contentHtml: "<p>x</p>", excerpt: "x", coverImageUrl: null, hashtags: [], likeCount: 0, dislikeCount: 0, commentCount: 0, viewCount: 0, aiViewCount: 0, shareCount: 0, postScore: 0, createdAt: new Date(2026, 0, 1, 0, 0, ++seq), ...over };
};

// =========================================================== huy hiệu
// Bảng ca CHUNG với frontend/tests/badges.test.js (hai phía phải ra cùng kết quả).
const BADGE_CASES = [
  [{ accountRole: "user" }, []],
  [{ accountRole: "admin" }, ["admin"]],
  [{ accountRole: "dev" }, ["dev"]],
  [{ accountRole: "moderator" }, ["moderator"]],
  [{ accountRole: "pro_user" }, ["pro"]],
  [{ accountRole: "test" }, ["tester"]],
  [{ accountRole: "user", isLegacyMember: true }, ["legacy"]],
  [{ accountRole: "admin", isLegacyMember: true }, ["admin", "legacy"]],
  [{ accountRole: "pro_user", isLegacyMember: true }, ["pro", "legacy"]],
  [{ accountRole: "ghost-role", isLegacyMember: false }, []],
  // v2.4.1 — NHÓM (accountGroup) là căn cứ chính: SA đặt tay thường vẫn mang accountRole "user" từ lúc đăng ký.
  [{ accountGroup: "SA", accountRole: "user" }, ["sa"]],
  [{ accountGroup: "SA" }, ["sa"]],
  [{ accountGroup: "SA", accountRole: "moderator" }, ["moderator"]],
  [{ accountGroup: "SA", accountRole: "pro_user" }, ["sa"]],
  [{ accountGroup: "SA", accountRole: "user", isLegacyMember: true }, ["sa", "legacy"]],
  [{ accountGroup: "RA", accountRole: "admin" }, []], // nhóm RA: không có quyền SA thì không được huy hiệu SA dù vai trò ghi admin
  [{ accountGroup: "RA", accountRole: "pro_user" }, ["pro"]],
  [{ accountGroup: "RA", accountRole: "user" }, []],
  [{ accountGroup: "LLA", accountRole: "user" }, ["tester"]],
  [{ accountGroup: "LLA" }, ["tester"]],
  [{ isLegacyMember: "true" }, []], // chỉ đúng kiểu boolean true mới tính
  [{}, []],
  [null, []],
  [undefined, []],
];
test("huy hiệu: badgeIdsForUser đúng cho mọi tổ hợp vai trò × thành viên cũ (bảng dùng chung với frontend)", () => {
  for (const [input, expected] of BADGE_CASES) {
    assert.deepEqual(badges.badgeIdsForUser(input), expected, JSON.stringify(input));
  }
});

test("huy hiệu: tài khoản SA đặt tay (accountGroup=SA, accountRole vẫn là 'user') PHẢI có huy hiệu — ca khiến 2.4.0 không hiện huy hiệu", async () => {
  reset();
  seedUser("uA", { accountGroup: "SA", accountRole: "user" });
  const pub = await call("GET", "/api/users/uA");
  assert.deepEqual(pub.body.user.badges, ["sa"]);
  seedPost("p1", "uA");
  const list = await call("GET", "/api/users/uA/posts");
  assert.deepEqual(list.body.posts[0].author.badges, ["sa"], "cả tác giả trên thẻ bài");
  const me = await call("GET", "/api/users/me", "tA");
  assert.deepEqual(me.body.user.badges, ["sa"]);
});

test("huy hiệu: mọi vai trò tài khoản có trong hệ thống đều được định nghĩa rõ (có huy hiệu hoặc cố ý không có)", () => {
  const { ACCOUNT_ROLE } = require("../src/utils/constants");
  const NO_BADGE_ON_PURPOSE = new Set([ACCOUNT_ROLE.USER]);
  for (const role of Object.values(ACCOUNT_ROLE)) {
    const has = badges.badgeIdsForUser({ accountRole: role }).length === 1;
    assert.equal(has, !NO_BADGE_ON_PURPOSE.has(role), `vai trò ${role}`);
  }
});

test("huy hiệu: toPublicUser (tác giả ở mọi thẻ) có `badges`; ảnh bìa CHỈ ở toPublicProfile", () => {
  const doc = { uid: "u1", displayName: "A", tagName: "a", accountRole: "moderator", isLegacyMember: true, coverUrl: "https://img.example.com/c.png", email: "a@x.com" };
  const pub = helpers.toPublicUser(doc);
  assert.deepEqual(pub.badges, ["moderator", "legacy"]);
  assert.equal(pub.coverUrl, undefined, "không gắn URL ảnh bìa vào mọi thẻ bài/bình luận");
  assert.equal(pub.email, undefined);
  const prof = helpers.toPublicProfile(doc);
  assert.equal(prof.coverUrl, "https://img.example.com/c.png");
  assert.deepEqual(prof.badges, ["moderator", "legacy"]);
  assert.equal(helpers.toPublicProfile({ uid: "u2", displayName: "B", tagName: "b" }).coverUrl, null);
  assert.equal(helpers.toPublicProfile(null), null);
});

test("huy hiệu: GET /users/:uid trả badges + coverUrl và không lộ trường riêng; /users/me trả badges", async () => {
  reset();
  seedUser("uA", { accountRole: "admin", accountGroup: "SA", isLegacyMember: true, coverUrl: "https://img.example.com/c.png", email: "a@x.com", birthday: "2000-01-01", pinnedPostIds: ["p1"] });
  const pub = await call("GET", "/api/users/uA");
  assert.equal(pub.status, 200);
  assert.deepEqual(pub.body.user.badges, ["admin", "legacy"]);
  assert.equal(pub.body.user.coverUrl, "https://img.example.com/c.png");
  const text = JSON.stringify(pub.body);
  for (const secret of ["a@x.com", "2000-01-01", "pinnedPostIds", "birthday"]) assert.ok(!text.includes(secret), `không lộ ${secret}`);
  const me = await call("GET", "/api/users/me", "tA");
  assert.equal(me.status, 200);
  assert.deepEqual(me.body.user.badges, ["admin", "legacy"]);
  assert.deepEqual(me.body.user.pinnedPostIds, ["p1"], "chủ tài khoản thấy danh sách ghim của mình");
});

test("huy hiệu: bảng xếp hạng (toRankingEntry) có huy hiệu, dùng cùng nguồn sự thật", () => {
  // trending.controller không export toRankingEntry — kiểm qua mã nguồn để không ai quên khi sửa select(...).
  const src = require("node:fs").readFileSync(path.join(__dirname, "../src/controllers/trending.controller.js"), "utf8");
  assert.match(src, /badges: badgeIdsForUser\(d\)/);
  assert.equal((src.match(/"accountRole", "isLegacyMember"/g) || []).length, 4, "cả 4 truy vấn users đều select accountRole + isLegacyMember");
});

// =========================================================== hồ sơ công khai: các ca 404
test("hồ sơ: id lạ / pending / hồ sơ ma / đang xoá đều 404 trên cả /:uid, /:uid/posts, /:uid/pinned", async () => {
  reset();
  seedUser("uPend", { status: "pending" });
  seedUser("uDel", { status: "deleting" });
  S["users/uGhost"] = { accountScore: 5 }; // không có status
  // (không thử ".." / "%2E%2E": URL chuẩn hoá chúng thành đoạn đường dẫn "lên một cấp" trước khi gửi — không phải route của hồ sơ)
  for (const uid of ["uPend", "uDel", "uGhost", "nobody", "a%2Fb", "__reserved__"]) {
    for (const suffix of ["", "/posts", "/pinned"]) {
      const r = await call("GET", `/api/users/${uid}${suffix}`);
      assert.equal(r.status, 404, `${uid}${suffix}`);
    }
  }
});

// =========================================================== ảnh bìa: URL ngoài
test("ảnh bìa (URL): cần đăng nhập; chỉ https; domain phải nằm trong danh sách nhúng; không khoảng trắng/thông tin đăng nhập", async () => {
  reset(); seedUser("uA");
  assert.equal((await call("PUT", "/api/users/me/cover", undefined, { url: "https://img.example.com/a.png" })).status, 401);
  const bad = [
    undefined, "", "   ", 123, { x: 1 },
    "http://img.example.com/a.png",
    "ftp://img.example.com/a.png",
    "javascript:alert(1)",
    "https://evil.example.org/a.png", // domain không nằm trong danh sách
    "https://user:pw@img.example.com/a.png",
    "https://img.example.com/a b.png",
    "https://img.example.com/" + "a".repeat(PROFILE.COVER_URL_MAX),
    "không phải url",
  ];
  for (const url of bad) {
    const r = await call("PUT", "/api/users/me/cover", "tA", { url });
    assert.equal(r.status, 400, String(JSON.stringify(url)).slice(0, 60));
  }
  assert.equal(S["users/uA"].coverUrl, undefined, "mọi ca xấu đều không ghi gì");
  const ok = await call("PUT", "/api/users/me/cover", "tA", { url: "  https://img.example.com/ok.png  " });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.coverUrl, "https://img.example.com/ok.png");
  assert.equal(S["users/uA"].coverUrl, "https://img.example.com/ok.png");
});

test("ảnh bìa (URL): URL đang lưu không bị kiểm lại domain (SA đổi danh sách sau này không chặn lưu lại ảnh cũ)", async () => {
  reset(); seedUser("uA", { coverUrl: "https://old-host.example/c.png" });
  const again = await call("PUT", "/api/users/me/cover", "tA", { url: "https://old-host.example/c.png" });
  assert.equal(again.status, 200);
  const other = await call("PUT", "/api/users/me/cover", "tA", { url: "https://other-host.example/c.png" });
  assert.equal(other.status, 400);
});

test("ảnh bìa (URL): khi SA tắt toàn bộ nhúng thì không đặt được URL ngoài mới", async () => {
  reset(); seedUser("uA");
  sanitize.setEmbedDomainsConfig({ enabled: false, domains: [] });
  assert.equal((await call("PUT", "/api/users/me/cover", "tA", { url: "https://img.example.com/a.png" })).status, 400);
});

// =========================================================== ảnh bìa: tải lên
test("ảnh bìa (tải lên): cần đăng nhập, chỉ nhận ảnh thật, ghi sổ assets kind=cover, public_id cố định và ghi đè", async () => {
  reset(); seedUser("uA");
  assert.equal((await uploadCover(undefined, PNG)).status, 401);
  assert.equal((await uploadCover("tA", PNG, "text/plain")).status, 400, "sai MIME khai báo");
  assert.equal((await uploadCover("tA", Buffer.from("đây không phải ảnh, chỉ là chữ dài hơn 12 byte"), "image/png")).status, 400, "MIME nói dối: nội dung không phải ảnh");
  assert.equal((await uploadCover("tA", PNG, "image/png", "avatar")).status, 400, "sai tên field");
  assert.equal(cld.calls.filter((c) => c[0] === "upload").length, 0, "request xấu không chạm Cloudinary");

  const r1 = await uploadCover("tA", PNG);
  assert.equal(r1.status, 200);
  assert.equal(r1.body.coverUrl, "https://res.cloudinary.com/demo/image/upload/v7/twelve/covers/uA/cover.jpg");
  assert.equal(S["users/uA"].coverUrl, r1.body.coverUrl);
  const ledger = S["assets/twelve__covers__uA__cover"];
  assert.ok(ledger, "có dòng trong sổ assets");
  assert.equal(ledger.kind, "cover");
  assert.equal(ledger.ownerUid, "uA");
  assert.equal(ledger.uploadCount, 1);
  const up = cld.calls.find((c) => c[0] === "upload");
  assert.equal(up[1], "twelve/covers/uA/cover");
  assert.equal(up[3], true, "overwrite");
  // v2.4.1: lưu NGUYÊN ảnh (giới hạn cạnh dài), KHÔNG cắt cứng 1500x500 — khung hiển thị nằm ở users.coverCrop.
  assert.equal(up[4].crop, "limit");
  assert.equal(up[4].width, 2400);
  assert.equal(up[4].height, 2400);

  const r2 = await uploadCover("tA", PNG);
  assert.equal(r2.status, 200);
  assert.equal(S["assets/twelve__covers__uA__cover"].uploadCount, 2, "đổi ảnh = ghi đè cùng một asset");
  assert.equal(Object.keys(S).filter((k) => k.startsWith("assets/")).length, 1);
});

test("ảnh bìa (tải lên): quá 3 MB bị chặn trước khi chạm Cloudinary; chưa cấu hình Cloudinary => 503", async () => {
  reset(); seedUser("uA");
  const big = Buffer.concat([PNG, Buffer.alloc(3 * 1024 * 1024 + 10, 2)]);
  const r = await uploadCover("tA", big);
  assert.equal(r.status, 400);
  assert.match(r.body.error, /tối đa 3MB/);
  assert.equal(cld.calls.filter((c) => c[0] === "upload").length, 0);

  cld.config = {};
  const r503 = await uploadCover("tA", PNG);
  assert.equal(r503.status, 503);
  assert.equal(S["users/uA"].coverUrl, undefined);
});

test("ảnh bìa: chuyển từ ảnh tải lên sang URL ngoài => gỡ file Twelve đang giữ; dán lại CHÍNH URL ảnh của mình thì KHÔNG gỡ", async () => {
  reset(); seedUser("uA");
  const up = await uploadCover("tA", PNG);
  const ownUrl = up.body.coverUrl;
  cld.calls.length = 0;

  // Dán lại đúng URL ảnh Twelve đang giữ (domain không nằm trong danh sách nhúng nhưng là URL đang lưu) — không được xoá file.
  const same = await call("PUT", "/api/users/me/cover", "tA", { url: ownUrl });
  assert.equal(same.status, 200);
  assert.equal(cld.calls.filter((c) => c[0] === "destroy").length, 0);
  assert.ok(S["assets/twelve__covers__uA__cover"], "sổ còn nguyên");

  // Một URL KHÁC nhưng vẫn trỏ vào file của mình (khác chuỗi, cùng public_id) — cũng không được xoá file đang được dùng.
  const alias = "https://res.cloudinary.com/demo/image/upload/w_800/v7/twelve/covers/uA/cover.jpg";
  sanitize.setEmbedDomainsConfig({ enabled: true, domains: [{ domain: "res.cloudinary.com", path: "" }] });
  const aliasRes = await call("PUT", "/api/users/me/cover", "tA", { url: alias });
  assert.equal(aliasRes.status, 200);
  assert.equal(cld.calls.filter((c) => c[0] === "destroy").length, 0, "URL mới vẫn trỏ vào file đó => giữ file");
  assert.ok(S["assets/twelve__covers__uA__cover"]);

  // URL ngoài thật sự => gỡ file + sổ.
  sanitize.setEmbedDomainsConfig({ enabled: true, domains: [{ domain: "img.example.com", path: "" }] });
  const ext = await call("PUT", "/api/users/me/cover", "tA", { url: "https://img.example.com/x.png" });
  assert.equal(ext.status, 200);
  assert.deepEqual(cld.calls.filter((c) => c[0] === "destroy"), [["destroy", "twelve/covers/uA/cover"]]);
  assert.equal(S["assets/twelve__covers__uA__cover"], undefined, "dòng sổ đã xoá");
  assert.equal(S["users/uA"].coverUrl, "https://img.example.com/x.png");
});

test("ảnh bìa: DELETE gỡ ảnh bìa + file + sổ; chạy lại vẫn 200 (idempotent); không đụng ảnh bìa của người khác", async () => {
  reset(); seedUser("uA"); seedUser("uB");
  await uploadCover("tA", PNG);
  await uploadCover("tB", PNG);
  cld.calls.length = 0;
  assert.equal((await call("DELETE", "/api/users/me/cover")).status, 401);
  const del = await call("DELETE", "/api/users/me/cover", "tA");
  assert.equal(del.status, 200);
  assert.equal(del.body.coverUrl, null);
  assert.equal(S["users/uA"].coverUrl, null);
  assert.deepEqual(cld.calls.filter((c) => c[0] === "destroy"), [["destroy", "twelve/covers/uA/cover"]]);
  assert.equal(S["assets/twelve__covers__uA__cover"], undefined);
  assert.ok(S["assets/twelve__covers__uB__cover"], "ảnh bìa của B còn nguyên");
  assert.ok(S["users/uB"].coverUrl);
  assert.equal((await call("DELETE", "/api/users/me/cover", "tA")).status, 200);
  assert.equal((await call("GET", "/api/users/uA")).body.user.coverUrl, null);
});

test("ảnh bìa: tài khoản chưa kích hoạt không đổi được ảnh bìa", async () => {
  reset(); seedUser("uPend", { status: "pending" });
  assert.equal((await call("PUT", "/api/users/me/cover", "tPend", { url: "https://img.example.com/a.png" })).status, 403);
  assert.equal((await uploadCover("tPend", PNG)).status, 403);
  assert.equal((await call("DELETE", "/api/users/me/cover", "tPend")).status, 403);
});

test("xoá tài khoản: dọn cả thư mục ảnh bìa trên Cloudinary và dòng sổ kind=cover", async () => {
  reset(); seedUser("uA");
  await uploadCover("tA", PNG);
  const assets = require("../src/services/assets.service");
  cld.calls.length = 0;
  await assets.deleteAllAssetsOfUser("uA");
  const prefixes = cld.calls.filter((c) => c[0] === "prefix").map((c) => c[1]);
  assert.ok(prefixes.includes("twelve/covers/uA/"), "xoá theo thư mục covers");
  assert.ok(prefixes.includes("twelve/avatars/uA/"), "vẫn xoá thư mục avatars");
  assert.ok(cld.calls.some((c) => c[0] === "ids" && c[1].includes("twelve/covers/uA/cover")));
  assert.equal(S["assets/twelve__covers__uA__cover"], undefined);
});

// =========================================================== v2.4.1 — khung hiển thị ảnh bìa (kéo/thu phóng như avatar)
const CROP = { x: 10, y: 20, width: 50, height: 50 / 3 };
test("khung ảnh bìa (parseCoverCrop): nhận số hợp lệ & làm tròn; chặn mọi giá trị lạ (đi thẳng vào CSS nên không cho chuỗi/NaN lọt qua)", () => {
  const ok = helpers.parseCoverCrop({ x: 10.123, y: 0, width: 50, height: 16.666, extra: "bỏ" });
  assert.deepEqual(ok, { ok: true, value: { x: 10.12, y: 0, width: 50, height: 16.67 } });
  assert.deepEqual(helpers.parseCoverCrop(undefined), { ok: true, value: undefined });
  assert.deepEqual(helpers.parseCoverCrop(null), { ok: true, value: null });
  assert.deepEqual(helpers.parseCoverCrop(""), { ok: true, value: null });
  assert.deepEqual(helpers.parseCoverCrop("null"), { ok: true, value: null });
  assert.equal(helpers.parseCoverCrop(JSON.stringify(CROP)).ok, true, "chuỗi JSON (trường multipart)");
  assert.equal(helpers.parseCoverCrop({ x: -0.3, y: 0, width: 100, height: 100 }).value.x, 0, "lệch làm tròn nhỏ được kéo về biên");
  assert.equal(helpers.parseCoverCrop({ x: 60.2, y: 0, width: 40, height: 40 }).value.x, 60, "x + width không vượt 100");
  const bad = [
    42, true, [], "{", "không phải json", "x".repeat(400), JSON.stringify({ x: 1 }),
    { x: "10", y: 0, width: 50, height: 50 },
    { x: 0, y: 0, width: NaN, height: 50 },
    { x: 0, y: 0, width: Infinity, height: 50 },
    { x: -5, y: 0, width: 50, height: 50 },
    { x: 0, y: 0, width: 9, height: 50 }, // phóng > 10 lần
    { x: 0, y: 0, width: 50, height: 9 },
    { x: 0, y: 0, width: 150, height: 50 },
    { x: 70, y: 0, width: 50, height: 50 },
    { x: 0, y: 70, width: 50, height: 50 },
    { x: 0, y: 0, width: "50%; background:url(x)", height: 50 },
  ];
  for (const b of bad) assert.equal(helpers.parseCoverCrop(b).ok, false, JSON.stringify(b)?.slice(0, 50));
});

test("khung ảnh bìa: tải lên kèm crop → lưu cùng ảnh, trả trong hồ sơ công khai; crop hỏng → 400 TRƯỚC khi chạm Cloudinary", async () => {
  reset(); seedUser("uA");
  const bad = await uploadCover("tA", PNG, "image/png", "cover", { x: 1, y: 1, width: 5, height: 5 });
  assert.equal(bad.status, 400);
  assert.equal((await uploadCover("tA", PNG, "image/png", "cover", "{khong-phai-json")).status, 400);
  assert.equal(cld.calls.filter((c) => c[0] === "upload").length, 0);
  assert.equal(S["users/uA"].coverUrl, undefined);

  const r = await uploadCover("tA", PNG, "image/png", "cover", CROP);
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.coverCrop, { x: 10, y: 20, width: 50, height: 16.67 });
  assert.deepEqual(S["users/uA"].coverCrop, r.body.coverCrop);
  const pub = await call("GET", "/api/users/uA");
  assert.deepEqual(pub.body.user.coverCrop, r.body.coverCrop);
  const noCrop = await uploadCover("tA", PNG);
  assert.equal(noCrop.body.coverCrop, null, "tải ảnh mới không kèm khung → về khung mặc định");
});

test("khung ảnh bìa: PUT /me/cover/crop chỉnh lại ảnh ĐANG CÓ (tải lên hay URL ngoài) mà không đụng tới ảnh/Cloudinary; crop=null về mặc định", async () => {
  reset(); seedUser("uA");
  assert.equal((await call("PUT", "/api/users/me/cover/crop", undefined, { crop: CROP })).status, 401);
  assert.equal((await call("PUT", "/api/users/me/cover/crop", "tA", { crop: CROP })).status, 400, "chưa có ảnh bìa");
  await call("PUT", "/api/users/me/cover", "tA", { url: "https://img.example.com/a.png" });
  cld.calls.length = 0;
  const r = await call("PUT", "/api/users/me/cover/crop", "tA", { crop: CROP });
  assert.equal(r.status, 200);
  assert.deepEqual(S["users/uA"].coverCrop, { x: 10, y: 20, width: 50, height: 16.67 });
  assert.equal(S["users/uA"].coverUrl, "https://img.example.com/a.png", "ảnh không đổi");
  assert.equal(cld.calls.length, 0, "không chạm Cloudinary");
  assert.equal((await call("PUT", "/api/users/me/cover/crop", "tA", { crop: { x: 0, y: 0, width: 3, height: 3 } })).status, 400);
  assert.equal((await call("PUT", "/api/users/me/cover/crop", "tA", {})).status, 400, "thiếu crop");
  assert.equal((await call("PUT", "/api/users/me/cover/crop", "tA", { crop: null })).status, 200);
  assert.equal(S["users/uA"].coverCrop, null);
});

test("khung ảnh bìa: URL ngoài kèm crop; đổi sang ảnh khác thì khung về mặc định; dán lại đúng URL cũ thì GIỮ khung; gỡ ảnh bìa xoá luôn khung", async () => {
  reset(); seedUser("uA");
  const first = await call("PUT", "/api/users/me/cover", "tA", { url: "https://img.example.com/a.png", crop: CROP });
  assert.equal(first.status, 200);
  assert.equal(S["users/uA"].coverCrop.x, 10);
  assert.equal((await call("PUT", "/api/users/me/cover", "tA", { url: "https://img.example.com/a.png" })).body.coverCrop.x, 10, "cùng URL: giữ khung");
  assert.equal((await call("PUT", "/api/users/me/cover", "tA", { url: "https://img.example.com/b.png" })).body.coverCrop, null, "ảnh khác: khung mặc định");
  assert.equal((await call("PUT", "/api/users/me/cover", "tA", { url: "https://img.example.com/c.png", crop: { x: 0, y: 0, width: 1, height: 1 } })).status, 400, "crop hỏng không ghi gì");
  assert.equal(S["users/uA"].coverUrl, "https://img.example.com/b.png");
  await call("PUT", "/api/users/me/cover/crop", "tA", { crop: CROP });
  await call("DELETE", "/api/users/me/cover", "tA");
  assert.equal(S["users/uA"].coverUrl, null);
  assert.equal(S["users/uA"].coverCrop, null);
});

test("khung ảnh bìa: hồ sơ công khai KHÔNG trả crop khi không còn ảnh bìa (dữ liệu sót)", async () => {
  reset(); seedUser("uA", { coverUrl: null, coverCrop: CROP });
  assert.equal((await call("GET", "/api/users/uA")).body.user.coverCrop, null);
});

// =========================================================== ghim bài
test("ghim: chủ bài ghim/gỡ ghim, bài mới ghim đứng đầu, ghim lại là idempotent", async () => {
  reset(); seedUser("uA"); seedPost("p1", "uA"); seedPost("p2", "uA"); seedPost("p3", "uA");
  const a = await call("PUT", "/api/posts/p1/pin", "tA");
  assert.equal(a.status, 200);
  assert.deepEqual(a.body.pinnedPostIds, ["p1"]);
  const b = await call("PUT", "/api/posts/p2/pin", "tA");
  assert.deepEqual(b.body.pinnedPostIds, ["p2", "p1"], "bài ghim sau đứng trước");
  const again = await call("PUT", "/api/posts/p2/pin", "tA");
  assert.equal(again.status, 200);
  assert.equal(again.body.changed, false);
  assert.deepEqual(S["users/uA"].pinnedPostIds, ["p2", "p1"]);
  const un = await call("DELETE", "/api/posts/p2/pin", "tA");
  assert.deepEqual(un.body.pinnedPostIds, ["p1"]);
  assert.equal((await call("DELETE", "/api/posts/p2/pin", "tA")).body.changed, false, "gỡ lại cũng idempotent");
  assert.deepEqual(S["users/uA"].pinnedPostIds, ["p1"]);
});

test(`ghim: tối đa ${PROFILE.PINNED_POSTS_MAX} bài — vượt thì 409 PIN_LIMIT_REACHED; ghim lại bài đã ghim không tính vào giới hạn`, async () => {
  reset(); seedUser("uA");
  const ids = Array.from({ length: PROFILE.PINNED_POSTS_MAX + 1 }, (_, i) => `q${i}`);
  ids.forEach((id) => seedPost(id, "uA"));
  for (const id of ids.slice(0, PROFILE.PINNED_POSTS_MAX)) assert.equal((await call("PUT", `/api/posts/${id}/pin`, "tA")).status, 200);
  const over = await call("PUT", `/api/posts/${ids[PROFILE.PINNED_POSTS_MAX]}/pin`, "tA");
  assert.equal(over.status, 409);
  assert.equal(over.body.code, "PIN_LIMIT_REACHED");
  assert.match(over.body.error, new RegExp(String(PROFILE.PINNED_POSTS_MAX)));
  assert.equal(S["users/uA"].pinnedPostIds.length, PROFILE.PINNED_POSTS_MAX);
  assert.equal((await call("PUT", `/api/posts/${ids[0]}/pin`, "tA")).status, 200, "đã ghim rồi: vẫn OK khi đầy");
  // Gỡ một bài thì ghim được bài mới.
  await call("DELETE", `/api/posts/${ids[0]}/pin`, "tA");
  assert.equal((await call("PUT", `/api/posts/${ids[PROFILE.PINNED_POSTS_MAX]}/pin`, "tA")).status, 200);
});

test("ghim: không ghim được bài của người khác (kể cả SA), bài không tồn tại, id lạ, chưa đăng nhập, chưa kích hoạt", async () => {
  reset(); seedUser("uA"); seedUser("uB"); seedUser("uSA", { accountGroup: "SA", accountRole: "admin" }); seedUser("uPend", { status: "pending" });
  seedPost("pB", "uB");
  seedPost("pPend", "uPend");
  const other = await call("PUT", "/api/posts/pB/pin", "tA");
  assert.equal(other.status, 403);
  assert.equal(other.body.code, "NOT_POST_OWNER");
  assert.equal((await call("PUT", "/api/posts/pB/pin", "tSA")).status, 403, "SA cũng không ghim hộ");
  assert.equal((await call("PUT", "/api/posts/khong-co/pin", "tA")).status, 404);
  assert.equal((await call("PUT", "/api/posts/a%2Fb/pin", "tA")).status, 404);
  assert.equal((await call("PUT", "/api/posts/pB/pin")).status, 401);
  assert.equal((await call("DELETE", "/api/posts/pB/pin")).status, 401);
  assert.equal((await call("PUT", "/api/posts/pPend/pin", "tPend")).status, 403, "pending bị requireActive chặn");
  assert.equal(S["users/uA"].pinnedPostIds, undefined);
  assert.equal(S["users/uB"].pinnedPostIds, undefined);
});

test("ghim: chỉ bài trong `posts` — id của blog không ghim được", async () => {
  reset(); seedUser("uA");
  S["blogs/b1"] = { id: "b1", authorUid: "uA", title: "Blog", isPublished: true };
  assert.equal((await call("PUT", "/api/posts/b1/pin", "tA")).status, 404);
});

test("ghim: dữ liệu lạ trong pinnedPostIds (không phải mảng / phần tử lạ / trùng) không làm hỏng — bị bỏ và ghi lại sạch", async () => {
  reset();
  seedUser("uA", { pinnedPostIds: ["p1", "p1", 7, null, "a/b", "..", "p2"] });
  seedPost("p1", "uA"); seedPost("p2", "uA"); seedPost("p3", "uA");
  const r = await call("PUT", "/api/posts/p3/pin", "tA");
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.pinnedPostIds, ["p3", "p1", "p2"]);
  reset(); seedUser("uA", { pinnedPostIds: "không phải mảng" }); seedPost("p1", "uA");
  assert.deepEqual((await call("PUT", "/api/posts/p1/pin", "tA")).body.pinnedPostIds, ["p1"]);
});

test("ghim: xoá bài (chủ bài hoặc SA) gỡ id khỏi danh sách ghim của tác giả và không dựng lại hồ sơ ma", async () => {
  reset(); seedUser("uA"); seedUser("uSA", { accountGroup: "SA", accountRole: "admin" });
  seedPost("p1", "uA"); seedPost("p2", "uA");
  await call("PUT", "/api/posts/p1/pin", "tA");
  await call("PUT", "/api/posts/p2/pin", "tA");
  assert.equal((await call("DELETE", "/api/posts/p1", "tA")).status, 200);
  const { waitFor } = { waitFor: async (fn) => { for (let i = 0; i < 200; i++) { if (await fn()) return true; await new Promise((r) => setTimeout(r, 15)); } return false; } };
  assert.ok(await waitFor(() => JSON.stringify(S["users/uA"].pinnedPostIds) === JSON.stringify(["p2"])), "chủ bài xoá");
  assert.equal((await call("DELETE", "/api/posts/p2", "tSA")).status, 200);
  assert.ok(await waitFor(() => JSON.stringify(S["users/uA"].pinnedPostIds) === JSON.stringify([])), "SA xoá");
});

test("ghim: bài đã bị xoá vẫn gỡ ghim được (id còn sót)", async () => {
  reset(); seedUser("uA", { pinnedPostIds: ["mat-tich"] });
  const r = await call("DELETE", "/api/posts/mat-tich/pin", "tA");
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.pinnedPostIds, []);
});

test("ghim: giới hạn tốc độ 60 lần/15 phút/tài khoản", async () => {
  reset(); seedUser("uA"); seedPost("p1", "uA");
  let last;
  for (let i = 0; i < 61; i++) last = await call("DELETE", "/api/posts/p1/pin", "tA");
  assert.equal(last.status, 429);
});

// =========================================================== danh sách bài + bài ghim của một hồ sơ
test("GET /users/:uid/posts: chỉ bài của người đó, mới nhất trước, có isPinned và tác giả có huy hiệu; không lộ trường riêng", async () => {
  reset();
  seedUser("uA", { accountRole: "pro_user", pinnedPostIds: ["a2"], email: "a@x.com" }); seedUser("uB");
  seedPost("a1", "uA"); seedPost("b1", "uB"); seedPost("a2", "uA"); seedPost("a3", "uA");
  const r = await call("GET", "/api/users/uA/posts");
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.posts.map((p) => p.id), ["a3", "a2", "a1"]);
  assert.deepEqual(r.body.posts.map((p) => p.isPinned), [false, true, false]);
  assert.deepEqual(r.body.posts[0].author.badges, ["pro"]);
  assert.equal(r.body.posts[0].author.uid, "uA");
  assert.ok(!JSON.stringify(r.body).includes("a@x.com"));
  assert.ok(!JSON.stringify(r.body).includes("contentHtml"), "thẻ không mang cả nội dung bài");
});

test("GET /users/:uid/posts: limit bị chặn trên, cursor sai 400, cursor của bài người khác bị bỏ qua", async () => {
  reset(); seedUser("uA"); seedUser("uB"); seedPost("a1", "uA"); seedPost("b1", "uB");
  assert.equal((await call("GET", "/api/users/uA/posts?cursor[]=x")).status, 400);
  assert.equal((await call("GET", "/api/users/uA/posts?cursor=a%2Fb")).status, 400);
  assert.equal((await call("GET", "/api/users/uA/posts?limit=-5")).status, 200);
  assert.equal((await call("GET", "/api/users/uA/posts?limit=99999")).status, 200);
  const r = await call("GET", "/api/users/uA/posts?cursor=b1");
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.posts.map((p) => p.id), ["a1"], "cursor của người khác không làm mất bài");
  assert.equal(r.body.nextCursor, "a1");
});

test("GET /users/:uid/posts: gắn myReaction của người đang xem (khách => null)", async () => {
  reset(); seedUser("uA"); seedUser("uB"); seedPost("a1", "uA");
  S["posts/a1/reactions/uB"] = { type: "like" };
  assert.equal((await call("GET", "/api/users/uA/posts", "tB")).body.posts[0].myReaction, "like");
  assert.equal((await call("GET", "/api/users/uA/posts")).body.posts[0].myReaction, null);
  assert.equal((await call("GET", "/api/users/uA/posts", "tA")).body.posts[0].myReaction, null);
});

test("GET /users/:uid/pinned: đúng thứ tự đã ghim, đánh dấu isPinned; hồ sơ không ghim gì => mảng rỗng", async () => {
  reset(); seedUser("uA", { pinnedPostIds: ["a2", "a1"] }); seedUser("uB");
  seedPost("a1", "uA"); seedPost("a2", "uA"); seedPost("a3", "uA");
  const r = await call("GET", "/api/users/uA/pinned");
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.posts.map((p) => p.id), ["a2", "a1"]);
  assert.ok(r.body.posts.every((p) => p.isPinned === true));
  assert.deepEqual((await call("GET", "/api/users/uB/pinned")).body, { posts: [] });
});

test("GET /users/:uid/pinned: tự loại bài đã mất / không còn của người này và gỡ id sót khỏi hồ sơ", async () => {
  reset(); seedUser("uA", { pinnedPostIds: ["a1", "mat-tich", "pB"] }); seedUser("uB");
  seedPost("a1", "uA"); seedPost("pB", "uB"); // pB của người khác (dữ liệu hỏng) — không được hiện ở hồ sơ A
  const r = await call("GET", "/api/users/uA/pinned");
  assert.deepEqual(r.body.posts.map((p) => p.id), ["a1"]);
  const { waitFor } = { waitFor: async (fn) => { for (let i = 0; i < 200; i++) { if (await fn()) return true; await new Promise((r2) => setTimeout(r2, 15)); } return false; } };
  assert.ok(await waitFor(() => JSON.stringify(S["users/uA"].pinnedPostIds) === JSON.stringify(["a1"])), "id sót đã được gỡ");
});

test("GET /users/:uid/pinned: chỉ hiện tối đa PINNED_POSTS_MAX bài dù dữ liệu có nhiều hơn", async () => {
  reset();
  const ids = Array.from({ length: PROFILE.PINNED_POSTS_MAX + 3 }, (_, i) => `z${i}`);
  seedUser("uA", { pinnedPostIds: ids });
  ids.forEach((id) => seedPost(id, "uA"));
  assert.equal((await call("GET", "/api/users/uA/pinned")).body.posts.length, PROFILE.PINNED_POSTS_MAX);
});

// =========================================================== SEO
test("SEO: og:image của hồ sơ ưu tiên ảnh bìa, rồi avatar, rồi ảnh mặc định", () => {
  const seo = require("../src/utils/seoMeta");
  const mk = (user) => seo.buildProfileMeta({ user: { displayName: "A", tagName: "@a", ...user }, posts: [], canonicalUrl: "https://x/u/1", frontendBase: "https://x", robots: "index" });
  assert.equal(mk({ coverUrl: "https://c/c.jpg", avatarUrl: "https://c/a.jpg" }).image, "https://c/c.jpg");
  assert.equal(mk({ avatarUrl: "https://c/a.jpg" }).image, "https://c/a.jpg");
  const prev = process.env.SITE_OG_IMAGE_URL;
  process.env.SITE_OG_IMAGE_URL = "https://c/default.png";
  try {
    assert.equal(mk({}).image, "https://c/default.png", "không có ảnh nào => ảnh mặc định của site");
  } finally {
    if (prev === undefined) delete process.env.SITE_OG_IMAGE_URL;
    else process.env.SITE_OG_IMAGE_URL = prev;
  }
});
