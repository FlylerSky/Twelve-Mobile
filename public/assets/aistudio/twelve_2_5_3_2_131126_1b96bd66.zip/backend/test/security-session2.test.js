// v2.0.11 — kiểm thử phần backend của bản vá theo Báo cáo bảo mật Phiên 2 (G1: thu báo cáo CSP).
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const express = require("express");

const ctrl = require("../src/controllers/csp.controller");
const router = require("../src/routes/csp.routes");

const listen = (app) => new Promise((r) => { const s = http.createServer(app).listen(0, () => r({ s, base: `http://127.0.0.1:${s.address().port}` })); });
const mockRes = () => { const r = { statusCode: 200, body: null }; r.status = (c) => ((r.statusCode = c), r); r.json = (b) => ((r.body = b), r); return r; };

test("G1: nhận cả 2 định dạng báo cáo, chuẩn hoá, gom nhóm, luôn trả 204", async (t) => {
  ctrl.__test.reset({}, mockRes());
  const app = express();
  app.use("/api/csp-report", router);
  const { s, base } = await listen(app);
  t.after(() => s.close());
  const post = (type, body) => fetch(base + "/api/csp-report", { method: "POST", headers: { "content-type": type }, body: typeof body === "string" ? body : JSON.stringify(body) });

  // định dạng report-uri (application/csp-report): query/hash bị bỏ, blocked chỉ còn origin, id bài được gom thành :id
  for (let i = 0; i < 3; i++) {
    const r = await post("application/csp-report", { "csp-report": {
      "document-uri": `https://twelve.example/post/abc${i}?token=SECRET#frag`, "effective-directive": "script-src-elem",
      "violated-directive": "script-src-elem", "blocked-uri": "https://evil.example/x.js?key=SECRET", disposition: "report",
    } });
    assert.equal(r.status, 204);
  }
  // định dạng Reporting API (application/reports+json): mảng báo cáo
  let r = await post("application/reports+json", [
    { type: "csp-violation", url: "https://twelve.example/", body: { documentURL: "https://twelve.example/", effectiveDirective: "img-src", blockedURL: "inline", disposition: "report", sample: "x".repeat(300) } },
    { type: "network-error", body: {} },
  ]);
  assert.equal(r.status, 204);
  // tiện ích trình duyệt: đếm riêng
  await post("application/csp-report", { "csp-report": { "document-uri": "https://twelve.example/", "effective-directive": "script-src", "blocked-uri": "chrome-extension://abcdef/inject.js" } });
  // rác / quá lớn / sai JSON: vẫn 204, không làm hỏng thống kê
  for (const [type, body] of [["application/csp-report", "{không phải json"], ["application/csp-report", JSON.stringify({ x: "a".repeat(40000) })], ["application/json", "null"], ["application/csp-report", JSON.stringify({ "csp-report": { "effective-directive": "<script>" } })]]) {
    assert.equal((await post(type, body)).status, 204);
  }

  const res = mockRes();
  ctrl.getCspReports({}, res);
  assert.equal(res.body.ignoredExtensions, 1);
  assert.equal(res.body.uniqueViolations, 2);
  const top = res.body.entries[0];
  assert.deepEqual({ d: top.directive, b: top.blocked, doc: top.document, n: top.count }, { d: "script-src-elem", b: "https://evil.example", doc: "https://twelve.example/post/:id", n: 3 });
  assert.ok(!JSON.stringify(res.body).includes("SECRET"), "không lưu query/hash/đường dẫn của URL bị chặn");
  assert.ok(res.body.entries.every((e) => e.sample.length <= 80));

  // bắt đầu lại cửa sổ quan sát
  const del = mockRes();
  ctrl.resetCspReports({}, del);
  const after = mockRes();
  ctrl.getCspReports({}, after);
  assert.deepEqual([after.body.total, after.body.uniqueViolations], [0, 0]);
});

test("G1: bộ nhớ thống kê có trần (không phình vô hạn khi bị bơm báo cáo đa dạng)", () => {
  ctrl.__test.reset({}, mockRes());
  for (let i = 0; i < 1000; i++) {
    ctrl.receiveCspReport({ body: { "csp-report": { "document-uri": "https://twelve.example/", "effective-directive": "img-src", "blocked-uri": `https://host${i}.example/a.png` } } }, { status: () => ({ end() {} }) });
  }
  assert.ok(ctrl.__test.entries.size <= 300);
  const res = mockRes();
  ctrl.getCspReports({}, res);
  assert.ok(res.body.droppedKeys > 0);
  assert.ok(res.body.entries.length <= 100);
});
