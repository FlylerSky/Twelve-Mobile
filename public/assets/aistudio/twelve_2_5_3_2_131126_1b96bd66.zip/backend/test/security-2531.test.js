// v2.5.3.121126 — hotfix "App Check không được làm treo frontend". Kiểm tra TĨNH mã nguồn frontend (không cần mạng/trình duyệt); hành vi chạy thật của
// `appCheckGuard` được test ở frontend/tests/appCheckGuard.test.js (vitest). Nguyên nhân gốc và cách tái hiện: PATCH-25-NOTES.md.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const FRONTEND = path.join(__dirname, "..", "..", "frontend");
const haveFrontend = fs.existsSync(path.join(FRONTEND, "vercel.json"));
const opts = { skip: !haveFrontend && "không có thư mục ../frontend" };
const stripComments = (s) => s.replace(/\/\*[\s\S]*?\*\//g, "").replace(/(^|[^:])\/\/.*$/gm, "$1");

test("2.5.3.1: App Check chỉ được khởi tạo SAU KHI reCAPTCHA sẵn sàng (waitForRecaptcha) và provider luôn được bọc timeout (withTokenTimeout)", opts, () => {
  const code = stripComments(fs.readFileSync(path.join(FRONTEND, "src/firebase.js"), "utf8"));
  assert.match(code, /from\s+"\.\/utils\/appCheckGuard"/);
  const iWait = code.indexOf("waitForRecaptcha(");
  const iInit = code.indexOf("initializeAppCheck(firebaseApp");
  assert.ok(iWait > -1 && iInit > iWait, "initializeAppCheck phải nằm SAU waitForRecaptcha");
  assert.equal((code.match(/initializeAppCheck\(/g) || []).length, 1);
  // Mọi provider reCAPTCHA đều đi qua withTokenTimeout — không còn đường tới `provider: new ReCaptcha…` trần (đường treo vô hạn của 2.5.3).
  assert.match(code, /provider:\s*withTokenTimeout\(/);
  assert.ok(!/provider:\s*new\s+ReCaptcha/.test(code), "provider reCAPTCHA trần có thể treo vô hạn khi script bị chặn");
  // Có nhánh lỗi cho lời hứa reCAPTCHA (bỏ qua App Check thay vì treo/ném lỗi chưa bắt).
  assert.match(code, /waitForRecaptcha\([^)]*\)\)?\.then\(\s*\(\)\s*=>[\s\S]*\(err\)\s*=>\s*\{[\s\S]*console\.warn/);
});

test("2.5.3.1: appCheckGuard — nạp script có onerror + timeout, bọc getToken có timeout + thời gian nguội; URL khớp URL SDK nạp (để SDK không nạp lần hai)", opts, () => {
  const src = fs.readFileSync(path.join(FRONTEND, "src/utils/appCheckGuard.js"), "utf8");
  assert.match(src, /script\.onerror\s*=/);
  assert.match(src, /setTimeout\(/);
  assert.match(src, /cooldownMs/);
  assert.ok(src.includes("https://www.google.com/recaptcha/api.js") && src.includes("https://www.google.com/recaptcha/enterprise.js"));
  // Nếu nâng Firebase SDK, kiểm lại URL mà @firebase/app-check nạp (RECAPTCHA_URL) vẫn khớp.
  const sdk = path.join(FRONTEND, "node_modules/@firebase/app-check/dist/esm/index.esm2017.js");
  if (fs.existsSync(sdk)) {
    const sdkSrc = fs.readFileSync(sdk, "utf8");
    assert.match(sdkSrc, /const RECAPTCHA_URL = 'https:\/\/www\.google\.com\/recaptcha\/api\.js'/);
    assert.match(sdkSrc, /const RECAPTCHA_ENTERPRISE_URL = 'https:\/\/www\.google\.com\/recaptcha\/enterprise\.js'/);
  }
});

test("2.5.3.1: Auth không còn gắn bộ xử lý popup/redirect (không nạp apis.google.com bị CSP chặn trên điện thoại/Safari) và mã không dùng popup/redirect", opts, () => {
  const code = stripComments(fs.readFileSync(path.join(FRONTEND, "src/firebase.js"), "utf8"));
  assert.match(code, /initializeAuth\(app,\s*\{\s*persistence:/);
  assert.ok(!/popupRedirectResolver|browserPopupRedirectResolver/.test(code));
  const hits = [];
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
    const p = path.join(d, e.name);
    if (e.isDirectory()) return walk(p);
    if (/\.(jsx?|mjs)$/.test(e.name) && /signInWithPopup|signInWithRedirect|linkWithPopup|linkWithRedirect|reauthenticateWithPopup|reauthenticateWithRedirect|getRedirectResult|GoogleAuthProvider|OAuthProvider/.test(stripComments(fs.readFileSync(p, "utf8")))) hits.push(path.relative(FRONTEND, p));
  });
  walk(path.join(FRONTEND, "src"));
  assert.deepEqual(hits, [], "nếu sau này dùng đăng nhập popup/redirect thì phải khôi phục popupRedirectResolver (getAuth) và mở CSP cho apis.google.com");
});

test("2.5.3.1: CSP của SPA vẫn CHẶT khi App Check tắt (hotfix không mở reCAPTCHA/Google script)", opts, () => {
  const vercel = fs.readFileSync(path.join(FRONTEND, "vercel.json"), "utf8");
  assert.ok(!/recaptcha|gstatic\.com|apis\.google\.com|firebaseappcheck/i.test(vercel));
});
