// v2.2.0 — Cài đặt > Tài khoản: xác nhận lại mật khẩu, tên thật riêng tư, đổi Tag Name Search, quên mật khẩu, xoá tài khoản bền vững.
// Chạy: node --test test/account-220.test.js
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const path = require("node:path");
const express = require("express");

const { install } = require("./helpers/fakeFirebase");
const nowSec = () => Math.floor(Date.now() / 1000);
const fb = install({
  tokens: { tA: "uA", tAold: "uA", tB: "uB", tSA: "uSA", tDel: "uDel" },
  authTimes: { tA: nowSec() - 10, tAold: nowSec() - 3600, tB: nowSec() - 10, tSA: nowSec() - 10, tDel: nowSec() - 10 },
});
const S = fb.store;

// ---- Cloudinary giả (đặt TRƯỚC khi nạp assets.service) ----
const cld = { calls: [], failNext: 0, onPrefix: null, gate: null, config: { cloud_name: "demo", api_key: "k", api_secret: "s" } };
const cloudinaryMock = {
  config: () => cld.config,
  uploader: { destroy: async (pid) => cld.calls.push(["destroy", pid]) },
  api: {
    delete_resources_by_prefix: async (prefix) => {
      if (cld.gate) await cld.gate;
      if (cld.failNext > 0) { cld.failNext--; throw new Error("Cloudinary sự cố tạm thời"); }
      cld.calls.push(["prefix", prefix]);
      if (cld.onPrefix) await cld.onPrefix(prefix);
      return {};
    },
    delete_resources: async (ids) => { cld.calls.push(["ids", ids]); return {}; },
  },
};
const cloudinaryPath = require.resolve(path.join(__dirname, "../src/config/cloudinary.js"));
require.cache[cloudinaryPath] = { id: cloudinaryPath, filename: cloudinaryPath, loaded: true, exports: cloudinaryMock };

const usersRouter = require("../src/routes/users.routes");
const authCtrl = require("../src/controllers/auth.controller");
const deletion = require("../src/services/accountDeletion");
const { __test: D } = deletion;

const app = express();
app.use(express.json());
app.use("/api/users", usersRouter);
let base;
let server;
test.before(async () => {
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

const call = async (method, url, token, body) => {
  const res = await fetch(base + url, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json = null;
  try { json = await res.json(); } catch (_e) { /* không có body */ }
  return { status: res.status, body: json };
};
const limiters = require("../src/middleware/rateLimiters");
const reset = () => {
  // Các limiter thật đang chạy trong app test: xoá bộ đếm giữa các test để chúng không ảnh hưởng nhau.
  for (const uid of ["uA", "uB", "uSA", "uDel"]) {
    limiters.sensitiveAccountLimiter.resetKey(`uid:${uid}`);
    limiters.accountDeleteLimiter.resetKey(`uid:${uid}`);
  }
  Object.keys(S).forEach((k) => delete S[k]);
  fb.authUsers.clear();
  fb.authCalls.updateUser = []; fb.authCalls.revoked = [];
  cld.calls.length = 0; cld.failNext = 0; cld.onPrefix = null; cld.gate = null;
  D.reset();
  D.CFG.VERIFY_DELAY_MS = 0; // v2.2.1: bước verify chạy ngay trong test (độ trễ thật 2 phút được kiểm riêng ở security-221.test.js)
  require("../src/middleware/auth").__test.clearRevokeCache();
};
const seedUser = (uid, over = {}) => {
  S[`users/${uid}`] = { uid, displayName: `Tên ${uid}`, tagName: `tag_${uid.toLowerCase()}`, status: "active", accountGroup: "RA", accountRole: "user", country: "VN", birthday: "2000-01-01", gender: "male", email: `${uid.toLowerCase()}@x.com`, postsScoreSum: 0, positiveScore: 0, accountScore: 0, ...over };
  S[`tagNames/tag_${uid.toLowerCase()}`] = { uid };
};
const seedAuth = (uid) => fb.authUsers.set(uid, { uid, email: `${uid.toLowerCase()}@x.com`, metadata: { creationTime: new Date().toUTCString() } });
const waitFor = async (fn, ms = 4000) => {
  const end = Date.now() + ms;
  while (Date.now() < end) { if (await fn()) return true; await new Promise((r) => setTimeout(r, 15)); }
  return false;
};

// =========================================================== requireRecentAuth + tên thật
test("tên thật: GET cần vừa nhập lại mật khẩu — phiên cũ (auth_time > 5 phút) bị 403 REAUTH_REQUIRED", async () => {
  reset(); seedUser("uA"); S["userPrivate/uA"] = { fullName: "Nguyễn Văn A" };
  const old = await call("GET", "/api/users/me/real-name", "tAold");
  assert.equal(old.status, 403);
  assert.equal(old.body.code, "REAUTH_REQUIRED");
  assert.ok(!JSON.stringify(old.body).includes("Nguyễn"), "không lộ tên thật trong phản hồi lỗi");
  const fresh = await call("GET", "/api/users/me/real-name", "tA");
  assert.equal(fresh.status, 200);
  assert.equal(fresh.body.fullName, "Nguyễn Văn A");
  assert.equal((await call("GET", "/api/users/me/real-name")).status, 401, "không token => 401");
});

test("tên thật: GET /users/me KHÔNG bao giờ trả fullName (kể cả tài khoản cũ còn field trong users/{uid})", async () => {
  reset(); seedUser("uA", { fullName: "Tên Cũ Legacy" });
  const me = await call("GET", "/api/users/me", "tA");
  assert.equal(me.status, 200);
  assert.equal(me.body.user.fullName, undefined);
  assert.ok(!JSON.stringify(me.body).includes("Legacy"));
});

test("tên thật: tài khoản cũ được chuyển lười sang userPrivate khi chủ xem (ghi mới trước, xoá cũ sau)", async () => {
  reset(); seedUser("uA", { fullName: "Tên Cũ Legacy" });
  const r = await call("GET", "/api/users/me/real-name", "tA");
  assert.equal(r.body.fullName, "Tên Cũ Legacy");
  assert.equal(S["userPrivate/uA"].fullName, "Tên Cũ Legacy");
  assert.equal(S["users/uA"].fullName, undefined, "field cũ đã bị xoá khỏi hồ sơ mà Client SDK đọc được");
  assert.equal((await call("GET", "/api/users/me/real-name", "tA")).body.fullName, "Tên Cũ Legacy", "đọc lại vẫn đúng");
});

test("tên thật: PUT cần mật khẩu mới, làm sạch ký tự nguy hiểm, ghi vào userPrivate và không đụng hồ sơ công khai", async () => {
  reset(); seedUser("uA"); S["userPrivate/uA"] = { fullName: "Cũ" };
  assert.equal((await call("PUT", "/api/users/me/real-name", "tAold", { fullName: "Mới" })).status, 403);
  assert.equal(S["userPrivate/uA"].fullName, "Cũ", "bị chặn thì không đổi");
  assert.equal((await call("PUT", "/api/users/me/real-name", "tA", { fullName: 123 })).status, 400);
  assert.equal((await call("PUT", "/api/users/me/real-name", "tA", { fullName: "   " })).status, 400);
  const ok = await call("PUT", "/api/users/me/real-name", "tA", { fullName: "Trần\u202E  Thị\u200B B" });
  assert.equal(ok.status, 200);
  assert.equal(S["userPrivate/uA"].fullName, "Trần Thị B");
  assert.equal(S["users/uA"].fullName, undefined);
});

test("PATCH /users/me từ chối fullName (phải đi qua endpoint có xác nhận mật khẩu) nhưng vẫn sửa được tên hiển thị", async () => {
  reset(); seedUser("uA");
  const bad = await call("PATCH", "/api/users/me", "tA", { fullName: "Hack" });
  assert.equal(bad.status, 400);
  assert.equal(bad.body.code, "USE_REAL_NAME_ENDPOINT");
  assert.equal(S["userPrivate/uA"], undefined);
  const ok = await call("PATCH", "/api/users/me", "tA", { displayName: "Tên Mới" });
  assert.equal(ok.status, 200);
  assert.equal(S["users/uA"].displayName, "Tên Mới");
});

test("đăng ký: tên thật vào userPrivate, KHÔNG nằm trong users/{uid}", async () => {
  reset();
  const res = { statusCode: 200, body: null, status(c) { this.statusCode = c; return this; }, json(b) { this.body = b; return this; } };
  await authCtrl.register({ body: { fullName: "Nguyễn Văn A", displayName: "Văn A", tagName: "vana", birthday: "1999-01-01", gender: "male", country: "VN", email: "a@example.com", password: "12345678" }, headers: {} }, res);
  assert.equal(res.statusCode, 201, JSON.stringify(res.body));
  const uid = res.body.uid;
  assert.equal(S[`users/${uid}`].fullName, undefined);
  assert.equal(S[`userPrivate/${uid}`].fullName, "Nguyễn Văn A");
});

// =========================================================== Tag Name Search
test("tag: đổi thành công — đặt tag mới, trả tag cũ, cập nhật hồ sơ (không cần nhập lại mật khẩu)", async () => {
  reset(); seedUser("uA");
  const r = await call("PUT", "/api/users/me/tag-name", "tAold", { tagName: "@Moi_Tag" });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.tagName, "@moi_tag");
  assert.equal(S["users/uA"].tagName, "moi_tag");
  assert.deepEqual(S["tagNames/moi_tag"], { uid: "uA" });
  assert.ok(!("tagNames/tag_ua" in S), "tag cũ đã được trả");
});

test("tag: đã có người giữ => 409 và KHÔNG đổi gì; không hợp lệ => 400; trùng tag hiện tại => không làm gì", async () => {
  reset(); seedUser("uA"); seedUser("uB");
  assert.equal((await call("PUT", "/api/users/me/tag-name", "tA", { tagName: "tag_ub" })).status, 409);
  assert.equal(S["users/uA"].tagName, "tag_ua");
  assert.deepEqual(S["tagNames/tag_ua"], { uid: "uA" });
  assert.deepEqual(S["tagNames/tag_ub"], { uid: "uB" }, "tag của người khác nguyên vẹn");
  for (const bad of ["ab", "có dấu", "x".repeat(21), 5, null]) assert.equal((await call("PUT", "/api/users/me/tag-name", "tA", { tagName: bad })).status, 400, String(bad));
  const same = await call("PUT", "/api/users/me/tag-name", "tA", { tagName: "TAG_UA" });
  assert.equal(same.status, 200);
  assert.deepEqual(S["tagNames/tag_ua"], { uid: "uA" });
});

test("tag: không xoá nhầm khoá của người khác khi dữ liệu tag cũ bị lệch", async () => {
  reset(); seedUser("uA");
  S["tagNames/tag_ua"] = { uid: "someoneElse" }; // lệch: tag hiện tại của uA đang trỏ về người khác
  assert.equal((await call("PUT", "/api/users/me/tag-name", "tA", { tagName: "tag_moi" })).status, 200);
  assert.deepEqual(S["tagNames/tag_ua"], { uid: "someoneElse" });
});

// =========================================================== quên mật khẩu
test("quên mật khẩu: thiếu FIREBASE_WEB_API_KEY => 503; email lạ/bị khoá/đang xoá => cùng câu trả lời chung và KHÔNG gửi gì", async () => {
  reset();
  const run = async (email) => {
    const res = { statusCode: 200, body: null, status(c) { this.statusCode = c; return this; }, json(b) { this.body = b; return this; } };
    await authCtrl.forgotPassword({ body: { email }, headers: {} }, res);
    return res;
  };
  delete process.env.FIREBASE_WEB_API_KEY;
  assert.equal((await run("a@x.com")).statusCode, 503);

  process.env.FIREBASE_WEB_API_KEY = "test-key";
  const sent = [];
  const realFetch = global.fetch;
  global.fetch = async (url, init) => { sent.push({ url, init }); return { ok: true, json: async () => ({}) }; };
  try {
    seedAuth("uA"); seedUser("uA");
    seedAuth("uS"); seedUser("uS", { status: "suspended" });
    seedAuth("uX"); seedUser("uX", { status: "deleting" });
    fb.authUsers.set("noProfile", { uid: "noProfile", email: "noprofile@x.com" });
    const unknown = await run("khong-ton-tai@x.com");
    const suspended = await run("us@x.com");
    const deleting = await run("ux@x.com");
    const noProfile = await run("noprofile@x.com");
    assert.equal(sent.length, 0, "không gửi cho email lạ / tài khoản bị khoá / đang xoá / không thuộc Twelve");
    for (const r of [unknown, suspended, deleting, noProfile]) assert.equal(r.statusCode, 200);
    const ok = await run("ua@x.com");
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(unknown.body, ok.body, "câu trả lời giống hệt dù email có tồn tại hay không (không cho dò tài khoản)");
    assert.equal(sent.length, 1);
    assert.match(sent[0].url, /accounts:sendOobCode\?key=test-key$/);
    assert.equal(sent[0].init.headers["X-Firebase-Locale"], "vi");
    assert.deepEqual(JSON.parse(sent[0].init.body), { requestType: "PASSWORD_RESET", email: "ua@x.com" });
  } finally {
    global.fetch = realFetch;
    delete process.env.FIREBASE_WEB_API_KEY;
  }
});

test("quên mật khẩu: giới hạn theo EMAIL (nhiều IP cùng làm phiền một người); Firebase báo quá tải/lỗi => VẪN 200 (v2.2.1: chỉ ghi log, không lộ qua mã trạng thái)", async () => {
  reset();
  authCtrl.__test.forgotByEmail.clear();
  process.env.FIREBASE_WEB_API_KEY = "test-key";
  seedAuth("uA"); seedUser("uA");
  let n = 0;
  const realFetch = global.fetch;
  global.fetch = async () => { n++; return { ok: true, json: async () => ({}) }; };
  const run = async (email) => {
    const res = { statusCode: 200, body: null, status(c) { this.statusCode = c; return this; }, json(b) { this.body = b; return this; } };
    await authCtrl.forgotPassword({ body: { email }, headers: {} }, res);
    return res;
  };
  try {
    await run("ua@x.com");
    await run("ua@x.com"); // trong 60 giây: bị chặn thầm (vẫn trả câu chung)
    assert.equal(n, 1, "lần thứ hai trong thời gian chờ không gửi thêm email");
    authCtrl.__test.forgotByEmail.clear();
    global.fetch = async () => ({ ok: false, status: 400, json: async () => ({ error: { message: "TOO_MANY_ATTEMPTS_TRY_LATER" } }) });
    const quiet = console.error; console.error = () => {};
    try {
      // v2.2.1 [A-03]: trước đây 429/502 chỉ xuất hiện với email CÓ tài khoản => dò được email. Nay mọi trường hợp đều 200 + câu chung; chi tiết chỉ ở log.
      const r429 = await run("ua@x.com");
      assert.equal(r429.statusCode, 200);
      global.fetch = async () => ({ ok: false, status: 500, json: async () => ({ error: { message: "INTERNAL" } }) });
      authCtrl.__test.forgotByEmail.clear();
      const r502 = await run("ua@x.com");
      assert.equal(r502.statusCode, 200);
      assert.equal(r502.body.message, r429.body.message);
    } finally { console.error = quiet; }
  } finally {
    global.fetch = realFetch;
    delete process.env.FIREBASE_WEB_API_KEY;
  }
});

test("quên mật khẩu: thử cả dạng email Gmail kiểu cũ (đã bỏ dấu chấm và +tag)", () => {
  assert.deepEqual(authCtrl.__test.emailCandidates("john.doe+x@gmail.com"), ["john.doe+x@gmail.com", "johndoe@gmail.com"]);
  assert.deepEqual(authCtrl.__test.emailCandidates("a@example.com"), ["a@example.com"]);
});

// =========================================================== yêu cầu xoá tài khoản
const seedRichAccount = (uid = "uDel") => {
  seedUser(uid, { avatarUrl: `https://res.cloudinary.com/demo/image/upload/v1/twelve/avatars/${uid}/avatar.jpg` });
  seedAuth(uid);
  S[`userPrivate/${uid}`] = { fullName: "Người Sắp Xoá" };
  S[`users/${uid}/positiveScoreLogs/l1`] = { delta: 1 };
  S[`users/${uid}/positiveScoreLogs/l2`] = { delta: 8 };
  for (const i of [1, 2, 3]) {
    S[`posts/p${i}`] = { authorUid: uid, title: `Bài ${i}` };
    S[`posts/p${i}/comments/c1`] = { authorUid: "uB", text: "bình luận của người khác" };
    S[`posts/p${i}/views/v1`] = {}; S[`posts/p${i}/reactions/uB`] = { type: "like" };
  }
  S["blogs/b1"] = { authorUid: uid, title: "Blog", isPublished: false }; // bản nháp cũng phải bị xoá
  S["blogs/b1/comments/c1"] = { authorUid: "uB", text: "x" };
  S[`assets/twelve__avatars__${uid}__avatar`] = { publicId: `twelve/avatars/${uid}/avatar`, ownerUid: uid, kind: "avatar" };
  S[`registrationMarkers/${uid}`] = { email: `${uid.toLowerCase()}@x.com`, createdAtMs: 1 };
};
const seedBystander = () => {
  seedUser("uB"); seedAuth("uB");
  S["posts/pB"] = { authorUid: "uB", title: "Bài của người khác" };
  S["posts/pB/comments/cDel"] = { authorUid: "uDel", text: "bình luận của người sắp xoá trên bài người khác" };
  S["assets/twelve__avatars__uB__avatar"] = { publicId: "twelve/avatars/uB/avatar", ownerUid: "uB" };
  S["userPrivate/uB"] = { fullName: "Người Khác" };
};
const leftoversOf = (uid) => Object.keys(S).filter((k) => k.includes(uid) || (S[k] && (S[k].authorUid === uid || S[k].ownerUid === uid || S[k].uid === uid)));

test("xoá tài khoản: cần vừa nhập lại mật khẩu, cần confirm:true, tài khoản SA không tự xoá được — và bị chặn thì KHÔNG ghi gì", async () => {
  reset(); seedRichAccount("uA"); seedUser("uSA", { accountGroup: "SA" });
  assert.equal((await call("POST", "/api/users/me/deletion", "tAold", { confirm: true })).status, 403);
  assert.equal((await call("POST", "/api/users/me/deletion", "tA", {})).status, 400);
  assert.equal((await call("POST", "/api/users/me/deletion", "tA", { confirm: "true" })).status, 400);
  const sa = await call("POST", "/api/users/me/deletion", "tSA", { confirm: true });
  assert.equal(sa.status, 403);
  assert.equal(sa.body.code, "SA_CANNOT_SELF_DELETE");
  assert.equal(S["users/uA"].status, "active");
  assert.equal(Object.keys(S).filter((k) => k.startsWith("accountDeletions/")).length, 0, "chưa có sổ nào được tạo");
});

test("xoá tài khoản: ghi sổ + khoá hồ sơ trong CÙNG transaction, trả 202; sau đó tài khoản không dùng được và hồ sơ công khai 404", async () => {
  reset(); seedRichAccount("uDel"); seedBystander();
  cld.gate = new Promise(() => {}); // chặn việc nền ở bước assets: chỉ kiểm trạng thái ngay sau khi nhận yêu cầu
  const r = await call("POST", "/api/users/me/deletion", "tDel", { confirm: true });
  assert.equal(r.status, 202, JSON.stringify(r.body));
  const entry = S["accountDeletions/uDel"];
  assert.ok(entry, "uid được ghi vào Firestore trước khi xoá");
  assert.equal(entry.uid, "uDel");
  assert.equal(S["users/uDel"].status, "deleting");

  const me = await call("GET", "/api/users/me", "tDel");
  assert.equal(me.status, 403);
  assert.equal(me.body.code, "ACCOUNT_DELETING");
  assert.equal((await call("PUT", "/api/users/me/tag-name", "tDel", { tagName: "abc" })).status, 403);
  assert.equal((await call("GET", "/api/users/uDel", null)).status, 404, "hồ sơ công khai biến mất ngay");
  // gửi lại (vd. mạng lỗi lúc nhận 202) không tạo thêm / không hỏng
  const again = await call("POST", "/api/users/me/deletion", "tDel", { confirm: true });
  assert.equal(again.status, 403);
  assert.equal(again.body.code, "ACCOUNT_DELETING");
});

// =========================================================== quy trình xoá nền
test("xoá tài khoản: xoá TRỌN VẸN (bài, blog nháp, subcollection, Cloudinary, tag, dữ liệu riêng, Auth, hồ sơ) rồi dọn sổ; dữ liệu người khác nguyên vẹn", async () => {
  reset(); seedRichAccount("uDel"); seedBystander();
  await deletion.requestDeletion("uDel");
  assert.ok(await waitFor(() => !("accountDeletions/uDel" in S)), "sổ theo dõi được dọn khi xong");

  assert.deepEqual(leftoversOf("uDel").filter((k) => k !== "posts/pB/comments/cDel" && k !== "posts/pB"), [], "không còn gì của uDel");
  assert.ok(!fb.authUsers.has("uDel"), "tài khoản Firebase Auth đã bị xoá");
  assert.ok(cld.calls.some((c) => c[0] === "prefix" && c[1] === "twelve/avatars/uDel/"), "dọn thư mục Cloudinary của đúng user");
  assert.ok(cld.calls.some((c) => c[0] === "ids" && c[1].includes("twelve/avatars/uDel/avatar")));
  assert.ok(!cld.calls.some((c) => JSON.stringify(c).includes("uB")), "không đụng Cloudinary của người khác");
  assert.ok(fb.authCalls.updateUser.some(([uid, p]) => uid === "uDel" && p.disabled === true), "đã vô hiệu hoá tài khoản Auth trước khi xoá");
  assert.ok(fb.authCalls.revoked.includes("uDel"));

  // người khác nguyên vẹn
  assert.ok(S["users/uB"] && S["tagNames/tag_ub"] && S["userPrivate/uB"] && S["assets/twelve__avatars__uB__avatar"] && S["posts/pB"]);
  assert.ok(fb.authUsers.has("uB"));
  assert.equal(S["posts/pB/comments/cDel"].text.includes("sắp xoá"), true, "bình luận trên bài người khác được giữ (phạm vi đã nêu trong PATCH-12-NOTES)");
  // tag được trả lại
  assert.ok(!("tagNames/tag_udel" in S));
});

test("xoá tài khoản: server sập giữa chừng — sổ + hồ sơ `deleting` còn đó, chạy lại thì xoá tiếp ĐÚNG từ bước dở và hoàn tất", async () => {
  reset(); seedRichAccount("uDel"); seedBystander();
  // Cloudinary sự cố ngay lần đầu => bước assets lỗi (bài viết/blog đã xoá xong ở bước trước đó). Đặt TRƯỚC khi kích hoạt việc nền.
  cld.failNext = 1;
  const quiet = console.error; console.error = () => {};
  try {
    await deletion.requestDeletion("uDel");
    assert.ok(await waitFor(() => S["accountDeletions/uDel"] && S["accountDeletions/uDel"].failures === 1), "lỗi được ghi vào sổ");
  } finally { console.error = quiet; }
  const mid = S["accountDeletions/uDel"];
  assert.equal(mid.step, "assets");
  assert.equal(mid.status, "retrying");
  assert.match(mid.lastError, /Cloudinary/);
  assert.ok(S["users/uDel"], "hồ sơ còn (xoá SAU CÙNG) — dấu vết để biết tài khoản nào đang dở");
  assert.equal(S["users/uDel"].status, "deleting");
  assert.ok(!Object.keys(S).some((k) => /^(posts|blogs)\/[^/]+$/.test(k) && S[k].authorUid === "uDel"), "bài/blog đã xoá ở bước trước, không phải làm lại");
  assert.ok(mid.nextAttemptAtMs > Date.now(), "có backoff, không thử lại dồn dập");

  // "Khởi động lại": backoff đã qua, Cloudinary hết sự cố
  S["accountDeletions/uDel"].nextAttemptAtMs = 0;
  D.reset();
  await deletion.pump();
  assert.ok(await waitFor(() => !("accountDeletions/uDel" in S)));
  assert.ok(!("users/uDel" in S) && !fb.authUsers.has("uDel"));
});

test("xoá tài khoản: processOne chạy lại sau khi đã xong một phần — các bước idempotent, kết quả y hệt", async () => {
  reset(); seedRichAccount("uDel"); seedBystander();
  S["users/uDel"].status = "deleting";
  S["accountDeletions/uDel"] = { uid: "uDel", status: "queued", step: "lock", requestedAtMs: Date.now(), failures: 0, rewinds: 0, leaseUntilMs: 0, nextAttemptAtMs: 0 };
  // Mô phỏng sập SAU khi xoá Auth + dữ liệu riêng nhưng TRƯỚC khi xoá hồ sơ
  fb.authUsers.delete("uDel");
  delete S["userPrivate/uDel"]; delete S["tagNames/tag_udel"];
  S["accountDeletions/uDel"].step = "auth";
  assert.equal(await D.processOne("uDel"), true);
  assert.ok(!("users/uDel" in S) && !("accountDeletions/uDel" in S));
  assert.equal(leftoversOf("uDel").filter((k) => k !== "posts/pB/comments/cDel" && k !== "posts/pB").length, 0, "kể cả bài/asset còn sót ở bước trước cũng bị xoá khi quay lại");
});

test("xoá tài khoản: bước kiểm cuối phát hiện bài lọt vào (request ghi dở) => quay lại bước content rồi xoá nốt", async () => {
  reset(); seedRichAccount("uDel");
  S["users/uDel"].status = "deleting";
  S["accountDeletions/uDel"] = { uid: "uDel", status: "queued", step: "lock", requestedAtMs: Date.now(), failures: 0, rewinds: 0, leaseUntilMs: 0, nextAttemptAtMs: 0 };
  let injected = false;
  cld.onPrefix = async () => { if (!injected) { injected = true; S["posts/straggler"] = { authorUid: "uDel", title: "Bài lọt vào sau khi đã xoá" }; } };
  assert.equal(await D.processOne("uDel"), true);
  assert.ok(injected);
  assert.ok(!("posts/straggler" in S), "bài lọt vào cũng bị xoá, không mồ côi");
  assert.ok(!("users/uDel" in S));
});

test("xoá tài khoản: lease — instance khác không giành được việc đang được giữ; lease hết hạn thì nhận lại được", async () => {
  reset(); seedUser("uDel");
  const now = Date.now();
  S["accountDeletions/uDel"] = { uid: "uDel", status: "running", step: "content", requestedAtMs: now, leaseOwner: "instance-khac", leaseUntilMs: now + 60000, failures: 0 };
  assert.equal(await D.claim("uDel"), null, "lease còn hạn của instance khác");
  S["accountDeletions/uDel"].leaseUntilMs = now - 1;
  const got = await D.claim("uDel");
  assert.ok(got, "lease hết hạn => nhận được");
  assert.equal(S["accountDeletions/uDel"].leaseOwner, D.INSTANCE_ID);
  S["accountDeletions/uDel"].status = "failed";
  S["accountDeletions/uDel"].leaseUntilMs = 0;
  assert.equal(await D.claim("uDel"), null, "việc đã 'failed' không tự được nhận");
});

test("xoá tài khoản: hàng chờ — tối đa MAX_CONCURRENT tài khoản chạy cùng lúc, phần còn lại chờ rồi vẫn được xử lý hết theo thứ tự yêu cầu", async () => {
  reset();
  const ids = ["q1", "q2", "q3", "q4", "q5"];
  ids.forEach((uid, i) => {
    seedUser(uid, { status: "deleting" }); seedAuth(uid);
    S[`accountDeletions/${uid}`] = { uid, status: "queued", step: "lock", requestedAtMs: 1000 + i, failures: 0, rewinds: 0, leaseUntilMs: 0, nextAttemptAtMs: 0 };
  });
  let open;
  cld.gate = new Promise((r) => { open = r; });
  const started = [];
  const origPrefix = cloudinaryMock.api.delete_resources_by_prefix;
  cloudinaryMock.api.delete_resources_by_prefix = async (p) => { started.push(p); return origPrefix(p); };
  try {
    await deletion.pump();
    assert.ok(await waitFor(() => started.length >= D.CFG.MAX_CONCURRENT));
    await new Promise((r) => setTimeout(r, 50));
    assert.equal(D.active.size, D.CFG.MAX_CONCURRENT, "không chạy quá hạn mức song song");
    assert.deepEqual(started.slice(0, 2).sort(), ["twelve/avatars/q1/", "twelve/avatars/q2/"], "tài khoản yêu cầu sớm nhất được xử lý trước");
    open();
    assert.ok(await waitFor(() => ids.every((uid) => !(`accountDeletions/${uid}` in S) && !(`users/${uid}` in S))), "mọi yêu cầu cuối cùng đều xong");
  } finally {
    cloudinaryMock.api.delete_resources_by_prefix = origPrefix;
  }
});

test("xoá tài khoản: lỗi liên tiếp quá ngưỡng => 'failed' (không tự thử nữa, hồ sơ vẫn ở trạng thái deleting); script đặt lại đưa về hàng chờ", async () => {
  reset(); seedRichAccount("uDel");
  S["users/uDel"].status = "deleting";
  S["accountDeletions/uDel"] = { uid: "uDel", status: "queued", step: "lock", requestedAtMs: Date.now(), failures: 0, rewinds: 0, leaseUntilMs: 0, nextAttemptAtMs: 0 };
  const maxBefore = D.CFG.MAX_FAILURES;
  D.CFG.MAX_FAILURES = 2;
  const quiet = console.error; console.error = () => {};
  try {
    cld.failNext = 99;
    assert.equal(await D.processOne("uDel"), false);
    assert.equal(S["accountDeletions/uDel"].status, "retrying");
    S["accountDeletions/uDel"].nextAttemptAtMs = 0;
    assert.equal(await D.processOne("uDel"), false);
    assert.equal(S["accountDeletions/uDel"].status, "failed");
    assert.equal(S["accountDeletions/uDel"].failures, 2);
    assert.ok(S["users/uDel"], "chưa mất hồ sơ — còn dấu vết để xử lý tay");
    await deletion.pump();
    await new Promise((r) => setTimeout(r, 30));
    assert.equal(D.active.size, 0, "pump bỏ qua việc 'failed'");

    cld.failNext = 0;
    const { listDeletions } = require("../scripts/account-deletions");
    const out = await listDeletions({ retryFailed: true });
    assert.equal(out.requeued, 1);
    assert.equal(S["accountDeletions/uDel"].status, "queued");
    assert.equal(await D.processOne("uDel"), true);
    assert.ok(!("users/uDel" in S));
  } finally {
    console.error = quiet;
    D.CFG.MAX_FAILURES = maxBefore;
  }
});

test("xoá tài khoản: backoff tăng dần và có trần", () => {
  assert.equal(D.backoffMs(1), D.CFG.BACKOFF_BASE_MS);
  assert.equal(D.backoffMs(2), D.CFG.BACKOFF_BASE_MS * 2);
  assert.equal(D.backoffMs(50), D.CFG.BACKOFF_MAX_MS);
});

test("xoá tài khoản: SIGTERM — releaseLeases trả lease để instance mới nhận ngay", async () => {
  reset(); seedUser("uDel", { status: "deleting" });
  const now = Date.now();
  S["accountDeletions/uDel"] = { uid: "uDel", status: "running", step: "content", requestedAtMs: now, leaseOwner: D.INSTANCE_ID, leaseUntilMs: now + 60000, failures: 0 };
  D.active.add("uDel");
  await deletion.releaseLeases();
  assert.equal(S["accountDeletions/uDel"].leaseUntilMs, 0);
  assert.equal(S["accountDeletions/uDel"].leaseOwner, null);
  D.reset();
});

test("script migrate-fullname-private: dry-run không ghi gì; --apply chuyển và dọn, chạy lại an toàn", async () => {
  reset(); seedUser("uA", { fullName: "Tên A" }); seedUser("uB"); S["userPrivate/uB"] = { fullName: "Tên B" };
  const { migrate } = require("../scripts/migrate-fullname-private");
  const dry = await migrate({ apply: false });
  assert.equal(dry.legacy, 1);
  assert.equal(S["users/uA"].fullName, "Tên A");
  assert.equal(S["userPrivate/uA"], undefined);
  const real = await migrate({ apply: true });
  assert.equal(real.moved, 1);
  assert.equal(S["userPrivate/uA"].fullName, "Tên A");
  assert.equal(S["users/uA"].fullName, undefined);
  assert.equal(S["userPrivate/uB"].fullName, "Tên B", "tài khoản đã chuyển không bị đụng");
  assert.equal((await migrate({ apply: true })).moved, 0);
});

test("Firestore rules: userPrivate và accountDeletions bị chặn hoàn toàn với Client SDK; fullName không còn ở collection đọc được", () => {
  const rules = require("node:fs").readFileSync(path.join(__dirname, "../firestore.rules"), "utf8");
  assert.match(rules, /match \/userPrivate\/\{uid\} \{\s*allow read, write: if false;/);
  assert.match(rules, /match \/accountDeletions\/\{uid\} \{\s*allow read, write: if false;/);
});
