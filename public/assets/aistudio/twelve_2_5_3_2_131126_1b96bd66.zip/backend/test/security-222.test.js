// v2.2.2 — Hồi quy cho báo cáo kiểm tra lại 2.2.1 (R-01 … R-04).
// Chạy: node --test test/security-222.test.js
// Dùng Firestore/Auth GIẢ (test/helpers/fakeFirebase.js) — KHÔNG chạm dịch vụ thật.
const test = require("node:test");
const assert = require("node:assert/strict");

const { install } = require("./helpers/fakeFirebase");
const fb = install({ tokens: {}, authTimes: {} });
const S = fb.store;

const mockRes = () => { const r = { statusCode: 200, body: null }; r.status = (c) => ((r.statusCode = c), r); r.json = (b) => ((r.body = b), r); return r; };
const reset = () => { Object.keys(S).forEach((k) => delete S[k]); fb.authUsers.clear(); };

// =========================================================== R-01
test("R-01: màu hex có kênh alpha ~0 (#fff0, #ffffff00…) và các dạng không tính được (color-mix, var, light-dark) bị loại; màu bình thường vẫn giữ", () => {
  const { sanitizeHtml } = require("../src/services/sanitize.service");
  const gone = [
    "#fff0", "#ffffff00", "#00000000", "#0001", "#ffffff0f", "#FFF0",
    "transparent", "TRANSPARENT", "rgba(0,0,0,0)", "rgba(0,0,0,0.05)", "rgba(0,0,0,5%)", "hsla(0,0%,0%,0)", "rgb(0,0,0,0)",
    "color-mix(in srgb, red, transparent)", "light-dark(red, transparent)", "var(--x)", "calc(1)", "rgb(from red r g b)",
    // v2.3.0 [R-01 còn sót]: ngưỡng alpha cho chữ là 0.5; màu HỆ THỐNG (luôn trùng nền) không còn được nhận
    "#fff2", "#ffffff1a", "#0002", "rgba(255,255,255,0.1)", "rgba(10,20,30,0.1)", "rgba(255,255,255,.49)", "rgba(0,0,0,40%)",
    "canvas", "Canvas", "field", "window", "buttonface", "menu", "highlight", "notacolor",
  ];
  for (const c of gone) {
    const out = sanitizeHtml(`<p style="color:${c}">ẩn</p>`);
    assert.ok(!/style=/.test(out), `color:${c} phải bị loại, nhận: ${out}`);
    assert.ok(out.includes("ẩn"), "nội dung chữ vẫn còn");
  }
  const kept = [
    "#fff", "#ffffff", "#FF0000", "#ffffffcc", "#fffa", "#ffffff80", "red", "Crimson", "RebeccaPurple", "currentcolor", "inherit",
    "rgb(230, 0, 0)", "rgb(230 0 0)", "rgba(10,20,30,0.8)", "rgba(10,20,30,80%)", "rgba(10,20,30,0.5)", "hsl(120, 100%, 50%)", "hsl(120deg 100% 50%)",
  ];
  for (const c of kept) {
    const out = sanitizeHtml(`<p style="color:${c}">hiện</p>`);
    assert.ok(/style=/.test(out) && /color/.test(out), `color:${c} phải được giữ, nhận: ${out}`);
  }
});

// =========================================================== R-02
const csp = require("../src/controllers/csp.controller");
const cspReset = () => csp.__test.reset({}, { json() {} });
const cspSend = (directive, blocked, ip, doc = "https://twelve.test/") =>
  csp.receiveCspReport({ ip, body: { "csp-report": { "document-uri": doc, "effective-directive": directive, "blocked-uri": blocked } } }, { status() { return { end() {} }; } });
const cspView = () => { const r = mockRes(); csp.getCspReports({}, r); return r.body; };
// Muối băm ngẫu nhiên theo tiến trình => hai IP có thể (hiếm) trùng ô. Test chọn IP có ô KHÁC NHAU để kết quả xác định.
let ipSeq = 0;
const distinctIps = (n) => { const out = []; const used = new Set(); while (out.length < n) { const ip = `100.64.${Math.floor(ipSeq / 250)}.${(ipSeq++ % 250) + 1}`; const b = csp.__test.reporterBucket(ip); if (!used.has(b)) { used.add(b); out.push(ip); } } return out; };

test("R-02: MỘT nguồn gửi không tự lấp đầy được bảng hay khoản dự trữ script-src — vi phạm script thật đến sau vẫn được ghi", () => {
  cspReset();
  // đúng kịch bản PoC của báo cáo, nhưng từ MỘT nguồn (không có IP => cùng một ô)
  const [attacker, honest] = distinctIps(2);
  for (let i = 0; i < 300; i++) cspSend("img-src", `https://n${i}.example/a.png`, attacker);
  for (let i = 0; i < 50; i++) cspSend("script-src", `https://evil${i}.example/x.js`, attacker);
  cspSend("script-src", "https://real-xss.example/payload.js", honest);
  const keys = [...csp.__test.entries.keys()];
  assert.ok(keys.some((k) => k.includes("real-xss")), "vi phạm script thật vẫn được ghi");
  assert.ok(keys.filter((k) => /^img-src\|https:\/\/n\d+/.test(k) || /^script-src\|https:\/\/evil/.test(k)).length <= 10, "một nguồn chỉ tạo tối đa 10 khoá mới");
  const v = cspView();
  assert.ok(v.throttled > 0, "phần vượt được đếm vào throttled");
  assert.equal(v.overflow, 0, "bảng chưa hề đầy");
  assert.ok(v.droppedKeys >= v.throttled);
});

test("R-02: số nguồn gửi (`reporters`) — vi phạm thật từ nhiều người dùng khác nhau nổi bật so với nhiễu một nguồn", () => {
  cspReset();
  const ips = distinctIps(8);
  for (let i = 0; i < 7; i++) cspSend("script-src", "https://real-cdn.example", ips[i], `https://twelve.test/page${i}`);
  for (let i = 0; i < 20; i++) cspSend("img-src", "https://noise.example", ips[7]);
  const v = cspView();
  const real = v.entries.find((e) => e.blocked === "https://real-cdn.example");
  const noise = v.entries.find((e) => e.blocked === "https://noise.example");
  assert.equal(real.reporters, 7);
  assert.equal(noise.reporters, 1);
  assert.equal(real.count, 7);
  assert.ok(!("reporterSet" in real), "không lộ cấu trúc nội bộ");
  assert.ok(real.otherDocuments > 0);
});

test("R-02: kẻ tấn công PHÂN TÁN (nhiều nguồn) vẫn có thể lấp đầy — nhưng tốn ≥5 nguồn cho khoản dự trữ, và bị báo bằng overflow; reset mở lại cửa sổ", () => {
  cspReset();
  const ips = distinctIps(36);
  for (let i = 0; i < 300; i++) cspSend("img-src", `https://n${i}.example/a.png`, ips[Math.floor(i / 10)]); // 30 nguồn x 10 khoá
  for (let i = 0; i < 50; i++) cspSend("script-src", `https://evil${i}.example/x.js`, ips[30 + Math.floor(i / 10)]); // 5 nguồn x 10 khoá
  cspSend("script-src", "https://real-xss.example/payload.js", ips[35]);
  assert.ok(![...csp.__test.entries.keys()].some((k) => k.includes("real-xss")), "giới hạn còn lại đã được ghi nhận (không phải lỗi mới)");
  const v = cspView();
  assert.ok(v.overflow >= 1, "nhưng không còn im lặng: overflow > 0");
  cspReset();
  assert.equal(cspView().throttled, 0);
  for (let i = 0; i < 10; i++) cspSend("img-src", `https://again${i}.example/a.png`, ips[0]);
  assert.equal(csp.__test.entries.size, 10, "sau reset, bộ đếm theo nguồn cũng được đặt lại");
});

test("R-02: nguồn gửi lấy từ IP THẬT do middleware Vercel chuyển tiếp (x-twelve-client-ip + secret khớp), không phải IP của Vercel", () => {
  cspReset();
  const prev = process.env.SSR_PROXY_SECRET;
  process.env.SSR_PROXY_SECRET = "s3cret-for-test";
  try {
    const vercelIp = "76.76.21.21"; // mọi request đều đến từ IP của Vercel
    const real = distinctIps(2);
    const sendVia = (clientIp, directive, blocked, secret = "s3cret-for-test") => csp.receiveCspReport({
      ip: vercelIp,
      headers: { "x-twelve-ssr-secret": secret, "x-twelve-client-ip": clientIp },
      body: { "csp-report": { "document-uri": "https://twelve.test/", "effective-directive": directive, "blocked-uri": blocked } },
    }, { status() { return { end() {} }; } });
    for (let i = 0; i < 10; i++) sendVia(real[0], "img-src", `https://a${i}.example/x.png`);
    for (let i = 0; i < 10; i++) sendVia(real[1], "img-src", `https://b${i}.example/x.png`);
    assert.equal(csp.__test.entries.size, 20, "hai người dùng thật khác nhau, mỗi người một hạn mức riêng dù cùng đi qua IP Vercel");
    // secret SAI: header IP không được tin => bị gộp vào một nguồn (IP của Vercel)
    cspReset();
    for (let i = 0; i < 30; i++) sendVia(real[i % 2], "img-src", `https://c${i}.example/x.png`, "sai-secret");
    assert.equal(csp.__test.entries.size, 10, "không tin x-twelve-client-ip khi secret sai");
  } finally { if (prev === undefined) delete process.env.SSR_PROXY_SECRET; else process.env.SSR_PROXY_SECRET = prev; }
});

// =========================================================== R-03
test("R-03: tag lookalike/ghép từ — chặn các dạng trong báo cáo, không chặn tên bình thường", () => {
  const { isReservedTagName: r } = require("../src/utils/helpers");
  const blocked = [
    // các dạng báo cáo kiểm tra lại nêu tên
    "adm1n", "tw3lve", "twe1ve", "suppport", "the_twelve", "twelvehelp", "twelve_vn", "realtwelve", "official_twelve", "admln", "tweive",
    // thêm: leetspeak khác, ghép với từ đệm, chữ lặp
    "h3lp", "r00t", "supp0rt", "moderat0r", "0fficial", "t3am", "the_admin", "admin_vn", "twelveapp_hq", "twelvee", "administrator_vn",
    // vẫn chặn như 2.2.1
    "admin", "Admin_", "admin2", "_admin", "twelve", "twelve_support", "support", "official",
  ];
  for (const t of blocked) assert.equal(r(t), true, `${t} phải bị chặn`);
  const fine = [
    "minh_anh", "twelvefan_vn", "twelve_lover", "an", "nguyen123", "adminton", "helpful", "model", "modern", "supporter", "teammate",
    "rooted", "hello", "nhat_minh", "botanic", "appleseed", "newsletter_vn", "vnexpress", "staffan", "info_nguyen", "mohamed", "island", "lisa",
  ];
  for (const t of fine) assert.equal(r(t), false, `${t} KHÔNG được bị chặn`);
  process.env.RESERVED_TAG_NAMES_EXTRA = "ceo, Founder_";
  try {
    for (const t of ["founder", "the_ceo", "c3o", "ceo9"]) assert.equal(r(t), true, t);
    assert.equal(r("ceoful"), false);
  } finally { delete process.env.RESERVED_TAG_NAMES_EXTRA; }
  assert.equal(r("founder"), false);
});

test("R-03: check-tagname báo 'đã dành riêng' cả với lookalike; script chỉ-đọc liệt kê tag dành riêng đang bị giữ kèm nhóm tài khoản", async () => {
  reset();
  const authCtrl = require("../src/controllers/auth.controller");
  const chk = mockRes(); await authCtrl.checkTagName({ query: { tag: "tw3lve" } }, chk);
  assert.deepEqual(chk.body, { available: false, reserved: true });

  S["users/uSA"] = { uid: "uSA", status: "active", accountGroup: "SA", tagName: "@admin" };
  S["users/uX"] = { uid: "uX", status: "active", accountGroup: "RA", tagName: "@the_twelve" };
  S["users/uY"] = { uid: "uY", status: "active", accountGroup: "RA", tagName: "@minh_anh" };
  S["tagNames/admin"] = { uid: "uSA" };
  S["tagNames/the_twelve"] = { uid: "uX" };
  S["tagNames/minh_anh"] = { uid: "uY" };
  const { auditReservedTags } = require("../src/services/reservedTagAudit");
  const out = await auditReservedTags();
  assert.equal(out.scanned, 3);
  assert.deepEqual(out.hits.map((h) => [h.tag, h.accountGroup]).sort(), [["admin", "SA"], ["the_twelve", "RA"]]);
  assert.equal(S["tagNames/the_twelve"].uid, "uX", "chỉ đọc — không sửa gì");
});

// =========================================================== R-04
test("R-04: pending:cleanup:apply kiểm lại NGAY trước khi xoá — người vừa xác minh email hoặc vừa được kích hoạt giữa hai vòng không bị xếp hàng xoá", async () => {
  reset();
  const iso = (d) => new Date(Date.now() - d * 86400000).toISOString();
  S["users/pRace"] = { uid: "pRace", status: "pending", email: "r@x.com", tagName: "prace", createdAt: iso(30) };
  S["users/pRace2"] = { uid: "pRace2", status: "pending", email: "r2@x.com", tagName: "prace2", createdAt: iso(30) };
  S["users/pStay"] = { uid: "pStay", status: "pending", email: "s@x.com", tagName: "pstay", createdAt: iso(30) };
  const calls = {};
  const realGetUser = fb.auth.getUser;
  fb.auth.getUser = async (uid) => {
    calls[uid] = (calls[uid] || 0) + 1;
    if (uid === "pRace") return { uid, emailVerified: calls[uid] > 1 };            // xác minh email SAU lần quét đầu
    if (uid === "pRace2") { if (calls[uid] === 1) S["users/pRace2"].status = "active"; return { uid, emailVerified: false }; } // được kích hoạt sau lần quét đầu
    return { uid, emailVerified: false };
  };
  try {
    const { cleanupExpiredPending } = require("../src/services/pendingCleanup");
    const out = await cleanupExpiredPending({ apply: true });
    assert.equal(out.expired.length, 3, "cả 3 đều lọt danh sách ở lần quét đầu (đó chính là khe hở)");
    assert.equal(out.queued, 1, "chỉ pStay được xếp hàng xoá");
    assert.equal(out.skippedLate, 2);
    assert.equal(S["users/pStay"].status, "deleting");
    assert.ok(S["accountDeletions/pStay"]);
    assert.equal(S["users/pRace"].status, "pending", "người vừa xác minh email giữ nguyên");
    assert.equal(S["users/pRace2"].status, "active", "người vừa được kích hoạt giữ nguyên");
    assert.equal(S["accountDeletions/pRace"], undefined);
    assert.equal(S["accountDeletions/pRace2"], undefined);
  } finally { fb.auth.getUser = realGetUser; }
});
