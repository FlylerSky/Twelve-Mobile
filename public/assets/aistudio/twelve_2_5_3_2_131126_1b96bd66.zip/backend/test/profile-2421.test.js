// v2.4.2.1 — URL hồ sơ dùng TAG NAME SEARCH thay cho UID: GET /api/users/by-tag/:tag, helper dựng URL, đổi tag.
// Chạy: node --test test/profile-2421.test.js
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const express = require("express");

const { install } = require("./helpers/fakeFirebase");
const nowSec = () => Math.floor(Date.now() / 1000);
const fb = install({
  tokens: { tA: "uA", tB: "uB" },
  authTimes: { tA: nowSec() - 10, tB: nowSec() - 10 },
});
const S = fb.store;

const helpers = require("../src/utils/helpers");
const limiters = require("../src/middleware/rateLimiters");

const app = express();
app.use(express.json());
app.use("/api/users", require("../src/routes/users.routes"));
let base;
let server;
test.before(async () => {
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

const call = async (method, url, token, body) => {
  const res = await fetch(base + url, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json = null;
  try { json = await res.json(); } catch (_e) { /* không có body */ }
  return { status: res.status, body: json };
};

const reset = () => {
  for (const uid of ["uA", "uB"]) {
    limiters.sensitiveAccountLimiter.resetKey(`uid:${uid}`);
    limiters.profileWriteLimiter.resetKey(`uid:${uid}`);
  }
  Object.keys(S).forEach((k) => delete S[k]);
};
// seedUser: có cả document `tagNames/<tag>` (khoá duy nhất của Tag Name) như dữ liệu thật.
const seedUser = (uid, over = {}) => {
  const tagName = over.tagName !== undefined ? over.tagName : `tag_${uid.toLowerCase()}`;
  S[`users/${uid}`] = { uid, displayName: `Tên ${uid}`, tagName, status: "active", accountGroup: "RA", accountRole: "user", country: "VN", email: `${uid.toLowerCase()}@x.com`, accountScore: 0, ...over };
  if (tagName) S[`tagNames/${tagName}`] = { uid };
};

// =========================================================== helper dựng URL
test("profilePath: /u/@<tag> chữ thường; thiếu tag hợp lệ thì rơi về UID (link không bao giờ chết)", () => {
  assert.equal(helpers.profilePath({ uid: "EZRxcGpJUEcSAuFfElxj8ja8KQ22", tagName: "@FlylerSky" }), "/u/@flylersky");
  assert.equal(helpers.profilePath({ uid: "u1", tagName: "abc_123" }), "/u/@abc_123");
  assert.equal(helpers.profilePath({ uid: "EZRx" }), "/u/EZRx");
  assert.equal(helpers.profilePath({ uid: "EZRx", tagName: "x" }), "/u/EZRx", "tag sai định dạng (quá ngắn) không dùng làm URL");
  assert.equal(helpers.profilePath({ uid: "EZRx", tagName: "có dấu" }), "/u/EZRx");
  assert.ok(!helpers.profilePath({ uid: "UID_SECRET_123", tagName: "@abc" }).includes("UID_SECRET_123"), "URL tag không chứa UID");
});

test("classifyProfileRef: chỉ 'tag có @' mới là tag; myProfile là route riêng; còn lại là UID cũ — không bao giờ nhập nhằng", () => {
  assert.deepEqual(helpers.classifyProfileRef("@abc"), { kind: "tag", tag: "abc" });
  assert.deepEqual(helpers.classifyProfileRef("@Abc_9"), { kind: "tag", tag: "abc_9" });
  assert.deepEqual(helpers.classifyProfileRef("@x".repeat(1)), { kind: "invalid" }, "'@x' — tag quá ngắn");
  assert.deepEqual(helpers.classifyProfileRef("@a-b-c"), { kind: "invalid" });
  assert.deepEqual(helpers.classifyProfileRef("@"), { kind: "invalid" });
  assert.deepEqual(helpers.classifyProfileRef("@" + "x".repeat(21)), { kind: "invalid" });
  // KHÔNG có "@" thì KHÔNG bao giờ là tag — kể cả khi trông giống tag hợp lệ.
  assert.equal(helpers.classifyProfileRef("abc").kind, "uid");
  assert.equal(helpers.classifyProfileRef("flylersky").kind, "uid");
  // route riêng của người đang đăng nhập, không phân biệt hoa/thường; "@myProfile" là tag bình thường (một người có thể đặt tag này)
  assert.deepEqual(helpers.classifyProfileRef("myProfile"), { kind: "self" });
  assert.deepEqual(helpers.classifyProfileRef("MYPROFILE"), { kind: "self" });
  assert.deepEqual(helpers.classifyProfileRef("@myProfile"), { kind: "tag", tag: "myprofile" });
  assert.equal(helpers.classifyProfileRef("EZRxcGpJUEcSAuFfElxj8ja8KQ22").kind, "uid");
  assert.equal(helpers.classifyProfileRef(undefined).kind, "uid");
  assert.equal(helpers.classifyProfileRef(["@abc"]).kind, "uid");
});

// =========================================================== GET /api/users/by-tag/:tag
test("by-tag: trả hồ sơ công khai; nhận 'abc', '@abc', chữ hoa; không lộ email/tên thật", async () => {
  reset(); seedUser("uA", { tagName: "flyler_sky", fullName: "Bí Mật", birthday: "2000-01-01" });
  for (const form of ["flyler_sky", "FLYLER_sky", "@flyler_sky", "%40Flyler_Sky"]) {
    const r = await call("GET", `/api/users/by-tag/${form}`);
    assert.equal(r.status, 200, `${form}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.user.tagName, "@flyler_sky");
    assert.equal(r.body.user.uid, "uA", "frontend cần uid để gọi /posts, /pinned (chỉ trong bộ nhớ, không lên thanh địa chỉ)");
    assert.equal(r.body.user.displayName, "Tên uA");
    assert.ok(Array.isArray(r.body.user.badges));
    const dump = JSON.stringify(r.body);
    assert.ok(!dump.includes("@x.com") && !dump.includes("Bí Mật") && !dump.includes("2000-01-01"), "không lộ email / tên thật / ngày sinh");
  }
});

test("by-tag: tag không tồn tại / sai định dạng => 404 như nhau (không phân biệt để dò)", async () => {
  reset(); seedUser("uA");
  for (const bad of ["khongco", "ab", "x".repeat(21), "co-gach", "c%C3%B3d%E1%BA%A5u", "a%2Fb", "tag_ua%2Fposts"]) {
    const r = await call("GET", `/api/users/by-tag/${bad}`);
    assert.equal(r.status, 404, bad);
    assert.equal(r.body.error, "Không tìm thấy người dùng.");
  }
});

test("by-tag: hồ sơ pending / đang xoá / 'ma' (không có status) => 404; suspended vẫn công khai (như API cũ)", async () => {
  reset();
  seedUser("uP", { tagName: "dang_cho", status: "pending" });
  seedUser("uD", { tagName: "dang_xoa", status: "deleting" });
  seedUser("uG", { tagName: "ho_so_ma", status: undefined });
  seedUser("uS", { tagName: "bi_khoa", status: "suspended" });
  assert.equal((await call("GET", "/api/users/by-tag/dang_cho")).status, 404);
  assert.equal((await call("GET", "/api/users/by-tag/dang_xoa")).status, 404);
  assert.equal((await call("GET", "/api/users/by-tag/ho_so_ma")).status, 404);
  assert.equal((await call("GET", "/api/users/by-tag/bi_khoa")).status, 200);
});

test("by-tag: document tagNames LỆCH (trỏ tới người đã đổi tag / không còn tồn tại) => 404, không bao giờ hiện nhầm hồ sơ", async () => {
  reset();
  seedUser("uA", { tagName: "tag_moi" });
  S["tagNames/tag_cu"] = { uid: "uA" }; // dữ liệu cũ lệch: uA đã đổi sang tag_moi nhưng khoá cũ còn sót
  assert.equal((await call("GET", "/api/users/by-tag/tag_cu")).status, 404, "uA không còn giữ tag_cu");
  assert.equal((await call("GET", "/api/users/by-tag/tag_moi")).status, 200);
  S["tagNames/mo_coi"] = { uid: "uBiXoa" }; // trỏ tới tài khoản không còn
  assert.equal((await call("GET", "/api/users/by-tag/mo_coi")).status, 404);
  S["tagNames/hong"] = {}; // thiếu uid
  assert.equal((await call("GET", "/api/users/by-tag/hong")).status, 404);
});

test("by-tag: tag trùng tên đường dẫn con ('posts', 'pinned') không bị nhầm với /:uid/posts", async () => {
  reset(); seedUser("uA", { tagName: "posts" }); seedUser("uB", { tagName: "pinned" });
  const a = await call("GET", "/api/users/by-tag/posts");
  assert.equal(a.status, 200);
  assert.equal(a.body.user.uid, "uA");
  const b = await call("GET", "/api/users/by-tag/pinned");
  assert.equal(b.status, 200);
  assert.equal(b.body.user.uid, "uB");
});

test("by-tag: có áp rate limit đọc hồ sơ (profileReadLimiter) như GET /:uid", async () => {
  reset(); seedUser("uA");
  const key = "ip:" + "127.0.0.1";
  let last = 200;
  // limiter dùng khoá theo uid/IP; chỉ cần chứng minh có 429 khi vượt mức — dùng đúng giới hạn đang cấu hình.
  for (let i = 0; i < 205 && last !== 429; i++) last = (await call("GET", "/api/users/by-tag/tag_ua")).status;
  assert.equal(last, 429, "vượt mức phải bị 429");
  // dọn bộ đếm để không ảnh hưởng test khác
  [key, "ip:::1", "ip:::ffff:127.0.0.1"].forEach((k) => { try { limiters.profileReadLimiter.resetKey(k); } catch (_e) { /* bỏ qua */ } });
});

// =========================================================== tương thích ngược + đổi tag
test("tương thích: GET /api/users/:uid (link/phiên bản cũ) vẫn hoạt động", async () => {
  reset(); seedUser("uA", { tagName: "tag_ua" });
  const r = await call("GET", "/api/users/uA");
  assert.equal(r.status, 200);
  assert.equal(r.body.user.tagName, "@tag_ua");
});

test("đổi Tag Name: URL mới tra được ngay, URL tag cũ => 404 (tag được trả lại)", async () => {
  reset(); seedUser("uA", { tagName: "tag_ua" });
  assert.equal((await call("GET", "/api/users/by-tag/tag_ua")).status, 200);
  const change = await call("PUT", "/api/users/me/tag-name", "tA", { tagName: "ten_moi" });
  assert.equal(change.status, 200, JSON.stringify(change.body));
  const fresh = await call("GET", "/api/users/by-tag/ten_moi");
  assert.equal(fresh.status, 200);
  assert.equal(fresh.body.user.uid, "uA");
  assert.equal((await call("GET", "/api/users/by-tag/tag_ua")).status, 404, "tag cũ không còn trỏ về uA");
});

test("tag cũ được người khác nhận: URL tag cũ thuộc về chủ MỚI, không về chủ cũ", async () => {
  reset(); seedUser("uA", { tagName: "tag_ua" }); seedUser("uB", { tagName: "tag_ub" });
  assert.equal((await call("PUT", "/api/users/me/tag-name", "tA", { tagName: "ten_moi" })).status, 200);
  assert.equal((await call("PUT", "/api/users/me/tag-name", "tB", { tagName: "tag_ua" })).status, 200);
  const r = await call("GET", "/api/users/by-tag/tag_ua");
  assert.equal(r.status, 200);
  assert.equal(r.body.user.uid, "uB");
});
