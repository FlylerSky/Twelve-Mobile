// v2.3.0 — Hồi quy cho khung "Gỡ lỗi" (src/debug/) + hai bản vá nhỏ R-01 (màu chữ) và R-03 (tag dành riêng).
// Chạy: node --test test/debug-230.test.js
// Dùng Firestore/Auth GIẢ. Các module chế độ "isolated" mở tiến trình con thật (≈ 1 giây mỗi module).
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const express = require("express");

const { install } = require("./helpers/fakeFirebase");
const nowSec = () => Math.floor(Date.now() / 1000);
const fb = install({
  tokens: { tSA: "uSA", tSAold: "uSA", tU: "uU" },
  authTimes: { tSA: nowSec() - 10, tSAold: nowSec() - 3600, tU: nowSec() - 10 },
});
const S = fb.store;
S["users/uSA"] = { uid: "uSA", displayName: "SA", tagName: "sa_user", status: "active", accountGroup: "SA", accountRole: "admin" };
S["users/uU"] = { uid: "uU", displayName: "U", tagName: "plain_user", status: "active", accountGroup: "RA", accountRole: "user" };

// Môi trường như server.js: lớp chuyển lỗi async + bộ bắt lỗi toàn cục (module cfg-runtime kiểm các lưới an toàn này)
require("../src/utils/asyncErrors").installAsyncErrorForwarding();
process.on("unhandledRejection", () => {});
process.on("uncaughtException", () => {});

const registry = require("../src/debug/registry");
const runner = require("../src/debug/runner");
const child = require("../src/debug/child");
const pkg = require("../package.json");

const REQUIRED_IDS = [ // QUY ƯỚC "chỉ thêm, không xoá": xoá một module trong danh sách này làm test đỏ. Thêm module mới thì thêm id vào đây.
  "a01-uid-crash", "a02-delete-race", "a03-forgot-timing", "a04-reserved-tags", "a05-csp-monitor", "a06-style-hidden-text",
  "cfg-runtime", "rules-private-collections", "manual-external",
];

// ---------------------------------------------------------------- sổ đăng ký
test("registry: nạp đủ module, không lỗi khai báo, id duy nhất, không xoá module cũ", () => {
  registry.__test.reset();
  const reg = registry.getRegistry();
  assert.deepEqual(reg.errors, [], "mọi tệp trong modules/ phải hợp lệ");
  const ids = reg.list.map((m) => m.id);
  assert.equal(new Set(ids).size, ids.length, "id không trùng");
  for (const id of REQUIRED_IDS) assert.ok(ids.includes(id), `thiếu module "${id}" — module chỉ được thêm, không được xoá`);
  for (const m of reg.list) {
    assert.ok(registry.compareVersions(m.recordedIn, pkg.version) <= 0, `${m.id}: recordedIn ${m.recordedIn} > phiên bản hiện tại ${pkg.version}`);
    if (m.fixedIn) {
      assert.ok(registry.compareVersions(m.fixedIn, m.recordedIn) >= 0, `${m.id}: fixedIn < recordedIn`);
      assert.ok(registry.compareVersions(m.fixedIn, pkg.version) <= 0, `${m.id}: fixedIn ${m.fixedIn} > phiên bản hiện tại`);
    }
  }
});

test("registry: validateModule bắt các khai báo sai", () => {
  const ok = { id: "x-1", title: "T", severity: "low", recordedIn: "2.3.0", description: "mô tả đủ dài để hợp lệ", mode: "unit", run() {} };
  assert.deepEqual(registry.validateModule(ok), []);
  for (const [patch, label] of [
    [{ id: "Bad_Id" }, "id sai"], [{ id: "a/b" }, "id có /"], [{ severity: "critical" }, "severity sai"], [{ recordedIn: "v2" }, "recordedIn sai"],
    [{ mode: "remote" }, "mode sai"], [{ run: null }, "thiếu run"], [{ description: "ngắn" }, "mô tả ngắn"], [{ timeoutMs: 999999 }, "timeout quá lớn"],
  ]) assert.ok(registry.validateModule({ ...ok, ...patch }).length > 0, `phải bắt: ${label}`);
});

// ---------------------------------------------------------------- bộ chạy (module tổng hợp)
const synthetic = (mods) => registry.__test.set({ list: mods, byId: new Map(mods.map((m) => [m.id, m])), errors: [] });
const base = { severity: "low", recordedIn: "2.3.0", description: "module tổng hợp dùng cho test bộ chạy", mode: "unit" };
test.afterEach(() => { registry.__test.reset(); runner.__test.reset(); delete process.env.DEBUG_PANEL_ENABLED; });

test("runner: suy ra trạng thái pass / fail / warn / error / skip / manual / không kiểm tra", async () => {
  synthetic([
    { ...base, id: "t-pass", title: "p", async run(c) { c.check("a", true); } },
    { ...base, id: "t-fail", title: "f", async run(c) { c.check("a", true); c.check("b", false, "hỏng"); } },
    { ...base, id: "t-warn", title: "w", async run(c) { c.check("a", true); c.check("b", false, "khuyến nghị", { level: "warn" }); } },
    { ...base, id: "t-err", title: "e", async run() { throw new Error("nổ"); } },
    { ...base, id: "t-skip", title: "s", async run(c) { return c.skip("không có mạng"); } },
    { ...base, id: "t-man", title: "m", async run(c) { return c.manual([{ title: "Bước 1", how: "làm X" }]); } },
    { ...base, id: "t-none", title: "n", async run() {} },
  ]);
  const get = async (id) => runner.runModule(id);
  assert.equal((await get("t-pass")).status, "pass");
  const f = await get("t-fail"); assert.equal(f.status, "fail"); assert.match(f.summary, /1 kiểm tra KHÔNG đạt/);
  assert.equal((await get("t-warn")).status, "warn");
  const e = await get("t-err"); assert.equal(e.status, "error"); assert.ok(e.logs.some((l) => /nổ/.test(l.msg)));
  const s = await get("t-skip"); assert.equal(s.status, "skip"); assert.equal(s.reason, "không có mạng");
  const m = await get("t-man"); assert.equal(m.status, "manual"); assert.equal(m.steps.length, 1);
  assert.equal((await get("t-none")).status, "error", "module không ghi phép kiểm tra nào không được 'đạt' ngầm");
});

test("runner: timeout kill việc đang chạy và chạy dọn dẹp; nhả khoá để chạy tiếp", async () => {
  let cleaned = false;
  synthetic([
    { ...base, id: "t-slow", title: "slow", timeoutMs: 80, async run(c) { c.onCleanup(() => { cleaned = true; }); await new Promise(() => {}); } },
    { ...base, id: "t-ok", title: "ok", async run(c) { c.check("a", true); } },
  ]);
  const r = await runner.runModule("t-slow");
  assert.equal(r.status, "timeout");
  assert.ok(cleaned, "cleanup phải chạy khi timeout");
  assert.equal((await runner.runModule("t-ok")).status, "pass", "khoá đã được nhả");
});

test("runner: chỉ MỘT module chạy một lúc (409 DEBUG_BUSY), id lạ 404, tắt bằng DEBUG_PANEL_ENABLED=off → 403", async () => {
  let release;
  synthetic([
    { ...base, id: "t-long", title: "long", async run(c) { await new Promise((r) => { release = r; }); c.check("a", true); } },
    { ...base, id: "t-ok", title: "ok", async run(c) { c.check("a", true); } },
  ]);
  const p = runner.runModule("t-long");
  await new Promise((r) => setTimeout(r, 30));
  await assert.rejects(() => runner.runModule("t-ok"), (e) => e.status === 409 && e.code === "DEBUG_BUSY");
  release(); await p;
  await assert.rejects(() => runner.runModule("khong-co"), (e) => e.status === 404);
  process.env.DEBUG_PANEL_ENABLED = "off";
  await assert.rejects(() => runner.runModule("t-ok"), (e) => e.status === 403 && e.code === "DEBUG_DISABLED");
});

test("runner: che bí mật (biến môi trường, khoá PEM, JWT) ở log, chi tiết kiểm tra và cả giá trị trả về", async () => {
  process.env.TEST_DEBUG_SECRET_TOKEN = "super-secret-value-123456";
  const jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abcdefghijklmnopqrstuvwxyz";
  const pem = "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkq\n-----END PRIVATE KEY-----";
  synthetic([{ ...base, id: "t-leak", title: "leak", async run(c) {
    c.log(`token=${process.env.TEST_DEBUG_SECRET_TOKEN}`);
    c.check(`tên ${process.env.TEST_DEBUG_SECRET_TOKEN}`, false, `chi tiết ${jwt} và ${pem}`);
    c.metric(`số đo ${process.env.TEST_DEBUG_SECRET_TOKEN}`, 1);
  } }]);
  const r = await runner.runModule("t-leak");
  const dump = JSON.stringify(r);
  delete process.env.TEST_DEBUG_SECRET_TOKEN;
  assert.ok(!dump.includes("super-secret-value-123456"), "bí mật env không được lọt");
  assert.ok(!dump.includes("eyJhbGciOiJIUzI1NiJ9"), "JWT không được lọt");
  assert.ok(!dump.includes("MIIEvQIBADANBgkq"), "khoá PEM không được lọt");
  assert.ok(dump.includes("[đã ẩn]"));
});

test("runner: giới hạn dung lượng (số dòng log, độ dài dòng, số kiểm tra) và đánh dấu truncated", async () => {
  synthetic([{ ...base, id: "t-big", title: "big", async run(c) {
    for (let i = 0; i < 1000; i++) c.log("x".repeat(2000));
    for (let i = 0; i < 500; i++) c.check(`c${i}`, true);
  } }]);
  const r = await runner.runModule("t-big");
  assert.ok(r.logs.length <= runner.LIMITS.LOG_LINES);
  assert.ok(r.logs.every((l) => l.msg.length <= runner.LIMITS.LINE_CHARS + 1));
  assert.ok(r.checks.length <= runner.LIMITS.CHECKS);
  assert.equal(r.truncated, true);
});

test("runner: chỉ lưu BẢN TÓM TẮT vào debugRuns (không log), ghi lại phiên bản và người chạy", async () => {
  synthetic([{ ...base, id: "t-save", title: "save", async run(c) { c.log("dòng log nhạy cảm"); c.check("a", true); } }]);
  await runner.runModule("t-save", { actorUid: "uSA" });
  const doc = S["debugRuns/t-save"];
  assert.ok(doc);
  assert.equal(doc.status, "pass"); assert.equal(doc.appVersion, pkg.version); assert.equal(doc.actorUid, "uSA");
  assert.ok(!JSON.stringify(doc).includes("nhạy cảm"), "không lưu log");
  assert.equal(doc.logs, undefined);
  delete S["debugRuns/t-save"];
});

test("runner: ctx.httpsGet chỉ tới host trong danh sách cho phép; ctx.http chỉ nhận đường dẫn tương đối", async () => {
  let called = 0;
  runner.__test.deps.fetch = async () => { called++; return { status: 404, text: async () => "x" }; };
  const out = {};
  synthetic([{ ...base, id: "t-net", title: "net", async run(c) {
    out.bad1 = await c.httpsGet("https://evil.example/x");
    out.bad2 = await c.httpsGet("http://firestore.googleapis.com/x");
    out.bad3 = await c.httpsGet("khong-phai-url");
    out.good = await c.httpsGet("https://firestore.googleapis.com/v1/projects/p/databases/(default)/documents/config/x");
    out.rel = await c.http.get("http://evil.example/");
    c.check("ok", true);
  } }]);
  await runner.runModule("t-net");
  runner.__test.deps.fetch = (...a) => globalThis.fetch(...a);
  assert.match(out.bad1.error, /HOST KHÔNG ĐƯỢC PHÉP/); assert.ok(out.bad2.error); assert.ok(out.bad3.error);
  assert.equal(out.good.status, 404); assert.equal(called, 1, "chỉ MỘT lượt fetch thật (tới host cho phép)");
  assert.ok(out.rel.error, "đường dẫn tuyệt đối bị từ chối");
});

// ---------------------------------------------------------------- tiến trình con
test("child: chỉ chạy script nằm trong children/; môi trường tiến trình con KHÔNG thừa kế bí mật", () => {
  for (const bad of ["../child.js", "../../server.js", "a/b.js", "x.sh", "", "Race-Probe.js", "race-probe.js; ls"]) assert.throws(() => child.runChildScript(bad), /không hợp lệ|không có script/, bad);
  assert.throws(() => child.runChildScript("race-probe.js", ["x".repeat(300)]), /args/);
  process.env.SOME_SECRET_TOKEN = "abc-secret"; process.env.FIREBASE_SERVICE_ACCOUNT = "{\"private_key\":\"zzz\"}"; process.env.CLOUDINARY_API_SECRET = "cl-secret";
  const env = child.buildChildEnv({ PORT: 1234 });
  delete process.env.SOME_SECRET_TOKEN; delete process.env.FIREBASE_SERVICE_ACCOUNT; delete process.env.CLOUDINARY_API_SECRET;
  assert.equal(env.NODE_ENV, "development");
  assert.equal(env.PORT, "1234");
  assert.ok(!("SOME_SECRET_TOKEN" in env) && !("FIREBASE_SERVICE_ACCOUNT" in env) && !("CLOUDINARY_API_SECRET" in env));
  assert.ok(Object.keys(env).every((k) => ["PATH", "HOME", "TMPDIR", "TEMP", "TMP", "LANG", "LC_ALL", "SystemRoot", "NODE_ENV", "TWELVE_DEBUG_CHILD", "PORT"].includes(k)), `biến lạ: ${Object.keys(env)}`);
});

// ---------------------------------------------------------------- module thật
test("module thật: a01…a06 ĐẠT trên mã hiện tại (hồi quy các lỗi đã vá), cfg/manual/rules đúng kiểu", async () => {
  registry.__test.reset();
  for (const id of ["a01-uid-crash", "a02-delete-race", "a03-forgot-timing", "a04-reserved-tags", "a05-csp-monitor", "a06-style-hidden-text"]) {
    const r = await runner.runModule(id);
    assert.equal(r.status, "pass", `${id} phải đạt, nhận ${r.status}: ${r.checks.filter((c) => !c.ok).map((c) => `${c.name} (${c.detail})`).join("; ")}`);
    assert.ok(r.checks.length >= 2, `${id} có phép kiểm tra thật`);
  }
  const cfg = await runner.runModule("cfg-runtime");
  assert.ok(["pass", "warn"].includes(cfg.status), `cfg-runtime: ${cfg.status} — ${JSON.stringify(cfg.checks.filter((c) => c.level === "fail"))}`);
  assert.equal((await runner.runModule("manual-external")).status, "manual");
});

test("module a05 chạy CÔ LẬP: không đụng bảng CSP của tiến trình thật", async () => {
  const csp = require("../src/controllers/csp.controller");
  csp.__test.reset({}, { json() {} });
  csp.receiveCspReport({ ip: "203.0.113.5", body: { "csp-report": { "document-uri": "https://twelve.test/", "effective-directive": "script-src", "blocked-uri": "https://giu-lai.example/x.js" } } }, { status() { return { end() {} }; } });
  const before = [...csp.__test.entries.keys()];
  assert.equal(before.length, 1);
  const r = await runner.runModule("a05-csp-monitor");
  assert.equal(r.status, "pass");
  assert.deepEqual([...csp.__test.entries.keys()], before, "dữ liệu quan sát của quản trị viên phải còn nguyên");
  csp.__test.reset({}, { json() {} });
});

test("module rules-private-collections: phân biệt được 'chặn' / 'cho đọc' / 'không phân biệt được' / 'không có mạng'", async () => {
  process.env.FIREBASE_PROJECT_ID = "demo-proj";
  const run = async (fn) => { runner.__test.deps.fetch = async (url) => fn(String(url)); return runner.runModule("rules-private-collections"); };
  const res = (status) => ({ status, text: async () => "" });
  try {
    // v2.5.3 [TW-07/TW-13]: đối chứng "cho đọc công khai" đổi từ config/ sang countries/ (config/ nay bị khoá nên cũng trả 403); thêm probe `config` và phép kiểm file rules nguồn.
    const ok = await run((u) => res(u.includes("/countries/") ? 404 : 403));
    assert.equal(ok.status, "pass"); assert.equal(ok.checks.length, 9); // 1 đối chứng countries + 7 probe (userPrivate, accountDeletions, assets, debugRuns, profileVisitors [v2.5.2], users, config [v2.5.3]) + 1 kiểm file rules nguồn
    assert.ok(ok.checks.some((c) => /firestore\.rules \(nguồn\)/.test(c.name) && c.ok), "file rules trong mã nguồn khoá positiveScoreLogs và config");
    const open = await run((u) => res(u.includes("/userPrivate/") || u.includes("/countries/") ? 404 : 403));
    assert.equal(open.status, "fail", "userPrivate cho đọc (404) phải bị phát hiện");
    assert.ok(open.checks.some((c) => !c.ok && /userPrivate/.test(c.name)));
    const cfgOpen = await run((u) => res(u.includes("/config/") || u.includes("/countries/") ? 404 : 403));
    assert.equal(cfgOpen.status, "fail", "config cho đọc công khai (rules cũ chưa deploy) phải bị phát hiện");
    assert.ok(cfgOpen.checks.some((c) => !c.ok && /^config:/.test(c.name)));
    const ambiguous = await run(() => res(403));
    assert.equal(ambiguous.status, "skip", "đối chứng cũng 403 ⇒ không phân biệt được ⇒ không được báo 'đạt' giả");
    const offline = await run(() => { throw new Error("ENOTFOUND"); });
    assert.equal(offline.status, "skip");
  } finally { runner.__test.deps.fetch = (...a) => globalThis.fetch(...a); delete process.env.FIREBASE_PROJECT_ID; }
  assert.equal((await runner.runModule("rules-private-collections")).status, "skip", "không có project id ⇒ bỏ qua");
});

// ---------------------------------------------------------------- API
const app = express();
app.use(express.json());
app.use("/api/admin", require("../src/routes/admin.routes"));
let server; let base_;
test.before(async () => { server = http.createServer(app); await new Promise((r) => server.listen(0, "127.0.0.1", r)); base_ = `http://127.0.0.1:${server.address().port}`; });
test.after(() => server.close());
const call = async (method, url, token) => {
  const res = await fetch(base_ + url, { method, headers: token ? { Authorization: `Bearer ${token}` } : {} });
  let body = null; try { body = await res.json(); } catch (_e) { /* không có thân */ }
  return { status: res.status, body };
};

test("API: phân quyền — chưa đăng nhập 401, người thường 403, SA mới xem/chạy được", async () => {
  assert.equal((await call("GET", "/api/admin/debug/modules")).status, 401);
  assert.equal((await call("GET", "/api/admin/debug/modules", "tU")).status, 403);
  assert.equal((await call("POST", "/api/admin/debug/modules/a04-reserved-tags/run", "tU")).status, 403);
  assert.equal((await call("POST", "/api/admin/debug/modules/a04-reserved-tags/run")).status, 401);
  const list = await call("GET", "/api/admin/debug/modules", "tSA");
  assert.equal(list.status, 200);
  assert.equal(list.body.appVersion, pkg.version);
  assert.equal(list.body.enabled, true);
  assert.equal(list.body.loadErrors, 0);
  assert.deepEqual(list.body.modules.map((m) => m.id).sort(), [...REQUIRED_IDS].sort());
  assert.ok(list.body.modules.every((m) => typeof m.run === "undefined" && m.description && m.recordedIn), "chỉ trả siêu dữ liệu, không lộ hàm run");
});

test("API: chạy module đòi nhập lại mật khẩu gần đây (token cũ → 403 REAUTH_REQUIRED), id lạ/độc hại → 404", async () => {
  const stale = await call("POST", "/api/admin/debug/modules/a04-reserved-tags/run", "tSAold");
  assert.equal(stale.status, 403); assert.equal(stale.body.code, "REAUTH_REQUIRED");
  for (const id of ["khong-co", "a%2Fb", "..", "%2e%2e", "A04", "a04_reserved", "x".repeat(200), "a04-reserved-tags;ls"]) {
    const r = await call("POST", `/api/admin/debug/modules/${id}/run`, "tSA");
    assert.equal(r.status, 404, `id ${id.slice(0, 30)} phải 404, nhận ${r.status}`);
  }
  const ok = await call("POST", "/api/admin/debug/modules/a04-reserved-tags/run", "tSA");
  assert.equal(ok.status, 200);
  assert.equal(ok.body.status, "pass");
  assert.ok(Array.isArray(ok.body.checks) && Array.isArray(ok.body.logs) && ok.body.durationMs >= 0);
  const list = await call("GET", "/api/admin/debug/modules", "tSA");
  const row = list.body.modules.find((m) => m.id === "a04-reserved-tags");
  assert.equal(row.lastRun.status, "pass"); assert.equal(row.lastRun.appVersion, pkg.version);
});

test("API: DEBUG_PANEL_ENABLED=off → danh sách vẫn xem được (enabled:false) nhưng chạy bị 403", async () => {
  process.env.DEBUG_PANEL_ENABLED = "off";
  const list = await call("GET", "/api/admin/debug/modules", "tSA");
  assert.equal(list.status, 200); assert.equal(list.body.enabled, false);
  const r = await call("POST", "/api/admin/debug/modules/a04-reserved-tags/run", "tSA");
  assert.equal(r.status, 403); assert.equal(r.body.code, "DEBUG_DISABLED");
});

test("API: hai request chạy cùng lúc → request thứ hai nhận 409 DEBUG_BUSY", async () => {
  let release;
  synthetic([{ ...base, id: "t-hold", title: "hold", async run(c) { await new Promise((r) => { release = r; }); c.check("a", true); } }, { ...base, id: "t-fast", title: "fast", async run(c) { c.check("a", true); } }]);
  const p1 = call("POST", "/api/admin/debug/modules/t-hold/run", "tSA");
  await new Promise((r) => setTimeout(r, 60));
  const r2 = await call("POST", "/api/admin/debug/modules/t-fast/run", "tSA");
  assert.equal(r2.status, 409); assert.equal(r2.body.code, "DEBUG_BUSY");
  release();
  assert.equal((await p1).status, 200);
});

// ---------------------------------------------------------------- hai bản vá nhỏ kèm theo
test("R-03 (2.3.0): chữ lặp ở RANH GIỚI hai từ không còn làm lọt tag mạo danh; tag bình thường không bị chặn nhầm", () => {
  const { isReservedTagName } = require("../src/utils/helpers");
  for (const n of ["support_team", "supportteam", "admin_news", "adminnews", "official_support_team_vn", "support_the", "suppport", "adm1n", "the_twelve", "twelve_vn"]) assert.equal(isReservedTagName(n), true, `${n} phải bị chặn`);
  for (const n of ["helpful", "supporter", "teammate", "modern", "newsletter", "twelvefan_vn", "staff_fan", "nguyen_van_a", "real_madrid"]) assert.equal(isReservedTagName(n), false, `${n} phải dùng được`);
});

test("R-01 (2.3.0): ngưỡng alpha cho chữ là 0.5 và màu hệ thống không còn được nhận; tên màu CSS vẫn dùng được", () => {
  const { sanitizeHtml } = require("../src/services/sanitize.service");
  const has = (c) => /style=/.test(sanitizeHtml(`<p style="color:${c}">x</p>`));
  for (const c of ["#fff2", "#ffffff1a", "rgba(255,255,255,0.1)", "rgba(0,0,0,.49)", "canvas", "field", "window", "buttonface", "notacolor", "transparent"]) assert.equal(has(c), false, `${c} phải bị loại`);
  for (const c of ["red", "Navy", "rebeccapurple", "#ffffff80", "#fffa", "rgba(0,0,0,0.5)", "rgb(230, 0, 0)", "currentcolor", "inherit"]) assert.equal(has(c), true, `${c} phải được giữ`);
});
