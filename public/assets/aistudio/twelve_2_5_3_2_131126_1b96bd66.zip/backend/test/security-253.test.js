// v2.5.3 — kiểm thử bản vá theo "Báo cáo bảo mật tổng hợp cuối v2.5.2" — ĐỢT 1: TW-01 (IP client), TW-03 (điểm xem/chia sẻ), TW-10 (Turnstile), TW-22 (CORS/urlencoded thừa), TW-27 (log SHARE DEBUG).
// Firestore GIẢ + Express thật; không cần mạng. Các đợt sau (TW-06/07/13…) nằm ở test/security-253b.test.js.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const http = require("node:http");
const express = require("express");

const { install } = require("./helpers/fakeFirebase");
const fb = install({ tokens: {} });
const S = fb.store;
process.env.SHARE_LINK_SECRET = "test-share-secret-253";

const mockRes = () => {
  const r = { statusCode: 200, body: null };
  r.status = (c) => ((r.statusCode = c), r);
  r.json = (b) => ((r.body = b), r);
  return r;
};
const listen = (app) =>
  new Promise((resolve) => {
    const server = http.createServer(app).listen(0, () => resolve({ server, base: `http://127.0.0.1:${server.address().port}` }));
  });
const reset = () => Object.keys(S).forEach((k) => delete S[k]);

// ============================================================ TW-01 — chuẩn hoá IP
const clientIp = require("../src/utils/clientIp");
const { normalizeIp, isCloudflareAddress, getClientKey, getRawClientIp, trustProxyHops } = clientIp;
const mkReq = (headers = {}, ip = "10.0.0.1") => ({ headers, ip, socket: { remoteAddress: ip } });

test("TW-01: normalizeIp — IPv4 giữ nguyên, ::ffff: bỏ tiền tố, IPv6 gộp về /64, rác → unknown", () => {
  assert.equal(normalizeIp("203.0.113.9"), "203.0.113.9");
  assert.equal(normalizeIp("::ffff:203.0.113.9"), "203.0.113.9");
  assert.equal(normalizeIp("::ffff:cb00:7109"), "203.0.113.9", "dạng hex của IPv4-mapped");
  // Cùng một /64 → cùng khoá dù 64 bit cuối khác nhau (xoay địa chỉ trong khối /64 không né được limiter)
  const a = normalizeIp("2001:db8:abcd:12::1");
  const b = normalizeIp("2001:0db8:ABCD:0012:ffff:ffff:ffff:ffff");
  assert.equal(a, b);
  assert.equal(a, "2001:0db8:abcd:0012::/64");
  // Hai /64 KHÁC nhau chỉ ở chữ số cuối của nhóm thứ 4 phải ra hai khoá KHÁC nhau
  assert.notEqual(normalizeIp("2001:db8:1:1::5"), normalizeIp("2001:db8:1:2::5"));
  assert.equal(normalizeIp("fe80::1%eth0"), normalizeIp("fe80::2"), "zone id bị bỏ");
  for (const bad of ["", "unknown", "<script>", "1.2.3", "1.2.3.4.5", "gggg::1", undefined, null, 5]) assert.equal(normalizeIp(bad), "unknown", String(bad));
});

test("TW-01: isCloudflareAddress — đối chiếu dải chính thức, kể cả IPv6 và IPv4-mapped", () => {
  for (const ip of ["104.16.0.1", "172.64.1.1", "162.158.5.5", "173.245.48.1", "131.0.72.9", "2606:4700::1", "2a06:98c0::1", "::ffff:104.16.0.1"]) assert.equal(isCloudflareAddress(ip), true, ip);
  for (const ip of ["8.8.8.8", "1.1.1.1", "10.0.0.1", "203.0.113.9", "2001:db8::1", "", "not-an-ip", undefined]) assert.equal(isCloudflareAddress(ip), false, String(ip));
  process.env.CLOUDFLARE_EXTRA_RANGES = "198.51.100.0/24";
  try {
    assert.equal(isCloudflareAddress("198.51.100.7"), true, "bổ sung dải qua env");
  } finally {
    delete process.env.CLOUDFLARE_EXTRA_RANGES;
  }
  assert.equal(isCloudflareAddress("198.51.100.7"), false);
});

test("TW-01: getClientKey — qua edge Cloudflare thì dùng CF-Connecting-IP; không qua Cloudflare thì KHÔNG tin header (không giả được)", () => {
  // Cùng một client, hai edge khác nhau → cùng khoá (đây chính là lỗi 2.5.2: khoá đổi theo edge)
  const viaA = mkReq({ "cf-connecting-ip": "203.0.113.9" }, "104.16.0.1");
  const viaB = mkReq({ "cf-connecting-ip": "203.0.113.9" }, "172.64.9.9");
  assert.equal(getClientKey(viaA), "203.0.113.9");
  assert.equal(getClientKey(viaB), "203.0.113.9");
  // Hai client khác nhau qua CÙNG một edge → khác khoá (không còn dùng chung bucket)
  assert.notEqual(getClientKey(mkReq({ "cf-connecting-ip": "203.0.113.10" }, "104.16.0.1")), getClientKey(viaA));

  // Gọi thẳng origin (req.ip không thuộc Cloudflare): header giả bị bỏ qua
  const spoof = mkReq({ "cf-connecting-ip": "1.2.3.4", "x-forwarded-for": "5.6.7.8" }, "9.9.9.9");
  assert.equal(getClientKey(spoof), "9.9.9.9");
  assert.equal(getRawClientIp(spoof), "9.9.9.9");

  // Header hỏng qua edge hợp lệ → rơi về req.ip
  assert.equal(getClientKey(mkReq({ "cf-connecting-ip": "<script>" }, "104.16.0.1")), "104.16.0.1");
  assert.equal(getClientKey(mkReq({ "cf-connecting-ip": "a, b" }, "104.16.0.1")), "104.16.0.1");
  // Thiếu header → rơi về req.ip (hành vi 2.5.2)
  assert.equal(getClientKey(mkReq({}, "104.16.0.1")), "104.16.0.1");

  // CLIENT_IP_MODE=proxy tắt hẳn nhánh CF
  process.env.CLIENT_IP_MODE = "proxy";
  try {
    assert.equal(getClientKey(viaA), "104.16.0.1");
  } finally {
    delete process.env.CLIENT_IP_MODE;
  }

  // Request đã xác thực từ middleware Vercel vẫn được ưu tiên số 1
  process.env.SSR_PROXY_SECRET = "top-secret";
  try {
    const trusted = mkReq({ "x-twelve-ssr-secret": "top-secret", "x-twelve-client-ip": "7.7.7.7", "cf-connecting-ip": "203.0.113.9" }, "104.16.0.1");
    assert.equal(getClientKey(trusted), "7.7.7.7");
  } finally {
    delete process.env.SSR_PROXY_SECRET;
  }

  // IPv6 qua Cloudflare → khoá /64; địa chỉ thật (raw) vẫn nguyên vẹn cho Turnstile
  const v6 = mkReq({ "cf-connecting-ip": "2001:db8:1:2:3:4:5:6" }, "2606:4700::1");
  assert.equal(getClientKey(v6), "2001:0db8:0001:0002::/64");
  assert.equal(getRawClientIp(v6), "2001:db8:1:2:3:4:5:6");
});

test("TW-01: trustProxyHops — mặc định 1 (như 2.5.2), nhận 0–10, giá trị rác → 1", () => {
  const prev = process.env.TRUST_PROXY_HOPS;
  try {
    delete process.env.TRUST_PROXY_HOPS;
    assert.equal(trustProxyHops(), 1);
    for (const [v, want] of [["2", 2], ["0", 0], ["10", 10], ["11", 1], ["-1", 1], ["abc", 1], ["1.5", 1], ["", 1]]) {
      process.env.TRUST_PROXY_HOPS = v;
      assert.equal(trustProxyHops(), want, `TRUST_PROXY_HOPS=${v}`);
    }
  } finally {
    if (prev === undefined) delete process.env.TRUST_PROXY_HOPS;
    else process.env.TRUST_PROXY_HOPS = prev;
  }
});

test("TW-01: limiter theo IP — xoay edge Cloudflare không né được; giả CF-Connecting-IP khi gọi thẳng origin cũng không né được", async (t) => {
  delete require.cache[require.resolve("../src/middleware/rateLimiters")];
  const { forgotPasswordLimiter } = require("../src/middleware/rateLimiters"); // 5 lần/giờ/IP, khoá `ip:<getClientKey>`
  const app = express();
  app.set("trust proxy", 1); // đúng như server.js (hop mặc định = 1): req.ip = mục ngoài cùng bên phải của X-Forwarded-For
  app.get("/x", forgotPasswordLimiter, (req, res) => res.send("ok"));
  const { server, base } = await listen(app);
  t.after(() => server.close());

  // (1) Client thật 203.0.113.9 đi qua 6 edge khác nhau (Render ghi IP edge vào cuối XFF)
  const edges = ["104.16.0.1", "104.17.0.2", "172.64.0.3", "162.158.0.4", "108.162.192.5", "141.101.64.6"];
  const statuses = [];
  for (const edge of edges) {
    const r = await fetch(base + "/x", { headers: { "x-forwarded-for": `203.0.113.9, ${edge}`, "cf-connecting-ip": "203.0.113.9" } });
    statuses.push(r.status);
  }
  assert.deepEqual(statuses, [200, 200, 200, 200, 200, 429], "lượt thứ 6 bị chặn dù mỗi lượt đi qua một edge khác nhau");

  // (2) Kẻ gọi thẳng origin (hop gần nhất KHÔNG phải Cloudflare) đổi CF-Connecting-IP ngẫu nhiên mỗi lượt
  const spoof = [];
  for (let i = 0; i < 6; i++) {
    const r = await fetch(base + "/x", { headers: { "x-forwarded-for": "9.9.9.9", "cf-connecting-ip": `198.51.100.${i + 1}` } });
    spoof.push(r.status);
  }
  assert.deepEqual(spoof, [200, 200, 200, 200, 200, 429], "header giả bị bỏ qua → vẫn bị khoá theo 9.9.9.9");

  // (3) Hai người thật khác nhau qua CÙNG một edge không dùng chung bộ đếm
  const other = await fetch(base + "/x", { headers: { "x-forwarded-for": "203.0.113.77, 104.16.0.1", "cf-connecting-ip": "203.0.113.77" } });
  assert.equal(other.status, 200);
});

test("TW-01: không nơi nào đọc req.ip trực tiếp ngoài utils/clientIp.js (mọi limiter/dedupe đi qua getClientKey)", () => {
  const root = path.join(__dirname, "..");
  const offenders = [];
  const walk = (d) =>
    fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
      const p = path.join(d, e.name);
      if (e.name === "node_modules") return;
      if (e.isDirectory()) return walk(p);
      if (!e.name.endsWith(".js")) return;
      const rel = path.relative(root, p).replace(/\\/g, "/");
      if (rel === "src/utils/clientIp.js" || rel.startsWith("test/")) return;
      const code = fs.readFileSync(p, "utf8").split("\n").filter((l) => !/^\s*(\/\/|\*|\/\*)/.test(l)).join("\n").replace(/"[^"\n]*"|'[^'\n]*'|`[^`]*`/g, '""');
      if (/\breq\.ip\b/.test(code)) offenders.push(rel);
    });
  walk(path.join(root, "src"));
  walk(path.join(root, "scripts"));
  const server = fs.readFileSync(path.join(root, "server.js"), "utf8").split("\n").filter((l) => !/^\s*\/\//.test(l)).join("\n");
  if (/\breq\.ip\b/.test(server)) offenders.push("server.js");
  assert.deepEqual(offenders, []);

  // Mọi rateLimit(...) trong server.js / routes phải có keyGenerator tường minh (mặc định của thư viện = req.ip thô)
  for (const rel of ["server.js", "src/routes/auth.routes.js", "src/routes/csp.routes.js"]) {
    const src = fs.readFileSync(path.join(root, rel), "utf8");
    const calls = src.match(/rateLimit\(\{[\s\S]*?\}\)/g) || [];
    assert.ok(calls.length > 0, rel);
    for (const c of calls) assert.match(c, /keyGenerator/, `${rel}: limiter thiếu keyGenerator`);
  }
});

test("TW-01: viewerKeyFromRequest — khách ẩn danh: cùng client qua nhiều edge → cùng khoá; /64 khác nhau → khoá khác nhau; không lộ IP", () => {
  const { viewerKeyFromRequest } = require("../src/utils/helpers");
  const k1 = viewerKeyFromRequest(mkReq({ "cf-connecting-ip": "203.0.113.9" }, "104.16.0.1"));
  const k2 = viewerKeyFromRequest(mkReq({ "cf-connecting-ip": "203.0.113.9" }, "172.64.0.9"));
  assert.equal(k1, k2);
  assert.match(k1, /^ip:[A-Za-z0-9_-]{22}$/);
  assert.ok(!k1.includes("203"), "khoá là băm, không phải IP viết lại");

  // Hai /64 chỉ khác chữ số cuối của nhóm thứ 4 (trước đây cắt 24 ký tự base64 làm hai khoá này trùng nhau)
  const a = viewerKeyFromRequest(mkReq({}, "2001:db8:1:1::5"));
  const b = viewerKeyFromRequest(mkReq({}, "2001:db8:1:2::5"));
  assert.notEqual(a, b);
  // Cùng /64, khác 64 bit cuối → cùng khoá
  assert.equal(viewerKeyFromRequest(mkReq({}, "2001:db8:1:1::5")), viewerKeyFromRequest(mkReq({}, "2001:db8:1:1:aaaa::9")));
  // Người đã đăng nhập vẫn khoá theo uid
  assert.equal(viewerKeyFromRequest({ ...mkReq(), authUid: "abc" }), "u:abc");
});

test("TW-01: ipTopologyProbe — tắt thì im lặng; bật thì chỉ in tối đa 20 dòng rồi tự ngừng", async (t) => {
  const warns = [];
  const realWarn = console.warn;
  console.warn = (...a) => warns.push(a.join(" "));
  t.after(() => {
    console.warn = realWarn;
    delete process.env.DEBUG_IP_TOPOLOGY;
  });
  const call = () => clientIp.ipTopologyProbe(mkReq({ "x-forwarded-for": "1.2.3.4, 104.16.0.1", "cf-connecting-ip": "1.2.3.4" }, "104.16.0.1"), {}, () => {});

  delete process.env.DEBUG_IP_TOPOLOGY;
  for (let i = 0; i < 5; i++) call();
  assert.equal(warns.filter((w) => w.includes("[IP-TOPO]")).length, 0, "mặc định không log gì");

  process.env.DEBUG_IP_TOPOLOGY = "on";
  for (let i = 0; i < 40; i++) call();
  const lines = warns.filter((w) => w.includes("[IP-TOPO]"));
  assert.equal(lines.length, 20);
  const parsed = JSON.parse(lines[0].slice(lines[0].indexOf("{")));
  assert.equal(parsed.hopIsCloudflare, true);
  assert.equal(parsed.chosen, "1.2.3.4");
  assert.equal(parsed.hops, 1);
});

// ============================================================ TW-03 — điểm xem / chia sẻ
const { registerView, registerShare, signShareParams, POST_SCORE_WEIGHTS } = require("../src/utils/helpers");
const MIN = 60 * 1000;
const T0 = Date.UTC(2026, 10, 7, 12, 0, 0);
const atTime = async (when, fn) => {
  const real = Date.now;
  Date.now = () => when;
  try {
    return await fn();
  } finally {
    Date.now = real;
  }
};

// Firestore thật BẮT BUỘC mọi tx.get xảy ra TRƯỚC mọi lệnh ghi (xem VÁ v0.8.26); Firestore giả không kiểm — bọc lại để test bắt đúng lỗi này.
const strictDb = () => {
  const real = fb.db.runTransaction.bind(fb.db);
  return Object.assign(Object.create(fb.db), {
    runTransaction: (fn) =>
      real(async (tx) => {
        let wrote = false;
        const guard = (name) => (...a) => {
          wrote = true;
          return tx[name](...a);
        };
        return fn({
          get: async (x) => {
            if (wrote) throw new Error("Firestore transactions require all reads to be executed before all writes.");
            return tx.get(x);
          },
          set: guard("set"),
          update: guard("update"),
          delete: guard("delete"),
        });
      }),
  });
};

const seedShare = (viewers = 6) => {
  reset();
  S["users/sharer"] = { status: "active", positiveScore: 0, accountScore: 0 };
  S["users/author"] = { status: "active", postsScoreSum: 0, accountScore: 0 };
  S["posts/p1"] = { authorUid: "author", shareCount: 0, viewCount: 0, externalPostScore: 0 };
  for (let i = 1; i <= viewers; i++) S[`users/v${i}`] = { status: "active", positiveScore: 0 };
};
const shareAs = (db, viewer, when = T0) =>
  atTime(when, () =>
    registerShare(db, fb.admin, "posts", "p1", {
      rawSharerUid: "sharer",
      signature: signShareParams("sharer", "posts", "p1"),
      authorUid: "author",
      source: "web",
      viewerKey: `u:${viewer}`,
      viewerUid: viewer,
    })
  );

test("TW-03: điểm xem MẶC ĐỊNH BẬT — mở lại bài sau >30 phút không cộng điểm lần nữa; viewCount vẫn tăng", async () => {
  delete process.env.VIEW_SCORE_ONCE_PER_PAIR;
  reset();
  S["users/viewer"] = { status: "active", positiveScore: 0 };
  S["users/author"] = { status: "active", postsScoreSum: 0 };
  S["posts/p1"] = { authorUid: "author", viewCount: 0, externalPostScore: 0 };
  const view = (when) => atTime(when, () => registerView(strictDb(), fb.admin, "posts", "p1", { viewerKey: "u:viewer", isAi: false, viewerUid: "viewer", authorUid: "author" }));
  await view(T0);
  await view(T0 + 31 * MIN);
  await view(T0 + 120 * MIN);
  assert.equal(S["posts/p1"].viewCount, 3, "viewCount hiển thị vẫn đếm");
  assert.equal(S["users/viewer"].positiveScore, 1, "chỉ +1 điểm cho người xem");
  assert.equal(S["posts/p1"].externalPostScore, POST_SCORE_WEIGHTS.view, "chỉ cộng 1 lần cho tác giả");
  for (const off of ["off", "0", "false", "OFF"]) {
    process.env.VIEW_SCORE_ONCE_PER_PAIR = off;
    try {
      reset();
      S["users/viewer"] = { status: "active", positiveScore: 0 };
      S["users/author"] = { status: "active", postsScoreSum: 0 };
      S["posts/p1"] = { authorUid: "author", viewCount: 0, externalPostScore: 0 };
      await view(T0);
      await view(T0 + 31 * MIN);
      assert.equal(S["users/viewer"].positiveScore, 2, `công tắc khẩn "${off}" quay về hành vi cũ`);
    } finally {
      delete process.env.VIEW_SCORE_ONCE_PER_PAIR;
    }
  }
});

test("TW-03: trần thưởng chia sẻ — vượt trần/ngày vẫn đếm shareCount nhưng không cộng điểm; sang ngày UTC mới được thưởng lại", async () => {
  process.env.SHARE_REWARD_DAILY_CAP = "2";
  try {
    seedShare();
    const db = strictDb(); // đồng thời kiểm đúng thứ tự đọc-trước-ghi trong transaction
    for (let i = 1; i <= 4; i++) {
      const r = await shareAs(db, `v${i}`);
      assert.equal(r.counted, true, `lượt ${i} vẫn được đếm`);
    }
    assert.equal(S["posts/p1"].shareCount, 4, "shareCount hiển thị đủ 4");
    assert.equal(S["users/sharer"].positiveScore, 16, "chỉ 2 lượt đầu được +8");
    assert.equal(S["users/sharer"].shareRewardCount, 2);
    assert.equal(S["users/sharer"].shareRewardDay, "2026-11-07");
    assert.equal(S["posts/p1"].externalPostScore, 2 * POST_SCORE_WEIGHTS.share, "externalPostScore chỉ tính 2 lượt được thưởng");
    assert.equal(S["users/author"].postsScoreSum, 2 * POST_SCORE_WEIGHTS.share);
    const logs = Object.keys(S).filter((k) => k.startsWith("users/sharer/positiveScoreLogs/"));
    assert.equal(logs.length, 2, "audit log chỉ ghi lượt có thưởng");

    // Ngày UTC kế tiếp → bộ đếm đặt lại
    const next = await shareAs(db, "v5", T0 + 24 * 60 * MIN);
    assert.equal(next.counted, true);
    assert.equal(S["users/sharer"].positiveScore, 24);
    assert.equal(S["users/sharer"].shareRewardCount, 1);
    assert.equal(S["users/sharer"].shareRewardDay, "2026-11-08");
  } finally {
    delete process.env.SHARE_REWARD_DAILY_CAP;
  }
});

test("TW-03: SHARE_REWARD_DAILY_CAP — 0/off = không giới hạn; mặc định 25; khách ẩn danh/người tự mở link không đụng tới bộ đếm", async () => {
  for (const v of ["0", "off"]) {
    process.env.SHARE_REWARD_DAILY_CAP = v;
    try {
      seedShare();
      for (let i = 1; i <= 5; i++) await shareAs(strictDb(), `v${i}`);
      assert.equal(S["users/sharer"].positiveScore, 40, `cap=${v}: không giới hạn`);
      assert.equal(S["users/sharer"].shareRewardCount, undefined, "không bật trần thì không ghi bộ đếm");
    } finally {
      delete process.env.SHARE_REWARD_DAILY_CAP;
    }
  }

  // Mặc định 25
  seedShare(30);
  for (let i = 1; i <= 30; i++) await shareAs(strictDb(), `v${i}`);
  assert.equal(S["posts/p1"].shareCount, 30);
  assert.equal(S["users/sharer"].positiveScore, 25 * 8, "mặc định trần 25 lần/ngày");

  // Khách ẩn danh: không điều kiện thưởng → không đọc/ghi bộ đếm
  seedShare(1);
  const anon = await atTime(T0, () =>
    registerShare(strictDb(), fb.admin, "posts", "p1", { rawSharerUid: "sharer", signature: signShareParams("sharer", "posts", "p1"), authorUid: "author", source: "web", viewerKey: "ip:xyz", viewerUid: null })
  );
  assert.equal(anon.counted, true);
  assert.equal(S["users/sharer"].positiveScore, 0);
  assert.equal(S["users/sharer"].shareRewardCount, undefined);
  // Người chia sẻ tự mở link của mình
  await shareAs(strictDb(), "sharer");
  assert.equal(S["users/sharer"].positiveScore, 0);
});

// ============================================================ TW-27 — log SHARE DEBUG
test("TW-27: [SHARE DEBUG] tắt mặc định; bật bằng SHARE_DEBUG=on thì tối đa 20 dòng/phút và không ghi uid", async (t) => {
  const warns = [];
  const realWarn = console.warn;
  console.warn = (...a) => warns.push(a.join(" "));
  t.after(() => {
    console.warn = realWarn;
    delete process.env.SHARE_DEBUG;
  });
  const bad = (i) =>
    registerShare(fb.db, fb.admin, "posts", "p1", { rawSharerUid: "secretuid123", signature: "bad", authorUid: "author", source: "web", viewerKey: `ip:k${i}`, viewerUid: null });

  seedShare(1);
  delete process.env.SHARE_DEBUG;
  for (let i = 0; i < 30; i++) await bad(i);
  assert.equal(warns.filter((w) => w.includes("[SHARE DEBUG]")).length, 0, "mặc định không log");

  process.env.SHARE_DEBUG = "on";
  seedShare(1);
  for (let i = 0; i < 50; i++) await bad(100 + i);
  const lines = warns.filter((w) => w.includes("[SHARE DEBUG]"));
  assert.equal(lines.length, 20, "tối đa 20 dòng/phút dù bị spam");
  assert.ok(!lines.some((l) => l.includes("secretuid123")), "không ghi uid người chia sẻ");
});

// ============================================================ TW-10 — Turnstile
const captcha = require("../src/middleware/captcha");

const withEnv = async (vars, fn) => {
  const prev = {};
  for (const k of Object.keys(vars)) {
    prev[k] = process.env[k];
    if (vars[k] === undefined) delete process.env[k];
    else process.env[k] = vars[k];
  }
  try {
    return await fn();
  } finally {
    for (const k of Object.keys(vars)) {
      if (prev[k] === undefined) delete process.env[k];
      else process.env[k] = prev[k];
    }
  }
};

test("TW-10: danh sách hostname hợp lệ — dẫn xuất từ CORS_ORIGIN + FRONTEND_URL ở production; env tường minh ưu tiên; công tắc khẩn", async () => {
  await withEnv({ NODE_ENV: "test", TURNSTILE_ALLOWED_HOSTNAMES: undefined, TURNSTILE_HOSTNAME_CHECK: undefined, CORS_ORIGIN: "https://a.example.com", FRONTEND_URL: undefined }, () => {
    assert.equal(captcha.turnstileAllowedHostnames(), null, "dev/test: không kiểm (khoá thử của Cloudflare luôn trả example.com)");
  });
  await withEnv({ NODE_ENV: "production", TURNSTILE_ALLOWED_HOSTNAMES: undefined, TURNSTILE_HOSTNAME_CHECK: undefined, CORS_ORIGIN: "https://a.example.com, https://B.example.org/", FRONTEND_URL: "https://app.example.net/x" }, () => {
    assert.deepEqual(captcha.turnstileAllowedHostnames().sort(), ["a.example.com", "app.example.net", "b.example.org"]);
  });
  await withEnv({ NODE_ENV: "production", TURNSTILE_ALLOWED_HOSTNAMES: "Only.example.com, *.cdn.example.com", CORS_ORIGIN: "https://a.example.com" }, () => {
    assert.deepEqual(captcha.turnstileAllowedHostnames(), ["only.example.com", "*.cdn.example.com"]);
  });
  await withEnv({ NODE_ENV: "test", TURNSTILE_ALLOWED_HOSTNAMES: "x.example.com" }, () => {
    assert.deepEqual(captcha.turnstileAllowedHostnames(), ["x.example.com"], "env tường minh có hiệu lực cả ngoài production");
  });
  await withEnv({ NODE_ENV: "production", TURNSTILE_HOSTNAME_CHECK: "off", CORS_ORIGIN: "https://a.example.com" }, () => {
    assert.equal(captcha.turnstileAllowedHostnames(), null);
  });
  await withEnv({ NODE_ENV: "production", TURNSTILE_ALLOWED_HOSTNAMES: undefined, TURNSTILE_HOSTNAME_CHECK: undefined, CORS_ORIGIN: undefined, FRONTEND_URL: undefined }, () => {
    assert.equal(captcha.turnstileAllowedHostnames(), null, "không có gì để so → không kiểm (tránh khoá nhầm toàn bộ đăng ký)");
  });
  assert.equal(captcha.hostnameAllowed("A.example.com", ["a.example.com"]), true);
  assert.equal(captcha.hostnameAllowed("evil-a.example.com", ["a.example.com"]), false);
  assert.equal(captcha.hostnameAllowed("x.cdn.example.com", ["*.cdn.example.com"]), true);
  assert.equal(captcha.hostnameAllowed("cdn.example.com", ["*.cdn.example.com"]), false, "wildcard không khớp chính tên miền gốc");
  assert.equal(captcha.hostnameAllowed("xcdn.example.com", ["*.cdn.example.com"]), false);
});

test("TW-10: timeout được kẹp 1–15 giây", async () => {
  await withEnv({ TURNSTILE_TIMEOUT_MS: undefined }, () => assert.equal(captcha.turnstileTimeoutMs(), 5000));
  for (const [v, want] of [["2000", 2000], ["999", 5000], ["15001", 5000], ["abc", 5000]]) {
    await withEnv({ TURNSTILE_TIMEOUT_MS: v }, () => assert.equal(captcha.turnstileTimeoutMs(), want, v));
  }
});

test("TW-10: verifyCaptcha — hostname khớp thì cho qua và gửi remoteip thật + signal; hostname lạ bị chặn; thiếu hostname chỉ cảnh báo", async (t) => {
  const realFetch = global.fetch;
  const realWarn = console.warn;
  console.warn = () => {};
  t.after(() => {
    global.fetch = realFetch;
    console.warn = realWarn;
  });
  const env = { TURNSTILE_SECRET_KEY: "secret", NODE_ENV: "production", CORS_ORIGIN: "https://app.example.com", FRONTEND_URL: undefined, TURNSTILE_ALLOWED_HOSTNAMES: undefined, TURNSTILE_HOSTNAME_CHECK: undefined, TURNSTILE_TIMEOUT_MS: undefined };
  const run = async (cfResponse, reqOver = {}) => {
    let seen = null;
    global.fetch = async (url, init) => {
      seen = { url, init };
      return { json: async () => cfResponse };
    };
    const res = mockRes();
    let nexted = false;
    const req = { body: { captchaToken: "tok" }, headers: { "cf-connecting-ip": "203.0.113.9" }, ip: "104.16.0.1", socket: { remoteAddress: "104.16.0.1" }, ...reqOver };
    await withEnv(env, () => captcha.verifyCaptcha(req, res, () => (nexted = true)));
    return { res, nexted, seen };
  };

  const ok = await run({ success: true, hostname: "app.example.com" });
  assert.equal(ok.nexted, true);
  assert.ok(ok.seen.init.signal instanceof AbortSignal, "fetch có AbortSignal (timeout)");
  assert.match(ok.seen.init.body, /remoteip=203\.0\.113\.9/, "remoteip = IP client thật qua hàm duy nhất, không phải IP edge");

  const wrong = await run({ success: true, hostname: "evil.example.net" });
  assert.equal(wrong.nexted, false);
  assert.equal(wrong.res.statusCode, 400);

  const missing = await run({ success: true });
  assert.equal(missing.nexted, true, "thiếu hostname: không kết luận được → không chặn người dùng thật");

  const fail = await run({ success: false, "error-codes": ["invalid-input-response"] });
  assert.equal(fail.nexted, false);
  assert.equal(fail.res.statusCode, 400);

  // Thiếu token vẫn 400 như trước
  const res = mockRes();
  await withEnv(env, () => captcha.verifyCaptcha({ body: {}, headers: {} }, res, () => assert.fail("không được qua")));
  assert.equal(res.statusCode, 400);

  // Tắt kiểm hostname bằng công tắc khẩn
  global.fetch = async () => ({ json: async () => ({ success: true, hostname: "evil.example.net" }) });
  let passed = false;
  await withEnv({ ...env, TURNSTILE_HOSTNAME_CHECK: "off" }, () => captcha.verifyCaptcha({ body: { captchaToken: "t" }, headers: {}, ip: "1.1.1.1" }, mockRes(), () => (passed = true)));
  assert.equal(passed, true);
});

test("TW-10: Cloudflare không phản hồi → hết hạn sau timeout và trả 503 (fail-closed), không treo", async (t) => {
  const realFetch = global.fetch;
  const realErr = console.error;
  console.error = () => {};
  t.after(() => {
    global.fetch = realFetch;
    console.error = realErr;
  });
  // fetch giả CHỈ kết thúc khi bị huỷ bằng signal — nếu mã không truyền signal thì test này treo và bị node:test cắt.
  global.fetch = (url, init) =>
    new Promise((resolve, reject) => {
      if (!init.signal) return; // không có signal => treo mãi (mô phỏng lỗi cũ)
      init.signal.addEventListener("abort", () => reject(init.signal.reason));
    });
  const res = mockRes();
  const t0 = Date.now();
  // `AbortSignal.timeout()` dùng bộ đếm giờ unref — trong server thật vòng lặp sự kiện vẫn sống nhờ cổng HTTP; trong test cần giữ vòng lặp sống thủ công.
  const keepAlive = setInterval(() => {}, 100);
  try {
    await withEnv({ TURNSTILE_SECRET_KEY: "secret", NODE_ENV: "test", TURNSTILE_TIMEOUT_MS: "1000" }, () =>
      captcha.verifyCaptcha({ body: { captchaToken: "tok" }, headers: {}, ip: "1.1.1.1" }, res, () => assert.fail("không được cho qua khi lỗi hạ tầng"))
    );
  } finally {
    clearInterval(keepAlive);
  }
  const took = Date.now() - t0;
  assert.equal(res.statusCode, 503);
  assert.ok(took >= 900 && took < 4000, `huỷ sau ~1 giây (đo được ${took}ms)`);
});

// ============================================================ TW-22 — cấu hình thừa
test("TW-22: CORS không còn credentials:true; không còn express.urlencoded; server dùng trustProxySetting (mặc định = trustProxyHops) + ipTopologyProbe", () => {
  const code = fs.readFileSync(path.join(__dirname, "../server.js"), "utf8").split("\n").filter((l) => !/^\s*\/\//.test(l)).join("\n");
  assert.ok(!/credentials\s*:\s*true/.test(code));
  assert.ok(!/express\.urlencoded/.test(code));
  // v2.5.3.2: `trustProxySetting()` trả số hop (`trustProxyHops()`) ở chế độ mặc định — hành vi không đổi; chế độ `cloudflare` là tuỳ chọn (security-2532.test.js).
  assert.match(code, /app\.set\("trust proxy", trustProxySetting\(\)\)/);
  assert.match(code, /app\.use\(ipTopologyProbe\)/);
  // Không route nào cần parse form: đối chiếu toàn bộ mã nguồn
  const hits = [];
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
    const p = path.join(d, e.name);
    if (e.isDirectory()) return walk(p);
    if (e.name.endsWith(".js") && /express\.urlencoded|bodyParser\.urlencoded/.test(fs.readFileSync(p, "utf8").replace(/\/\/.*$/gm, ""))) hits.push(p);
  });
  walk(path.join(__dirname, "../src"));
  assert.deepEqual(hits, []);
});

// ============================================================ Sau rà soát độc lập (v2.5.3): chuẩn hoá TURNSTILE_ALLOWED_HOSTNAMES
test("TW-10 (rà soát độc lập): TURNSTILE_ALLOWED_HOSTNAMES viết kiểu URL/có cổng/đường dẫn vẫn khớp hostname trần của Cloudflare; *.domain được giữ; mục rác bị bỏ", () => {
  const captcha = require("../src/middleware/captcha");
  const old = { h: process.env.TURNSTILE_ALLOWED_HOSTNAMES, c: process.env.TURNSTILE_HOSTNAME_CHECK, n: process.env.NODE_ENV };
  try {
    delete process.env.TURNSTILE_HOSTNAME_CHECK;
    process.env.TURNSTILE_ALLOWED_HOSTNAMES = " https://TwelveTa.vercel.app/ , staging.example.com:8443/path?x=1, *.preview.example.com , http://user@host.example.org:80, ,not a host!! ";
    const list = captcha.turnstileAllowedHostnames();
    assert.deepEqual(list, ["twelveta.vercel.app", "staging.example.com", "*.preview.example.com", "host.example.org"]);
    assert.ok(captcha.hostnameAllowed("twelveta.vercel.app", list));
    assert.ok(captcha.hostnameAllowed("staging.example.com", list));
    assert.ok(captcha.hostnameAllowed("a.preview.example.com", list));
    assert.ok(!captcha.hostnameAllowed("preview.example.com", list), "wildcard không khớp chính tên miền gốc");
    assert.ok(!captcha.hostnameAllowed("evil-twelveta.vercel.app", list));
    assert.ok(!captcha.hostnameAllowed("twelveta.vercel.app.evil.com", list));
  } finally {
    for (const [k, v] of [["TURNSTILE_ALLOWED_HOSTNAMES", old.h], ["TURNSTILE_HOSTNAME_CHECK", old.c], ["NODE_ENV", old.n]]) { if (v === undefined) delete process.env[k]; else process.env[k] = v; }
  }
});
