// v2.3.0: cài đặt thật nằm ở src/debug/support/fakeFirebase.js (module "Gỡ lỗi" cần dùng ở production). Giữ file này để mọi test cũ không phải đổi đường dẫn.
module.exports = require("../../src/debug/support/fakeFirebase");
