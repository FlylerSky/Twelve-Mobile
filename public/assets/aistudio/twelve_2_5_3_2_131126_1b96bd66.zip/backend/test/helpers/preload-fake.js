// Dùng với `node -r ./test/helpers/preload-fake.js server.js` (xem test/security-221.test.js): chạy server.js THẬT với Firestore/Auth GIẢ
// (fakeFirebase mô phỏng cả việc SDK thật ném lỗi với id có dấu "/"), để kiểm hành vi cấp tiến trình (sống/chết) mà không cần mạng hay khoá thật.
const { install } = require("./fakeFirebase");
install({ tokens: {} });
