// v2.5.3 — kiểm thử bản vá theo "Báo cáo bảo mật tổng hợp cuối v2.5.2" — ĐỢT 5–6: TW-20 (sanitize lớp 2 khi SSR đọc bài), TW-17/18 (mã chết), TW-04 (App Check tuỳ chọn),
// TW-23 (đồng bộ tài liệu/phiên bản), TW-24 (lockfile đã vá), và "lưới an toàn" cho quy ước dự án (test mới phải nằm trong script `test`, mọi nơi ghi phiên bản khớp nhau).
// Firestore GIẢ; không cần mạng.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const BACKEND = path.join(__dirname, "..");
const ROOT = path.join(BACKEND, "..");
const FRONTEND = path.join(ROOT, "frontend");
const haveFrontend = fs.existsSync(path.join(FRONTEND, "vercel.json"));
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const pkg = readJson(path.join(BACKEND, "package.json"));

const { spawnSync } = require("node:child_process");
const { install } = require("./helpers/fakeFirebase");
const fake = install({ tokens: {} });
process.env.SANITIZE_WORKER = "off"; // chạy DOMPurify cùng tiến trình trong test

// ============================================================ TW-20 — sanitize lớp 2 khi SSR
const { sanitizeAgainForSsr, SSR_TRIPWIRE } = require("../src/utils/ssrContent");

test("TW-20: dây vấp bắt đúng các dấu hiệu nguy hiểm, không bắt nội dung Quill bình thường", () => {
  const bad = [
    "<p>a</p><script>alert(1)</script>",
    '<img src="x" onerror="alert(1)">',
    "<img src=x onerror=alert(1)>",
    '<a href="javascript:alert(1)">x</a>',
    '<a href=" JaVaScRiPt:alert(1)">x</a>',
    '<iframe srcdoc="<b>x</b>"></iframe>',
    "<svg onload=1></svg>",
    '<p onclick="x()">a</p>',
    '<object data="x"></object>',
    "<style>body{display:none}</style>",
    '<a href="data:text/html;base64,AAAA">x</a>',
    "<form action=x><input></form>",
    '<meta http-equiv="refresh" content="0;url=x">',
  ];
  for (const html of bad) assert.ok(SSR_TRIPWIRE.test(html), `phải bắt: ${html}`);
  const good = [
    '<h2>Tiêu đề</h2><p class="ql-align-center">Xin chào</p><p><strong style="color: rgb(255, 0, 0);">đậm</strong></p>',
    '<pre class="ql-syntax" spellcheck="false">&lt;script&gt;alert(1)&lt;/script&gt;</pre>',
    '<p><a href="https://example.com/?a=1&amp;online=2" rel="ugc nofollow noopener" target="_blank">link</a></p>',
    '<iframe class="ql-video" src="https://www.youtube.com/embed/abc" allowfullscreen="true" sandbox="allow-scripts allow-same-origin allow-presentation"></iframe>',
    '<img src="https://res.cloudinary.com/x/a.png" alt="x" loading="lazy">',
    "<ol><li data-list=\"bullet\">a</li></ol><blockquote>trích dẫn</blockquote>",
  ];
  for (const html of good) assert.ok(!SSR_TRIPWIRE.test(html), `không được bắt: ${html}`);
});

test("TW-20: HTML sạch KHÔNG tốn thêm lượt làm sạch; HTML dơ được làm sạch lại; lỗi ⇒ trả rỗng (đóng an toàn); không phải chuỗi ⇒ giữ nguyên", async () => {
  let calls = 0;
  const spy = async (h) => { calls++; return { html: h.replace(/<script[\s\S]*?<\/script>/gi, ""), excerpt: "" }; };
  const clean = '<p class="ql-align-center">Xin chào</p>';
  assert.equal(await sanitizeAgainForSsr(clean, { id: "p1", processContentHtml: spy }), clean);
  assert.equal(calls, 0, "nội dung bình thường không đi qua DOMPurify lần hai");

  const warn = [];
  const origWarn = console.warn; console.warn = (...a) => warn.push(a.join(" "));
  try {
    const out = await sanitizeAgainForSsr("<p>a</p><script>alert(1)</script>", { id: "p2", processContentHtml: spy });
    assert.equal(out, "<p>a</p>");
    assert.equal(calls, 1);
    assert.ok(warn.some((w) => /ssr-tripwire/.test(w) && /p2/.test(w) && /resanitize/.test(w)), "có log để biết kho dữ liệu còn HTML cũ");
    // có tripwire nhưng làm sạch không đổi gì (dương tính giả như chữ "onion = 1") ⇒ không log
    warn.length = 0;
    const same = await sanitizeAgainForSsr("<p>mình có onion = 1</p>", { id: "p3", processContentHtml: async (h) => ({ html: h, excerpt: "" }) });
    assert.equal(same, "<p>mình có onion = 1</p>");
    assert.equal(warn.length, 0);
  } finally { console.warn = origWarn; }

  const origErr = console.error; console.error = () => {};
  try {
    assert.equal(await sanitizeAgainForSsr("<script>x</script>", { id: "p4", processContentHtml: async () => { throw new Error("worker chết"); } }), "", "lỗi ⇒ KHÔNG in HTML chưa làm sạch");
  } finally { console.error = origErr; }

  for (const v of [null, undefined, 42, "", {}]) assert.equal(await sanitizeAgainForSsr(v, { processContentHtml: spy }), v);
});

// ---- Sau rà soát độc lập (v2.5.3): tripwire phải thấy cả dạng mà TRÌNH DUYỆT giải mã trước khi phân tích
const { ssrTripwireHit } = require("../src/utils/ssrContent");
const OBFUSCATED_BAD = [
  '<a href="&#106;avascript:alert(1)">x</a>',
  '<a href="&#x6A;avascript:alert(1)">x</a>',
  '<a href="&#0000106;avascript:alert(1)">x</a>',
  '<a href="javascript&colon;alert(1)">x</a>',
  '<a href="java&#9;script:alert(1)">x</a>',
  '<a href="JAVA&Tab;SCRIPT:alert(1)">x</a>',
  '<a href="java&NewLine;script:alert(1)">x</a>',
  '<a href="java\tscript:alert(1)">x</a>',
  '<a href="java\nscript:alert(1)">x</a>',
  '<iframe src="&#106;avascript:alert(1)"></iframe>',
  '<button formaction="&#x6A;avascript:alert(1)">x</button>',
  '<a href="da\tta:text/html;base64,AAAA">x</a>',
  '<a href="data&colon;text/html,x">x</a>',
  '<img src=x\n&#111;nerror=alert(1)>',
  '<img src=x &#111;nerror=alert(1)>',
  '<img src="x"&#32;onerror=alert(1)>',
];
const OBFUSCATED_GOOD = [
  '<h2>Tiêu đề</h2><p class="ql-align-center">Xin chào</p>',
  '<pre class="ql-syntax" spellcheck="false">&lt;script&gt;alert(1)&lt;/script&gt;</pre>',
  '<pre class="ql-syntax">if (a &lt; b &amp;&amp; c &gt; d) {}</pre>',
  '<p><a href="https://example.com/?a=1&amp;online=2" rel="ugc nofollow noopener" target="_blank">link</a></p>',
  "<p>Tom &amp; Jerry &copy; 2020 &#8211; &nbsp;ok</p>",
  "<p>Giá &#36;5 &quot;ngon&quot;</p>",
  "<p>Xin\nchào\tbạn</p>",
];

test("TW-20 (rà soát độc lập): dạng thô của dây vấp BỊ LÁCH bởi thực thể/TAB; ssrTripwireHit thì không — và không bắt oan nội dung thường (kể cả <pre> hiển thị mã script đã thoát)", () => {
  assert.ok(OBFUSCATED_BAD.filter((h) => !SSR_TRIPWIRE.test(h)).length >= 10, "biến thể lách dạng thô (chứng minh test này có nghĩa)");
  for (const html of OBFUSCATED_BAD) assert.ok(ssrTripwireHit(html), `phải bắt: ${JSON.stringify(html)}`);
  for (const html of OBFUSCATED_GOOD) assert.ok(!ssrTripwireHit(html), `không được bắt oan: ${JSON.stringify(html)}`);
  assert.equal(ssrTripwireHit(""), false);
  assert.equal(ssrTripwireHit(null), false);
  assert.equal(ssrTripwireHit(42), false);
});

test("TW-20 (rà soát độc lập): với bộ lọc THẬT, HTML đã lưu có link javascript: viết bằng thực thể/TAB được làm sạch lại trước khi SSR in ra", async () => {
  for (const html of OBFUSCATED_BAD.filter((h) => /<a |<iframe/.test(h))) {
    const out = await sanitizeAgainForSsr(`<p>trước</p>${html}<p>sau</p>`, { id: "obf" });
    const flat = out.replace(/&#x?[0-9a-f]+;?|&(?:colon|tab|newline);/gi, "").replace(/[\t\n\r]/g, "");
    assert.ok(!/javascript\s*:|data\s*:\s*text\/html/i.test(flat), `còn URL nguy hiểm sau làm sạch: ${JSON.stringify(out)}`);
    assert.match(out, /trước/); assert.match(out, /sau/);
  }
});

test("TW-20: dùng đúng bộ lọc thật (contentPipeline + DOMPurify): script/on*/javascript: bị bỏ, định dạng Quill hợp lệ được giữ", async () => {
  const dirty = '<p class="ql-align-center">giữ</p><script>alert(1)</script><img src="x" onerror="alert(2)"><a href="javascript:alert(3)">l</a><span class="ql-hidden">ẩn</span>';
  const warn = console.warn; console.warn = () => {};
  let out;
  try { out = await sanitizeAgainForSsr(dirty, { id: "real" }); } finally { console.warn = warn; }
  assert.ok(!/<script|onerror|javascript:|ql-hidden/i.test(out), out);
  assert.match(out, /<p class="ql-align-center">giữ<\/p>/);
});

test("TW-20: mã SSR gọi lớp 2 TRƯỚC khi làm alt/lazy-load (đọc cấu trúc route)", () => {
  const src = fs.readFileSync(path.join(BACKEND, "src/routes/ssr.routes.js"), "utf8");
  const a = src.indexOf("sanitizeAgainForSsr(post.contentHtml");
  const b = src.indexOf("ensureImageAlts(lazyLoadImages(post.contentHtml)");
  assert.ok(a > -1 && b > -1 && a < b, "lớp 2 phải chạy trước khi dựng alt/lazy");
});

// ============================================================ TW-17 / TW-18 — mã chết
test("TW-17: requireOwnerCapable (không ai dùng) đã bị xoá; middleware/roles chỉ còn requireGroup + requireSA", () => {
  const roles = require("../src/middleware/roles");
  assert.deepEqual(Object.keys(roles).sort(), ["requireGroup", "requireSA"]);
  const hits = [];
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
    const p = path.join(d, e.name);
    if (e.isDirectory()) { if (e.name !== "node_modules") walk(p); return; }
    if (/\.(js|md)$/.test(e.name) && /requireOwnerCapable/.test(fs.readFileSync(p, "utf8")) && !p.endsWith("roles.js") && !p.endsWith("security-253d.test.js") && !/PATCH-|README/.test(e.name)) hits.push(path.relative(BACKEND, p));
  });
  walk(path.join(BACKEND, "src")); walk(path.join(BACKEND, "test"));
  assert.deepEqual(hits, []);
});

test("TW-18: RouteGuards.jsx (RequireAuth/RequireSA không ai import) đã bị xoá; không còn import nào tới nó", { skip: !haveFrontend && "không có thư mục ../frontend" }, () => {
  assert.ok(!fs.existsSync(path.join(FRONTEND, "src/components/RouteGuards.jsx")));
  const hits = [];
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
    const p = path.join(d, e.name);
    if (e.isDirectory()) return walk(p);
    if (/\.(jsx?|mjs)$/.test(e.name) && /from\s+["'][^"']*RouteGuards["']|RequireSA|RequireAuth\b/.test(fs.readFileSync(p, "utf8"))) hits.push(path.relative(FRONTEND, p));
  });
  walk(path.join(FRONTEND, "src")); walk(path.join(FRONTEND, "tests"));
  assert.deepEqual(hits, []);
});

// ============================================================ TW-04 — App Check tuỳ chọn
test("TW-04: App Check chỉ khởi tạo khi có VITE_FIREBASE_APPCHECK_SITE_KEY (nằm trong `if`), có bắt lỗi, token debug chỉ ở DEV; CSP của SPA vẫn CHẶT (không mở reCAPTCHA khi tính năng đang tắt)", { skip: !haveFrontend && "không có thư mục ../frontend" }, () => {
  const src = fs.readFileSync(path.join(FRONTEND, "src/firebase.js"), "utf8");
  const code = src.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");
  const iAppCheck = code.indexOf("initializeAppCheck(firebaseApp");
  const iIf = code.indexOf("if (appCheckSiteKey)");
  assert.ok(iAppCheck > -1 && iIf > -1 && iIf < iAppCheck, "initializeAppCheck phải nằm SAU `if (appCheckSiteKey)`");
  assert.equal((code.match(/initializeAppCheck\(/g) || []).length, 1);
  assert.match(code, /try\s*\{[\s\S]*initializeAppCheck[\s\S]*\}\s*catch/);
  assert.match(code, /import\.meta\.env\.DEV\s*&&\s*import\.meta\.env\.VITE_FIREBASE_APPCHECK_DEBUG_TOKEN/);
  assert.match(code, /isTokenAutoRefreshEnabled:\s*true/);
  assert.match(code, /const appCheckSiteKey\s*=\s*import\.meta\.env\.VITE_FIREBASE_APPCHECK_SITE_KEY/);
  const vercel = fs.readFileSync(path.join(FRONTEND, "vercel.json"), "utf8");
  assert.ok(!/recaptcha|gstatic\.com|firebaseappcheck/i.test(vercel), "CSP chưa mở reCAPTCHA — chỉ thêm KHI bật App Check (xem hướng dẫn trong src/firebase.js)");
  const envEx = fs.readFileSync(path.join(FRONTEND, ".env.example"), "utf8");
  for (const k of ["VITE_FIREBASE_APPCHECK_SITE_KEY", "VITE_FIREBASE_APPCHECK_PROVIDER", "VITE_FIREBASE_APPCHECK_DEBUG_TOKEN"]) assert.ok(envEx.includes(k), k);
});

// ============================================================ TW-23 — đồng bộ tài liệu / phiên bản
test("TW-23: apiInfo ghi avatar đúng giới hạn thực (2MB theo constants), không còn '10MB'", () => {
  const { ASSET_LIMITS, ASSET_KIND } = require("../src/utils/constants");
  const mb = ASSET_LIMITS[ASSET_KIND.AVATAR].MAX_BYTES / (1024 * 1024);
  assert.equal(mb, 2);
  const src = fs.readFileSync(path.join(BACKEND, "src/controllers/apiInfo.controller.js"), "utf8");
  assert.ok(!/max 10\s?MB/i.test(src));
  assert.match(src, new RegExp(`max ${mb}MB`));
});

test("TW-23: số phiên bản khớp ở MỌI nơi quy ước (package.json ×2, lockfile ×4 vị trí, version.json, tiêu đề README, dòng đầu SECURITY-STATUS, .env.example, TWELVE-MAP)", () => {
  const v = pkg.version;
  assert.match(v, /^\d+\.\d+\.\d+\.\d{6}$/, "MAJOR.MINOR.PATCH.ddmmyy");
  const lock = readJson(path.join(BACKEND, "package-lock.json"));
  assert.equal(lock.version, v); assert.equal(lock.packages[""].version, v);
  const readme = fs.readFileSync(path.join(BACKEND, "README.md"), "utf8").split("\n")[0];
  assert.ok(readme.includes(`(v${v})`), readme);
  assert.match(fs.readFileSync(path.join(BACKEND, ".env.example"), "utf8"), new RegExp(`^BACKEND_VERSION=${v.replace(/\./g, "\\.")}$`, "m"));
  const status = path.join(ROOT, "SECURITY-STATUS.md");
  if (fs.existsSync(status)) assert.ok(fs.readFileSync(status, "utf8").split("\n").slice(0, 4).join("\n").includes(v), "SECURITY-STATUS.md phải ghi phiên bản hiện tại ở đầu file");
  const map = path.join(ROOT, "TWELVE-MAP.md");
  if (fs.existsSync(map)) assert.ok(fs.readFileSync(map, "utf8").split("\n").slice(0, 12).join("\n").includes(v.split(".").slice(0, 3).join(".")), "TWELVE-MAP.md phải nêu bản hiện tại ở phần đầu");
  if (haveFrontend) {
    const fpkg = readJson(path.join(FRONTEND, "package.json"));
    assert.equal(fpkg.version, v);
    const flock = readJson(path.join(FRONTEND, "package-lock.json"));
    assert.equal(flock.version, v); assert.equal(flock.packages[""].version, v);
    assert.deepEqual(readJson(path.join(FRONTEND, "public/version.json")), { frontend: v });
  }
});

test("quy ước: mọi file test/*.test.js đều nằm trong script `test` của package.json (test viết xong mà không chạy là test không tồn tại)", () => {
  const listed = new Set((pkg.scripts.test.match(/test\/[\w.-]+\.test\.js/g) || []).map((s) => path.basename(s)));
  const onDisk = fs.readdirSync(__dirname).filter((f) => /\.test\.js$/.test(f));
  assert.deepEqual(onDisk.filter((f) => !listed.has(f)), [], "file test chưa được thêm vào script `test`");
  assert.deepEqual([...listed].filter((f) => !onDisk.includes(f)), [], "script `test` trỏ tới file không tồn tại");
  for (const f of ["security-253.test.js", "security-253b.test.js", "security-253c.test.js", "security-253d.test.js"]) assert.ok(pkg.scripts["test:security"].includes(f), `test:security thiếu ${f}`);
});

// ============================================================ TW-24 — lockfile đã vá các mục cao có bản vá không phá vỡ
const semverGte = (a, b) => {
  const pa = a.split(".").map((x) => parseInt(x, 10)); const pb = b.split(".").map((x) => parseInt(x, 10));
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0); }
  return true;
};
test("TW-24: lockfile backend — body-parser ≥ 1.20.9 và multer ≥ 2.5.0 (npm audit mức cao, bản vá không phá vỡ)", () => {
  const lock = readJson(path.join(BACKEND, "package-lock.json")).packages;
  assert.ok(semverGte(lock["node_modules/body-parser"].version, "1.20.9"), lock["node_modules/body-parser"].version);
  assert.ok(semverGte(lock["node_modules/multer"].version, "2.5.0"), lock["node_modules/multer"].version);
});

test("TW-24: lockfile frontend — follow-redirects ≥ 1.16.2 (npm audit mức cao, bản vá không phá vỡ)", { skip: !haveFrontend && "không có thư mục ../frontend" }, () => {
  const lock = readJson(path.join(FRONTEND, "package-lock.json")).packages;
  assert.ok(semverGte(lock["node_modules/follow-redirects"].version, "1.16.2"), lock["node_modules/follow-redirects"].version);
});

// ============================================================ TW-05 — công cụ thu hồi phiên (vận hành; không có endpoint HTTP)
const { revokeUserSessions } = require("../src/services/revokeSessions");
const { COLLECTIONS: COL } = require("../src/utils/constants");

async function seedAcct(email, profile) {
  const rec = await fake.auth.createUser({ email, displayName: "T" });
  fake.store[`${COL.USERS}/${rec.uid}`] = { uid: rec.uid, ...profile };
  return rec.uid;
}

test("TW-05: DRY-RUN (mặc định) không đổi gì — không hạ nhóm, không vô hiệu hoá, không thu hồi", async () => {
  const uid = await seedAcct("sa1@example.com", { accountGroup: "SA", accountRole: "admin", status: "active" });
  const before = JSON.stringify(fake.store[`${COL.USERS}/${uid}`]);
  const r = await revokeUserSessions({ uids: [uid], demote: true, disable: true });
  assert.equal(r.apply, false);
  assert.deepEqual(r.results[0].actions, ["demote", "disable", "revoke"], "báo SẼ làm gì");
  assert.equal(JSON.stringify(fake.store[`${COL.USERS}/${uid}`]), before);
  assert.ok(!(fake.authCalls.revoked || []).includes(uid));
  assert.ok(!(fake.authCalls.updateUser || []).some(([u]) => u === uid));
});

test("TW-05: --apply chỉ thu hồi phiên (mặc định không hạ nhóm, không vô hiệu hoá)", async () => {
  const uid = await seedAcct("sa2@example.com", { accountGroup: "SA", accountRole: "admin", status: "active" });
  const r = await revokeUserSessions({ uids: [uid], apply: true });
  assert.deepEqual(r.results[0].actions, ["revoke"]);
  assert.ok(fake.authCalls.revoked.includes(uid));
  assert.equal(fake.store[`${COL.USERS}/${uid}`].accountGroup, "SA", "không tự hạ nhóm nếu không có --demote");
  assert.ok(!(fake.authCalls.updateUser || []).some(([u]) => u === uid));
});

test("TW-05: --apply --demote --disable hạ về RA/user, vô hiệu hoá Auth và thu hồi; tìm được tài khoản theo email; trùng uid/email chỉ xử lý một lần", async () => {
  const uid = await seedAcct("sa3@example.com", { accountGroup: "SA", accountRole: "dev", status: "active" });
  const r = await revokeUserSessions({ uids: [uid], emails: ["SA3@Example.com"], apply: true, demote: true, disable: true });
  assert.equal(r.results.length, 1, "uid và email cùng trỏ một tài khoản ⇒ một dòng");
  assert.deepEqual(r.results[0].actions, ["demote", "disable", "revoke"]);
  assert.equal(fake.store[`${COL.USERS}/${uid}`].accountGroup, "RA");
  assert.equal(fake.store[`${COL.USERS}/${uid}`].accountRole, "user");
  assert.ok(fake.authCalls.updateUser.some(([u, p]) => u === uid && p.disabled === true));
  assert.equal(fake.authCalls.revoked.filter((u) => u === uid).length, 1);
});

test("TW-05: một tài khoản lỗi/không tồn tại KHÔNG chặn các tài khoản còn lại; uid rác bị từ chối trước khi đụng Firestore", async () => {
  const good = await seedAcct("sa4@example.com", { accountGroup: "SA", accountRole: "moderator", status: "active" });
  const r = await revokeUserSessions({ uids: ["../users/x", "khong-ton-tai-123", good], emails: ["nobody@example.com"], apply: true, demote: true });
  const byUid = Object.fromEntries(r.results.map((x) => [x.uid, x]));
  assert.equal(byUid[good].ok, true);
  assert.equal(r.results.filter((x) => !x.ok).length, 3, "uid rác + uid không có Auth + email không có");
  assert.equal(fake.store[`${COL.USERS}/${good}`].accountGroup, "RA");
  assert.ok(fake.authCalls.revoked.includes(good));
});

test("TW-05: script CLI — thiếu đối tượng thì thoát mã 2 mà KHÔNG khởi tạo Firebase; mặc định dry-run; không nhận/in mật khẩu; có npm script", () => {
  const r = spawnSync(process.execPath, [path.join(BACKEND, "scripts/revoke-user-sessions.js")], { cwd: BACKEND, encoding: "utf8", timeout: 30000, env: { PATH: process.env.PATH, NODE_ENV: "test" } });
  assert.equal(r.status, 2, r.stderr);
  assert.match(r.stderr, /Thiếu đối tượng/);
  const src = fs.readFileSync(path.join(BACKEND, "scripts/revoke-user-sessions.js"), "utf8");
  assert.match(src, /APPLY = argv\.includes\("--apply"\)/, "chỉ --apply mới ghi thật");
  assert.ok(!/--password|--pass\b|readline|prompt\(/i.test(src), "không có tham số/nhập mật khẩu");
  assert.match(pkg.scripts["sessions:revoke"], /revoke-user-sessions\.js$/);
  assert.match(pkg.scripts["sessions:revoke:apply"], /revoke-user-sessions\.js --apply$/);
});
