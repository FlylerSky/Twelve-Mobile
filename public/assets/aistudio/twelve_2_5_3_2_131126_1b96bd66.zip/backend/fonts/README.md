# Font chữ có sẵn trên server (#1.1)

Đặt file font (`.woff2` / `.woff` / `.ttf` / `.otf`) vào thư mục này, **commit và deploy** (hệ thống file của Render là
tạm thời — file chỉ tồn tại nếu nằm trong mã nguồn được deploy). Sau đó vào
**Cài đặt > Quản trị > Font chữ trên server**, chọn "Thêm từ file trên server" rồi Lưu.

- Chỉ file được SA thêm vào danh sách mới được phục vụ công khai tại `/api/fonts/files/<tên-file>`.
- Tên file chỉ gồm chữ/số, `.`, `_`, `-` (không dấu cách, không dấu tiếng Việt).
- Ưu tiên `.woff2` (nhỏ nhất). Font phải hỗ trợ đủ tiếng Việt.
- Chú ý giấy phép: chỉ đưa font bạn được phép phân phối công khai.
- Ghi đè nội dung một file đã có sẽ mất tới ~1 ngày mới thấy ở trình duyệt đã cache — hãy ĐỔI TÊN file khi thay font.
