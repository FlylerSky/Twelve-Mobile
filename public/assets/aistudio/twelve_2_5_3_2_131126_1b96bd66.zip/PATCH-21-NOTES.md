# PATCH 21 — v2.5.1.241026: Hợp nhất 2.4.2.2 (nút "Sao chép URL Profile") + 2.5.0 (rà soát & nâng cấp SEO)

Backend + frontend. Test sau hợp nhất: backend **205/205** (196 → +9 từ `seo-250.test.js`), frontend **315/315** (291 → +19 từ 2.4.2.2 `profileCopyUrl2422.test.jsx` → +5 từ 2.5.0 `seo250.test.jsx`), `vite build` sạch. Không đổi biến môi trường bắt buộc, `middleware.js`, `firestore.rules`, API. **Có thêm 1 composite index** (mục 5 bên dưới).

## 0. Hợp nhất
Hai nhánh phát triển song song từ cùng gốc `2.4.2.1` (`twelve_2_4_2_1_r2.zip`):
| Nhánh | Phạm vi | File đụng tới |
|---|---|---|
| **2.4.2.2** (`PATCH-20-NOTES.md`) | Chỉ frontend: nút **Sao chép URL Profile** ở headZone trang Profile (URL Ngắn `/u/@tag` / URL cố định `/u/<UID>`); backend chỉ đổi số phiên bản | `PublicProfilePage.jsx`, `CopyProfileUrlDialog.jsx` (mới), `utils/profilePath.js`, `utils/clipboard.js` (mới), `settings/debugReport.js`, 3 file test, `SECURITY-STATUS.md`, `frontend/README.md` |
| **2.5.0** (mục 1–6 dưới đây) | SEO: backend SSR/sitemap/robots + 4 file frontend (`index.html`, `TurnstileWidget.jsx`, `vercel.json`, 1 test) | xem mục 2 |

Cách hợp nhất: **hợp nhất 3 chiều bằng git** (gốc 2.4.2.1 ↔ 2.4.2.2 ↔ 2.5.0). Hai nhánh **không có file mã nào trùng nhau** nên không có xung đột mã. Chỉ có 3 việc phải xử lý tay:
1. **Số phiên bản** → `2.5.1.241026` đồng bộ ở `backend/package.json`, `frontend/package.json`, `frontend/public/version.json` (+ 2 `package-lock.json`). Chỉ đổi đúng các dòng version (đối chiếu với bản gốc: chênh lệch của lock chỉ là các dòng này).
2. **Trùng tên `PATCH-20-NOTES.md`** (cả hai nhánh đều tạo): giữ nguyên cho 2.4.2.2; ghi chú SEO + hợp nhất này là `PATCH-21-NOTES.md`.
3. **Tài liệu**: `SECURITY-STATUS.md` (dòng đầu → 2.5.1 + trỏ tới PATCH-21), `backend/README.md` (mục -29 mới; mục -28 của 2.5.0 giữ lại, đổi tham chiếu sang PATCH-21).

Kiểm tra tương tác giữa hai nhánh (không chỉ "gộp được"):
- SSR hồ sơ (2.5.0) vẫn dùng canonical `/u/@tag` đúng hệ thống URL Profile — 2.4.2.2 **không đổi** hệ thống URL (`profilePath()` vẫn tag-first; URL UID chỉ là lựa chọn sao chép, bot được 301 sang tag), nên sitemap/canonical/JSON-LD hồ sơ mới của 2.5.0 vẫn đúng.
- Test quét `src/` cấm tự ghép `/u/…` ngoài `profilePath.js` (2.4.2.1/2.4.2.2) vẫn xanh: 2.5.0 không thêm đường dẫn hồ sơ nào ở frontend.
- Chạy lại **toàn bộ** test backend + frontend và `vite build` trên cây đã hợp nhất (số liệu ở đầu file).

## Phần 2.4.2.2 (tóm tắt — chi tiết ở `PATCH-20-NOTES.md`)
Nút **Sao chép URL Profile** cho hồ sơ của mình lẫn người khác; hộp chọn URL Ngắn (Tag Name Search) / URL cố định (UID, tự chuyển về `/u/@tag` khi mở). `profilePath.js` thêm `profileTagPath`, `profileUidPath`, `profileShareUrls`; `copyText` chuyển ra `utils/clipboard.js`. Lưu ý mục 5.1 của PATCH-20: link UID do người dùng chủ động chọn nên UID nằm trong link họ gửi.

# Phần 2.5.0 — Rà soát & nâng cấp SEO theo Cẩm nang khởi đầu SEO của Google

Nguồn đối chiếu: Cẩm nang SEO của Google (developers.google.com/search/docs/fundamentals/seo-starter-guide) + tài liệu dữ liệu có cấu trúc "Discussion forum". Hạ tầng SEO từ 2.0.x (SSR cho bot qua `middleware.js`, sitemap, robots, canonical, `rel="ugc nofollow"`, hook `useSeo`) được giữ nguyên; bản này vá các khoảng trống còn lại.

## 1. Những gì đã thay đổi
| # | Vấn đề tìm thấy | Cách xử lý |
|---|---|---|
| 1 | Bài viết dùng JSON-LD `Article` — loại dành cho nội dung do chính nhà xuất bản viết, không phải nội dung người dùng đăng | Bài viết (`/post/:id`) → **Microdata `DiscussionForumPosting`** (Google khuyến nghị Microdata cho loại này để khỏi nhân đôi khối văn bản): `headline`, `author`(Person+url), `datePublished`/`dateModified`, `text` = chính thân bài, `image`, `interactionStatistic`, `commentCount`, `comment`. Blog → **JSON-LD `BlogPosting`** kèm `commentCount` + `comment`, `keywords`, `inLanguage` |
| 2 | Bản SSR **không có bình luận** ("tải phía client") — nội dung thảo luận vô hình với Google | SSR render sẵn tối đa **10 bình luận cũ nhất** của tác giả **active** (bình luận của hồ sơ ma/chưa kích hoạt/bị khoá không lộ cho bot). Nội dung escape tự động. `commentCount = 0` → không tốn lượt đọc Firestore |
| 3 | Trang chi tiết chỉ link tới tác giả + hashtag → bài cũ chỉ được khám phá qua sitemap | Thêm 2 khối liên kết nội bộ có anchor mô tả: **"Cùng chủ đề #tag"** (≤5) và **"Bài khác của <tác giả>"** (≤5) |
| 4 | Ảnh trong thân bài **không có `alt`** (Quill không tạo alt) | SSR điền alt dự phòng `"<tiêu đề> — hình n"` cho ảnh thiếu/rỗng alt (không sửa dữ liệu lưu); alt mô tả có sẵn giữ nguyên. Ảnh bìa/avatar cũng có alt mô tả; thêm `og:image:alt`, `twitter:image:alt` |
| 5 | Sitemap chưa có ảnh | `<image:image><image:loc>` cho **ảnh bìa** bài viết/blog (chỉ https hợp lệ; ảnh xấu → bỏ thẻ ảnh, URL trang vẫn còn) |
| 6 | Mô tả hồ sơ/hashtag là một câu khuôn mẫu dùng chung | Mô tả **riêng từng trang**: hồ sơ nêu tên + tiêu đề bài gần đây; hashtag nêu số bài + tiêu đề tiêu biểu |
| 7 | Bot và người dùng thấy **tiêu đề khác nhau** ở cùng URL (SSR "Mạng xã hội chia sẻ bài viết" vs SPA "Nền tảng mạng xã hội…") | SSR dùng đúng chuỗi của SPA (hằng số trong `seoMeta.js`, có test đối chiếu với `IndexPage.jsx`/`index.html`) |
| 8 | JSON-LD hồ sơ/hashtag/blog thiếu | `ProfilePage` + `dateCreated`; `BreadcrumbList` cho hồ sơ, hashtag, `/blog`; hashtag → `CollectionPage`; trang chủ → `WebSite` + `Organization` (logo nếu đặt `SITE_LOGO_URL`) |
| 9 | Hồ sơ SSR: "Tham gia từ" in `[object Object]` (Timestamp thô) | Chuẩn hoá `createdAt` → ISO trước khi render |
| 10 | `robots.txt` không loại trang vô giá trị | `Disallow: /settings`, `/u/myProfile`, `/csp-report`. **Không** chặn `/login`, `/register` (cần thu thập để thấy `noindex`) và các URL chia sẻ có tham số (cần thu thập để đọc `canonical`) |
| 11 | Trải nghiệm người dùng thật (Core Web Vitals đo trên bản SPA, không phải bản SSR) | Script Cloudflare Turnstile **không còn nạp ở mọi trang** — `TurnstileWidget` tự nạp khi cần (chỉ trang đăng ký). `vercel.json`: `/assets/*` (tên file có hash) cache bất biến 1 năm |

## 2. File chính
Backend: `utils/seoMeta.js`, `utils/ssrContent.js` (mới), `routes/ssr.routes.js`, `controllers/seo.controller.js`, `views/content.ejs`, `views/partials/top.ejs`, `views/partials/style.ejs`, `firestore.indexes.json`, `test/seo-250.test.js` (+ thêm vào script `npm test`).
Frontend: `components/TurnstileWidget.jsx`, `index.html`, `vercel.json`, `tests/seo250.test.jsx`.

## 3. Hành vi thay đổi có chủ ý
- JSON-LD của `/post/:id` chỉ còn `BreadcrumbList`; phần `DiscussionForumPosting` nằm trong HTML (Microdata). Test cũ không phụ thuộc chi tiết này nên không phải sửa.
- Mô tả/tiêu đề SSR của trang chủ, `/blog`, hồ sơ, hashtag đổi nội dung (xem bảng).

## 4. Chi phí Firestore (SSR bài chi tiết, chỉ khi cache CDN `s-maxage=300` miss)
+ bình luận: ≤10 đọc + ≤10 đọc hồ sơ tác giả, **chỉ khi `commentCount > 0`**; + liên kết nội bộ: ≤6 + ≤6 đọc (≤12 nếu hashtag phải lùi về truy vấn chữ hoa/thường gốc). Mọi lỗi ở phần phụ bị nuốt — trang vẫn trả 200.

## 5. Điều bạn nên biết (đọc trước khi deploy)
1. **Deploy index mới**: `firebase deploy --only firestore:indexes` (blogs: `isPublished` + `authorUid` + `createdAt ↓`, dùng cho "Bài khác của tác giả" ở trang blog). Chưa deploy thì `fetchNewest` tự lùi về quét `FALLBACK_SCAN` tài liệu và ghi cảnh báo — vẫn chạy, chỉ tốn đọc hơn.
2. Sau khi lên bản: dùng **Rich Results Test / URL Inspection** của Search Console kiểm tra 1 bài viết (kỳ vọng thấy "Discussion forum") và 1 blog; gửi lại `sitemap.xml`.
3. Tuỳ chọn: đặt `SITE_LOGO_URL` (URL https ảnh logo vuông) để `Organization`/`BlogPosting.publisher` có logo.

## 6. Chưa làm (có chủ đích) và lý do
- **Phân trang SSR cho danh sách**: sitemap đã liệt kê toàn bộ URL (tới 45.000 bài mỗi loại) và 2 khối liên kết mới đã tạo đường đi tới bài cũ; phân trang keyset sẽ sinh trang `noindex` hoặc trang mà SPA không khớp nội dung → thêm rủi ro, ít lợi.
- **URL có slug (`/post/<id>-<tiêu-đề>`) và đường dẫn hashtag sạch (`/tag/<x>`)**: cẩm nang nói từ khoá trong URL ảnh hưởng xếp hạng rất ít; đổi canonical hàng loạt đụng SPA, app mobile, link chia sẻ cũ. Nên làm riêng (có 301) nếu muốn.
- **`X-Robots-Tag: noindex` cho host backend (onrender.com)**: nếu secret proxy Vercel/Render lệch nhau, mọi trang sẽ tự `noindex` — thất bại quá nặng so với lợi ích (canonical đã gom về domain frontend).
- **Chia nhỏ bundle** (chunk `index` ≈ 1.066 kB / 307 kB gzip khi build): đáng làm cho Core Web Vitals nhưng cần kiểm thử trên trình duyệt thật.
- **Kết xuất động** (bot ≠ người dùng) là giải pháp tạm thời theo Google; hướng dài hạn là SSR/pre-render cho mọi người dùng.
