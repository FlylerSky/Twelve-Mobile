# PATCH 13 — Twelve 2.2.1.151026 · Vá bảo mật sau báo cáo kiểm tra độc lập 2.2.0

Nền: `twelve_2_2_0` (2.2.0.111026). Phiên bản mới: **2.2.1.151026** (frontend `package.json` + `public/version.json`, backend `package.json` + `.env.example`).
Nguồn: `Bao_cao_kiem_tra_bao_mat_Twelve_2_2_0.md` + `twelve-audit-poc.zip` (PoC-0…5). Mình đọc lại mã nguồn 2.2.0 để xác minh từng nhận định trước khi sửa.
Kiểm thử: backend **118/118** (96 cũ + 22 mới trong `test/security-221.test.js`), frontend **153/153** (không đổi), `vite build` sạch.
Chạy lại **chính các PoC gốc** trên mã đã vá: `poc-crash.js` → `GET /api/users/a%2Fb` trả 404, tiến trình sống (exit = null, `/health` 200); PoC-1/2/3/4 (các assert mô tả LỖI) đều **không còn đúng** (PUT/POST → 403, không còn bài/hồ sơ ma, CSP giữ khoá hợp lệ). Riêng PoC-5 vẫn "pass" vì nó gọi `isValidTagName` (kiểm ĐỊNH DẠNG, giữ nguyên); phần chặn tên dành riêng là hàm mới `isReservedTagName`.

## 1. Đã vá

| ID | Mức | Việc đã làm | Test |
|---|---|---|---|
| **A-01** | Cao | 3 lớp: (1) `isSafeDocId` + `router.param` cho `:uid/:id/:commentId` ở users/posts/blog/SSR → id có `/` trả **404**, không bao giờ tới Firestore; (2) `getPublicProfile`/`getMe` có try/catch; (3) `utils/asyncErrors.js` chuyển mọi Promise bị reject của handler async sang `next(err)` (Express 4 không tự làm); (4) `server.js`: `unhandledRejection` **không thoát** ở lần đầu, chỉ thoát nếu > 10 lần/60 giây; `uncaughtException` vẫn thoát ngay; error handler thêm `if (res.headersSent) return next(err)` | `A-01: …` (5 test, gồm chạy `server.js` thật) |
| **A-02** | P2/P3 | `writeRealName`/`moveLegacyFullName` → **transaction** kiểm `active` (T-220-01). `createPost`/`createBlog`: `batch` → transaction có đọc hồ sơ tác giả (`assertActorActive`). `react`/`addComment` cũng kiểm `active` trong transaction. **Bước `verify`** mới sau `profile` (xem mục 2). Hồ sơ "ma" (không có `status`) → 404 ở `/api/users/:uid`, `/u/:uid`, và không được gắn làm tác giả bài/bình luận. Script `ghosts:purge` dọn dữ liệu đã lỡ có | `A-02: …` (11 test) |
| A-03 | P3 | `forgotPassword` **trả lời ngay** (cùng mã, cùng câu, cùng thời gian) rồi mới tra Auth/đọc hồ sơ/gọi Firebase ở nền. 429/502 của Firebase chỉ còn trong log. Thiếu `FIREBASE_WEB_API_KEY` vẫn 503 (lỗi cấu hình, không phụ thuộc email) | `A-03: …` |
| A-04 | P3 | Tag Name dành riêng (`admin`, `twelve`, `support`, `moderator`, `official`, `security`, `staff`, `system`, `root`…): chặn cả biến thể (`admin_`, `admin2`, `twelve_support`) ở **đăng ký**, **đổi tag**, **check-tagname** (`available:false, reserved:true`). SA được đặt. Thêm tên qua `RESERVED_TAG_NAMES_EXTRA`. Script `pending:cleanup` dọn tài khoản `pending` > 14 ngày chưa xác minh | `A-04: …` (3 test) |
| A-05 | P3 | CSP: bảng đầy **không loại khoá cũ** nữa (đếm vào `overflow`); khoá gom theo `chỉ thị \| nguồn bị chặn` (bỏ đường dẫn tài liệu do người gửi tự khai); họ `script-src`/`default-src` có thêm 50 chỗ dự trữ; panel SA hiện số báo cáo bị bỏ | `A-05: …` |
| A-06 | Thấp | `sanitizeStyleAttr` giới hạn số: `font-size` 8–72px (0.5–5em, từ khoá `small…xx-large`), `line-height` 0.8–4, `margin/padding` trái-phải 0–200px (không âm), `color` không `transparent`/alpha < 0.1; `calc()` bị loại. XSS vẫn chặn | `A-06: …` |
| A-07 | Info | `.env.example`: cảnh báo `NODE_ENV=production`, thêm `FIREBASE_WEB_API_KEY`, `VIEW_SCORE_ONCE_PER_PAIR`, biến mới. Nhãn phiên bản lệch: `/api/version` ưu tiên `BACKEND_VERSION` (cùng nguồn `/health`), `seed:version` mặc định lấy `package.json`. `SECURITY-STATUS.md` cập nhật | — |

### Phát hiện thêm trong lúc vá (không có trong báo cáo)
1. **Id lồng nhau**: `GET /api/users/<uid>%2FpositiveScoreLogs%2F<id>` không làm sập mà **trỏ vào tài liệu lồng nhau** — mình kiểm với SDK Firestore thật: `doc("a/b/c")` hợp lệ (`users/a/b/c`), chỉ số đoạn lẻ mới ném lỗi. `toPublicUser` chỉ trả vài trường nên tác động nhỏ, nhưng `isSafeDocId` đóng luôn cả lớp này. Id dạng `__x__`, `.`, `..` (Firestore từ chối ở máy chủ → cũng từng thành rejection) cũng bị chặn.
2. **Hồ sơ ma sinh ra KHÔNG cần race**: `deleteComment` trừ điểm tác giả bình luận bằng `set + merge`; bình luận của tài khoản đã xoá được giữ lại có chủ đích (PATCH-12 mục 4), nên **mỗi lần SA/chủ bài xoá một bình luận như vậy** là dựng lại `users/{uid-đã-xoá}` (kèm log điểm mồ côi). Đã sửa; nếu beta đã từng làm vậy thì dùng `npm run ghosts:purge`.
3. Hồ sơ ma còn hiện "@undefined" ở **tác giả bình luận** và bài (qua `attachAuthors`) — đã lọc.

## 2. Quyết định tôi tự đưa ra — hãy duyệt

- **Không đổi `set + merge` → `tx.update` như báo cáo gợi ý.** Chú thích gốc trong `helpers.js` ghi rõ merge là có chủ đích (không được làm hỏng thao tác chính vì user doc vắng), và `tx.update` lên hồ sơ không tồn tại làm **cả transaction hỏng** — sẽ làm hỏng việc xoá bình luận của người đã xoá. Thay vào đó: người **thực hiện** hành động phải còn `active` ngay trong transaction (bị tuần tự hoá với `requestDeletion`), đường xoá bình luận bỏ qua tác giả đã mất, cộng thêm lưới `verify` + ẩn hồ sơ ma.
- **Bước `verify`**: sau khi xoá hồ sơ, sổ `accountDeletions` **giữ thêm 2 phút** (`waiting_verify`, đổi bằng `ACCOUNT_DELETION_VERIFY_DELAY_MS`, 0 = ngay) rồi quét lại và dọn mọi thứ bị ghi muộn (`userPrivate`, hồ sơ ma + subcollection, bài/asset mồ côi) trước khi xoá sổ. `npm run deletions:list` sẽ thấy trạng thái mới `waiting_verify`. Đăng ký lại cùng email/tag vẫn được ngay sau khi xoá (Auth và tag được giải phóng ở các bước trước).
- **`unhandledRejection`**: không thoát ngay như báo cáo gợi ý hay như trước; thoát chỉ khi dồn dập (> 10/phút) để tránh tiến trình hỏng ngầm. Muốn thay đổi ngưỡng: `createRejectionGuard({limit, windowMs})` trong `server.js`.
- **Regex id** `^[A-Za-z0-9_-]{1,128}$` (+ không dạng `__x__`): khớp uid Firebase Auth và id tự sinh của Firestore; dữ liệu di trú từ Twelve Old dùng đúng uid Auth (đã đọc `migrate-legacy-data.js`). **Mình không xem được dữ liệu thật** — xem mục 4.1.
- **Dọn tài khoản `pending` là script chạy tay** (`pending:cleanup` → dry-run, `:apply` để xếp hàng xoá), không phải job tự chạy: tự xoá tài khoản là quyết định sản phẩm. Mặc định 14 ngày (`--days=N`), bỏ qua tài khoản đã `emailVerified` và hồ sơ thiếu `createdAt`. Muốn tự động hoá thì đặt một Render Cron Job chạy `npm run pending:cleanup:apply`.
- **Tag dành riêng không áp ngược** cho tài khoản đang giữ tag đó từ trước (chỉ chặn đăng ký/đổi tag mới).
- **Không thêm `package-lock.json`** vào gói: repo thật của bạn có thể đã có (báo cáo A-08 chỉ nói zip không có) và ghi đè sẽ đổi phiên bản bạn đã ghim. Nếu chưa có: `npm install` ở `backend/` và `frontend/`, commit lockfile, dùng `npm ci` khi deploy.

## 3. Cần làm khi triển khai
1. Deploy **backend** (không đổi `firestore.rules`, không cần index mới), rồi **frontend** (chỉ đổi panel CSP + số phiên bản).
2. Render: xác nhận `NODE_ENV=production`; `BACKEND_VERSION=2.2.1.151026` (nhãn trong UI nay theo biến này; không cần `seed:version`).
3. Firebase Console → Authentication → Settings → bật **Email enumeration protection** (A-03; kiểm tra ảnh hưởng tới luồng đăng nhập/quên mật khẩu của bạn trước).
4. `npm run ghosts:purge` (dry-run, xem danh sách) → `npm run ghosts:purge:apply`. Chạy sau khi deploy bản mới để không có hồ sơ ma mới sinh ra.
5. `npm run pending:cleanup` (dry-run) → quyết định có `:apply` không.
6. (Tuỳ chọn) `node src/seed/resanitizeContent.js` để áp bộ lọc style mới cho bài cũ — **script này ghi đè dữ liệu** (không có dry-run), nên sao lưu/chạy thử trên bản sao trước.

## 4. Chưa kiểm chứng được với Firebase/Render thật — hãy thử tay
1. Firestore Console: có tài khoản nào mà document id chứa ký tự ngoài `A-Z a-z 0-9 _ -` không (nếu có sẽ thành 404 ở hồ sơ công khai)? Uid Firebase tự sinh dài 28 ký tự chữ-số nên thường là không.
2. Xoá một tài khoản thử: sổ `accountDeletions` hiện `waiting_verify` khoảng 2 phút rồi biến mất; `users`, `userPrivate`, `tagNames`, Auth đều sạch.
3. Quên mật khẩu: email có thật vẫn nhận được thư; email lạ nhận cùng thông báo ngay lập tức. (PoC-3 gốc đo thời gian **hoàn tất handler** nên vẫn hiện ~250 ms; phản hồi HTTP thì đã trả ngay — test `A-03` đo đúng thời điểm gửi phản hồi.)
4. Đăng ký/đổi sang tag `admin` bị chặn với thông báo "được dành riêng"; ô Tag Name hiện "đã có người dùng" khi gõ tag dành riêng.
5. `%2F` qua proxy Render (báo cáo mục 7.5): thử trên máy cục bộ/staging — **sau bản vá này** `GET /api/users/a%2Fb` phải trả 404.
6. Có tài khoản nào đang giữ tag `admin`/`twelve`/… mà không phải SA không? (chỉ chặn được người mới).

## 5. Không làm trong bản này (ngoài phạm vi hoặc cần quyết định của bạn)
- **F3** (`VIEW_SCORE_ONCE_PER_PAIR=on`) và **G1** (`script-src` enforce): quyết định sản phẩm — làm sau khi panel CSP sạch (A-05 giúp số liệu đáng tin hơn).
- **Nâng dependency** (A-07/báo cáo mục 9): cần đợt hồi quy riêng. `firebase-admin` 14 vẫn bị `firebase-admin-surface.test.js` chặn có chủ đích.
- **IPv6 và limiter theo IP**: chưa xác minh Render chuyển IPv6 hay IPv4; sửa mù có thể làm hỏng limiter.
- `sensitiveAccountLimiter` dùng chung một bộ đếm (xem tên thật/đổi tên thật/đổi tag): chỉ ảnh hưởng trải nghiệm.
- **Hồ sơ ma còn có thể sinh ra rất hiếm** từ `registerView`/`registerShare`/`syncAccountScore` (người xem đang bị xoá giữa chừng, cửa sổ dưới một giây): chỉ chứa điểm số, đã bị ẩn khỏi mọi trang công khai; `verify` dọn nếu nằm trong 2 phút sau khi xoá, còn lại do `ghosts:purge`.
- **Mật khẩu tài khoản beta** đã chia sẻ cho Manus (báo cáo mục 7.9): đổi mật khẩu — việc này nằm ngoài mã.
