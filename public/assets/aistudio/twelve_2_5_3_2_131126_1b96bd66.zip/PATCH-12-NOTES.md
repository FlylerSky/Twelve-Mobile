# PATCH 12 — Twelve 2.2.0.111026 · Bảo mật và bảo vệ tài khoản người dùng

Nền: `twelve_2_1_0` (2.1.0.081026). Phiên bản mới: **2.2.0.111026** (frontend `package.json` + `public/version.json`, backend `package.json` + `.env.example`).
Kiểm thử tự động: backend **96/96** (71 cũ + 25 mới), frontend **153/153** (115 cũ + 38 mới). `vite build` chạy sạch.

## 1. Tính năng

### Cài đặt > Tài khoản (tab mới, chỉ cho người đã đăng nhập)
Theo đúng hệ thống thư mục của 2.1.0 (`settings/registry.jsx`): gốc tab hiện 2 mục.

| Mục | Nội dung |
|---|---|
| **Thông tin** (lá) | Ảnh đại diện · Tên thật (ẩn, cần mật khẩu để hiện/đổi) · Tag Name Search (đổi có kiểm tra trùng trực tiếp) · Tên hiển thị · Sinh nhật · Giới tính · Quốc gia. Nút Lưu chỉ sáng khi có thay đổi và chỉ gửi trường đã sửa. |
| **Bảo mật** (thư mục) → **Đổi mật khẩu** | Mật khẩu cũ + mới + nhập lại (8–128 ký tự). "Quên mật khẩu?" mở hộp gửi email đặt lại (email khoá theo tài khoản). |
| **Bảo mật** → **Xóa tài khoản** | Liệt kê rõ cái gì bị xoá, bắt tick "không thể hoàn tác" + nhập mật khẩu, sau đó đăng xuất ngay. |

Trang **Đăng nhập** có thêm nút **Quên mật khẩu?** dùng CHUNG một hộp (`ForgotPasswordDialog`) với màn Đổi mật khẩu.

### Nhập lại mật khẩu — cách làm
Backend không kiểm được mật khẩu (Admin SDK không có chức năng đó). Luồng chuẩn: frontend gọi `reauthenticateWithCredential` → Firebase cấp ID token mới có `auth_time` = bây giờ → middleware mới `requireRecentAuth` (backend) chỉ chấp nhận token có `auth_time` trong 5 phút (`RECENT_AUTH_MAX_AGE_SEC`). Token tự làm mới theo giờ KHÔNG đổi `auth_time`, nên một phiên đăng nhập cũ không qua được. Áp dụng cho: xem tên thật, đổi tên thật, xoá tài khoản. Lỗi trả `403 { code: "REAUTH_REQUIRED" }`.

### Tên thật: ẩn THẬT, không chỉ che giao diện
Rules cho chủ tài khoản đọc nguyên document `users/{uid}` bằng Client SDK (AuthContext dùng `onSnapshot`) → mọi field trong đó, kể cả `fullName`, đều tới trình duyệt. Nên tên thật chuyển sang collection **`userPrivate/{uid}`** (rules chặn hoàn toàn Client SDK; chỉ backend đọc/ghi):
- `GET /api/users/me/real-name`, `PUT /api/users/me/real-name` — đều qua `requireRecentAuth`.
- `GET /api/users/me` không bao giờ trả `fullName`; `PATCH /api/users/me` từ chối `fullName` (400 `USE_REAL_NAME_ENDPOINT`).
- Đăng ký ghi tên thật vào `userPrivate` (không còn vào `users`).
- Tài khoản cũ còn `fullName` trong `users/{uid}`: backend tự chuyển lười khi chủ xem/đổi (ghi nơi mới trước, xoá nơi cũ sau); frontend cũng lọc nó khỏi dữ liệu realtime. Chuyển hàng loạt (tuỳ chọn): `npm run realname:migrate` (dry-run) / `realname:migrate:apply`.
- Màn Chào mừng không còn ô tên thật (đã khai lúc đăng ký; đổi trong Cài đặt).

### Đổi Tag Name Search
`PUT /api/users/me/tag-name`: đặt tag mới + trả tag cũ + cập nhật hồ sơ trong **một transaction** (không có lúc 2 người cùng giữ một tag, hay một người mất tag mà chưa có tag mới). Hồ sơ/bài tham chiếu theo uid nên đổi tag không gãy liên kết. Limiter 10 lần/15 phút/tài khoản.

### Quên mật khẩu (backend + Firebase)
`POST /api/auth/forgot-password` `{ email, captchaToken }`: backend kiểm CAPTCHA (Turnstile, như đăng ký), giới hạn theo IP (5/giờ) và theo email (cách nhau ≥60 giây, ≤5/giờ), chỉ gửi cho tài khoản Twelve hợp lệ (có hồ sơ, không bị khoá/đang xoá), rồi nhờ **Firebase** gửi email bằng REST `accounts:sendOobCode` (template tiếng Việt qua header `X-Firebase-Locale`). Luôn trả **cùng một câu trả lời** dù email có tồn tại hay không (không cho dò tài khoản). Thử cả dạng email Gmail kiểu cũ (đã bỏ dấu chấm/`+tag`).

### Xoá tài khoản bền vững (`backend/src/services/accountDeletion.js`)
1. **Ghi nhớ trước**: một transaction ghi `accountDeletions/{uid}` + đặt `users/{uid}.status = "deleting"` (cả hai hoặc không cái nào). Trả **202** ngay; phần còn lại chạy NỀN trong server, không phụ thuộc request/trình duyệt của người dùng.
2. **Các bước, mỗi bước idempotent**: `lock` (vô hiệu hoá + thu hồi phiên Firebase Auth) → `content` (mọi bài viết + blog kể cả nháp, kèm comments/views/reactions…) → `assets` (Cloudinary + sổ `assets` + avatar kiểu cũ) → `residual` (trả Tag Name Search, xoá `userPrivate`, `registrationMarkers`, `positiveScoreLogs`…) → `auth` (xoá tài khoản Firebase Auth) → `profile` (**xoá hồ sơ SAU CÙNG**).
3. **Kiểm cuối** trước khi xoá hồ sơ: còn bài/blog/asset sót (request ghi dở lọt qua lúc khoá) thì quay lại bước tương ứng (tối đa 3 lần).
4. **Sổ `accountDeletions` = nhật ký + hàng chờ**: chỉ xoá khi MỌI thứ đã xong. Mỗi instance xử lý tối đa 2 tài khoản song song (`ACCOUNT_DELETION_CONCURRENCY`), phần còn lại chờ theo thứ tự yêu cầu.
5. **Lease** (3 phút, gia hạn liên tục, nhận bằng transaction): instance chết ⇒ lease hết hạn ⇒ instance khác nhặt tiếp. `startSweeper()` quét 1 lần sau khi khởi động + mỗi phút. SIGTERM (Render deploy) trả lease ngay.
6. **Lỗi tạm thời** ⇒ thử lại với backoff 15s → 30 phút; quá 10 lần ⇒ `failed` (không tự thử nữa). Xem/đặt lại: `npm run deletions:list` / `npm run deletions:retry-failed`.
7. Tài khoản `deleting` bị chặn ở MỌI endpoint (kể cả 2 endpoint cho phép pending, để `activation/sync` không lật `deleting` thành `active`), hồ sơ công khai và SSR `/u/:uid` trả 404, frontend tự đăng xuất (kể cả ở thiết bị khác qua dữ liệu realtime) và KHÔNG coi là "pending" (tránh PendingSessionGate đẩy về /login).

## 2. Cần làm khi triển khai

1. **Render (backend)**: thêm `FIREBASE_WEB_API_KEY` = giá trị `VITE_FIREBASE_API_KEY` (Web API key, vốn công khai). Thiếu biến này chỉ làm `forgot-password` trả 503; mọi thứ khác chạy bình thường. Nếu key bị giới hạn theo HTTP referrer trong Google Cloud, thêm `FIREBASE_WEB_API_REFERER`.
2. **Deploy `firestore.rules`** (thêm khối chặn `userPrivate` và `accountDeletions`). Không cần thêm index (hàng chờ đọc rồi lọc trong bộ nhớ).
3. Firebase Console → Authentication → Templates → **Password reset**: kiểm tra nội dung/ngôn ngữ email; Settings → Authorized domains có domain frontend nếu bạn dùng `continueUrl` sau này.
4. (Tuỳ chọn) `npm run realname:migrate` rồi `:apply` để chuyển hết tên thật cũ sang `userPrivate`.

## 3. Quyết định tôi tự đưa ra — hãy duyệt

- **Tên thật chuyển sang `userPrivate`** (mục trên). Nếu bạn chỉ muốn che ở giao diện thì có thể bỏ, nhưng khi đó DevTools vẫn thấy tên thật.
- **Tài khoản SA không tự xoá được** (`403 SA_CANNOT_SELF_DELETE`): tránh mất tài khoản quản trị cuối cùng. Gỡ bằng xoá một khối `if` trong `account.controller.js#requestAccountDeletion` (và `isSA` trong `DeleteAccountPanel`).
- **Không có thời gian chờ khi đổi tag** (chỉ có limiter 10 lần/15 phút). Muốn chặn đổi tag liên tục có thể thêm cooldown.
- **Cấu trúc**: "Thông tin" và "Bảo mật" là 2 mục ở gốc tab Tài khoản theo mô hình thư mục của 2.1.0, không phải thanh tab con.
- **Tái sử dụng**: tách `ProfileFields`, `TagNameField` + `useTagNameAvailability`, `useAvatarUpload` dùng chung cho Đăng ký · Chào mừng · Cài đặt; `PasswordConfirmDialog`/`reauth.js`/`ForgotPasswordDialog` dùng chung cho mọi thao tác cần mật khẩu. `purgeContentSubcollections` (xoá bài thường ngày) và quy trình xoá tài khoản cùng dùng `deleteContentTree`.

## 4. Giới hạn đã biết (cố ý không làm)

- **Bình luận / lượt like của người dùng trên bài của NGƯỜI KHÁC được giữ lại** (hiển thị "Người dùng Twelve"). Xoá chúng phải chỉnh lại bộ đếm trên bài người khác — nên làm thành một bản riêng nếu bạn muốn.
- **Bảng xếp hạng tuần đã chốt** (`weeklyLeaderboards`) lưu ảnh chụp tên/ảnh đại diện của top 10; tài khoản bị xoá vẫn còn trong lịch sử tuần đó (ảnh có thể vỡ vì file Cloudinary đã xoá).
- Cloudinary: chỉ xoá `image` (đúng với việc hiện chỉ upload avatar). Khi thêm loại upload khác, `deleteAllAssetsOfUser` cần mở rộng `resource_type`.
- Render free tier có thể ngủ khi không có request; việc xoá dở sẽ được nhặt lại khi server thức (sau ~5 giây khi khởi động).
- Firebase API key là công khai nên ai cũng có thể gọi thẳng Firebase gửi email đặt lại mật khẩu mà không qua endpoint này; lớp bảo vệ ở đây chặn lạm dụng qua Twelve, không thay được cấu hình chống lạm dụng của Firebase.

## 5. Chưa kiểm chứng được với Firebase/Cloudinary thật — hãy thử tay

Môi trường của tôi dùng Firestore/Auth/Cloudinary giả, nên các điểm sau chỉ kiểm bằng logic và test giả lập:
1. Sau **Đổi mật khẩu**, tab hiện tại vẫn dùng bình thường (token mới không bị coi là "bị thu hồi" bởi kiểm tra `auth_time` của F6); thiết bị khác phải đăng nhập lại trong ≤1 phút.
2. Email "Quên mật khẩu" tới hộp thư, tiếng Việt, đặt lại xong đăng nhập được (cả từ trang Đăng nhập lẫn từ Cài đặt).
3. **Hiện tên thật** với phiên đăng nhập cũ (>5 phút): hộp nhập mật khẩu phải hiện và sau khi nhập đúng thì hiện được.
4. **Xoá tài khoản thử** (tài khoản có bài viết, blog nháp, avatar): sau vài giây kiểm tra Firestore (`users`, `posts`, `blogs`, `tagNames`, `userPrivate`, `accountDeletions` đều sạch), Cloudinary (thư mục `twelve/avatars/<uid>`), Authentication (user biến mất). Thử cả: đóng trình duyệt ngay sau khi bấm; và tắt backend giữa chừng (vd. đặt tạm Cloudinary sai khoá để bước `assets` lỗi) rồi bật lại — sổ `accountDeletions` phải còn, tự chạy tiếp và hết.
5. Đăng ký email cũ ngay sau khi xoá xong phải được (tài khoản Auth + Tag Name Search đã được giải phóng).
