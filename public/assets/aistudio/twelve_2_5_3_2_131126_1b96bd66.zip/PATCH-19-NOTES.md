# PATCH 19 — v2.4.2.1.221026: URL hồ sơ dùng Tag Name Search thay cho UID

Backend + frontend. Test: backend **196/196** (181 → +15: file mới `profile-2421.test.js` 11 test, `security-ssr.test.js` +4), frontend **291/291** (260 → +31: file mới `profileUrl2421.test.jsx` 28 test, `account220.test.jsx` +3), `vite build` sạch. Không đổi biến môi trường, `firestore.rules`/`firestore.indexes.json`, `middleware.js`, `vercel.json` (matcher `/u/:path+` đã phủ mọi URL mới).

> Bản này đã chỉnh theo 3 phản hồi sau lần thử đầu: (1) đổi Tag Name rồi Back về Profile báo "không tồn tại" → hồ sơ của chính mình là `/u/myProfile`; (2) "@" bắt buộc trong URL tag; (3) hộp cảnh báo khi đổi Tag Name. Số phiên bản giữ nguyên `2.4.2.1.221026` (cùng một bản cập nhật) — đổi ở `package.json` ×2, `package-lock.json` ×2, `frontend/public/version.json` nếu bạn muốn tách bản.

## 1. Các dạng URL
| URL | Ý nghĩa |
|---|---|
| `/u/@flylersky` | Hồ sơ công khai theo Tag Name (chữ thường, 3–20 ký tự). Đây là link **chia sẻ / SEO / canonical** |
| `/u/myProfile` | **Hồ sơ của người đang đăng nhập** (không chứa tag nên không chết khi đổi tag). Chưa đăng nhập → `/login`, đăng nhập xong quay lại |
| `/u/<UID>` | Link CŨ — vẫn mở được; SPA **thay** thanh địa chỉ sang `/u/@<tag>` (hoặc `/u/myProfile` nếu là hồ sơ của chính mình), không thêm mục lịch sử; SSR cho bot trả **301** sang `/u/@<tag>` |
| `/u/@FlylerSky` (chữ hoa) | Chấp nhận; chuẩn hoá về chữ thường (SPA: replace, SSR: 301) nên mỗi hồ sơ chỉ có **một** URL |
| `/u/flylersky` (không `@`) | **Không phải tag** — coi như UID cũ nên 404. (Dạng này chỉ có trong bản 2.4.2.1 trước khi chỉnh) |
| `/u/@ab`, `/u/@a-b` | `@` + tag sai định dạng → "không tìm thấy" ngay, không gọi API |

"@" là ký tự phân định: `myProfile` và mọi route phụ về sau của trang Profile không bao giờ trùng với tag của ai (kể cả người đặt tag `myprofile` → URL của họ là `/u/@myprofile`).

## 2. Lỗi Back sau khi đổi Tag Name — nguyên nhân và cách sửa
Lịch sử trình duyệt giữ `/u/@tag-cũ`; đổi tag xong bấm Back → tra tag cũ → 404 "không tìm thấy". Sửa: **mọi đường vào hồ sơ của chính mình đều kết thúc ở `/u/myProfile`**:
- Menu "Profile" (Navbar) đi thẳng `/u/myProfile`.
- Bấm tên/avatar của mình ở bài viết/bình luận/xếp hạng, mở link UID cũ của mình, hoặc gõ `/u/@tag-của-mình` → trang Profile tải xong thì **thay** URL sang `/u/myProfile` (không thêm mục lịch sử, không tải lại lần hai). Phiên đăng nhập tải muộn hơn hồ sơ cũng được xử lý.
- `/u/myProfile` tra theo **UID trong phiên** (`GET /users/:uid`), không theo tag.
- Có test dựng lại đúng kịch bản (lịch sử `[/u/myProfile, /settings/account/info]`, đổi tag, Back) và thử tắt tính năng để chắc test báo đỏ (8 test đỏ).

## 3. Hộp cảnh báo khi đổi Tag Name (Cài đặt › Tài khoản › Thông tin)
Hộp đổi tag giờ có 2 bước. Bước 1 nhập tag mới (kiểm tra trùng như trước); bấm "Đổi tag" **chưa đổi gì**, chuyển sang bước cảnh báo:
- Khung cảnh báo "Link hồ sơ bạn đã chia sẻ sẽ không còn dùng được" + link hiện tại (sẽ ngừng hoạt động) và link mới, dạng `https://<tên miền>/u/@…`.
- Nêu rõ: link cũ đã đăng ngoài Twelve báo "Không tìm thấy người dùng"; tag cũ được trả lại nên người khác có thể nhận và khi đó link cũ mở ra hồ sơ của họ; bài viết/bình luận/điểm giữ nguyên.
- "Quay lại" về bước nhập (giữ tag đã gõ); "Vẫn đổi tag" mới gọi API. Lỗi từ máy chủ (vd. tag vừa bị người khác lấy) đưa về bước nhập kèm thông báo.

## 4. Cách làm (kỹ thuật)
- **Tra theo Tag Name**: `GET /api/users/by-tag/:tag` → `tagNames/{tag}` (khoá duy nhất của Tag Name) → nạp hồ sơ; đối chiếu ngược `users/{uid}.tagName === tag` (document `tagNames` lệch ⇒ 404). Giữ mọi quy tắc 404 cũ (pending, đang xoá, hồ sơ "ma"); suspended vẫn công khai. Dùng `profileReadLimiter`.
- **Một nơi tra hồ sơ cho API lẫn SSR**: `services/profileLookup.js`.
- **Dựng URL ở MỘT chỗ**: backend `helpers.js` (`profilePath`, `classifyProfileRef`), frontend `utils/profilePath.js` (`profilePath(user)`, `SELF_PROFILE_PATH`, `classifyProfileRef`). `onProfileClick` của `UserIdentity` nhận **đối tượng người dùng**. Test quét `src/`: cấm tự ghép `` `/u/${…}` ``, `'/u/' + biến`, `` `/u/@${…}` `` và gõ cứng `/u/myProfile`.
- **Trang Profile**: hồ sơ đã tải được gắn kèm khoá URL của nó — đổi URL sang người khác thì dữ liệu người trước biến mất ngay (không hiện nhầm), còn khi trang tự thay URL sang dạng chuẩn thì không tải lại. UID lấy từ hồ sơ đã tải để gọi `/posts`, `/pinned`.
- **SSR cho bot**: `/u/@tag` render; canonical/JSON-LD/sitemap/link tác giả là `/u/@tag`; `/u/myProfile`, `@`+tag sai, tag không `@` → 404 `noindex`; UID cũ → 301 (không có tag hợp lệ hoặc hồ sơ pending → 404, không lộ tag).

## 5. Test cũ phải đổi (hành vi đổi có chủ ý)
- `security-ssr.test.js`: fixture thêm `tagNames`; tag `an` (2 ký tự, không hợp lệ theo luật 3–20) đổi thành `annguyen`; URL → `/u/@<tag>`; sitemap kỳ vọng `/u/@annguyen` và **không** chứa `/u/u1`.
- `profile240.test.jsx`: mock thêm `getPublicProfileByTag`, route `/u/:ref`, URL `/u/@lan`, `/u/@toi`.
- `account220.test.jsx`: "Đổi tag" giờ cần thêm một lần bấm "Vẫn đổi tag".

## 6. Điều bạn nên biết (đọc trước khi deploy)
1. **Địa chỉ trên thanh trình duyệt khi đang xem hồ sơ của mình là `/u/myProfile`** — copy link từ đó gửi người khác thì họ sẽ thấy hồ sơ **của chính họ** (hoặc bị chuyển tới đăng nhập), không phải của bạn. Link chia sẻ đúng là `/u/@<tag>` và hiện **chưa có nút nào lấy link này** (canonical SEO của trang đã là `/u/@<tag>`). Nên thêm nút "Sao chép liên kết hồ sơ" ở headZone của hồ sơ mình — chưa làm vì chưa được yêu cầu.
2. **UID chưa biến mất khỏi hệ thống — chỉ khỏi URL hồ sơ.** API vẫn trả `uid` (đối tượng `author` trong bài/bình luận/xếp hạng, `GET /users/by-tag`…) vì frontend dùng để so quyền sở hữu, ghim bài, gọi `/posts`. Giấu hẳn UID khỏi API là thay đổi lớn hơn nhiều — chưa làm.
3. **Link chia sẻ bài viết vẫn mang UID**: `…/post/<id>?idu=<UID>&s=<chữ ký>` (ghi công người chia sẻ, `share.controller.js`) — tính năng riêng, chưa đụng.
4. **Đổi Tag Name thì link hồ sơ đã chia sẻ chết và tag cũ có thể bị người khác nhận** (có test mô tả đúng hành vi này). Hộp cảnh báo ở mục 3 chỉ **báo trước**, chưa giảm được hậu quả. Cách giảm: giữ bảng "tag cũ → UID" để chuyển hướng, hoặc khoá tag cũ vài chục ngày trước khi cho người khác nhận.
5. **Tài khoản giữ tag không đúng luật** (tag Twelve cũ dài > 20 ký tự — `migrate-legacy-data.js` chỉ cảnh báo) không dùng tag làm URL được: hồ sơ tự rơi về `/u/<uid>` như trước (vẫn mở được). Chưa kiểm số lượng trên dữ liệu thật.
6. Tra theo tag cho phép dò tag có chủ hay không (404 vs 200) — tương đương `useTagNameAvailability` công khai sẵn có, có limiter 200 lượt/15 phút.
7. **Chưa kiểm trên trình duyệt/Firestore/Vercel thật** (test dùng Firestore giả và `MemoryRouter`). Nên thử tay: (a) menu Profile → `/u/myProfile`; (b) đổi Tag Name (xem hộp cảnh báo), rồi bấm Back về hồ sơ — phải hiện hồ sơ; (c) bấm tên mình ở một bài viết → URL phải về `/u/myProfile` và Back không quay vòng; (d) mở `/u/@<tag của người khác>` và link UID cũ của họ — thanh địa chỉ về `/u/@tag`; (e) mở `/u/myProfile` khi chưa đăng nhập → `/login` rồi quay lại; (f) `curl -A Googlebot -I https://twelveta.vercel.app/u/<UID>` → 301 sang `/u/@<tag>`; (g) `/sitemap-1.xml` chỉ còn URL `/u/@tag`.

## 7. File chính
Mới (backend): `services/profileLookup.js`, test `profile-2421.test.js`. Mới (frontend): `utils/profilePath.js`, test `profileUrl2421.test.jsx`.
Đổi (backend): `utils/helpers.js`, `controllers/users.controller.js`, `routes/users.routes.js`, `routes/ssr.routes.js`, `controllers/seo.controller.js`, `utils/seoMeta.js`, `views/content.ejs`, `views/profile.ejs`, `package.json`, test `security-ssr.test.js`.
Đổi (frontend): `pages/PublicProfilePage.jsx`, `pages/settings/AccountInfoPanel.jsx` (hộp cảnh báo), `App.jsx`, `api/users.api.js`, `components/UserIdentity.jsx`, `CommentModal.jsx`, `Navbar.jsx`, `RankingList.jsx`, test `profile240.test.jsx`, `account220.test.jsx`.
Phiên bản: `package.json` ×2, `package-lock.json` ×2, `frontend/public/version.json`. Tài liệu: `SECURITY-STATUS.md`, README (backend: bảng endpoint; frontend: ghi chú mục 0b).
