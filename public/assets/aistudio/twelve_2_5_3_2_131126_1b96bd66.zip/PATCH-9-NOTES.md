# v2.0.12 — Vá theo Báo cáo bảo mật Phiên 3 (Tổng quát) + đóng chương trình 3 phiên

Xây trên **v2.0.11**. Nhãn `2.0.12.091026` là tạm. Báo cáo Phiên 3 không có lỗ hổng mới; bản này xử lý các ghi chú còn lại và
**quan trọng nhất là `SECURITY-STATUS.md`** — bảng theo dõi toàn bộ 23 mục của 3 phiên (F1–F11, G1–G5, N1–N7), việc vận hành và các quyết định còn mở.

## Đã làm
| Mục | Thay đổi |
|---|---|
| **F5** (còn lại) | `firebase-admin` `^12` → `^13.10`: `npm audit` **hết 2 HIGH** (`node-forge`), còn 8 moderate qua `uuid` (không chạm tới). Không phải sửa mã: đã kiểm bề mặt API trên bản thật (offline). **Không nâng lên 14**: bản 14 xoá `admin.firestore.*`/`admin.auth()`/`admin.credential` ⇒ cần di chuyển mã. Thêm `test/firebase-admin-surface.test.js` (chạy trên thư viện thật) để ai nâng 14 sớm sẽ thấy lỗi rõ ràng |
| **N2** | Gỡ `cookie-parser` + `COOKIE_SECRET` (không có `req.cookies`/`res.cookie` nào; xác thực bằng Bearer token) |
| **N3** | Đăng ký dở chừng không còn kẹt email: `registrationMarkers/{uid}` ghi sau khi tạo Auth, xoá trong cùng giao dịch tạo hồ sơ. Khi `createUser` báo email đã tồn tại, nếu tài khoản có dấu + không hồ sơ + quá 10 phút ⇒ dọn rồi đăng ký lại. Script `npm run auth:cleanup-orphans[:apply]` (dry-run mặc định). **Thiết kế an toàn:** tài khoản Auth KHÔNG có dấu (vd. do app khác cùng dự án Firebase tạo) tuyệt đối không bị xoá — có test riêng cho ca kẻ xấu đăng ký email của nạn nhân |
| **F3** | Công tắc `VIEW_SCORE_ONCE_PER_PAIR=on` (mặc định TẮT): điểm xem chỉ cộng 1 lần/(người xem, bài); `viewCount` không đổi; bản ghi view cũ được cộng thêm đúng 1 lần rồi khoá. Bạn chỉ cần đặt biến môi trường để bật/tắt |
| Tài liệu | `SECURITY-STATUS.md` (bảng theo dõi, danh sách biến môi trường, việc sau deploy, quyết định còn mở, ánh xạ test) |

## Kiểm thử
Backend **71/71** (+14: N2, N3 ×7 gồm 4 ca "không được xoá nhầm", F3 ×3, bề mặt firebase-admin ×3) · Frontend **82/82** · fuzz 2.324 request sai kiểu trên `server.js` thật: **0 lỗi 5xx** · `vite build` OK.
Đột biến: bỏ kiểm tra dấu đăng ký ⇒ test "tài khoản không dấu không bị xoá" FAIL; bỏ thời gian ân hạn ⇒ 2 test FAIL; vô hiệu công tắc F3 ⇒ 2 test FAIL.
**Chưa kiểm:** `firebase-admin@13` với Firebase thật (đăng nhập/`verifyIdToken`/Firestore/Auth Admin) — sau deploy hãy thử đăng ký, đăng nhập, đăng bài, và đổi mật khẩu rồi dùng lại token cũ (phải bị từ chối trong ≤ 60 giây).

## Cần bạn quyết định (xem SECURITY-STATUS.md mục 3)
1. **Bật `VIEW_SCORE_ONCE_PER_PAIR=on`?** (F3) — mình đề xuất bật.
2. Thời điểm chuyển `script-src` sang enforce (G1) sau khi quan sát panel CSP.
3. Có làm tính năng **xoá tài khoản** (N5) không, và chính sách nội dung (xoá hay ẩn danh).
4. Đợt nâng `firebase`/`react-router-dom` (frontend) và di chuyển `firebase-admin` 14 — cần hồi quy trên trình duyệt/Firebase thật.
