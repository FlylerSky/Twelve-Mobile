# Bản vá 3 (hotfix) — nút like/dislike nhảy loạn

## Nguyên nhân
`useContentEngagement` có một effect "đồng bộ từ `initial`" chạy lại khi BẤT KỲ trường nào của `initial` đổi
và reset cả `myReaction` lẫn số like/dislike về giá trị trong `initial`. Với thẻ bài ở danh sách, `initial` là
đối tượng bài lấy lúc tải danh sách (CHƯA có lượt like vừa bấm). Khi gửi bình luận, hộp bình luận gọi
`adjustCommentCount` → `commentCount` trong danh sách đổi → effect chạy → nút like mất màu, số like về cũ.
Bấm lại thì hook tưởng đang "like mới" (cộng 1 → hiện 2) trong khi server đang bỏ like (→ 0), rồi `myReaction`
cục bộ sai làm các lần bấm sau đảo ngược. Trang chi tiết bài cũng dính (mỗi lần realtime đổi `post`, `initial`
đổi và `myReaction` bị đặt lại về `myReaction0` lúc tải).

## Sửa (`frontend/src/hooks/useContentEngagement.js`)
- Đổi `id`: reset toàn bộ. Ngoài ra `myReaction` chỉ nhận từ `initial` khi CHÍNH trường đó trong `initial` đổi.
- Số đếm: sau khi realtime trả dữ liệu đầu tiên thì realtime là nguồn đúng duy nhất; `initial` cũ không ghi đè.
  Trước đó (hoặc khi listener lỗi) vẫn đồng bộ từng trường khi trường đó đổi.
- Sau khi gọi API react, dùng `myReaction` server trả về để tự sửa nếu UI lệch.

## Kiểm thử
`frontend/tests/useContentEngagement.test.jsx` (6 ca, gồm đúng kịch bản bạn mô tả). 3/6 ca FAIL trên hook cũ và
6/6 PASS trên hook mới. Vitest không được thêm vào `package.json`; muốn chạy lại:
`npm i -D vitest jsdom @testing-library/react && npx vitest run`.
Chưa thử trên trình duyệt thật: hãy lặp lại thí nghiệm (like → mở comment → gửi → đóng → quan sát nút like).
