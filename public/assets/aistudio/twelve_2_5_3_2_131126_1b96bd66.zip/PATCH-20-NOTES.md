# PATCH 20 — v2.4.2.2.231026: nút "Sao chép URL Profile" ở headZone trang Profile

Chỉ frontend (backend chỉ đổi số phiên bản). Test: frontend **310/310** (291 → +19: file mới `profileCopyUrl2422.test.jsx`; 4 test cũ đổi kỳ vọng, xem mục 4), backend **196/196** (không đổi), `vite build` sạch. Không đổi biến môi trường, `firestore.rules`, `middleware.js`, `vercel.json`, API.

Bản này cũng là phần "nên thêm nút sao chép liên kết hồ sơ ở headZone" mà `PATCH-19-NOTES.md` mục 6.1 đã nêu.

## 1. Tính năng
Trang Profile (`/u/…`) có nút **Sao chép URL Profile** (icon liên kết) ở headZone — **hồ sơ của mình lẫn của mọi người khác** (kể cả khách chưa đăng nhập). Hồ sơ của mình có 2 nút: "Chỉnh sửa hồ sơ" (đứng trước) rồi "Sao chép URL Profile". Nút chỉ hiện khi hồ sơ đã tải xong (cần `tagName`/`uid` để dựng link).

Bấm nút → hộp **Sao chép URL Profile** với 2 lựa chọn; chọn một dòng là sao chép ngay, báo "Đã sao chép…" và đóng hộp:
| Lựa chọn | Link sao chép | Ghi chú trong hộp |
|---|---|---|
| **URL Ngắn (Tag Name Search)** | `https://<tên miền>/u/@<tag>` | Gọn, dễ nhớ; đổi theo nếu chủ hồ sơ đổi Tag Name |
| **URL cố định (UID)** | `https://<tên miền>/u/<UID>` | Không đổi dù đổi Tag Name; khi mở, Twelve tự chuyển sang URL Tag Name |

Hồ sơ chưa có Tag Name hợp lệ (tag cũ > 20 ký tự — PATCH-19 mục 6.5): dòng URL Ngắn bị khoá kèm lời giải thích, URL cố định vẫn dùng được. Sao chép thất bại (trình duyệt chặn clipboard): báo lỗi, giữ hộp mở; link hiển thị dạng văn bản để tự chọn và sao chép tay. Đang mở hộp mà chuyển sang hồ sơ người khác → hộp tự đóng.

## 2. Hệ thống URL Profile KHÔNG đổi (đọc kỹ)
- **URL Tag Name `/u/@tag` vẫn là URL hồ sơ chính** (canonical, SEO, sitemap, link trong app, `/u/myProfile` của chính mình). `profilePath()` vẫn ưu tiên tag; UID chỉ là đường lùi khi hồ sơ không có tag hợp lệ — y như PATCH-19.
- URL UID **chỉ là một lựa chọn sao chép thêm**, tận dụng việc link UID cũ vẫn được hỗ trợ: SPA mở `/u/<UID>` thì **thay** thanh địa chỉ sang `/u/@<tag>` (hoặc `/u/myProfile` nếu là hồ sơ của người mở); SSR cho bot trả **301** sang `/u/@<tag>`. Bản này không sửa dòng nào của cơ chế đó (backend, `PublicProfilePage` phần tra cứu/chuẩn hoá URL giữ nguyên).
- Có test chốt chặn: (a) `profilePath()` vẫn tag-first; (b) mở đúng đường dẫn mà nút "URL cố định (UID)" sao chép → thanh địa chỉ về `/u/@tag` (người khác) / `/u/myProfile` (chính mình); (c) bấm sao chép không điều hướng. Đã thử đảo `profilePath()` thành UID-first để chắc test báo đỏ (11 test đỏ), và thử bỏ nút (6 test đỏ).

## 3. Cách làm (kỹ thuật)
- **Dựng link ở MỘT chỗ — `utils/profilePath.js`** (test quét `src/` vẫn cấm tự ghép `/u/…` ở nơi khác): thêm `profileTagPath(user)` (chỉ `/u/@tag`, không rơi về UID), `profileUidPath(user)`, `profileShareUrls(user, origin)` → `{ tag, uid }` tuyệt đối. `profilePath()` viết lại bằng hai hàm này, kết quả y nguyên.
- Link dựng từ **đối tượng hồ sơ đã tải**, không từ thanh địa chỉ — vì hồ sơ của mình đang ở `/u/myProfile`, link đó gửi người khác sẽ mở ra hồ sơ của *họ*.
- **Hộp**: `components/profile/CopyProfileUrlDialog.jsx` (MUI Dialog như `ConfirmDialog`, snackbar như phần còn lại của app).
- **Dùng lại, không viết lại**: `copyText` (clipboard + đường dự phòng `execCommand`) trước nằm trong `pages/settings/debugReport.js` nay chuyển ra `utils/clipboard.js`; `debugReport.js` vẫn `export { copyText }` nên Gỡ lỗi và test cũ không đổi.
- **headZone**: thêm action `copy-profile-url` vào `headActions` của `PublicProfilePage` (đúng quy ước `useRegisterPageHeader`: `useMemo`, key ổn định; `onClick` chỉ `setCopyUrlOpen(true)`).

## 4. Test cũ phải đổi (hành vi đổi có chủ ý — người khác từng "không có action")
- `profile240.test.jsx`: hồ sơ người khác → `["copy-profile-url"]`; chính chủ → `["edit-profile", "copy-profile-url"]`.
- `profileUrl2421.test.jsx`: 3 chỗ `["edit-profile"]` → thêm `"copy-profile-url"`; 2 chỗ `[]` của hồ sơ người khác → `["copy-profile-url"]` (kỳ vọng "trước khi hồ sơ tải xong chỉ có `edit-profile`" giữ nguyên).

## 5. Điều bạn nên biết
1. **Link UID đưa UID ra ngoài link chia sẻ.** PATCH-19 giảm lộ UID trên URL; nay người dùng *chủ động chọn* sao chép dạng UID thì UID nằm trong link họ gửi. Không thêm bề mặt mới (API công khai vẫn trả `uid` — PATCH-19 mục 6.2) và link UID không vào sitemap/SEO (301 sang tag). Tên "cố định" chỉ đúng với **hồ sơ còn tồn tại**; hồ sơ bị xoá thì link UID cũng 404.
2. Hộp cảnh báo đổi Tag Name (`AccountInfoPanel.jsx`) vẫn tự ghép `${origin}/u/@${tag}` để hiển thị — có từ PATCH-19, **chưa đụng** (khác ca ở đây: nó hiển thị tag người dùng đang gõ, chưa phải hồ sơ đã tải). Nếu muốn gom về `profileShareUrls` thì làm ở bản sau.
3. Chưa kiểm trên trình duyệt thật (test dùng jsdom và clipboard giả). Nên thử tay: (a) hồ sơ người khác → nút xuất hiện, chọn URL Ngắn → dán ra `…/u/@tag`; (b) chọn URL cố định → dán vào tab ẩn danh → thanh địa chỉ chuyển sang `/u/@tag`; (c) hồ sơ của mình → link ngắn là `/u/@<tag của mình>` (không phải `/u/myProfile`); (d) trên điện thoại (HTTPS) clipboard hoạt động, trên `http://` không có HTTPS thì dùng đường dự phòng; (e) thanh headZone trên màn hình hẹp: hồ sơ của mình có 2 nút, nút thứ 2 có thể nằm trong "Thêm" tuỳ độ rộng.

## 6. File chính
Mới: `frontend/src/components/profile/CopyProfileUrlDialog.jsx`, `frontend/src/utils/clipboard.js`, `frontend/tests/profileCopyUrl2422.test.jsx`.
Đổi: `frontend/src/pages/PublicProfilePage.jsx`, `frontend/src/utils/profilePath.js`, `frontend/src/pages/settings/debugReport.js` (re-export `copyText`), test `profile240.test.jsx`, `profileUrl2421.test.jsx`.
Phiên bản `2.4.2.2.231026`: `package.json` ×2, `package-lock.json` ×2, `frontend/public/version.json`. Tài liệu: `SECURITY-STATUS.md` (dòng đầu), `frontend/README.md` (ghi chú mục 0b).
