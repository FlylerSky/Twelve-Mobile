# Bản vá 10 — v2.0.13.100726 (xây trên v2.0.12.091026)

## Sửa lỗi: không mở được hộp "Đăng bài viết" ở lần đầu sau khi tải lại trang (F5)
**Triệu chứng:** vào Twelve → menu → "Đăng bài viết" không có gì xảy ra; chuyển sang trang khác thì hộp mới hiện;
F5 xong lỗi lặp lại.

**Nguyên nhân gốc:** `useRegisterPageHeader` (`frontend/src/context/PageHeaderContext.jsx`) đặt `actions` — mảng MỚI ở mỗi lần
render (vd. `actions: []`) — vào deps của `useEffect`. Effect chạy lại ở mọi lần render → `setPageHeader` → Provider render
lại → trang (là consumer) render lại → lặp vô hạn (đo được hàng trăm lần/giây trên bản dev). Từ v2.0.11 (G4) hộp soạn bài được
tải lười (`lazy` + `Suspense`), cần một lượt render ưu tiên thấp ("retry") của React để hiện; vòng lặp ở trên chiếm hết thời
gian nên lượt đó không bao giờ chạy cho tới khi đổi trang (vòng lặp dừng). Sau lần mount đầu tiên hộp không cần retry nữa
nên mở bình thường — đúng như mô tả.

**Cách sửa:** effect chỉ phụ thuộc `actionsKey` (key + nhãn + disabled + màu của các action); `onClick` luôn gọi bản mới nhất
qua `ref` nên không bị closure cũ. Sửa MỘT chỗ cho tất cả các trang dùng hook (Index, Login, Register, Blog, Settings, Trending,
Post, Profile…). Kèm theo: các trang không còn render lặp vô ích → bớt tốn CPU/pin.

**Kiểm chứng:** tái hiện và xác nhận sửa xong trên Chromium thật (build production, mạng thường và mạng giả lập chậm);
test hồi quy mới `frontend/tests/pageHeaderLoop.test.jsx` (đỏ trên mã cũ, xanh trên mã mới). Toàn bộ test: frontend 84/84,
backend 71/71.

## Không đổi
Backend, Firestore rules, biến môi trường: không đổi. Chỉ cần deploy lại frontend (backend chỉ đổi nhãn phiên bản).
