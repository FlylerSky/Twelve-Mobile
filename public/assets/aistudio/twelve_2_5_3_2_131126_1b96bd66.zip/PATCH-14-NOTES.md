# PATCH 14 — Twelve 2.2.2.171026 · Vá các điểm sót sau báo cáo kiểm tra lại 2.2.1

Nền: `twelve_2_2_1` (2.2.1.151026). Phiên bản mới: **2.2.2.171026** (frontend `package.json` + `public/version.json`, backend `package.json` + `.env.example`).
Nguồn: `Bao_cao_kiem_tra_lai_Twelve_2_2_1.md` + `twelve-221-recheck-poc.zip`. Báo cáo không có lỗi từ Trung bình trở lên; 4 điểm sót mức Thấp (R-01…R-04) đều đã xử lý.
Kiểm thử: backend **126/126** (118 cũ + 8 mới trong `test/security-222.test.js`), frontend **153/153**, `vite build` sạch. Không đổi dependency, không đổi `firestore.rules`, không cần index mới.
Chạy lại **hai PoC của báo cáo** trên mã đã vá: A-03 (đo qua HTTP) vẫn đạt; test "A-04 lookalike" và "A-06 hex-alpha" — vốn khẳng định lỗi còn tồn tại — **nay thất bại** (= đã vá: cả 10 dạng lookalike lẫn `#fff0`/`#ffffff00` đều bị chặn). PoC `221b` (R-02) xem lưu ý ở mục 2.

## 1. Đã vá

| ID | Việc đã làm | Test |
|---|---|---|
| **R-01** | `color` chuyển từ danh sách đen sang **danh sách trắng**: hex 3/6 chữ số; hex 4/8 chữ số chỉ khi alpha ≥ 0.1 (`#fff0`, `#ffffff00`, `#0001` bị loại); từ khoá chữ cái (trừ `transparent`); `rgb()/rgba()/hsl()/hsla()` thành phần số, alpha ≥ 0.1. Các dạng không tính được độ trong suốt — `color-mix()`, `light-dark()`, `var()`, `calc()`, màu tương đối — bị loại luôn | `R-01: …` |
| **R-02** | Mỗi **nguồn gửi** (IP thật, chỉ giữ dạng băm có muối ngẫu nhiên — vẫn không lưu IP) chỉ tạo tối đa **10 khoá CSP mới** mỗi cửa sổ quan sát: một người gửi không còn tự lấp đầy khoản dự trữ `script-src` (cần ≥5 nguồn) hay cả bảng (≥30 nguồn). Mỗi khoá ghi thêm số nguồn gửi khác nhau (`reporters`): vi phạm thật đến từ nhiều người dùng, nhiễu thường chỉ 1. Panel SA hiện `reporters` và chip "bị bỏ vì một nguồn gửi quá nhiều khoá mới" (`throttled`) | `R-02: …` (4 test) |
| **R-03** | Tag dành riêng so khớp theo dạng "gập": bỏ gạch dưới/số đuôi, leetspeak (`0→o 1→i 3→e 4→a 5→s 7→t`), coi `l`≈`i` (bắt `admln`, `tweive`), gộp chữ lặp (`suppport`). Thêm **chặn ghép từ**: tag bị chặn nếu toàn bộ ghép được từ (từ dành riêng ∪ từ đệm `the/real/official/app/hq/vn/team/staff/help/support/admin/mod/security/service/care/bot/global/contact/info/news/account/verified`) và có ≥1 từ dành riêng → `the_twelve`, `realtwelve`, `twelvehelp`, `twelve_vn`, `official_twelve`, `admin_vn` bị chặn. So khớp đúng toàn chuỗi nên `helpful`, `model`, `supporter`, `teammate`, `twelvefan_vn` vẫn dùng được. Thêm script **chỉ đọc** `npm run tags:reserved`: liệt kê tag dành riêng đang bị tài khoản giữ (kèm nhóm SA/khác) | `R-03: …` (2 test) |
| **R-04** | `pending:cleanup:apply` **kiểm lại ngay trước từng lần xếp hàng xoá**: hồ sơ còn `pending` và email chưa xác minh; người vừa xác minh/được kích hoạt giữa hai vòng được bỏ qua (script báo số bỏ qua) | `R-04: …` |

## 2. Lưu ý / giới hạn còn lại — hãy đọc

- **R-02 và PoC `221b`**: PoC gọi thẳng controller **không kèm IP**, nên kẻ tấn công và báo cáo "thật" nằm chung một nguồn → báo cáo thật bị giới hạn theo nguồn đó (bảng chỉ có 10 khoá, `overflow` = 0), vì vậy assert "vi phạm thật không được ghi" vẫn đúng. Với lưu lượng thật, báo cáo thật đến từ IP khác nên được ghi — test `R-02: MỘT nguồn gửi không tự lấp đầy được…` mô phỏng đúng điều đó.
- **Kẻ tấn công phân tán** (nhiều IP) vẫn lấp đầy được; giờ tốn công hơn nhiều, bị báo qua `overflow`, và nhận ra được nhờ `reporters` = 1. Không có cách triệt để nếu `blocked-uri` do người gửi tự khai.
- **Phụ thuộc `SSR_PROXY_SECRET`**: IP thật của người dùng lấy từ `x-twelve-client-ip` do middleware Vercel gửi (chỉ tin khi secret khớp, cùng cơ chế với `cspReportLimiter`). Nếu production **chưa** đặt `SSR_PROXY_SECRET` thì mọi báo cáo nhìn như một nguồn và 10 khoá mới là hạn mức **chung** — cảnh báo khi khởi động đã được bổ sung. Hãy kiểm biến này ở cả Render và Vercel.
- Gợi ý "gom `blocked-uri` về origin" của báo cáo **đã có sẵn** từ trước (`normalizeBlocked` chỉ giữ origin); PoC lấp đầy bằng nhiều **host** khác nhau nên không đổi được gì — vì thế cách chữa là giới hạn theo nguồn gửi.
- **R-01**: danh sách trắng cũng loại các màu hợp lệ nhưng hiếm như `lab()`, `oklch()`, `color()`, `color-mix()` (Quill và trình soạn thảo hiện tại không tạo ra chúng). Chữ **cùng màu nền** vẫn không phát hiện được bằng allowlist.
- **R-03**: không thể chặn mọi lookalike (vd. `rn` ↔ `m`, `vv` ↔ `w`, ký tự gần giống khác). Tag chỉ chặn **người mới** — tài khoản đang giữ tag dành riêng từ trước không bị đụng; dùng `npm run tags:reserved` để xem. Ghép từ nay chặn cả `administrator_vn`/`admin_vn` (ở 2.2.1 chỉ chặn đúng tên).
- **Hạn mức 10 khoá mới/nguồn** có thể làm một người dùng thật (hoặc cả một văn phòng chung IP) chỉ đóng góp tối đa 10 vi phạm *khác nhau* mỗi cửa sổ; các người dùng khác vẫn bổ sung được, nên số liệu vẫn đủ cho quyết định G1.

## 3. Cần làm khi triển khai
1. Deploy **backend**, rồi **frontend** (chỉ đổi panel CSP + số phiên bản). `BACKEND_VERSION=2.2.2.171026` trên Render.
2. Xác nhận `SSR_PROXY_SECRET` giống nhau ở Render và Vercel (xem mục 2).
3. `npm run tags:reserved` — xem có tài khoản thường đang giữ tag dành riêng không.
4. Nếu định chạy `node src/seed/resanitizeContent.js` (áp bộ lọc style cho bài cũ; **ghi đè dữ liệu, không có dry-run**): làm **sau khi** deploy 2.2.2 để R-01 đã có hiệu lực, và sao lưu trước.
5. Nên đặt cảnh báo trên log Render cho chuỗi `unhandledRejection (` (xuất hiện mỗi lần có rejection lọt qua; tiến trình chỉ thoát khi > 10 lần/phút).
6. `npm run ghosts:purge` quét toàn bộ `users` và `userPrivate`: chạy dry-run vào giờ thấp điểm (tốn lượt đọc tỷ lệ với số người dùng).

## 4. Không làm trong bản này
- **A-08 lockfile**: vẫn không đưa `package-lock.json` vào gói — nếu repo thật của bạn đã có, ghi đè sẽ đổi phiên bản đã ghim. Chưa có thì `npm install` ở `backend/` và `frontend/`, commit lockfile, dùng `npm ci`.
- **F3**, **G1** (`script-src` enforce), nâng dependency, `NODE_ENV=production`, IPv6/limiter, Email enumeration protection, đổi mật khẩu tài khoản beta đã chia sẻ: giữ nguyên như `PATCH-13-NOTES.md` mục 3–5 (quyết định sản phẩm hoặc việc chỉ kiểm được trên Render/Firebase thật).
