# Twelve — Bảng theo dõi bảo mật (3 phiên trên v2.0.9 + kiểm tra độc lập trên v2.2.0)

Cập nhật ở **v2.5.3.131126** ("2.5.3.2") — đo + sửa nhận diện IP client (TW-01): panel Cài đặt › Quản trị › **Nhận diện IP**, endpoint `GET /api/admin/ip-topology` (chỉ SA, chỉ đọc), chế độ tuỳ chọn `TRUST_PROXY_MODE=cloudflare` (mặc định hành vi KHÔNG đổi); `vercel.json` bỏ `usb=()` và thêm ImageKit vào `img-src` Report-Only; đính chính báo cáo phụ lục (V-01 mở lại ở mức "chưa kết luận") — xem `PATCH-26-NOTES.md`. Trước đó **v2.5.3.121126** — hotfix: App Check (TW-04) làm treo đăng nhập/Firestore khi reCAPTCHA bị CSP chặn, nay không thể treo (xem `PATCH-25-NOTES.md`; không đổi bề mặt tấn công, CSP giữ nguyên). Trước đó v2.5.3.081126 (bản vá theo "Báo cáo bảo mật tổng hợp cuối v2.5.2", 27 phát hiện TW-01…TW-27 — xem `PATCH-24-NOTES.md` và **mục 1b** bên dưới: sửa nhận diện IP client sau Cloudflare, bật chống cày điểm xem mặc định, chặn thật `script-src`, khoá `config/*` và `positiveScoreLogs`, nhập lại mật khẩu + nhật ký cho thao tác ghi của SA, dọn `pending` tự động, lọc `class`/`style`, v.v.). Trước đó **v2.5.2.031126** (hoàn thiện trang Profile, xem `PATCH-23-NOTES.md` — **thêm 5 endpoint và dữ liệu mới, xem mục 3 điểm 6**: tiểu sử văn bản thuần (không HTML), lịch sử khách ghé thăm chỉ chủ hồ sơ xem được, ngày sinh/giới tính chỉ ra công khai khi chính chủ bật và được lọc ở backend; tất cả đi qua limiter, `requireAuth`/`optionalAuth` đúng chỗ, rules chặn Client SDK). Trước đó `PATCH-22-NOTES.md` (thẻ meta xác thực Search Console — không đổi bề mặt tấn công). Mức độ lấy theo các báo cáo; chi tiết bản có thay đổi bảo mật gần nhất trước đó: `PATCH-21-NOTES.md` (hợp nhất 2.4.2.2 + 2.5.0 SEO — **không thêm endpoint/quyền mới**; SSR giờ hiển thị ≤10 bình luận đã vốn công khai qua API, chỉ của tác giả `active`, escape tự động; script Turnstile chuyển sang nạp theo nhu cầu, CSP không đổi); trước đó `PATCH-20-NOTES.md` (nút "Sao chép URL Profile" — chỉ frontend, **không đổi bề mặt tấn công**; lưu ý mục 5.1: link UID do người dùng chủ động chọn sao chép nên UID nằm trong link họ gửi, UID vốn đã công khai qua API); trước đó `PATCH-19-NOTES.md` (URL hồ sơ dùng Tag Name Search thay cho UID — **giảm lộ UID trên URL/sitemap/SEO**, thêm 1 endpoint đọc công khai `GET /api/users/by-tag/:tag` có limiter; xem mục 4 của file đó về phần UID còn lại); trước đó `PATCH-18-NOTES.md` (điều hướng Back — chỉ frontend, **không đổi bề mặt tấn công**); trước đó `PATCH-17-NOTES.md` (sửa trang Profile — mục 6: khung ảnh bìa), `PATCH-16-NOTES.md` (trang Profile, mục 6), trước đó `PATCH-15-NOTES.md` (mục **Gỡ lỗi** + vá nốt R-01/R-03), `PATCH-14-NOTES.md`, `PATCH-13-NOTES.md`.

## 1. Trạng thái từng phát hiện
| # | Mức | Tiêu đề ngắn | Trạng thái | Sửa ở | Ghi chú |
|---|---|---|---|---|---|
| F1 | 🔴 CRITICAL | DoS `sanitizeHtml` | ✅ Đã vá | 2.0.10 | Giới hạn đầu vào + sanitize ở `worker_threads` có timeout 3 s (rộng hơn báo cáo: `<table>`, `<div>` lồng sâu, nhiều media) |
| F2 | 🟠 HIGH | multipart avatar | ✅ Đã vá | 2.0.10 | multer `fields/fieldSize/parts/headerPairs` |
| F3 | 🟠 HIGH | Cày điểm xem | ✅ **Đã bật mặc định** | 2.0.12 → 2.5.3 | Công tắc `VIEW_SCORE_ONCE_PER_PAIR`: **từ 2.5.3 mặc định BẬT** (TW-03); `off` để về hành vi cũ. Thưởng share thêm trần theo ngày |
| F4 | 🟡 MEDIUM | Pending nhận điểm share | ✅ Đã vá | 2.0.10 | Cũng vá luôn đường điểm xem; pending/suspended = khách |
| F5 | 🟡 MEDIUM | CVE phụ thuộc backend | 🟢 Đã giảm | 2.0.10 + 2.0.12 | `file-type` ^21.3.4; `firebase-admin` ^13.10 → **hết 2 HIGH**, còn 8 moderate qua `uuid` (không chạm tới: chỉ dùng `v4()`). Bản 14 cần di chuyển mã (mục 3) |
| F6 | 🔵 LOW | `checkRevoked` | ✅ Đã vá | 2.0.10 | Cache 60 s/uid |
| F7 | 🔵 LOW | Unicode trong tên | ✅ Đã vá | 2.0.10 | |
| F8 | 🔵 LOW | Sai kiểu → 500 | ✅ Đã vá | 2.0.10 | Fuzz 2.324 request: 0 lỗi 5xx (chạy lại ở 2.0.12: vẫn 0) |
| F9 | ⚪ INFO | `birthday` | ✅ Đã vá | 2.0.10 | |
| F10 | ⚪ INFO | Rescan kích hoạt lại F1 | ✅ Đã vá | 2.0.10 | |
| F11 | 🟡 MEDIUM | `file-type` lặp vô hạn (ASF) — *phát sinh khi điều tra F5* | ✅ Đã vá | 2.0.10 | |
| G1 | 🟡 MEDIUM | CSP chỉ Report-Only | 🟢 Đã làm đến `script-src` | 2.0.11 → 2.5.3 | Header chặn thật: `object-src/base-uri/form-action/frame-ancestors` (2.0.11) **+ `script-src 'self' https://challenges.cloudflare.com; script-src-attr 'none'` (2.5.3, TW-02)**. `img-src`/`frame-src` còn Report-Only (phụ thuộc allowlist nhúng do SA sửa lúc chạy — dùng `npm run csp:sources`) |
| G2 | 🟡 MEDIUM | `quill@1.3.7` | 🟢 Đã giảm | 2.0.11 | `convert()` làm sạch HTML trước khi vào DOM; Quill 2 là việc trung hạn |
| G3 | 🔵 LOW | CVE `react-router`/Firebase SDK | ⏳ Hoãn có chủ đích | — | Mã bị cảnh báo **không có trong bundle** (0 kết quả); nâng cùng đợt hồi quy trình duyệt (mục 3) |
| G4 | ⚪ INFO | Bundle chưa tách | ✅ Đã làm | 2.0.11 | 1.459 → 1.018 KB |
| G5 | ⚪ INFO | Giới hạn nội dung phía client | ✅ Đã làm | 2.0.11 | |
| N1, N3, N4, N6, N7 | ✅ | Đã kiểm chứng an toàn | — | — | N3 có ghi chú độ bền → xem N3 bên dưới |
| N2 | ✅ | CORS + cookie an toàn | — | 2.0.12 | Gỡ `cookie-parser` (không dùng, giảm bề mặt) |
| N3 | ✅ | Giao dịch đăng ký (ghi chú độ bền) | ✅ Đã xử lý | 2.0.12 | Dấu `registrationMarkers` + tự dọn Auth mồ côi + script `auth:cleanup-orphans` — **không bao giờ** xoá tài khoản Auth không có dấu |
| N5 | ⚪ INFO | Không có endpoint xoá tài khoản | ✅ Đã làm | 2.2.0 | `POST /api/users/me/deletion` (nhập lại mật khẩu), xoá bền vững + hàng chờ; bình luận/like trên bài người khác được giữ lại có chủ đích (PATCH-12 mục 4) |
| A-01 | 🔴 HIGH | Một request không cần đăng nhập làm **sập tiến trình** (`GET /api/users/a%2Fb`) | ✅ Đã vá | 2.2.1 | Kiểm id ở route + try/catch + chuyển lỗi async vào error handler + `unhandledRejection` không thoát ngay |
| A-02 | 🟡 MEDIUM | Race xoá tài khoản dựng lại tên thật / hồ sơ ma / bài mồ côi (T-220-01 mở rộng); xoá bình luận của người đã xoá dựng lại hồ sơ ma | ✅ Đã vá | 2.2.1 | Transaction kiểm `active`; bước `verify` sau xoá; `npm run ghosts:purge` |
| A-03 | 🔵 LOW | Quên mật khẩu lộ sự tồn tại email (thời gian + mã lỗi) | ✅ Đã vá | 2.2.1 | Trả lời ngay, gửi ở nền. **Còn nên bật Email enumeration protection** trong Firebase |
| A-04 / R-03 / R-04 | 🔵 LOW | Không có Tag Name dành riêng (rồi lookalike/ghép từ lọt; rồi chữ lặp ở ranh giới hai từ — `support_team`, `admin_news`); tài khoản `pending` không hết hạn; khe hở nhỏ khi xoá hàng loạt | ✅ Đã vá | 2.2.1 → 2.2.2 → 2.3.0 | Tag dành riêng + gập leetspeak/`l`≈`i` + chặn ghép từ; `tags:reserved` (chỉ đọc) liệt kê tag đã bị giữ từ trước; `pending:cleanup` (chạy tay) kiểm lại ngay trước khi xoá |
| A-05 / R-02 | 🔵 LOW | Đầu độc bảng báo cáo CSP (rồi lấp đầy khoản dự trữ `script-src`) | 🟢 Đã giảm | 2.2.1 → 2.2.2 | Không loại khoá cũ khi đầy; bộ đếm tràn; mỗi nguồn gửi ≤10 khoá mới/cửa sổ + `reporters`. Kẻ tấn công phân tán vẫn lấp được (tốn ≥5 nguồn cho khoản dự trữ), nhưng bị báo qua `overflow`. Cần `SSR_PROXY_SECRET` để IP thật đúng |
| A-06 / R-01 | 🔵 LOW | Bộ lọc `style` cho chữ ẩn / phá bố cục (rồi hex-alpha `#fff0` lọt; rồi ngưỡng alpha 0.1 và màu hệ thống `canvas`/`field`… lọt) | 🟢 Đã giảm | 2.2.1 → 2.2.2 → 2.3.0 | Giới hạn số; `color`: ngưỡng alpha 0.5, danh sách trắng 148 tên màu CSS (màu hệ thống, `color-mix()`, `var()`… bị loại); chữ trùng màu nền (vd. `#fff` trên nền trắng) không thể phát hiện bằng allowlist |
| DBG | ⚪ INFO | Không có cách kiểm lại lỗi cũ có tái xuất không | ✅ Đã làm | 2.3.0 | Cài đặt → Quản trị → **Gỡ lỗi**: mỗi lỗi từng gặp là một module chạy lại được (9 module). Xem `backend/src/debug/README.md` |
| P-240 | ⚪ INFO | Bề mặt mới của trang Profile (ảnh bìa tải lên/URL, ghim bài, danh sách bài theo người dùng, huy hiệu) | ✅ Đã rà + có test | 2.4.0 | Chủ sở hữu kiểm ở backend; URL ảnh bìa đi qua cùng danh sách domain với ảnh bìa bài; magic-bytes + 3 MB cho upload; giới hạn tốc độ riêng; id lạ → 404 (không tái xuất A-01). Chi tiết: `PATCH-16-NOTES.md` mục 6 |
| P-241 | ⚪ INFO | Khung hiển thị ảnh bìa (`coverCrop`, `PUT /users/me/cover/crop`): giá trị do người dùng gửi và đi vào CSS ở frontend | ✅ Đã rà + có test | 2.4.1 | Backend chỉ nhận 4 số hữu hạn trong biên (width/height ≥ 10%, x+width ≤ 100%), làm tròn, bỏ khoá thừa, chuỗi/NaN/Infinity bị 400; frontend kiểm lại lần nữa trước khi dựng CSS (khung lạ → canh giữa). Chỉ chủ tài khoản đổi được khung của mình |
| A-07/A-08 | ⚪ INFO | Cấu hình vận hành, nhãn phiên bản lệch, lockfile | 🟢 Một phần | 2.2.1 | `.env.example`, `/api/version` theo `BACKEND_VERSION`. Lockfile/NODE_ENV/IPv6: cần bạn kiểm trên repo/Render thật |

## 1b. Báo cáo bảo mật tổng hợp cuối v2.5.2 → v2.5.3 (TW-01 … TW-27)
Chi tiết, lý do thiết kế và điều bạn cần quyết: `PATCH-24-NOTES.md`. ✅ = đã vá trong mã; 🔧 = cần thao tác vận hành của bạn; ⏸ = quyết định của bạn.
| # | Mức | Trạng thái | Ghi chú |
|---|---|---|---|
| TW-01 | 🟠 HIGH | ✅ + 🔧 đo 1 lần | `clientIp.js` — `getClientKey` duy nhất; `CF-Connecting-IP` chỉ khi hop kế cuối thuộc dải Cloudflare; **mặc định `TRUST_PROXY_HOPS=1` (như 2.5.2) cho tới khi bạn đo bằng panel Nhận diện IP (Cài đặt › Quản trị) hoặc `DEBUG_IP_TOPOLOGY=on`**; IPv6 /64; **2.5.3.2**: panel + `GET /api/admin/ip-topology` + chế độ tuỳ chọn `TRUST_PROXY_MODE=cloudflare` (`PATCH-26-NOTES.md`). Báo cáo phụ lục V-01/V-02 chưa kết luận được — cần đo |
| TW-02 | 🟡 MEDIUM | 🟢 Một phần | `script-src` + `script-src-attr 'none'` đã **chặn thật**; `img-src`/`frame-src` còn Report-Only. **Chưa kiểm được trên Vercel thật** |
| TW-03 | 🟡 MEDIUM | ✅ | Điểm xem 1 lần/cặp **mặc định bật**; trần share 25/ngày |
| TW-04 | 🟡 MEDIUM* | 🟢 Có sẵn, **tắt** | App Check tuỳ chọn — bật theo thứ tự CSP → biến → Monitor → Enforce |
| TW-05 | 🟡 MEDIUM (vận hành) | 🔧 | `npm run sessions:revoke[:apply]`; đổi mật khẩu + xoay khoá là việc của bạn |
| TW-06 | 🔵 LOW | ✅ + 🔧 | Allowlist `class`; tắt `data-*`/`aria-*`; **chạy `content:resanitize` (dry-run → sao lưu → `:apply`)** cho bài cũ |
| TW-07 / TW-13 | 🔵 LOW | ✅ | `config/*` và `positiveScoreLogs` khoá hẳn (deploy rules **sau cùng**) |
| TW-08 | 🔵 LOW | ✅ | Sweeper `pending` tự động, 7 ngày, trần 500/lượt (`PENDING_SWEEPER=off` để tắt) |
| TW-09 | 🔵 LOW | ✅ | `requireRecentAuth` cho 3 route ghi của SA + nhật ký `configAudit` + `GET /api/admin/config-audit` |
| TW-10 | 🔵 LOW | ✅ | Turnstile: timeout + kiểm hostname (production) |
| TW-11 | 🔵 LOW | ✅ | `debugLog` chỉ DEV + che bí mật; getter `AuthContext` chỉ DEV, bản chiếu |
| TW-12 | 🔵 LOW | ⏸ | Công tắc "không để lại dấu khi ghé thăm" — quyết định sản phẩm/pháp lý |
| TW-14 / TW-25 | 🔵 LOW / ⚪ | ✅ | Hết `.doc(null)` → 500; `updateMe` một lần ghi; `syncActivation` transaction |
| TW-15 | 🔵 LOW | ⏸ | Express 4 → 5 là đợt riêng (lưới A-01 còn nguyên) |
| TW-16 | 🔵 LOW | ⏸ | Đăng ký còn báo "email đã tồn tại" — chính sách của bạn |
| TW-17 / TW-18 | ⚪ INFO | ✅ | Xoá mã chết `requireOwnerCapable`, `RouteGuards.jsx` |
| TW-19 | ⚪ INFO | ✅ | `style` khi dán qua `sanitizeStyleForPaste` |
| TW-20 | ⚪ INFO | ✅ | SSR sanitize lớp 2 khi có dấu hiệu nguy hiểm (`ssrTripwireHit`: thô + giải mã thực thể + bỏ TAB/LF), lỗi ⇒ rỗng |
| TW-21 | ⚪ INFO | 🔧 | Đặt `DEBUG_PANEL_ENABLED=off` khi không dùng module Gỡ lỗi |
| TW-22 | ⚪ INFO | 🟢 Một phần | Bỏ `credentials:true` + `urlencoded`; `GET /` vẫn liệt kê admin — ⏸ quyết định của bạn |
| TW-23 | ⚪ INFO | ✅ | Tài liệu/phiên bản đồng bộ; test "lưới an toàn" giữ chúng khớp |
| TW-24 | ⚪ INFO | 🟢 Một phần | `body-parser`, `multer`, `follow-redirects` đã vá. Còn: backend 10 moderate (chuỗi `firebase-admin`→14), frontend 6 high + 11 moderate (chuỗi `firebase`, `vite` ≤ 6.4.3 — **chỉ dev server**) — cần nâng bản lớn, xem `PATCH-24-NOTES.md` §6 |
| TW-26 / TW-27 | ⚪ INFO | ⏸ / ✅ | TW-26 ghi nhận (theo dõi khi lớn); TW-27 `[SHARE DEBUG]` tắt mặc định, giới hạn tần suất |

## 1c. Báo cáo phụ lục re-audit 2.5.3 (V-01 … V-21) — tình trạng sau 2.5.3.2
Chi tiết đối chiếu mã: `PATCH-26-NOTES.md` §1 và §6. Các mục đã vá hiệu lực (V-04/05/06/09/12/13/15/17/18/19/20), cải thiện (V-16), chờ quyết định (V-07/11/14) giữ nguyên như báo cáo; các mục thay đổi:
| # | Báo cáo nói | Tình trạng theo mã + 2.5.3.2 |
|---|---|---|
| V-01 | §9: false positive | **Chưa kết luận.** Hai bằng chứng độc lập (header `x-ratelimit-*` nhảy dù chỉ `globalLimiter` ghi; `viewCount` tăng nhiều dù dedupe ở Firestore) chỉ về khoá IP không ổn định. Đo bằng panel **Nhận diện IP**, sửa bằng biến env được gợi ý |
| V-02 | Tăng nhẹ do multi-instance | Cùng nguyên nhân V-01 (khoá chống trùng nằm ở Firestore, không phải RAM) — tự hết khi khoá đúng |
| V-03 / V-08 | Report-Only | Giữ Report-Only; 2.5.3.2 thêm ImageKit vào `img-src` Report-Only. Enforce sau ≥ 7 ngày quan sát, nguồn lấy bằng `npm run csp:sources` |
| (App Check) | §8: tắt do CSP chặn reCAPTCHA | Đúng (fail-open nhờ hotfix). Quyết định bật/gỡ là của bạn — `PATCH-26-NOTES.md` §5 |

## 2. Việc vận hành cần làm (gộp từ tất cả bản vá)
**Biến môi trường**
| Biến | Nơi | Bắt buộc? | Tác dụng |
|---|---|---|---|
| `SSR_PROXY_SECRET` | Render **và** Vercel (cùng giá trị) | Khuyến nghị mạnh | Xác thực middleware Vercel → backend; thiếu thì SSR không cộng view (an toàn nhưng mất số liệu bot) |
| `SITEMAP_REFRESH_TOKEN` | Render | Tuỳ chọn | Cho phép `?refresh=1` kèm header `x-sitemap-token`; để trống = tắt |
| `VIEW_SCORE_ONCE_PER_PAIR` | Render | Tuỳ chọn (**F3/TW-03**) | **Từ 2.5.3 mặc định BẬT** (điểm xem 1 lần/(người xem, bài)); `off` = hành vi cũ |
| `NODE_ENV` | Render | **Bắt buộc `production`** | `development` tắt mọi kiểm tra fail-fast (CORS/CAPTCHA/SHARE_LINK_SECRET/SSR_PROXY_SECRET) |
| `FIREBASE_WEB_API_KEY` | Render | Bắt buộc cho Quên mật khẩu | Thiếu ⇒ `forgot-password` trả 503 |
| `RESERVED_TAG_NAMES_EXTRA`, `ACCOUNT_DELETION_VERIFY_DELAY_MS` | Render | Tuỳ chọn (2.2.1) | Thêm tên tag dành riêng; độ trễ bước `verify` sau khi xoá tài khoản (mặc định 120000) |
| `DEBUG_PANEL_ENABLED` | Render | Tuỳ chọn (2.3.0) | `off` = tắt việc CHẠY module Gỡ lỗi (danh sách vẫn xem được). Mặc định bật; chỉ SA + nhập lại mật khẩu |
| `TRUST_PROXY_HOPS`, `CLIENT_IP_MODE`, `DEBUG_IP_TOPOLOGY`, `CLOUDFLARE_EXTRA_RANGES` | Render | Tuỳ chọn (2.5.3, **TW-01**) | Số hop proxy (mặc định 1) — **đo trước khi đổi**; chế độ nhận diện IP; bật tạm để đo; dải Cloudflare bổ sung |
| `TRUST_PROXY_MODE`, `TRUST_PROXY_EXTRA` | Render | Tuỳ chọn (2.5.3.2, **TW-01**) | `TRUST_PROXY_MODE=cloudflare` = Express tin dải Cloudflare + nội bộ thay vì "N hop" (không phụ thuộc số hop); mặc định `hops` (như 2.5.3). `TRUST_PROXY_EXTRA` = thêm dải proxy tin cậy (IP/CIDR, phân cách bằng dấu phẩy). **Chỉ đặt sau khi panel Nhận diện IP báo cấu hình này cho đúng IP**; đổi biến phải khởi động lại |
| `SHARE_REWARD_DAILY_CAP`, `SHARE_DEBUG` | Render | Tuỳ chọn (2.5.3, TW-03/27) | Trần thưởng share/ngày/người (mặc định 25; `0`/`off` = không giới hạn); bật log `[SHARE DEBUG]` |
| `TURNSTILE_TIMEOUT_MS`, `TURNSTILE_ALLOWED_HOSTNAMES`, `TURNSTILE_HOSTNAME_CHECK` | Render | Tuỳ chọn (2.5.3, TW-10) | Timeout siteverify; hostname hợp lệ (mặc định suy từ `CORS_ORIGIN`+`FRONTEND_URL` ở production); `off` = công tắc khẩn |
| `PENDING_SWEEPER`, `PENDING_MAX_AGE_DAYS`, `PENDING_SWEEP_INTERVAL_MIN`, `PENDING_SWEEP_MAX_PER_RUN` | Render | Tuỳ chọn (2.5.3, TW-08) | Sweeper `pending` (mặc định BẬT, 7 ngày, 360 phút, 500/lượt) |
| `VITE_FIREBASE_APPCHECK_SITE_KEY` (+ `_PROVIDER`, `_DEBUG_TOKEN`) | Vercel | Tuỳ chọn (2.5.3, TW-04) | App Check — **chỉ đặt sau khi mở CSP cho reCAPTCHA** |
| `SANITIZE_WORKER` | Render | Không | `off` chỉ khi môi trường thiếu `worker_threads` |
| `SITE_OG_IMAGE_URL`, `FONTS_DIR` | Render | Không | Ảnh OG mặc định / thư mục font |
| ~~`COOKIE_SECRET`~~ | — | **Bỏ** | Không còn dùng từ 2.0.12 |

**Triển khai:** Node ≥ 20 (`engines`); `firebase deploy --only firestore:indexes` **trước** backend; deploy backend → frontend → `firestore:rules` **cuối cùng**; thay `frontend/public/og-default.png`; chạy `npm run hashtags:backfill:apply`, `npm run orphans:purge` (xem dry-run trước), `node src/seed/resanitizeContent.js` (áp quy tắc `rel` cho bài cũ).

**Triển khai 2.5.3 (thêm vào quy trình trên):** không có index mới; deploy backend → frontend → **`firestore:rules` cuối cùng**; đo IP (`DEBUG_IP_TOPOLOGY`) rồi mới chốt `TRUST_PROXY_HOPS`; kiểm CSP trên bản xem trước Vercel; `npm run content:resanitize` (dry-run) → sao lưu → `:apply`; checklist TW-05 trong `PATCH-24-NOTES.md` mục 1. Sau mỗi lần deploy: **Gỡ lỗi › Chạy tất cả**. Sau deploy 2.5.3, mỗi khách ẩn danh được tính thêm **một** lượt xem (khoá `viewerKey` đổi định dạng).

**Theo dõi sau deploy:** log Render (dòng `sanitize worker lỗi`, `[CSP]`, cảnh báo thiếu index); bộ nhớ Render sau khi nạp worker (+~50–60 MB); header `X-Twelve-Ssr-Trusted: 1` qua Vercel (đã xác nhận); panel **Báo cáo vi phạm CSP**.

## 3. Quyết định / việc còn mở (cần bạn)
1. ~~F3 — bật công tắc?~~ **Đã bật mặc định ở 2.5.3** (TW-03): `viewCount` hiển thị không đổi, chỉ điểm tác giả/người xem bị giới hạn 1 lần mỗi cặp, giống bình luận (v2.0.5) và reaction. Muốn về cũ: `VIEW_SCORE_ONCE_PER_PAIR=off`.
2. **G1/TW-02 — enforce nốt `img-src`/`frame-src`?** `script-src` đã chặn thật từ 2.5.3. Với hai directive còn lại: sau ≥ 7 ngày có lưu lượng thật mà panel CSP không còn vi phạm đáng lo, chạy `npm run csp:sources` để lấy danh sách theo allowlist nhúng hiện tại rồi chuyển hai directive sang header chặn thật trong `vercel.json` (rollback = đổi lại; **mỗi lần SA đổi allowlist nhúng phải cập nhật lại** — đây là lý do chưa tự enforce). Cân nhắc thêm `report-to` (Chromium) bên cạnh `report-uri`.
3. **Nâng dependency (F5 còn lại + G3)** — làm ở một đợt riêng có hồi quy trình duyệt:
   - *Backend:* `firebase-admin` 14 **bỏ** `admin.firestore.*`, `admin.auth()`, `admin.credential`, `admin.apps` (chỉ còn API module, Node ≥ 22). Cần di chuyển `config/firebase.js` + ~15 chỗ `admin.firestore.FieldValue/FieldPath`. Test `firebase-admin-surface.test.js` sẽ **fail rõ ràng** nếu ai nâng lên 14 trước khi di chuyển.
   - *Frontend:* đã thử trong bản sao: `firebase@12` + `react-router-dom@7` → 82/82 test và build vẫn qua nhưng bundle +17% và `npm audit` vẫn còn `@grpc/grpc-js`. Cần kiểm tay trên trình duyệt: đăng nhập/đăng ký, Firestore realtime (like/comment), điều hướng, Turnstile.
4. ~~N5 — xoá tài khoản~~: đã làm ở 2.2.0 (xoá bài/blog/asset/tag/Auth/hồ sơ; giữ lại bình luận/like trên bài người khác). Còn mở: có cần xoá cả bình luận/like của người đã xoá không (phải chỉnh bộ đếm trên bài người khác).
5. **Quill 2** (G2, trung hạn) và **`firebase-admin` 14** là hai việc di chuyển lớn nhất còn lại.
6. **v2.5.2 — quyền riêng tư của người ghé thăm hồ sơ** (cần bạn quyết, chi tiết `PATCH-23-NOTES.md` mục 8): hệ thống ghi lại ai đã xem hồ sơ ai (50 người gần nhất) và người ghé không được báo hay có công tắc từ chối. Đề xuất: công tắc "Không để lại dấu khi ghé thăm" và/hoặc nêu trong Điều khoản. Các điểm bảo mật đã xử lý ở 2.5.2: danh sách khách chỉ đọc qua `GET /users/me/visitors` (uid lấy từ token, **không** có `/:uid/visitors`); collection `profileVisitors` bị rules chặn tường minh và bị xoá cùng tài khoản; ngày sinh/giới tính/trạng thái/UID chỉ lọt vào API khi chủ bật, **không bao giờ lên SSR** (CDN giữ bản chụp tới ~40 phút); công tắc áp dụng ở backend, không chỉ ở giao diện; `bio` là chữ thuần, thoát ở React/EJS/JSON-LD.

7. **v2.5.3 — việc cần bạn quyết** (chi tiết `PATCH-24-NOTES.md` mục 9): TW-12 (công tắc không để lại dấu khi ghé thăm); TW-16 (đăng ký còn báo "email đã tồn tại"); `GET /` còn liệt kê endpoint admin (TW-22); bật App Check (TW-04); các mặc định mới do mình chọn (share 25/ngày, view-once bật, pending tự dọn 7 ngày, kiểm hostname Turnstile); nâng bản lớn (`firebase-admin` 14, `firebase`, `react-router`, `vite`, Quill 2) và Express 5 (TW-15). **Việc vận hành**: TW-05 (đổi mật khẩu/thu hồi phiên/xoay khoá các tài khoản SA thử nghiệm), TW-21 (`DEBUG_PANEL_ENABLED=off` khi không dùng).
8. **v2.5.3.2 — việc cần bạn làm/quyết** (chi tiết `PATCH-26-NOTES.md` §3 và §5): **đo nhận diện IP** (Cài đặt › Quản trị › Nhận diện IP › Đo ngay) rồi chốt biến `TRUST_PROXY_MODE`/`TRUST_PROXY_HOPS` nếu panel báo sai — V-01/V-02 của báo cáo phụ lục chỉ đóng được sau bước này; App Check (gỡ biến site key hoặc bật thật theo `PATCH-25-NOTES.md` §4; provider hiện là `enterprise`); kiểm allowlist domain nhúng có `suno.ai` không (ảnh `cdn2.suno.ai` đang hiện); enforce `img-src`/`frame-src` sau ≥ 7 ngày quan sát.

## 4. Chạy lại toàn bộ kiểm thử bảo mật
```bash
cd backend  && npm test             # 312 test (npm run test:security chỉ chạy nhóm bảo mật)
cd frontend && npx vitest run       # 385 test (cần: npm i --no-save vitest@2 jsdom @testing-library/react @testing-library/dom --legacy-peer-deps — `--no-save`: `npm audit fix` sẽ xoá chúng nếu lỡ lưu vào package.json)
```
Mapping: F1/F2/F4/F6–F9/F11 → `backend/test/security-session1.test.js`; G1 → `security-session2.test.js` + `frontend/tests/middleware.test.js`; N2/N3/F3 → `security-session3.test.js`; F5 → `firebase-admin-surface.test.js`; G2 → `frontend/tests/quillSafeClipboard.test.jsx`; G4/G5 → `frontend/tests/lazyRoutes.test.jsx`, `contentLimits.test.jsx`; A-01…A-06 → `backend/test/security-221.test.js` (A-01 có test chạy `server.js` thật qua `test/helpers/preload-fake.js`); R-01…R-04 → `backend/test/security-222.test.js`; khung Gỡ lỗi + bản vá R-01/R-03 ở 2.3.0 → `backend/test/debug-230.test.js`, `frontend/tests/debugPanel.test.jsx`; TW-01/03/06/10/22/27 → `backend/test/security-253.test.js`; TW-02/06/07/08/13 → `security-253b.test.js`; TW-08/09/11/14/25 → `security-253c.test.js`; TW-04/05/17/18/20/23/24 → `security-253d.test.js` (+ `security-ssr.test.js` cho TW-20); frontend TW-09/11 → `frontend/tests/security253.test.jsx`, TW-19 → `quillSafeClipboard.test.jsx`. **Sau mỗi lần nâng phiên bản: mở Cài đặt → Quản trị → Gỡ lỗi → "Chạy tất cả".**
