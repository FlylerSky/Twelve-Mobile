import { rewrite, next } from "@vercel/functions";

// Middleware "định tuyến SEO": gửi bot / AI agent sang bản HTML SSR của backend
// (backend/src/routes/ssr.routes.js), người dùng thật nhận SPA React.
//
// ==== v2.0.4 ====
//  1. [Bảo mật] Mọi request rewrite sang backend mang 2 header do middleware tự gắn:
//       x-twelve-ssr-secret : bí mật dùng chung (env SSR_PROXY_SECRET, cùng giá trị ở Render)
//       x-twelve-client-ip  : IP thật của client (do Vercel cung cấp, client không giả được)
//     Backend CHỈ cộng view/AI-view và nới hạn mức cho crawler khi secret khớp. Mọi header
//     x-twelve-* do client gửi lên đều bị xoá trước khi chuyển tiếp.
//  2. [Đúng người dùng] Không còn đẩy người dùng thật sang trang tĩnh chỉ vì thiếu
//     `Sec-Fetch-User` (header này không có ở nhiều trình duyệt/ngữ cảnh điều hướng). Tiêu chí
//     "người dùng thật" nay là Sec-Fetch-Mode = navigate; fetch phía server của AI agent / curl
//     không gửi Sec-Fetch-* nên vẫn nhận SSR.
//  3. [Chính xác] Gộp 2 regex bot trùng nhau thành 1 danh sách token; bỏ các token quá rộng
//     ("fetch", "preview", "bot" trần khớp cả máy Cubot…).
//  4. [Không vòng lặp] `?spa=1` (link "Mở bản đầy đủ" trong trang SSR) luôn trả SPA.
//  5. Trang chủ `/` và `/blog` giờ cũng có bản SSR (backend: /__ssr/home, /__ssr/blog).
//  6. Thêm `Vary` vì kết quả phụ thuộc User-Agent / Sec-Fetch-Mode.
export const config = {
  matcher: [
    "/",
    "/blog",
    "/post/:path+",
    "/blog/:path+",
    "/u/:path+",
    "/trending",
    "/robots.txt",
    "/csp-report",
    "/sitemap.xml",
    "/sitemap-:slug.xml",
  ],
};

// URL gốc backend, khai báo trên Vercel (Project Settings > Environment Variables):
// BACKEND_ORIGIN=https://twelveta.onrender.com — KHÔNG trailing slash.
const BACKEND_ORIGIN = (process.env.BACKEND_ORIGIN || "").replace(/\/$/, "");
// Bí mật dùng chung với backend (SSR_PROXY_SECRET). Thiếu => backend coi request là không tin cậy
// (vẫn render SSR bình thường nhưng KHÔNG cộng view và không nới hạn mức crawler).
const SSR_PROXY_SECRET = process.env.SSR_PROXY_SECRET || "";

const VARY = "User-Agent, Sec-Fetch-Mode";

// ---- Nhận diện bot: MỘT danh sách token duy nhất ----------------------------------
// Bot "cứng": chắc chắn không phải trình duyệt người dùng (cũng dùng cho nhánh link share).
const STRONG_BOT_TOKENS = [
  "(?<!cu)bot(?![a-z])", // Googlebot, GPTBot, ClaudeBot, Applebot… (loại Cubot)
  "spider", "crawl", "slurp",
  "yandex", "baiduspider", "sogou", "exabot",
  "facebookexternalhit", "facebot", "meta-externalagent",
  "twitterbot", "slackbot", "discordbot", "telegrambot", "linkedinbot", "whatsapp",
  "embedly", "iframely", "skypeuripreview", "quora link preview",
  "perplexity", "claude-web", "anthropic", "chatgpt", "oai-searchbot", "gptbot",
  "bytespider", "petalbot", "ahrefs", "semrush", "mj12bot", "dotbot", "ccbot", "diffbot",
  "scrapy", "python-requests", "curl\\/", "wget\\/", "node-fetch", "axios\\/",
  "headlesschrome", "phantomjs", "lighthouse", "pagespeed",
  "google-inspectiontool", "google-extended", "googleother", "google-cloudvertexbot",
  "google-agent", "google-notebooklm", "google-gemininotebook", "geminiios", "\\bgemini\\b",
  "duckduckbot", "bingbot", "archive\\.org_bot", "ia_archiver", "wayback",
];
// Token bổ sung (đủ tin cậy để SSR nhưng không đủ để coi là "bot cứng" ở nhánh link share).
const EXTRA_BOT_TOKENS = [
  "pinterest", "outbrain", "vkshare", "redditbot", "w3c_validator", "nuzzel", "flipboard",
  "bitlybot", "mediapartners", "adsbot", "googleproducer", "google-pagerenderer",
  "googleassistant", "googlewv", "compatible;\\s*google",
];

const STRONG_BOT_UA = new RegExp(STRONG_BOT_TOKENS.join("|"), "i");
const BOT_UA = new RegExp([...STRONG_BOT_TOKENS, ...EXTRA_BOT_TOKENS].join("|"), "i");
const BROWSER_LIKE_UA = /Mozilla\/|Chrome\/|CriOS\/|Safari\/|Firefox\/|Edg\/|OPR\/|Android|iPhone|iPad|Mobile/i;

/** Trình duyệt thật đang điều hướng? (fetch phía server của AI agent / curl không gửi Sec-Fetch-Mode) */
function isRealBrowserNavigation(request, userAgent) {
  const mode = request.headers.get("sec-fetch-mode");
  return BROWSER_LIKE_UA.test(userAgent) && (mode === "navigate" || mode === "nested-navigate");
}

/**
 * Quyết định có phục vụ SSR hay không.
 *  1. UA là bot (BOT_UA) => SSR.
 *  2. Không phải trình duyệt thật đang điều hướng => SSR (AI agent giả UA Chrome, curl, preview…).
 *  3. Còn lại => SPA.
 * Link share (?idu= / ?shared=1): ưu tiên SPA cho người dùng để đếm share; bot cứng vẫn SSR.
 */
function shouldServeSsr(request) {
  const userAgent = request.headers.get("user-agent") || "";
  const isStrongBot = STRONG_BOT_UA.test(userAgent);
  const isRealUser = isRealBrowserNavigation(request, userAgent);

  try {
    const url = new URL(request.url);
    const isShareLink =
      url.searchParams.has("idu") ||
      url.searchParams.get("shared") === "1" ||
      url.searchParams.get("shared") === "true";
    if (isShareLink) {
      if (isStrongBot) return true;
      if (isRealUser) return false;
      if (BROWSER_LIKE_UA.test(userAgent)) return false; // app chat/mobile không gửi Sec-Fetch-*: vẫn là người dùng
      return true; // curl / fetch thuần => SSR, không đếm share
    }
  } catch (_) {
    /* ignore */
  }

  if (BOT_UA.test(userAgent)) return true;
  return !isRealUser;
}

/** Header chuyển tiếp sang backend: xoá mọi x-twelve-* của client, rồi gắn secret + IP thật. */
function buildBackendHeaders(request) {
  const headers = new Headers(request.headers);
  for (const name of [...headers.keys()]) {
    if (name.toLowerCase().startsWith("x-twelve-")) headers.delete(name);
  }
  const clientIp =
    request.headers.get("x-real-ip") || (request.headers.get("x-forwarded-for") || "").split(",")[0].trim();
  if (SSR_PROXY_SECRET) headers.set("x-twelve-ssr-secret", SSR_PROXY_SECRET);
  if (clientIp) headers.set("x-twelve-client-ip", clientIp);
  return headers;
}

function toBackend(request, pathAndSearch) {
  return rewrite(new URL(pathAndSearch, BACKEND_ORIGIN), {
    headers: { Vary: VARY },
    request: { headers: buildBackendHeaders(request) },
  });
}

// Đường dẫn SPA ↔ đường dẫn SSR riêng của backend cho các trang danh sách.
const LIST_SSR_PATHS = { "/": "/__ssr/home", "/blog": "/__ssr/blog" };

export default function middleware(request) {
  if (!BACKEND_ORIGIN) {
    // Chưa cấu hình BACKEND_ORIGIN => không rewrite được, trả SPA như cũ.
    return next();
  }

  const url = new URL(request.url);
  const { pathname } = url;

  // v2.0.11 [G1]: báo cáo vi phạm CSP của SPA (policy khai báo `report-uri /csp-report`) -> backend POST /api/csp-report.
  // Dùng đường dẫn cùng origin để vercel.json không phải hardcode host backend.
  if (pathname === "/csp-report") {
    return toBackend(request, "/api/csp-report");
  }

  // robots.txt / sitemap*.xml LUÔN do backend sinh (không phụ thuộc UA).
  if (/^\/(robots\.txt|sitemap(?:-[^/]+)?\.xml)$/.test(pathname)) {
    return toBackend(request, pathname + url.search);
  }

  // "Mở bản đầy đủ" từ trang SSR: luôn SPA (tránh vòng lặp SSR -> SSR).
  if (url.searchParams.get("spa") === "1") {
    return next({ headers: { Vary: VARY } });
  }

  if (shouldServeSsr(request)) {
    const ssrPath = LIST_SSR_PATHS[pathname];
    return toBackend(request, ssrPath ? ssrPath + url.search : pathname + url.search);
  }

  return next({ headers: { Vary: VARY } });
}
