// Chỉ dùng khi chạy test hook: npm i -D vitest jsdom @testing-library/react && npx vitest run
import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
export default defineConfig({ plugins: [react()], test: { environment: "jsdom", include: ["tests/*.test.jsx", "tests/*.test.js"] } });
