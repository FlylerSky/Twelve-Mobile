import { initializeApp } from "firebase/app";
import { initializeAppCheck, ReCaptchaV3Provider, ReCaptchaEnterpriseProvider } from "firebase/app-check";
import { getAuth, initializeAuth, indexedDBLocalPersistence, browserLocalPersistence, browserSessionPersistence } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { waitForRecaptcha, withTokenTimeout } from "./utils/appCheckGuard";

// Cấu hình lấy từ biến môi trường (Vercel: khai báo trong Project Settings > Environment Variables)
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const firebaseApp = initializeApp(firebaseConfig);

/**
 * ==== v2.5.3 [TW-04] — Firebase App Check (TUỲ CHỌN, TẮT mặc định) ====
 * `firestore.rules` cho đọc công khai `posts`/`blogs`/comments qua Client SDK/REST — không đi qua Express nên KHÔNG chịu limiter nào; một vòng lặp `list` + `pageToken` đốt được hạn mức đọc
 * (Spark: truy vấn bị từ chối tới khi reset hạn mức; Blaze: đội chi phí). App Check chứng minh yêu cầu đến từ ứng dụng thật (reCAPTCHA) — kẻ gọi REST trần không có token sẽ bị từ chối khi bạn
 * bật "Enforce" cho Cloud Firestore trong Firebase Console.
 *
 * CHỈ bật khi đặt VITE_FIREBASE_APPCHECK_SITE_KEY (khoá site reCAPTCHA đã đăng ký trong Firebase Console > App Check). Không đặt ⇒ không khởi tạo gì và không tải script nào
 * (phần lõi SDK App Check vẫn nằm trong bundle nhưng không chạy). VITE_FIREBASE_APPCHECK_PROVIDER = "v3" (mặc định) hoặc "enterprise".
 *
 * !! THỨ TỰ BẮT BUỘC (xem PATCH-24-NOTES.md và PATCH-25-NOTES.md) — làm sai là người dùng THẬT không đọc được dữ liệu:
 *   1. Thêm vào CSP của `vercel.json` (đang CHẶT, chỉ cho 'self' + Turnstile): script-src  https://www.google.com/recaptcha/ https://www.gstatic.com/recaptcha/ ;
 *      frame-src https://www.google.com/recaptcha/ https://recaptcha.google.com/recaptcha/ ; connect-src https://firebaseappcheck.googleapis.com (nếu đã có connect-src) — rồi deploy và kiểm tra.
 *   2. Đặt VITE_FIREBASE_APPCHECK_SITE_KEY trên Vercel, deploy lại.
 *   3. Firebase Console > App Check > Cloud Firestore ở chế độ "Monitor" vài ngày; chỉ sang "Enforce" khi tỉ lệ yêu cầu có token ≈ 100%.
 * Bản dev có thể đặt VITE_FIREBASE_APPCHECK_DEBUG_TOKEN (chỉ đọc khi import.meta.env.DEV) để dùng token gỡ lỗi đã đăng ký trong Console.
 *
 * ==== v2.5.3.121126 — App Check KHÔNG được phép làm treo ứng dụng (xem utils/appCheckGuard.js để biết nguyên nhân) ====
 * Ở 2.5.3, làm sai bước 1 (hoặc reCAPTCHA bị chặn/lỗi mạng) khiến đăng nhập/đăng ký/đọc Firestore treo vô hạn vì SDK chờ token reCAPTCHA mãi mãi. Nay:
 *   - App Check chỉ được khởi tạo SAU KHI reCAPTCHA đã tải xong và sẵn sàng (có `onerror` + timeout 8 giây); không được ⇒ bỏ qua App Check ở phiên này và ghi cảnh báo,
 *     ứng dụng chạy như khi chưa bật (ở chế độ Monitor yêu cầu vẫn đi, chỉ không kèm token hợp lệ; ở "Enforce" Firestore sẽ từ chối NHANH thay vì treo).
 *   - `getToken()` của provider được bọc timeout 5 giây (sau lần quá hạn đầu tiên, bỏ qua App Check 60 giây) nên không còn đường nào treo vô hạn.
 */
const appCheckSiteKey = import.meta.env.VITE_FIREBASE_APPCHECK_SITE_KEY;
if (appCheckSiteKey) {
  let usingDebugToken = false;
  if (import.meta.env.DEV && import.meta.env.VITE_FIREBASE_APPCHECK_DEBUG_TOKEN) {
    // eslint-disable-next-line no-undef
    self.FIREBASE_APPCHECK_DEBUG_TOKEN = import.meta.env.VITE_FIREBASE_APPCHECK_DEBUG_TOKEN;
    usingDebugToken = true; // token gỡ lỗi không đi qua reCAPTCHA nên không cần chờ nó
  }
  const enterprise = import.meta.env.VITE_FIREBASE_APPCHECK_PROVIDER === "enterprise";
  (usingDebugToken ? Promise.resolve() : waitForRecaptcha({ enterprise })).then(
    () => {
      try {
        initializeAppCheck(firebaseApp, {
          provider: withTokenTimeout(enterprise ? new ReCaptchaEnterpriseProvider(appCheckSiteKey) : new ReCaptchaV3Provider(appCheckSiteKey)),
          isTokenAutoRefreshEnabled: true,
        });
      } catch (err) {
        // Không để lỗi App Check làm hỏng cả ứng dụng (vd. khoá site sai): ở chế độ Monitor yêu cầu vẫn đi, chỉ không kèm token.
        console.warn("App Check không khởi tạo được:", err && err.message);
      }
    },
    (err) => {
      console.warn("App Check bị bỏ qua (ứng dụng vẫn chạy bình thường):", err && err.message);
    }
  );
}

/**
 * ==== v2.5.3.121126 — Auth không nạp bộ xử lý popup/redirect ====
 * `getAuth()` luôn gắn `browserPopupRedirectResolver`; trên điện thoại/Safari/iOS Firebase khởi tạo nó NGAY khi mở trang và nạp `https://apis.google.com/js/api.js` + iframe
 * `/__/auth/iframe`. Từ 2.5.3 CSP chặn `script-src` thật nên script đó bị chặn (báo vi phạm ở mỗi lần mở trang trên điện thoại) — mà Twelve chỉ đăng nhập bằng email/mật khẩu,
 * không dùng popup/redirect (không có signInWithPopup/Redirect, OAuth provider… trong mã). Bỏ resolver ⇒ không nạp script Google nào, không cần mở `apis.google.com` trong CSP.
 * Thứ tự lưu phiên giữ nguyên mặc định của `getAuth()`. `getAuth` làm dự phòng khi module chạy lại (HMR) và Auth đã được khởi tạo.
 */
function createAuth(app) {
  try {
    return initializeAuth(app, { persistence: [indexedDBLocalPersistence, browserLocalPersistence, browserSessionPersistence] });
  } catch (err) {
    return getAuth(app);
  }
}

export const auth = createAuth(firebaseApp);
export const db = getFirestore(firebaseApp);
export default firebaseApp;
