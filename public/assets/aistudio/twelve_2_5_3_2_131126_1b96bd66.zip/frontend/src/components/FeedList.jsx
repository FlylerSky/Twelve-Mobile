import React, { useMemo } from "react";
import { Box, Button, Typography, CircularProgress } from "@mui/material";
import PostCardList from "./PostCardList";

/**
 * ==== v2.0.0 — Phần thân feed (spinner / trống / danh sách / "Tải thêm") ====
 * Dùng chung cho Trang chủ và Blog; nhận `feed` từ usePaginatedFeed.
 */
export default function FeedList({ feed, api, detailPath, collectionName, emptyText }) {
  const source = useMemo(
    () => ({ api, detailPath, collectionName }),
    [api, detailPath, collectionName]
  );

  return (
    <>
      {feed.loading && (
        <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}>
          <CircularProgress />
        </Box>
      )}

      {!feed.loading && feed.items.length === 0 && (
        <Typography variant="body1" color="text.secondary" textAlign="center" sx={{ py: 6 }}>
          {emptyText}
        </Typography>
      )}

      <PostCardList
        posts={feed.loading ? [] : feed.items}
        resolveSource={() => source}
        onCommentCountChange={feed.adjustCommentCount}
      />

      {!feed.loading && feed.items.length > 0 && feed.hasMore && (
        <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
          <Button onClick={feed.loadMore} disabled={feed.loadingMore} variant="outlined">
            {feed.loadingMore ? "Đang tải..." : "Tải thêm bài viết"}
          </Button>
        </Box>
      )}
    </>
  );
}
