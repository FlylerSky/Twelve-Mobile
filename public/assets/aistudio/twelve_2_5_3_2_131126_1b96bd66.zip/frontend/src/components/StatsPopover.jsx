import React from "react";
import { Popover, Box, Typography, Stack } from "@mui/material";
import useSnapshotAnchor from "../hooks/useSnapshotAnchor";

/**
 * ==== v2.0.0 — Khung popover thống kê dùng chung ====
 * ViewStatsPopover / PostScorePopover / AccountScorePopover chỉ còn khai báo
 * nội dung (tiêu đề + các dòng); phần neo vị trí, chặn click nổi bọt, kích
 * thước… nằm ở đây.
 */
export default function StatsPopover({ anchorEl, onClose, title, minWidth = 260, spacing = 1, children }) {
  const position = useSnapshotAnchor(anchorEl);

  return (
    <Popover
      open={!!anchorEl && !!position}
      anchorReference="anchorPosition"
      anchorPosition={position || { top: 0, left: 0 }}
      onClose={onClose}
      anchorOrigin={{ vertical: "top", horizontal: "center" }}
      transformOrigin={{ vertical: "bottom", horizontal: "center" }}
      onClick={(e) => e.stopPropagation()}
      disableRestoreFocus
    >
      <Box sx={{ p: 2, minWidth }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.25 }}>
          {title}
        </Typography>
        <Stack spacing={spacing}>{children}</Stack>
      </Box>
    </Popover>
  );
}

/** 1 dòng "icon + nhãn ........ giá trị" trong StatsPopover. */
export function StatRow({ icon, label, value, labelBold = false, valueBold = false, title }) {
  return (
    <Stack direction="row" justifyContent="space-between" alignItems="center">
      <Stack direction="row" spacing={0.75} alignItems="center">
        {icon}
        <Typography variant="body2" fontWeight={labelBold ? 700 : undefined}>
          {label}
        </Typography>
      </Stack>
      <Typography variant="body2" fontWeight={valueBold ? 700 : undefined} title={title}>
        {value}
      </Typography>
    </Stack>
  );
}
