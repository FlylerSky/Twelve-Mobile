import React, { useState } from "react";
import PostCard from "./PostCard";
import CommentModal from "./CommentModal";

/**
 * ==== v2.0.0 — Danh sách PostCard + hộp bình luận dùng chung ====
 * IndexPage, BlogPage và HashtagPostList trước đây mỗi nơi tự giữ state "bài
 * đang mở bình luận" + CommentModal + cập nhật số bình luận. Giờ gom ở đây.
 *
 * `resolveSource(post)` → `{ api, detailPath, collectionName, key? }` cho TỪNG
 * bài (danh sách trộn post+blog ở Xu hướng chọn lại mỗi bài; Trang chủ/Blog
 * luôn trả cùng 1 nguồn).
 * `onCommentCountChange(postId, delta)`: để cha cập nhật số bình luận trong state danh sách.
 */
export default function PostCardList({ posts, resolveSource, onCommentCountChange }) {
  const [target, setTarget] = useState(null); // { post, source }

  const handleCountChange = (delta) => {
    if (!target) return;
    onCommentCountChange?.(target.post.id, delta);
    setTarget((prev) =>
      prev ? { ...prev, post: { ...prev.post, commentCount: (prev.post.commentCount || 0) + delta } } : prev
    );
  };

  return (
    <>
      {posts.map((post) => {
        const source = resolveSource(post);
        return (
          <PostCard
            key={source.key ?? post.id}
            post={post}
            api={source.api}
            detailPath={source.detailPath}
            onOpenComments={(p) => setTarget({ post: p, source })}
          />
        );
      })}

      <CommentModal
        open={!!target}
        onClose={() => setTarget(null)}
        post={target?.post || null}
        api={target?.source.api}
        collectionName={target?.source.collectionName}
        onCommentCountChange={handleCountChange}
      />
    </>
  );
}
