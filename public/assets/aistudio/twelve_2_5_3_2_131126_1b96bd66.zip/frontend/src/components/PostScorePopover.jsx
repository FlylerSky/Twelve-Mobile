import React from "react";
import { Divider } from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import ThumbDownIcon from "@mui/icons-material/ThumbDown";
import ChatBubbleOutlineIcon from "@mui/icons-material/ChatBubbleOutline";
import ShareIcon from "@mui/icons-material/Share";
import { formatCount, formatScore } from "../utils/number";
import { POST_SCORE_WEIGHTS } from "../utils/postScore";
import StatsPopover, { StatRow } from "./StatsPopover";

/** Popover thống kê điểm bài viết (khung + neo vị trí: StatsPopover). */
export default function PostScorePopover({
  anchorEl,
  onClose,
  viewCount = 0,
  likeCount = 0,
  dislikeCount = 0,
  commentCount = 0,
  shareCount = 0,
  score = 0,
}) {
  const rows = [
    { key: "view", label: "Lượt xem", icon: <VisibilityIcon fontSize="small" color="action" />, count: viewCount, weight: POST_SCORE_WEIGHTS.view },
    { key: "like", label: "Thích", icon: <ThumbUpIcon fontSize="small" color="action" />, count: likeCount, weight: POST_SCORE_WEIGHTS.like },
    { key: "dislike", label: "Không thích", icon: <ThumbDownIcon fontSize="small" color="action" />, count: dislikeCount, weight: POST_SCORE_WEIGHTS.dislike },
    { key: "comment", label: "Bình luận", icon: <ChatBubbleOutlineIcon fontSize="small" color="action" />, count: commentCount, weight: POST_SCORE_WEIGHTS.comment },
    { key: "share", label: "Chia sẻ", icon: <ShareIcon fontSize="small" color="action" />, count: shareCount, weight: POST_SCORE_WEIGHTS.share },
  ];

  return (
    <StatsPopover anchorEl={anchorEl} onClose={onClose} title="Điểm bài viết">
      {rows.map((r) => (
        <StatRow
          key={r.key}
          icon={r.icon}
          label={`${r.label} × ${r.weight > 0 ? `+${r.weight}` : r.weight}`}
          value={formatCount(r.count)}
          title={String(r.count)}
        />
      ))}
      <Divider />
      <StatRow label="Tổng điểm" labelBold value={formatScore(score)} valueBold title={String(score)} />
    </StatsPopover>
  );
}
