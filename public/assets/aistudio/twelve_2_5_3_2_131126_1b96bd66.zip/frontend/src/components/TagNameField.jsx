import React from "react";
import { TextField, InputAdornment, CircularProgress } from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";

/**
 * ==== v2.2.0 — Ô nhập Tag Name Search dùng chung (Đăng ký + Cài đặt > Tài khoản) ====
 * Chỉ vẽ ô nhập + biểu tượng/ghi chú theo `status` (xem hooks/useTagNameAvailability). Muốn đổi cách hiển thị: sửa một nơi này.
 */
const HELPER = {
  invalid: "Chỉ dùng chữ, số, gạch dưới, 3-20 ký tự.",
  taken: "Tag Name Search này đã có người dùng.",
  available: "Tag Name Search khả dụng.",
  same: "Đây là Tag Name Search hiện tại của bạn.",
};
const DEFAULT_HELPER = "Dạng @username, dùng để tìm kiếm và định danh bạn trên Twelve.";

export default function TagNameField({ value, onChange, status, label = "Tag Name Search", ...rest }) {
  let adornment = null;
  if (status === "checking") adornment = <CircularProgress size={18} />;
  else if (status === "available") adornment = <CheckCircleIcon color="success" fontSize="small" />;
  else if (status === "taken" || status === "invalid") adornment = <CancelIcon color="error" fontSize="small" />;

  return (
    <TextField
      label={label}
      placeholder="@username"
      value={value}
      onChange={onChange}
      fullWidth
      helperText={HELPER[status] || DEFAULT_HELPER}
      error={status === "taken" || status === "invalid"}
      InputProps={{
        startAdornment: <InputAdornment position="start">@</InputAdornment>,
        endAdornment: <InputAdornment position="end">{adornment}</InputAdornment>,
      }}
      {...rest}
    />
  );
}
