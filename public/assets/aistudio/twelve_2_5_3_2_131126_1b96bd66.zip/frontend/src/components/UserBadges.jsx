import React, { useState } from "react";
import { Box, Popover, Stack, Typography, Tooltip } from "@mui/material";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { badgeSizeForVariant, getBadgeInfo, resolveBadgeIds } from "../utils/badges";

/**
 * ==== v2.4.0 — Huy hiệu cạnh tên người dùng ====
 * Chỉ vẽ ICON (không chữ) để không tốn chỗ:
 *  • 0 huy hiệu → không vẽ gì;
 *  • 1 huy hiệu → icon của huy hiệu đó;
 *  • từ 2 huy hiệu → GỘP thành MỘT huy hiệu "3 chấm" (cho biết người này có nhiều huy hiệu).
 * Bấm vào (huy hiệu hay 3 chấm) mở danh sách: icon + tên + mô tả từng huy hiệu. Bấm KHÔNG kích hoạt phần tử cha (thẻ bài, hàng xếp hạng…).
 *
 * Dùng `<UserBadges user={...} variant="subtitle2" />` (hoặc `ids={[...]}`). `variant` = kiểu chữ của TÊN đứng cạnh → cỡ icon theo cỡ chữ
 * (bảng duy nhất ở utils/badges.js) nên mọi nơi nhìn đồng nhất. Được gắn sẵn vào <UserName> nên mọi nơi hiện tên người dùng đều có huy hiệu;
 * chỉ gọi trực tiếp khi tên không đi qua UserName (Menu, đầu trang hồ sơ, bảng xếp hạng). Có test quét mã nguồn để không ai quên (badgeCoverage).
 */
function BadgeIcon({ info, size }) {
  const Icon = info.icon;
  return <Icon sx={{ fontSize: size, color: info.color === "default" ? "text.secondary" : `${info.color}.main` }} />;
}

export default function UserBadges({ user, ids, variant, size: sizeProp, sx }) {
  const size = sizeProp || badgeSizeForVariant(variant);
  const [anchor, setAnchor] = useState(null);
  const list = (ids || resolveBadgeIds(user)).map(getBadgeInfo);
  if (list.length === 0) return null;

  const multiple = list.length > 1;
  const triggerLabel = multiple ? `${list.length} huy hiệu` : list[0].label;

  return (
    <>
      <Tooltip title={triggerLabel} arrow enterTouchDelay={700}>
        <Box
          component="button"
          type="button"
          data-testid="user-badges"
          aria-label={multiple ? `Xem ${list.length} huy hiệu` : `Huy hiệu: ${list[0].label}`}
          aria-haspopup="dialog"
          onClick={(e) => {
            e.stopPropagation();
            setAnchor(e.currentTarget);
          }}
          sx={{
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
            p: 0,
            m: 0,
            border: 0,
            bgcolor: "transparent",
            cursor: "pointer",
            borderRadius: "50%",
            width: size + 4,
            height: size + 4,
            color: "text.secondary",
            "&:hover": { bgcolor: "action.hover" },
            "&:focus-visible": { outline: "2px solid", outlineColor: "primary.main" },
            ...sx,
          }}
        >
          {multiple ? <MoreHorizIcon sx={{ fontSize: size }} data-testid="badge-multi" /> : <BadgeIcon info={list[0]} size={size} />}
        </Box>
      </Tooltip>

      <Popover
        open={!!anchor}
        anchorEl={anchor}
        onClose={() => setAnchor(null)}
        onClick={(e) => e.stopPropagation()}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
      >
        <Stack spacing={1.25} sx={{ p: 1.75, maxWidth: 300 }}>
          <Typography variant="subtitle2" fontWeight={700}>
            Huy hiệu
          </Typography>
          {list.map((info) => (
            <Stack key={info.id} direction="row" spacing={1.25} alignItems="flex-start" data-testid={`badge-row-${info.id}`}>
              <Box sx={{ mt: 0.25 }}>
                <BadgeIcon info={info} size={22} />
              </Box>
              <Box sx={{ minWidth: 0 }}>
                <Typography variant="body2" fontWeight={600}>
                  {info.label}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {info.description}
                </Typography>
              </Box>
            </Stack>
          ))}
        </Stack>
      </Popover>
    </>
  );
}
