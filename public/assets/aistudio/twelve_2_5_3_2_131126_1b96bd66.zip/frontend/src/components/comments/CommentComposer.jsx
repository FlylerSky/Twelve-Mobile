import React, { useState } from "react";
import { Box, TextField, IconButton, Button, Typography, useMediaQuery, useTheme } from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import useAuthGate from "../../hooks/useAuthGate";
import { useAuth } from "../../context/AuthContext";

/**
 * Kích thước ô soạn bình luận — MỘT nơi duy nhất cho cả trang bài viết lẫn
 * hộp bình luận (trước v2.0.0 hai nơi tự đặt và đã lệch nhau: 2/8 và 1/6).
 * `minRows=1` + dải đệm dành cho nút gửi → ô trống cao ~2 dòng.
 */
export const COMMENT_COMPOSER_ROWS = Object.freeze({ min: 1, max: 6 });

/**
 * ==== v2.0.0 — Ô soạn bình luận dùng chung ====
 * Ô full width; nút gửi nằm TRONG ô, góc dưới phải (chữ không đè lên nút).
 * Chưa đăng nhập → hiện thông báo từ resolveAuthActionGate (+ "Thử lại" nếu cần).
 *
 * props:
 *  - onSubmit(content) => Promise<boolean>: true nếu thành công (composer tự xoá nháp)
 *  - sending: đang gửi
 *  - gateAlign: "left" | "center" (căn thông báo khi chưa đăng nhập)
 */
export default function CommentComposer({ onSubmit, sending = false, gateAlign = "left" }) {
  const { isLoggedIn, refreshProfile } = useAuth();
  const { gate } = useAuthGate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [draft, setDraft] = useState("");

  if (!isLoggedIn) {
    return (
      <Box sx={{ textAlign: gateAlign }}>
        <Typography variant="body2" color="text.secondary">
          {gate.message}
          {gate.shouldRefresh && (
            <>
              {" "}
              <Button size="small" onClick={() => refreshProfile?.()}>
                Thử lại
              </Button>
            </>
          )}
        </Typography>
      </Box>
    );
  }

  const submit = async () => {
    if (sending || !draft.trim()) return;
    const ok = await onSubmit(draft);
    if (ok) setDraft("");
  };

  return (
    <Box sx={{ position: "relative" }}>
      <TextField
        fullWidth
        size="small"
        placeholder={isMobile ? "Viết bình luận..." : "Viết bình luận... (Shift+Enter xuống dòng, Enter gửi)"}
        value={draft}
        multiline
        minRows={COMMENT_COMPOSER_ROWS.min}
        maxRows={COMMENT_COMPOSER_ROWS.max}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => {
          if (!isMobile && e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            submit();
          }
        }}
        sx={{
          "& .MuiOutlinedInput-root": {
            borderRadius: 1,
            bgcolor: "action.hover",
            // Chừa góc dưới phải cho nút gửi — chữ không đè icon
            pb: 4.5,
            pr: 1,
            alignItems: "flex-start",
          },
          "& .MuiOutlinedInput-input": { pr: 5 },
        }}
      />
      <IconButton
        color="primary"
        onClick={submit}
        disabled={sending || !draft.trim()}
        aria-label="Gửi bình luận"
        sx={{ position: "absolute", right: 6, bottom: 6, zIndex: 1 }}
      >
        <SendIcon />
      </IconButton>
    </Box>
  );
}
