import React from "react";
import { Paper, Box, Stack, Typography, TextField, Button, IconButton } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { formatRelativeTime } from "../../utils/time";
import CommentText from "../CommentText";
import { UserAvatar, UserName, UserTagChip } from "../UserIdentity";

/**
 * ==== v2.0.0 — 1 thẻ bình luận (dùng chung trang bài viết + hộp bình luận) ====
 * Trước đây markup này bị chép nguyên ở PostDetailPage và CommentModal.
 */
export default function CommentItem({
  comment: c,
  mine,
  editing,
  editValue,
  onEditChange,
  onEditSave,
  onEditCancel,
  onMenuOpen,
  onProfileClick,
}) {
  return (
    <Paper
      variant="outlined"
      sx={{
        borderRadius: 1,
        p: { xs: 1.25, sm: 1.5 },
        display: "flex",
        gap: 1.25,
        alignItems: "flex-start",
        bgcolor: "background.paper",
      }}
    >
      <UserAvatar user={c.author} size={36} onProfileClick={onProfileClick} />
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap" useFlexGap>
          <UserName user={c.author} onProfileClick={onProfileClick} />
          <UserTagChip user={c.author} height={22} onProfileClick={onProfileClick} />
          <Typography variant="caption" color="text.secondary">
            {formatRelativeTime(c.createdAt)}
            {c.isEdited ? " (đã sửa)" : ""}
          </Typography>
        </Stack>

        {editing ? (
          <Box sx={{ mt: 0.75 }}>
            <TextField
              fullWidth
              multiline
              size="small"
              value={editValue}
              onChange={(e) => onEditChange(e.target.value)}
              sx={{ "& .MuiOutlinedInput-root": { borderRadius: 1 } }}
            />
            <Stack direction="row" spacing={1} sx={{ mt: 0.75 }}>
              <Button size="small" variant="contained" onClick={() => onEditSave(c.id)}>
                Lưu
              </Button>
              <Button size="small" onClick={onEditCancel}>
                Hủy
              </Button>
            </Stack>
          </Box>
        ) : (
          <Box sx={{ mt: 0.5 }}>
            <CommentText content={c.content} />
          </Box>
        )}
      </Box>

      {mine && !editing && (
        <IconButton size="small" onClick={(e) => onMenuOpen(e, c)} sx={{ flexShrink: 0, mt: -0.5 }}>
          <MoreVertIcon fontSize="small" />
        </IconButton>
      )}
    </Paper>
  );
}
