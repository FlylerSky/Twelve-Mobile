import React from "react";
import { Box, Stack, Typography, Button, CircularProgress, Menu, MenuItem } from "@mui/material";
import CommentItem from "./CommentItem";

/**
 * ==== v2.0.0 — Danh sách bình luận + "Xem thêm" + menu Sửa/Xóa ====
 * Nhận `thread` từ useCommentThread. Dùng chung trang bài viết và hộp bình luận.
 *  - `emptyText`: hiện khi chưa có bình luận (bỏ trống → không hiện gì).
 *  - Sentinel của IntersectionObserver nằm cuối danh sách: tự tải thêm khi cuộn
 *    chạm tới (root mặc định = viewport; trong modal thì container cuộn riêng
 *    được hook gắn qua `containerRef`).
 */
export default function CommentThread({ thread, onProfileClick, emptyText = null, spinnerPy = 3 }) {
  const {
    comments,
    loading,
    loadingMore,
    hasMore,
    loadMore,
    sentinelRef,
    editingId,
    editValue,
    setEditValue,
    saveEdit,
    cancelEdit,
    openMenu,
    closeMenu,
    startEdit,
    remove,
    menuAnchor,
    isMine,
  } = thread;

  if (loading && comments.length === 0) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: spinnerPy }}>
        <CircularProgress size={26} />
      </Box>
    );
  }

  if (comments.length === 0) {
    return emptyText ? (
      <Typography variant="body2" color="text.secondary" sx={{ textAlign: "center", py: 3 }}>
        {emptyText}
      </Typography>
    ) : null;
  }

  return (
    <>
      <Stack spacing={1.5}>
        {comments.map((c) => (
          <CommentItem
            key={c.id}
            comment={c}
            mine={isMine(c)}
            editing={editingId === c.id}
            editValue={editValue}
            onEditChange={setEditValue}
            onEditSave={saveEdit}
            onEditCancel={cancelEdit}
            onMenuOpen={openMenu}
            onProfileClick={onProfileClick}
          />
        ))}
        {hasMore && (
          <Box ref={sentinelRef} sx={{ display: "flex", justifyContent: "center", py: 1.5 }}>
            {loadingMore ? (
              <CircularProgress size={20} />
            ) : (
              <Button size="small" onClick={loadMore}>
                Xem thêm bình luận
              </Button>
            )}
          </Box>
        )}
      </Stack>

      <Menu anchorEl={menuAnchor} open={!!menuAnchor} onClose={closeMenu}>
        <MenuItem onClick={startEdit}>Sửa bình luận</MenuItem>
        <MenuItem onClick={remove} sx={{ color: "error.main" }}>
          Xóa bình luận
        </MenuItem>
      </Menu>
    </>
  );
}
