import React from "react";
import { Avatar } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { formatScore } from "../utils/number";
import RankingBoard from "./RankingBoard";
import UserBadges from "./UserBadges";
import { profilePath } from "../utils/profilePath";

/**
 * Bảng xếp hạng NGƯỜI DÙNG (tab Xu hướng → Người dùng).
 * v2.0.0: layout podium/list nằm ở RankingBoard (dùng chung với hashtag);
 * file này chỉ khai báo cách vẽ 1 người dùng.
 */
export default function RankingList({
  ranking = [],
  scoreField = "accountScore",
  scoreLabel = "Điểm",
  loading = false,
  emptyHint = "Chưa có dữ liệu xếp hạng.",
}) {
  const navigate = useNavigate();

  const getScoreText = (u) => {
    const v = (u && u[scoreField]) || 0;
    return scoreField === "weeklyGrowth" && v > 0 ? `+${formatScore(v)}` : formatScore(v);
  };

  return (
    <RankingBoard
      ranking={ranking}
      loading={loading}
      emptyHint={emptyHint}
      scoreLabel={scoreLabel}
      getKey={(u) => u.uid}
      getName={(u) => u.displayName || "(Ẩn danh)"}
      renderNameExtra={(u) => <UserBadges user={u} variant="body2" />}
      getSubtitle={(u) => (u.tagName ? (u.tagName.startsWith("@") ? u.tagName : `@${u.tagName}`) : null)}
      getScoreText={getScoreText}
      renderAvatar={(u, { size, color }) => (
        <Avatar
          src={u.avatarUrl}
          sx={{ width: size, height: size, ...(color ? { border: `2px solid ${color}` } : {}) }}
        >
          {u.displayName?.[0]}
        </Avatar>
      )}
      onSelect={(u) => profilePath(u) && navigate(profilePath(u))}
    />
  );
}
