import React, { useCallback } from "react";
import { Avatar, Box, Chip, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import UserBadges from "./UserBadges";
import { profilePath } from "../utils/profilePath";

/**
 * ==== v2.0.0 — Nhận diện người dùng dùng chung (avatar / tên / chip tagName) ====
 * Trước đây khối "avatar bấm được + tên + chip tagName + navigate('/u/uid')"
 * bị chép ở PostCard, PostDetailPage (3 chỗ), CommentModal (3 chỗ), đồng thời
 * tên dự phòng "Người dùng Twelve" chỉ có ở 2 nơi. Giờ mọi nơi dùng 3 mảnh này;
 * muốn đổi cách hiển thị tác giả/bình luận (huy hiệu, xác minh…) chỉ sửa ở đây.
 *
 * v2.4.2.1: URL hồ sơ là /u/@<tagName> (xem utils/profilePath.js) — không còn /u/<UID>. Vì thế hàm đi tới hồ sơ nhận CẢ ĐỐI TƯỢNG người dùng
 * (cần `tagName`), không còn chỉ nhận uid.
 *
 * `onProfileClick(user)` (tuỳ chọn): ghi đè hành vi mặc định (điều hướng
 * /u/@<tag>) — vd. hộp bình luận đóng modal trước khi chuyển trang.
 */
export function useGoToProfile(onProfileClick) {
  const navigate = useNavigate();
  return useCallback(
    (user) => {
      if (!user || !profilePath(user)) return;
      if (onProfileClick) onProfileClick(user);
      else navigate(profilePath(user));
    },
    [navigate, onProfileClick]
  );
}

export function UserAvatar({ user, size, onProfileClick, sx }) {
  const go = useGoToProfile(onProfileClick);
  const clickable = !!profilePath(user);
  return (
    <Avatar
      src={user?.avatarUrl}
      onClick={() => go(user)}
      sx={{
        cursor: clickable ? "pointer" : "default",
        ...(size ? { width: size, height: size, flexShrink: 0 } : {}),
        ...sx,
      }}
    >
      {user?.displayName?.[0]}
    </Avatar>
  );
}

/**
 * v2.4.0: tên + HUY HIỆU ngay cạnh tên (xem UserBadges). Vì mọi nơi hiện tên người dùng (thẻ bài, trang bài, bình luận…) đều đi qua đây
 * nên huy hiệu có mặt ở mọi nơi. `showBadges={false}` để tắt ở chỗ đặc biệt (không có chỗ nào dùng hiện nay).
 */
export function UserName({ user, variant = "subtitle2", fallback = "Người dùng Twelve", onProfileClick, showBadges = true, sx }) {
  const go = useGoToProfile(onProfileClick);
  const clickable = !!profilePath(user);
  return (
    <Box component="span" sx={{ display: "inline-flex", alignItems: "center", gap: 0.5, minWidth: 0, maxWidth: "100%" }}>
      <Typography
        component="span"
        variant={variant}
        fontWeight={600}
        onClick={() => go(user)}
        sx={{
          cursor: clickable ? "pointer" : "default",
          "&:hover": clickable ? { color: "primary.main" } : {},
          ...sx,
        }}
      >
        {user?.displayName || fallback}
      </Typography>
      {showBadges && <UserBadges user={user} variant={variant} />}
    </Box>
  );
}

export function UserTagChip({ user, height, onProfileClick, sx }) {
  const go = useGoToProfile(onProfileClick);
  if (!user?.tagName) return null;
  return (
    <Chip
      size="small"
      variant="outlined"
      label={user.tagName}
      onClick={() => go(user)}
      sx={{ cursor: profilePath(user) ? "pointer" : "default", ...(height ? { height } : {}), ...sx }}
    />
  );
}
