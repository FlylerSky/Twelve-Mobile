import React from "react";
import { Divider } from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import SmartToyIcon from "@mui/icons-material/SmartToy";
import PersonIcon from "@mui/icons-material/Person";
import { formatCount } from "../utils/number";
import StatsPopover, { StatRow } from "./StatsPopover";

/** Thống kê lượt xem (khung + neo vị trí: StatsPopover). */
export default function ViewStatsPopover({ anchorEl, onClose, viewCount = 0, aiViewCount = 0 }) {
  const humanViewCount = Math.max(0, (viewCount || 0) - (aiViewCount || 0));

  return (
    <StatsPopover anchorEl={anchorEl} onClose={onClose} title="Thống kê lượt xem" minWidth={240} spacing={1.25}>
      <StatRow
        icon={<VisibilityIcon fontSize="small" color="action" />}
        label="Tổng lượt xem"
        value={formatCount(viewCount)}
        valueBold
        title={String(viewCount)}
      />
      <Divider />
      <StatRow
        icon={<PersonIcon fontSize="small" color="action" />}
        label="Người dùng"
        value={formatCount(humanViewCount)}
        title={String(humanViewCount)}
      />
      <StatRow
        icon={<SmartToyIcon fontSize="small" color="action" />}
        label="View Bot A.I"
        value={formatCount(aiViewCount)}
        title={String(aiViewCount)}
      />
    </StatsPopover>
  );
}
