import React, { useEffect, useState } from "react";
import { Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Button, TextField, Alert, Stack } from "@mui/material";
import { reauthWithPassword } from "../utils/reauth";

/**
 * ==== v2.2.0 — Hộp "nhập lại mật khẩu" dùng chung ====
 * Xem tên thật · đổi tên thật · xoá tài khoản đều đi qua đây. Luồng: nhập mật khẩu → Firebase xác nhận (utils/reauth) → chạy `onConfirm()`
 * (request tới backend, lúc này backend thấy token vừa xác thực) → đóng hộp. Lỗi ở bất kỳ bước nào hiện ngay trong hộp, hộp giữ nguyên để thử lại.
 *
 * props:
 *  - open, title, description
 *  - onConfirm: () => Promise<void>  — chạy SAU khi mật khẩu đúng; ném lỗi (có .message) để hiện trong hộp
 *  - onClose: () => void              — gọi khi huỷ HOẶC sau khi onConfirm thành công
 *  - confirmText / confirmColor / confirmDisabled (vd. chưa tick ô cam kết)
 *  - children: nội dung thêm đặt phía trên ô mật khẩu (vd. ô nhập tên thật mới, ô tick xác nhận)
 */
export default function PasswordConfirmDialog({
  open,
  title = "Xác nhận mật khẩu",
  description,
  confirmText = "Xác nhận",
  confirmColor = "primary",
  confirmDisabled = false,
  onConfirm,
  onClose,
  children,
}) {
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setPassword("");
      setError("");
      setBusy(false);
    }
  }, [open]);

  const submit = async (e) => {
    if (e) e.preventDefault();
    if (busy || confirmDisabled) return;
    setBusy(true);
    setError("");
    try {
      await reauthWithPassword(password);
      await onConfirm();
      if (onClose) onClose();
    } catch (err) {
      setError(err?.message || "Đã có lỗi xảy ra, vui lòng thử lại.");
    } finally {
      setBusy(false);
    }
  };

  const handleClose = () => {
    if (!busy && onClose) onClose();
  };

  return (
    <Dialog open={!!open} onClose={handleClose} maxWidth="xs" fullWidth>
      <form onSubmit={submit}>
        <DialogTitle>{title}</DialogTitle>
        <DialogContent>
          {description && <DialogContentText sx={{ mb: 2 }}>{description}</DialogContentText>}
          <Stack spacing={2}>
            {children}
            <TextField
              label="Mật khẩu hiện tại"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              autoFocus
              fullWidth
              required
            />
            {error && <Alert severity="error">{error}</Alert>}
          </Stack>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={handleClose} disabled={busy}>
            Hủy
          </Button>
          <Button type="submit" variant="contained" color={confirmColor} disabled={busy || confirmDisabled || !password}>
            {busy ? "Đang xử lý..." : confirmText}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
}
