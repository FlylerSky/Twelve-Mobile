import React, { useEffect, useRef, useState } from "react";
import { Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Button, TextField, Alert, Stack } from "@mui/material";
import TurnstileWidget from "./TurnstileWidget";
import { forgotPassword } from "../api/auth.api";

/**
 * ==== v2.2.0 — Quên mật khẩu (dùng chung trang Đăng nhập + Cài đặt > Bảo mật > Đổi mật khẩu) ====
 * Gửi email đặt lại mật khẩu: backend kiểm CAPTCHA + giới hạn tần suất rồi nhờ Firebase gửi email (xem backend auth.controller#forgotPassword).
 * Thông báo thành công luôn giống nhau dù email có tồn tại hay không — vì vậy câu chữ ở đây cũng không khẳng định "đã gửi tới tài khoản của bạn".
 *
 * props: open, onClose, initialEmail (điền sẵn), emailLocked (khoá ô email — dùng khi người dùng đã đăng nhập và đổi mật khẩu cho CHÍNH họ)
 */
export default function ForgotPasswordDialog({ open, onClose, initialEmail = "", emailLocked = false }) {
  // Giống RegisterPage: CAPTCHA chỉ bắt buộc khi có site key (backend cũng chỉ đòi khi có secret).
  const captchaRequired = Boolean(import.meta.env.VITE_TURNSTILE_SITE_KEY);
  const [email, setEmail] = useState(initialEmail);
  const [captchaToken, setCaptchaToken] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [doneMessage, setDoneMessage] = useState("");
  const turnstileRef = useRef(null);

  useEffect(() => {
    if (open) {
      setEmail(initialEmail);
      setCaptchaToken(null);
      setBusy(false);
      setError("");
      setDoneMessage("");
    }
  }, [open, initialEmail]);

  const submit = async (e) => {
    if (e) e.preventDefault();
    if (busy || doneMessage) return;
    setBusy(true);
    setError("");
    try {
      const res = await forgotPassword({ email: email.trim(), captchaToken });
      setDoneMessage(res?.message || "Nếu email này thuộc một tài khoản Twelve, chúng tôi đã gửi hướng dẫn đặt lại mật khẩu.");
    } catch (err) {
      setError(err?.message || "Không gửi được yêu cầu. Vui lòng thử lại.");
      // Token Turnstile chỉ dùng được một lần (xem TurnstileWidget) — lấy token mới cho lần thử sau.
      setCaptchaToken(null);
      turnstileRef.current?.reset();
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={!!open} onClose={busy ? undefined : onClose} maxWidth="xs" fullWidth>
      <form onSubmit={submit}>
        <DialogTitle>Quên mật khẩu</DialogTitle>
        <DialogContent>
          {doneMessage ? (
            <Alert severity="success">{doneMessage}</Alert>
          ) : (
            <>
              <DialogContentText sx={{ mb: 2 }}>
                Nhập email đăng ký. Chúng tôi sẽ gửi một liên kết để bạn đặt mật khẩu mới.
              </DialogContentText>
              <Stack spacing={2}>
                <TextField
                  label="Email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={emailLocked}
                  autoComplete="email"
                  autoFocus={!emailLocked}
                  fullWidth
                  required
                />
                <TurnstileWidget ref={turnstileRef} onToken={setCaptchaToken} />
                {error && <Alert severity="error">{error}</Alert>}
              </Stack>
            </>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={onClose} disabled={busy}>
            Đóng
          </Button>
          {!doneMessage && (
            <Button type="submit" variant="contained" disabled={busy || !email.trim() || (captchaRequired && !captchaToken)}>
              {busy ? "Đang gửi..." : "Gửi email"}
            </Button>
          )}
        </DialogActions>
      </form>
    </Dialog>
  );
}
