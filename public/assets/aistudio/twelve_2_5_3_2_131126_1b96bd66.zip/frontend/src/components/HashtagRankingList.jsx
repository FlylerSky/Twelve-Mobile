import React from "react";
import { Box } from "@mui/material";
import TagIcon from "@mui/icons-material/Tag";
import { formatScore, formatCount } from "../utils/number";
import RankingBoard from "./RankingBoard";

function TagAvatar({ size, color }) {
  return (
    <Box
      sx={{
        width: size,
        height: size,
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        bgcolor: "action.hover",
        border: color ? `2px solid ${color}` : "1px solid",
        borderColor: color || "divider",
        flexShrink: 0,
      }}
    >
      <TagIcon sx={{ fontSize: size * 0.55, color: color || "text.secondary" }} />
    </Box>
  );
}

/**
 * ==== v0.10.8 — Bảng xếp hạng Hashtag (tab Xu hướng) ====
 * v2.0.0: layout podium/list nằm ở RankingBoard (dùng chung với người dùng);
 * file này chỉ khai báo cách vẽ 1 hashtag (icon # thay avatar, bấm → mở danh
 * sách bài viết của hashtag qua `onSelectHashtag(tag)`).
 */
export default function HashtagRankingList({
  ranking = [],
  scoreField = "growth",
  scoreLabel = "Điểm tăng tuần này",
  loading = false,
  emptyHint = "Chưa có dữ liệu xếp hạng.",
  onSelectHashtag,
}) {
  const getScoreText = (h) => {
    const v = (h && h[scoreField]) || 0;
    return scoreField === "growth" && v > 0 ? `+${formatScore(v)}` : formatScore(v);
  };

  return (
    <RankingBoard
      ranking={ranking}
      loading={loading}
      emptyHint={emptyHint}
      scoreLabel={scoreLabel}
      getKey={(h) => h.tag}
      getName={(h) => h.tag}
      getSubtitle={(h) => `${formatCount(h.usageCount)} lượt dùng`}
      getScoreText={getScoreText}
      renderAvatar={(h, { size, color }) => <TagAvatar size={size} color={color} />}
      onSelect={(h) => h?.tag && onSelectHashtag?.(h.tag)}
    />
  );
}
