import { useCallback, useMemo } from "react";
import { useSearchParams } from "react-router-dom";

/**
 * ==== v2.4.1 — Cây tab nhiều cấp đồng bộ với URL (dùng cùng StickyTabs/TabTreeBars) ====
 * Khai báo MỘT cây, trang tự có tab, sub-tab, sub-tab của sub-tab… mà không phải viết thêm logic:
 *
 *   const TREE = [
 *     { key: "home", label: "Trang chủ", Component: Home },
 *     { key: "posts", label: "Bài viết", Component: Posts, children: [          // ← thêm sub-tab = thêm `children`
 *         { key: "all", label: "Tất cả", Component: AllPosts },
 *         { key: "media", label: "Ảnh", Component: MediaPosts } ] },
 *     { key: "saved", label: "Đã lưu", Component: Saved, visible: (ctx) => ctx.isOwn },   // ← tab có điều kiện
 *   ];
 *
 * URL: `?tab=posts&sub=media&sub2=…`. Mỗi cấp CHỌN node mặc định (node đầu tiên) khi URL không nói gì, và URL được giữ SẠCH: chọn node mặc định
 * thì tham số của cấp đó (và các cấp sâu hơn) bị xoá. Khoá lạ trên URL → rơi về node mặc định (không lỗi). Các tham số khác trên URL được giữ nguyên.
 * Node có `visible(ctx) === false` coi như không tồn tại (kể cả khi URL trỏ tới nó).
 *
 * @returns {{ levels: {items, activeKey}[], path: node[], active: node, select: (level, key) => void }}
 *   - levels[i].items: các node hiển thị ở hàng thứ i (đã lọc `visible`); levels[i].activeKey: khoá node đang chọn ở hàng đó
 *   - active: node SÂU NHẤT đang mở — dùng `active.Component` để vẽ nội dung
 */
export const TAB_PARAMS = ["tab", "sub", "sub2", "sub3"];

function visibleNodes(nodes, ctx) {
  return (nodes || []).filter((n) => (typeof n.visible === "function" ? n.visible(ctx) !== false : true));
}

export default function useTabTree(tree, { ctx = {}, params = TAB_PARAMS } = {}) {
  const [searchParams, setSearchParams] = useSearchParams();

  const ctxKey = JSON.stringify(ctx); // cờ nhỏ (boolean/chuỗi): so theo giá trị, không theo identity của đối tượng mới mỗi lần render
  const resolved = useMemo(() => {
    const levels = [];
    const path = [];
    let nodes = visibleNodes(tree, ctx);
    for (let level = 0; level < params.length && nodes.length > 0; level++) {
      const wanted = searchParams.get(params[level]);
      const node = nodes.find((n) => n.key === wanted) || nodes[0];
      levels.push({ items: nodes, activeKey: node.key });
      path.push(node);
      nodes = visibleNodes(node.children, ctx);
    }
    return { levels, path, active: path[path.length - 1] || null };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tree, searchParams, params, ctxKey]);

  const select = useCallback(
    (level, key) => {
      const items = resolved.levels[level]?.items;
      if (!items || !items.some((n) => n.key === key)) return;
      const next = new URLSearchParams(searchParams);
      for (let i = level + 1; i < params.length; i++) next.delete(params[i]); // đổi một cấp thì các cấp sâu hơn về mặc định
      if (key === items[0].key) next.delete(params[level]);
      else next.set(params[level], key);
      setSearchParams(next, { replace: true });
    },
    [resolved, searchParams, params, setSearchParams]
  );

  return { ...resolved, select };
}
