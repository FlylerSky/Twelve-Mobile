import React from "react";
import { Box, Container, Tab, Tabs, useMediaQuery, useTheme } from "@mui/material";

/**
 * ==== v2.4.1 — HỆ THỐNG TAB DÙNG CHUNG của Twelve (một hàng tab sticky dưới head) ====
 * Trước đây Cài đặt và Xu hướng mỗi trang tự lặp lại cùng một khuôn (hàng sticky dưới AppBar, Container md, Tabs cuộn ngang, TAB_SX…) —
 * cùng giao diện nhưng là hai bản sao, trang Profile (2.4.0) lại tự dựng bản thứ ba. Nay cả ba dùng ĐÚNG component này; sửa giao diện/hành vi tab
 * ở một chỗ là mọi trang đổi theo.
 *
 * Quy ước (giữ nguyên từ Xu hướng v0.10.7): mọi hàng cùng `top` = chiều cao AppBar; nhiều cấp thì `level` tăng dần → z-index cao dần,
 * nên khi cuộn, hàng con trượt lên và ĐÈ hàng cha (nền đặc, không lộ nội dung phía dưới). Không dùng JS đo scroll.
 *
 * Props:
 *  - tabs:  [{ key, label, icon?, disabled? }]
 *  - value: key của tab đang mở (không khớp tab nào → không tab nào được chọn)
 *  - onChange(key, tab): khi chọn một tab KHÁC tab đang mở
 *  - onTabClick(tab): mọi lần bấm vào một tab, kể cả tab đang mở (Cài đặt cần để "bấm lại tab → về gốc tab")
 *  - level: cấp của hàng (0 = hàng trên cùng)
 *  - maxWidth: bề rộng nội dung của hàng — đặt TRÙNG bề rộng nội dung trang để tab thẳng hàng với nội dung (mặc định "md")
 */
export const TAB_BAR_HEIGHT = 48;
export const TAB_SX = { minHeight: TAB_BAR_HEIGHT, textTransform: "none", fontWeight: 600 };
const BASE_Z_INDEX = 11;

/** Chiều cao AppBar (56 trên điện thoại, 64 trên màn rộng) — mốc `top` của mọi hàng tab sticky. */
export function useAppBarHeight() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  return { appBarH: isMobile ? 56 : 64, isMobile };
}

export default function StickyTabs({ tabs, value, onChange, onTabClick, level = 0, maxWidth = "md", ariaLabel }) {
  const { appBarH, isMobile } = useAppBarHeight();
  const active = tabs.some((t) => t.key === value) ? value : false;

  return (
    <Box
      data-testid={`sticky-tabs-${level}`}
      sx={{
        position: "sticky",
        top: appBarH,
        zIndex: BASE_Z_INDEX + level,
        minHeight: TAB_BAR_HEIGHT,
        bgcolor: "background.paper",
        borderBottom: "1px solid",
        borderColor: "divider",
        // Nền đặc — không lộ nội dung phía dưới khi hàng con đè lên hàng cha
        backgroundImage: "none",
      }}
    >
      <Container maxWidth={maxWidth} disableGutters={isMobile}>
        <Tabs
          value={active}
          onChange={(_e, key) => onChange?.(key, tabs.find((t) => t.key === key))}
          variant="scrollable"
          scrollButtons="auto"
          allowScrollButtonsMobile
          aria-label={ariaLabel}
          sx={{ px: { xs: 1, sm: 2 }, minHeight: TAB_BAR_HEIGHT }}
        >
          {tabs.map((t) => (
            <Tab
              key={t.key}
              value={t.key}
              icon={t.icon}
              iconPosition="start"
              label={t.label}
              disabled={t.disabled}
              sx={TAB_SX}
              onClick={onTabClick ? () => onTabClick(t) : undefined}
            />
          ))}
        </Tabs>
      </Container>
    </Box>
  );
}
