import React from "react";
import StickyTabs from "./StickyTabs";

/**
 * ==== v2.4.1 — Vẽ các hàng tab của một cây tab (xem useTabTree) ====
 * Mỗi cấp một hàng StickyTabs (cấp sau đè cấp trước khi cuộn). Hàng chỉ có MỘT tab thì không vẽ — không có gì để chuyển.
 * Đặt các hàng này ở GỐC trang (anh em với Container nội dung, như Xu hướng) để sticky chạy suốt chiều dài trang.
 */
export default function TabTreeBars({ tabTree, maxWidth = "md", ariaLabel = "Tab" }) {
  return (
    <>
      {tabTree.levels.map((lv, level) =>
        lv.items.length < 2 ? null : (
          <StickyTabs
            key={level}
            level={level}
            maxWidth={maxWidth}
            ariaLabel={level === 0 ? ariaLabel : `${ariaLabel} (cấp ${level + 1})`}
            tabs={lv.items}
            value={lv.activeKey}
            onChange={(key) => tabTree.select(level, key)}
          />
        )
      )}
    </>
  );
}
