import React from "react";
import { Box, Typography, CircularProgress } from "@mui/material";
import PostCardList from "./PostCardList";
import { postsApi, blogsApi } from "../api/content.api";
import useIncrementalReveal from "../hooks/useIncrementalReveal";

/**
 * ==== v0.10.8 — danh sách bài viết dùng chung cho tab Hashtag / Tìm kiếm ====
 * Khác với Trang chủ/Blog (toàn "post" hoặc toàn "blog"), danh sách ở đây có
 * thể TRỘN cả 2 loại (mỗi item có `type: "post"|"blog"` từ backend — xem
 * trending.controller.js#formatContentCards) nên nguồn (api/detailPath/
 * collectionName) được chọn LẠI cho từng bài qua `resolveSource`.
 *
 * v2.0.0: thẻ bài + hộp bình luận dùng PostCardList (chung với Trang chủ/Blog).
 *
 * v0.10.8.2 — `posts` đã là TOÀN BỘ kết quả (tối đa 100/50, không phân trang
 * qua API); chỉ render dần theo `useIncrementalReveal` (page size 10).
 */
const resolveSource = (post) => {
  const isBlog = post.type === "blog";
  return {
    key: `${post.type || "post"}:${post.id}`,
    api: isBlog ? blogsApi : postsApi,
    detailPath: post.detailPath || (isBlog ? "/blog" : "/post"),
    collectionName: isBlog ? "blogs" : "posts",
  };
};

export default function HashtagPostList({ posts = [], loading = false, emptyHint = "Không có bài viết nào." }) {
  // v0.10.8.2 — Hook PHẢI gọi trước mọi return sớm bên dưới (Rules of Hooks).
  const { visibleCount, sentinelRef, hasMore } = useIncrementalReveal(posts.length, 10);

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!posts.length) {
    return (
      <Typography variant="body2" color="text.secondary" textAlign="center" sx={{ py: 4 }}>
        {emptyHint}
      </Typography>
    );
  }

  return (
    <>
      <PostCardList posts={posts.slice(0, visibleCount)} resolveSource={resolveSource} />

      {hasMore && (
        <Box ref={sentinelRef} sx={{ display: "flex", justifyContent: "center", py: 3 }}>
          <CircularProgress size={22} />
        </Box>
      )}
    </>
  );
}
