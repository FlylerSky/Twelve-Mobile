import React from "react";
import { Box, Chip } from "@mui/material";
import { useNavigate } from "react-router-dom";

/**
 * ==== v2.0.0 — Hàng chip hashtag của bài viết (dùng chung PostCard + PostDetailPage) ====
 * v0.9.7: hiển thị hashtag bài viết. v0.10.8: bấm hashtag dẫn tới tab Hashtag
 * của trang Xu hướng, mở thẳng danh sách bài viết của hashtag đó
 * (xem TrendingPage.jsx). Trước đây markup + đường dẫn này bị chép 2 nơi.
 */
export default function HashtagChips({ hashtags, gap = 0.5, sx }) {
  const navigate = useNavigate();
  if (!Array.isArray(hashtags) || hashtags.length === 0) return null;
  return (
    <Box sx={{ display: "flex", flexWrap: "wrap", gap, ...sx }}>
      {hashtags.map((tag) => (
        <Chip
          key={tag}
          size="small"
          variant="outlined"
          label={tag}
          clickable
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/trending?tab=hashtag&hashtag=${encodeURIComponent(tag)}`);
          }}
        />
      ))}
    </Box>
  );
}
