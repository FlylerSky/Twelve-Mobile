import React, { useEffect, useState } from "react";
import { Alert, Box, Button, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, Divider, Paper, Stack, Typography } from "@mui/material";
import EmojiEventsOutlinedIcon from "@mui/icons-material/EmojiEventsOutlined";
import { useNavigate } from "react-router-dom";
import { getProfileExtraInfo } from "../../api/users.api";
import { buildExtraRows, formatWeekLabel } from "../../utils/profileExtras";

/**
 * ==== v2.5.2 — Hộp "Xem thêm" của trang Profile ====
 * Mở từ nút "Xem thêm" ở đầu trang Profile (hồ sơ của mình lẫn của người khác). Tải KHI MỞ (GET /users/:uid/extra-info), không nằm trong lần tải hồ sơ,
 * vì phần thành tích cần đọc bảng xếp hạng tuần — không đáng để mọi lượt xem hồ sơ phải trả.
 *
 * Nội dung do CHỦ HỒ SƠ chọn (Cài đặt > Tài khoản > Thông tin > Thông tin mở rộng) và được BACKEND lọc: mục đang tắt không bao giờ có trong dữ liệu nhận về,
 * nên ở đây không có logic "ẩn" nào để bị bỏ qua — hộp chỉ vẽ những gì có.
 *   • các trường: Tên hiển thị, Nhóm/Vai trò tài khoản, Ngày sinh, Ngày tham gia, Giới tính, Trạng thái, UID (xem utils/profileExtras.js);
 *   • thành tích: điểm tài khoản + các tuần người này lọt top 10 người tăng điểm mạnh nhất của trang Xu hướng (tổng hợp từ bảng chốt tuần — xem backend services/achievements.js).
 * Chủ hồ sơ có thêm lối tắt tới nơi chọn mục hiển thị.
 */
function Row({ label, value, testId }) {
  return (
    <Box data-testid={testId} sx={{ display: "flex", gap: 2, px: 2, py: 1.25, alignItems: "baseline" }}>
      <Typography variant="body2" color="text.secondary" sx={{ flex: "0 0 38%", minWidth: 0 }}>
        {label}
      </Typography>
      <Typography variant="body2" fontWeight={600} sx={{ flex: 1, minWidth: 0, wordBreak: "break-word" }}>
        {value}
      </Typography>
    </Box>
  );
}

function Stat({ label, value, caption, testId }) {
  return (
    <Box data-testid={testId} sx={{ flex: "1 1 40%", minWidth: 120, p: 1.5, border: "1px solid", borderColor: "divider", borderRadius: 1, bgcolor: "action.hover" }}>
      <Typography variant="caption" color="text.secondary" component="div">
        {label}
      </Typography>
      <Typography variant="h6" fontWeight={700} component="div">
        {value}
        {caption && (
          <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 0.5, fontWeight: 400 }}>
            {caption}
          </Typography>
        )}
      </Typography>
    </Box>
  );
}

const fmtGrowth = (n) => `${n > 0 ? "+" : ""}${Number(n).toLocaleString("vi-VN")} điểm`;

function Achievements({ data }) {
  const w = data.weekly || {};
  return (
    <Paper variant="outlined" sx={{ borderRadius: 1, overflow: "hidden" }} data-testid="more-achievements">
      <Stack direction="row" alignItems="center" spacing={1} sx={{ px: 2, pt: 1.5, pb: 1 }}>
        <EmojiEventsOutlinedIcon color="warning" fontSize="small" />
        <Typography variant="subtitle2" fontWeight={700}>
          Thành tích
        </Typography>
      </Stack>
      <Box sx={{ px: 2, pb: 2 }}>
        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
          <Stat testId="stat-score" label="Điểm tài khoản" value={Number(data.accountScore || 0).toLocaleString("vi-VN")} />
          <Stat testId="stat-top10" label="Vào top 10 tuần" value={w.top10Count || 0} caption={w.weeksRecorded ? `/ ${w.weeksRecorded} tuần` : undefined} />
          {w.top10Count > 0 && <Stat testId="stat-top3" label="Trong top 3" value={w.top3Count || 0} caption="lần" />}
          {w.top10Count > 0 && <Stat testId="stat-first" label="Hạng 1 tuần" value={w.firstPlaceCount || 0} caption="lần" />}
        </Box>

        {w.top10Count > 0 ? (
          <>
            {w.best && (
              <Typography variant="body2" sx={{ mt: 1.5 }} data-testid="best-week">
                Hạng cao nhất: <b>hạng {w.best.rank}</b> · {formatWeekLabel(w.best.weekCode)} ({fmtGrowth(w.best.weeklyGrowth)})
              </Typography>
            )}
            <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 1.5, mb: 0.5 }}>
              Các tuần gần đây lọt top 10
            </Typography>
            <Box component="ul" sx={{ listStyle: "none", m: 0, p: 0 }} data-testid="recent-weeks">
              {(w.recent || []).map((r) => (
                <Box component="li" key={r.weekCode} sx={{ display: "flex", justifyContent: "space-between", gap: 1, py: 0.5 }}>
                  <Typography variant="body2">{formatWeekLabel(r.weekCode)}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    Hạng {r.rank} · {fmtGrowth(r.weeklyGrowth)}
                  </Typography>
                </Box>
              ))}
            </Box>
          </>
        ) : (
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1.5 }} data-testid="no-weekly">
            Chưa lọt top 10 tăng điểm tuần nào ở trang Xu hướng.
          </Typography>
        )}
      </Box>
    </Paper>
  );
}

export default function ProfileMoreDialog({ open, onClose, user, isOwn = false }) {
  const navigate = useNavigate();
  const [state, setState] = useState({ status: "idle", data: null, error: "" });

  useEffect(() => {
    if (!open || !user?.uid) return undefined;
    let cancelled = false;
    setState({ status: "loading", data: null, error: "" });
    getProfileExtraInfo(user.uid)
      .then((data) => {
        if (!cancelled) setState({ status: "ready", data, error: "" });
      })
      .catch((err) => {
        if (!cancelled) setState({ status: "error", data: null, error: err?.message || "Không tải được thông tin." });
      });
    return () => {
      cancelled = true;
    };
  }, [open, user?.uid]);

  const rows = state.status === "ready" ? buildExtraRows(state.data?.fields) : [];
  const achievements = state.status === "ready" ? state.data?.achievements : null;
  const isEmpty = state.status === "ready" && rows.length === 0 && !achievements;

  return (
    <Dialog open={!!open} onClose={onClose} maxWidth="xs" fullWidth scroll="paper" aria-labelledby="profile-more-title">
      <DialogTitle id="profile-more-title">Xem thêm</DialogTitle>
      <DialogContent dividers>
        {state.status === "loading" && (
          <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
            <CircularProgress aria-label="Đang tải thông tin" />
          </Box>
        )}
        {state.status === "error" && <Alert severity="error">{state.error}</Alert>}
        {state.status === "ready" && (
          <Stack spacing={2}>
            {rows.length > 0 && (
              <Paper variant="outlined" sx={{ borderRadius: 1 }} data-testid="more-fields">
                {rows.map((r, i) => (
                  <React.Fragment key={r.key}>
                    {i > 0 && <Divider />}
                    <Row testId={`more-row-${r.key}`} label={r.label} value={r.value} />
                  </React.Fragment>
                ))}
              </Paper>
            )}
            {achievements && <Achievements data={achievements} />}
            {isEmpty && (
              <Typography color="text.secondary" textAlign="center" sx={{ py: 3 }} data-testid="more-empty">
                {isOwn ? "Bạn chưa bật mục thông tin nào để hiển thị." : "Người dùng này chưa chia sẻ thông tin mở rộng nào."}
              </Typography>
            )}
            {isOwn && (
              <Typography variant="caption" color="text.secondary">
                Đây là những gì người khác thấy ở hộp này. Bạn chọn mục hiển thị trong Cài đặt.
              </Typography>
            )}
          </Stack>
        )}
      </DialogContent>
      <DialogActions sx={{ p: 2 }}>
        {isOwn && (
          <Button
            data-testid="more-customize"
            onClick={() => {
              onClose();
              navigate("/settings/account/info");
            }}
          >
            Tùy chỉnh
          </Button>
        )}
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose}>Đóng</Button>
      </DialogActions>
    </Dialog>
  );
}
