import React, { useCallback, useEffect, useState } from "react";
import { Alert, Box, Button, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, Stack, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { listMyVisitors } from "../../api/users.api";
import { UserAvatar, UserName, UserTagChip } from "../UserIdentity";
import { profilePath } from "../../utils/profilePath";
import { formatRelativeTime } from "../../utils/time";

/**
 * ==== v2.5.2 — Hộp "Khách ghé thăm" (chỉ chủ hồ sơ; mở từ nút ở headZone trang Profile của chính mình) ====
 * Danh sách người đã đăng nhập vừa xem hồ sơ của mình: TỐI ĐA 50 người gần nhất, mỗi người một dòng (không trùng — vào lại thì dòng đó lên đầu), mới nhất trên cùng.
 * Mỗi dòng dùng MODULE NHẬN DIỆN NGƯỜI DÙNG dùng chung (components/UserIdentity.jsx — cùng bộ với thẻ bài và bình luận): avatar, Tên hiển thị + huy hiệu tài khoản
 * (UserName), Tag Name Search (UserTagChip) — rồi đến thời gian ghé thăm. Bấm vào avatar/tên/tag => đóng hộp rồi sang hồ sơ người đó (như hộp bình luận).
 * Dữ liệu từ GET /users/me/visitors (backend đọc tươi hồ sơ từng khách nên đổi tên/huy hiệu hiện ngay; khách đã xoá tài khoản bị lọc).
 * Danh sách được tải lại mỗi lần mở hộp.
 */
export default function ProfileVisitorsDialog({ open, onClose }) {
  const navigate = useNavigate();
  const [state, setState] = useState({ status: "idle", visitors: [], max: 50, error: "" });

  useEffect(() => {
    if (!open) return undefined;
    let cancelled = false;
    setState({ status: "loading", visitors: [], max: 50, error: "" });
    listMyVisitors()
      .then((res) => {
        if (!cancelled) setState({ status: "ready", visitors: res?.visitors || [], max: res?.max || 50, error: "" });
      })
      .catch((err) => {
        if (!cancelled) setState({ status: "error", visitors: [], max: 50, error: err?.message || "Không tải được danh sách khách ghé thăm." });
      });
    return () => {
      cancelled = true;
    };
  }, [open]);

  // Đóng hộp trước khi chuyển trang (hộp là Dialog của trang Profile — nếu không đóng, nó đè lên hồ sơ mới).
  const goToProfile = useCallback(
    (user) => {
      const target = profilePath(user);
      if (!target) return;
      onClose();
      navigate(target);
    },
    [navigate, onClose]
  );

  return (
    <Dialog open={!!open} onClose={onClose} maxWidth="xs" fullWidth scroll="paper" aria-labelledby="profile-visitors-title">
      <DialogTitle id="profile-visitors-title">Khách ghé thăm</DialogTitle>
      <DialogContent dividers sx={{ px: { xs: 1.5, sm: 2 } }}>
        {state.status === "loading" && (
          <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
            <CircularProgress aria-label="Đang tải khách ghé thăm" />
          </Box>
        )}
        {state.status === "error" && <Alert severity="error">{state.error}</Alert>}
        {state.status === "ready" && state.visitors.length === 0 && (
          <Typography color="text.secondary" textAlign="center" sx={{ py: 4 }} data-testid="visitors-empty">
            Chưa có ai ghé thăm hồ sơ của bạn.
          </Typography>
        )}
        {state.status === "ready" && state.visitors.length > 0 && (
          <Stack spacing={1} component="ul" sx={{ listStyle: "none", m: 0, p: 0 }} data-testid="visitors-list">
            {state.visitors.map((v) => (
              <Box
                component="li"
                key={v.uid}
                data-testid={`visitor-${v.uid}`}
                sx={{ display: "flex", alignItems: "center", gap: 1.5, p: 1.25, border: "1px solid", borderColor: "divider", borderRadius: 1, bgcolor: "action.hover", minWidth: 0 }}
              >
                <UserAvatar user={v} size={44} onProfileClick={goToProfile} />
                <Box sx={{ minWidth: 0, flex: 1 }}>
                  <UserName user={v} variant="subtitle2" onProfileClick={goToProfile} />
                  <Stack direction="row" alignItems="center" spacing={1} flexWrap="wrap" useFlexGap sx={{ mt: 0.5 }}>
                    <UserTagChip user={v} onProfileClick={goToProfile} />
                    <Typography variant="caption" color="text.secondary" data-testid={`visitor-time-${v.uid}`}>
                      {formatRelativeTime(v.visitedAt)}
                    </Typography>
                  </Stack>
                </Box>
              </Box>
            ))}
          </Stack>
        )}
        {state.status === "ready" && (
          <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 2 }}>
            Chỉ hiển thị {state.max} người ghé thăm gần nhất (mỗi người một lần) và chỉ ghi nhận người đã đăng nhập.
          </Typography>
        )}
      </DialogContent>
      <DialogActions sx={{ p: 2 }}>
        <Button onClick={onClose}>Đóng</Button>
      </DialogActions>
    </Dialog>
  );
}
