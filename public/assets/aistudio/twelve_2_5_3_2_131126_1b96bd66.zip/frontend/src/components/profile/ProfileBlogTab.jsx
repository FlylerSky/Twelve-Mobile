import React, { useMemo } from "react";
import FeedList from "../FeedList";
import usePaginatedFeed from "../../hooks/usePaginatedFeed";
import { blogsApi } from "../../api/content.api";
import { listUserBlogs } from "../../api/users.api";
import { useAuth } from "../../context/AuthContext";

/**
 * ==== v2.5.2 — Tab "Blog" của Profile: các bài Blog (đã xuất bản) do người này đăng trên trang Blog của Twelve, mới nhất trước ====
 * CHỈ có với hồ sơ của tài khoản bậc SA (xem profileTabs.jsx — `visible: ctx.isSA`), vì chỉ SA mới đăng được Blog.
 * Cùng khuôn với tab Bài viết (usePaginatedFeed + FeedList) nên thẻ blog, phân trang, bình luận, thả cảm xúc giống hệt trang Blog; `api={blogsApi}` để
 * các thao tác trên thẻ gọi đúng /blogs/... và `detailPath="/blog"` để mở đúng trang bài. Không có ghim (chỉ bài viết thường mới ghim được).
 */
export default function ProfileBlogTab({ uid, isOwn }) {
  const { isAuthReady } = useAuth();
  // `api.list(cursor, limit)` phải ỔN ĐỊNH theo uid (đổi identity = tải lại từ đầu).
  const listApi = useMemo(() => ({ list: (cursor, limit) => listUserBlogs(uid, cursor, limit) }), [uid]);
  const feed = usePaginatedFeed({ api: listApi, listKey: "blogs", isAuthReady });

  return (
    <div data-testid="profile-blog-tab">
      <FeedList
        feed={feed}
        api={blogsApi}
        detailPath="/blog"
        collectionName="blogs"
        emptyText={isOwn ? "Bạn chưa đăng bài Blog nào." : "Người dùng này chưa đăng bài Blog nào."}
      />
    </div>
  );
}
