import React, { useEffect, useState } from "react";
import { Box } from "@mui/material";

/**
 * ==== v2.4.1 — Ảnh bìa hồ sơ, DÙNG CHUNG cho đầu trang Profile và bản xem trước ở Cài đặt ====
 * - Khổ 3:1 (COVER_ASPECT). Bo góc `COVER_RADIUS` — cố ý NHỎ (2.4.0 dùng `borderRadius: 2` của MUI = 2 × 16px = 32px của theme nên quá tròn).
 * - `crop` = khung người dùng đã kéo/thu phóng ({ x, y, width, height } theo % ảnh gốc, đúng `croppedArea` của react-easy-crop).
 *   Hiển thị bằng CSS thuần (đặt ảnh phóng to + dời), KHÔNG cần canvas nên dùng được cả với ảnh URL ngoài (không dính CORS) và chỉnh lại được
 *   bất cứ lúc nào. Khung phải có tỉ lệ pixel 3:1 (cắt bằng khung 3:1) — khi đó kéo giãn theo % không méo ảnh. Không có/khung hỏng → canh giữa (cover).
 * - Chưa có ảnh bìa, hoặc ảnh lỗi/không tải được → nền gradient theo màu chủ đạo của theme (không để khung trống hay ảnh vỡ).
 */
export const COVER_ASPECT = 3;
export const COVER_RADIUS = "8px";
const MIN_PERCENT = 10; // khớp backend PROFILE.COVER_CROP_MIN_PERCENT

const num = (v) => typeof v === "number" && Number.isFinite(v);

/** Khung hợp lệ (số hữu hạn, trong biên)? Dữ liệu lạ → false → dùng canh giữa, không bao giờ để giá trị lạ lọt vào CSS. */
export function isValidCrop(c) {
  return (
    !!c &&
    [c.x, c.y, c.width, c.height].every(num) &&
    c.x >= 0 &&
    c.y >= 0 &&
    c.width >= MIN_PERCENT &&
    c.height >= MIN_PERCENT &&
    c.width <= 100 &&
    c.height <= 100 &&
    c.x + c.width <= 100.5 &&
    c.y + c.height <= 100.5
  );
}

/** Style của <img> để phần ảnh trong khung `c` vừa khít khung 3:1: ảnh rộng 100/width·100% khung, dời -x/width·100% (trái) và -y/height·100% (trên). */
export function frameImageSx(c) {
  if (!isValidCrop(c)) return { width: "100%", height: "100%", objectFit: "cover" };
  return {
    position: "absolute",
    maxWidth: "none",
    width: `${(10000 / c.width).toFixed(3)}%`,
    height: `${(10000 / c.height).toFixed(3)}%`,
    left: `${((-c.x / c.width) * 100).toFixed(3)}%`,
    top: `${((-c.y / c.height) * 100).toFixed(3)}%`,
    objectFit: "fill",
  };
}

export default function ProfileCover({ url, crop, alt = "", onLoadError, testId = "profile-cover", sx }) {
  const [failed, setFailed] = useState(false);
  // Đổi ảnh (hoặc sang hồ sơ khác) thì thử tải lại, không dính trạng thái "lỗi" của ảnh trước.
  useEffect(() => setFailed(false), [url]);
  const show = !!url && !failed;

  return (
    <Box
      data-testid={testId}
      sx={{
        position: "relative",
        width: "100%",
        aspectRatio: `${COVER_ASPECT} / 1`,
        borderRadius: COVER_RADIUS,
        overflow: "hidden",
        bgcolor: "action.hover",
        backgroundImage: (theme) => (show ? "none" : `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`),
        ...sx,
      }}
    >
      {show && (
        <Box
          component="img"
          src={url}
          alt={alt}
          loading="eager"
          referrerPolicy="no-referrer"
          onError={() => {
            setFailed(true);
            onLoadError?.();
          }}
          sx={{ display: "block", ...frameImageSx(crop) }}
        />
      )}
    </Box>
  );
}
