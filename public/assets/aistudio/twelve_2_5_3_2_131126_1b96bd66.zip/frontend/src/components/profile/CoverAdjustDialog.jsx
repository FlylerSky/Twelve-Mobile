import React, { useCallback, useEffect, useState } from "react";
import { Alert, Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Slider, Typography } from "@mui/material";
import Cropper from "react-easy-crop";
import { COVER_ASPECT, isValidCrop } from "./ProfileCover";

/**
 * ==== v2.4.1 — Kéo & thu phóng ảnh bìa (như ảnh đại diện) ====
 * Khác AvatarCropper ở chỗ KHÔNG cắt ảnh ra file mới: chỉ trả KHUNG hiển thị `{ x, y, width, height }` (% ảnh gốc) để lưu cùng ảnh bìa.
 * Nhờ vậy dùng được cho cả ảnh đã tải lên lẫn ảnh dán bằng URL ngoài (không cần canvas nên không dính CORS), và mở lại để chỉnh bất cứ lúc nào
 * (`initialCrop` đưa khung đang lưu vào lại đúng vị trí/mức phóng).
 *
 * props: open, onClose, imageSrc (blob URL hoặc https), initialCrop (khung đang lưu hoặc null), onSave(crop) → Promise (ném lỗi = giữ hộp mở + báo lỗi),
 *        title, saveLabel
 */
export default function CoverAdjustDialog({ open, onClose, imageSrc, initialCrop = null, onSave, title = "Điều chỉnh ảnh bìa", saveLabel = "Lưu ảnh bìa" }) {
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [area, setArea] = useState(null); // khung % do react-easy-crop báo
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [imageFailed, setImageFailed] = useState(false);

  // Mỗi lần mở (hoặc đổi ảnh): về trạng thái sạch.
  useEffect(() => {
    if (open) {
      setCrop({ x: 0, y: 0 });
      setZoom(1);
      setArea(null);
      setSaving(false);
      setError("");
      setImageFailed(false);
    }
  }, [open, imageSrc]);

  const onCropComplete = useCallback((percent) => setArea(percent), []);

  const handleSave = async () => {
    if (!area || saving) return;
    setSaving(true);
    setError("");
    try {
      await onSave(area);
      onClose();
    } catch (err) {
      setError(err?.message || "Không lưu được ảnh bìa. Vui lòng thử lại.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={!!open} onClose={saving ? undefined : onClose} fullWidth maxWidth="sm">
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
          Kéo để chọn vị trí, kéo thanh bên dưới để thu phóng. Khung là phần sẽ hiện trên trang cá nhân của bạn (khổ ngang {COVER_ASPECT}:1).
        </Typography>
        {imageFailed ? (
          <Alert severity="error">Không tải được ảnh này để chỉnh. Hãy chọn ảnh khác hoặc dùng đường dẫn khác.</Alert>
        ) : (
          <>
            <Box sx={{ position: "relative", width: "100%", height: { xs: 220, sm: 300 }, bgcolor: "#000", borderRadius: "8px", overflow: "hidden" }} data-testid="cover-cropper">
              {imageSrc && (
                <Cropper
                  image={imageSrc}
                  crop={crop}
                  zoom={zoom}
                  aspect={COVER_ASPECT}
                  cropShape="rect"
                  showGrid={false}
                  minZoom={1}
                  maxZoom={3}
                  initialCroppedAreaPercentages={isValidCrop(initialCrop) ? initialCrop : undefined}
                  onCropChange={setCrop}
                  onZoomChange={setZoom}
                  onCropComplete={onCropComplete}
                  mediaProps={{ onError: () => setImageFailed(true) }}
                />
              )}
            </Box>
            <Box sx={{ px: 1, mt: 2 }}>
              <Typography variant="caption" color="text.secondary">
                Thu phóng
              </Typography>
              <Slider value={zoom} min={1} max={3} step={0.05} onChange={(_, v) => setZoom(v)} aria-label="Thu phóng ảnh bìa" />
            </Box>
          </>
        )}
        {error && (
          <Alert severity="error" sx={{ mt: 1 }}>
            {error}
          </Alert>
        )}
      </DialogContent>
      <DialogActions sx={{ p: 2 }}>
        <Button
          onClick={() => {
            setCrop({ x: 0, y: 0 });
            setZoom(1);
          }}
          disabled={saving || imageFailed}
        >
          Đặt lại
        </Button>
        <Box sx={{ flex: 1 }} />
        <Button onClick={onClose} disabled={saving}>
          Hủy
        </Button>
        <Button variant="contained" onClick={handleSave} disabled={saving || !area || imageFailed}>
          {saving ? "Đang lưu..." : saveLabel}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
