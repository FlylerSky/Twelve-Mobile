import React, { useMemo } from "react";
import FeedList from "../FeedList";
import usePaginatedFeed from "../../hooks/usePaginatedFeed";
import { postsApi } from "../../api/content.api";
import { listUserPosts } from "../../api/users.api";
import { useAuth } from "../../context/AuthContext";

/**
 * ==== v2.4.0 — Tab "Bài viết" của Profile: bài của người này, mới nhất trước ====
 * Cùng khuôn với feed Trang chủ (usePaginatedFeed + FeedList) nên thẻ bài, phân trang, hộp bình luận… giống hệt. Thẻ bài của CHÍNH chủ hồ sơ
 * có nút ghim/gỡ ghim trong hàng thông số (xem PostCard + usePinPost).
 */
export default function ProfilePostsTab({ uid, isOwn }) {
  const { isAuthReady } = useAuth();
  // usePaginatedFeed cần `api.list(cursor, limit)` ỔN ĐỊNH theo uid (đổi identity = tải lại từ đầu).
  const listApi = useMemo(() => ({ list: (cursor, limit) => listUserPosts(uid, cursor, limit) }), [uid]);
  const feed = usePaginatedFeed({ api: listApi, listKey: "posts", isAuthReady });

  return (
    <div data-testid="profile-posts-tab">
      <FeedList
        feed={feed}
        api={postsApi}
        detailPath="/post"
        collectionName="posts"
        emptyText={isOwn ? "Bạn chưa đăng bài viết nào." : "Người dùng này chưa đăng bài viết nào."}
      />
    </div>
  );
}
