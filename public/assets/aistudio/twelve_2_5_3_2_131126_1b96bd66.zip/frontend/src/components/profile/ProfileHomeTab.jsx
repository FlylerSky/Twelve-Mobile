import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Box, CircularProgress, Stack, Typography } from "@mui/material";
import PushPinIcon from "@mui/icons-material/PushPin";
import PostCardList from "../PostCardList";
import { postsApi } from "../../api/content.api";
import { listPinnedPosts } from "../../api/users.api";
import { useAuth } from "../../context/AuthContext";
import { useSnackbar } from "../../context/SnackbarContext";

/**
 * ==== v2.4.0 — Tab "Trang chủ" của Profile: các bài người dùng GHIM ====
 * (Ảnh bìa / avatar / tên / huy hiệu nằm ở ProfileHeader phía trên các tab.)
 * Với CHÍNH chủ hồ sơ: danh sách ghim đổi ngay khi ghim/gỡ ghim ở bất cứ đâu (theo `profile.pinnedPostIds` realtime) — tải lại theo khoá đó.
 * Với người khác: tải một lần theo uid.
 */
const SOURCE = { api: postsApi, detailPath: "/post", collectionName: "posts" };

export default function ProfileHomeTab({ uid, isOwn }) {
  const { profile, isAuthReady } = useAuth();
  const snackbar = useSnackbar();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Chỉ chủ hồ sơ cần theo dõi thay đổi ghim; người khác không (khoá cố định).
  const pinKey = isOwn && Array.isArray(profile?.pinnedPostIds) ? profile.pinnedPostIds.join(",") : "";

  useEffect(() => {
    // Đợi auth sẵn sàng (như feed Trang chủ): thiếu token thì không có myReaction đúng.
    if (!isAuthReady) return undefined;
    let cancelled = false;
    setLoading(true);
    listPinnedPosts(uid)
      .then((list) => {
        if (!cancelled) setPosts(list);
      })
      .catch((err) => {
        if (!cancelled) snackbar.error(err?.message || "Không tải được bài viết đã ghim.");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [uid, isAuthReady, pinKey]);

  const resolveSource = useCallback(() => SOURCE, []);
  const adjustComments = useCallback(
    (postId, delta) => setPosts((prev) => prev.map((p) => (p.id === postId ? { ...p, commentCount: (p.commentCount || 0) + delta } : p))),
    []
  );
  const emptyText = useMemo(
    () => (isOwn ? "Bạn chưa ghim bài viết nào. Mở tab “Bài viết” và bấm biểu tượng ghim trên bài muốn ghim." : "Người dùng này chưa ghim bài viết nào."),
    [isOwn]
  );

  return (
    <Box data-testid="profile-home-tab">
      <Stack direction="row" alignItems="center" spacing={0.75} sx={{ mb: 1.5 }}>
        <PushPinIcon fontSize="small" color="action" />
        <Typography variant="subtitle1" fontWeight={700}>
          Bài viết đã ghim
        </Typography>
      </Stack>

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress size={28} aria-label="Đang tải bài viết đã ghim" />
        </Box>
      ) : posts.length === 0 ? (
        <Typography variant="body2" color="text.secondary" textAlign="center" sx={{ py: 4 }}>
          {emptyText}
        </Typography>
      ) : (
        <PostCardList posts={posts} resolveSource={resolveSource} onCommentCountChange={adjustComments} />
      )}
    </Box>
  );
}
