import React from "react";
import { Avatar, Box, Button, Chip, Stack, Typography } from "@mui/material";
import PublicOutlinedIcon from "@mui/icons-material/PublicOutlined";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import UserBadges from "../UserBadges";
import ProfileCover from "./ProfileCover";

/**
 * ==== Đầu trang Profile: ảnh bìa · avatar · tên + huy hiệu · Tag Name Search ====
 * - Ảnh bìa: ProfileCover (khổ 3:1, bo góc nhỏ, có khung kéo/thu phóng, tự có nền dự phòng) — xem ProfileCover.jsx.
 * - Huy hiệu luôn nằm NGAY cạnh tên (xem UserBadges: 1 huy hiệu → icon; nhiều → "3 chấm", bấm ra danh sách).
 * - Avatar đè lên mép dưới ảnh bìa; viền theo màu nền trang để tách khỏi ảnh ở cả giao diện sáng/tối.
 * - v2.5.2: Tiểu sử (`user.bio`) ngay dưới tên/tag — văn bản THUẦN nhiều dòng (React text + white-space: pre-wrap; không bao giờ là HTML), chỉ vẽ khi có;
 *   nút "Xem thêm" mở hộp thông tin mở rộng (ProfileMoreDialog) — `onOpenMore` do trang Profile truyền (không truyền thì không vẽ nút).
 */
export default function ProfileHeader({ user, onOpenMore }) {
  return (
    <Box data-testid="profile-header" sx={{ mb: 1 }}>
      <ProfileCover url={user?.coverUrl} crop={user?.coverCrop} />

      <Box sx={{ px: { xs: 1.5, sm: 2 } }}>
        <Avatar
          src={user.avatarUrl || undefined}
          sx={{
            width: { xs: 84, sm: 96 },
            height: { xs: 84, sm: 96 },
            mt: { xs: -5.5, sm: -6.5 },
            border: "4px solid",
            borderColor: "background.default",
            fontSize: 36,
          }}
        >
          {user.displayName?.[0]}
        </Avatar>

        <Stack direction="row" alignItems="center" spacing={0.75} sx={{ mt: 1, minWidth: 0 }}>
          <Typography variant="h5" fontWeight={700} sx={{ wordBreak: "break-word", minWidth: 0 }}>
            {user.displayName}
          </Typography>
          <UserBadges user={user} variant="h5" />
        </Stack>

        <Stack direction="row" alignItems="center" spacing={1} flexWrap="wrap" useFlexGap sx={{ mt: 0.75 }}>
          {user.tagName && <Chip size="small" variant="outlined" label={user.tagName} />}
          {user.country && (
            <Stack direction="row" alignItems="center" spacing={0.5} sx={{ color: "text.secondary" }}>
              <PublicOutlinedIcon sx={{ fontSize: 16 }} />
              <Typography variant="body2" color="text.secondary">
                {user.country}
              </Typography>
            </Stack>
          )}
        </Stack>

        {user.bio && (
          <Typography variant="body2" data-testid="profile-bio" sx={{ mt: 1.5, whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
            {user.bio}
          </Typography>
        )}

        {onOpenMore && (
          <Button size="small" variant="outlined" startIcon={<InfoOutlinedIcon />} onClick={onOpenMore} data-testid="profile-more-button" sx={{ mt: 1.5 }}>
            Xem thêm
          </Button>
        )}
      </Box>
    </Box>
  );
}
