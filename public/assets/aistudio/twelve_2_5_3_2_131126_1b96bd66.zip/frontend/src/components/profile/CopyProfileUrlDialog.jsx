import React, { useMemo } from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, List, ListItemButton, ListItemIcon, ListItemText, Typography } from "@mui/material";
import AlternateEmailIcon from "@mui/icons-material/AlternateEmail";
import FingerprintIcon from "@mui/icons-material/Fingerprint";
import { profileShareUrls } from "../../utils/profilePath";
import { copyText } from "../../utils/clipboard";
import { useSnackbar } from "../../context/SnackbarContext";

/**
 * ==== v2.4.2.2 — Hộp "Sao chép URL Profile" (mở từ nút ở headZone trang Profile; có ở hồ sơ của mình lẫn của người khác) ====
 * Hai loại URL để chọn:
 *   • URL Ngắn (Tag Name Search) — `/u/@<tag>`: URL hồ sơ CHÍNH của Twelve; gọn, dễ nhớ; đổi theo Tag Name khi chủ hồ sơ đổi tag.
 *   • URL cố định (UID)          — `/u/<uid>`: không đổi dù chủ hồ sơ đổi Tag Name. KHÔNG phải URL chính: đây là link UID kiểu cũ mà hệ thống VẪN hỗ trợ điều hướng,
 *                                  và khi ai đó mở nó thì trang Profile tự chuyển sang URL Tag Name (xem PublicProfilePage) — ở đây ta chỉ tận dụng điều đó.
 * Link dựng từ ĐỐI TƯỢNG hồ sơ (`user.tagName`, `user.uid`) qua profileShareUrls() — không đọc thanh địa chỉ (hồ sơ của mình đang ở /u/myProfile, link đó không chia sẻ được)
 * và không tự ghép chuỗi `/u/...` (xem utils/profilePath.js).
 * Chọn một dòng => sao chép ngay + đóng hộp. Sao chép thất bại (trình duyệt chặn clipboard) => báo lỗi, giữ hộp mở; link hiển thị dạng văn bản để tự chọn/sao chép tay.
 *
 * v2.5.2 [GIAO DIỆN]: hai lựa chọn trước đây là hai hàng phẳng — không viền, không nền — nên nhìn như chữ thường, không ai biết bấm được. Nay mỗi lựa chọn là một
 * THẺ: nền `action.hover` + viền `divider` + khoảng cách giữa hai thẻ (cùng kiểu thẻ của Menu/Navbar), đổi nền + viền sáng khi rê chuột/focus bàn phím để báo "bấm được".
 * Màu lấy từ theme (không hardcode) nên đúng ở cả giao diện sáng/tối. Thẻ bị vô hiệu (thiếu Tag/UID) vẫn có viền, chỉ mờ đi.
 */
const CARD_SX = {
  borderRadius: 1,
  alignItems: "flex-start",
  border: "1px solid",
  borderColor: "divider",
  bgcolor: "action.hover",
  transition: "background-color 0.15s, border-color 0.15s",
  "&:hover, &.Mui-focusVisible": { bgcolor: "action.selected", borderColor: "primary.light" },
};
const OPTIONS = [
  {
    key: "tag",
    title: "URL Ngắn (Tag Name Search)",
    copied: "Đã sao chép URL Ngắn (Tag Name Search).",
    hint: "Gọn, dễ nhớ — nên dùng để chia sẻ. Link đổi theo nếu chủ hồ sơ đổi Tag Name.",
    missing: "Hồ sơ này chưa có Tag Name hợp lệ.",
    icon: <AlternateEmailIcon />,
  },
  {
    key: "uid",
    title: "URL cố định (UID)",
    copied: "Đã sao chép URL cố định (UID).",
    hint: "Không đổi dù chủ hồ sơ đổi Tag Name. Khi mở, Twelve tự chuyển sang URL Tag Name.",
    missing: "Không có UID cho hồ sơ này.",
    icon: <FingerprintIcon />,
  },
];

export default function CopyProfileUrlDialog({ open, onClose, user }) {
  const snackbar = useSnackbar();
  const urls = useMemo(() => profileShareUrls(user), [user]);

  const pick = async (opt) => {
    const url = urls[opt.key];
    if (!url) return;
    const ok = await copyText(url);
    if (ok) {
      snackbar.success(opt.copied);
      onClose();
    } else {
      snackbar.error("Không thể sao chép tự động. Hãy chọn link rồi sao chép thủ công.");
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth aria-labelledby="copy-profile-url-title">
      <DialogTitle id="copy-profile-url-title">Sao chép URL Profile</DialogTitle>
      <DialogContent sx={{ px: { xs: 1, sm: 2 } }}>
        <Typography variant="body2" color="text.secondary" sx={{ px: 1, pb: 1 }}>
          Chọn loại URL muốn sao chép:
        </Typography>
        <List disablePadding sx={{ display: "flex", flexDirection: "column", gap: 1.25 }}>
          {OPTIONS.map((opt) => {
            const url = urls[opt.key];
            return (
              <ListItemButton key={opt.key} disabled={!url} onClick={() => pick(opt)} data-testid={`copy-url-${opt.key}`} sx={CARD_SX}>
                <ListItemIcon sx={{ minWidth: 40, mt: 0.5 }}>{opt.icon}</ListItemIcon>
                <ListItemText
                  primary={opt.title}
                  primaryTypographyProps={{ fontWeight: 600 }}
                  secondaryTypographyProps={{ component: "div" }}
                  secondary={
                    <>
                      <Typography component="div" variant="body2" color="text.primary" sx={{ fontFamily: "monospace", wordBreak: "break-all", userSelect: "text" }} data-testid={`copy-url-${opt.key}-value`}>
                        {url || opt.missing}
                      </Typography>
                      {url && (
                        <Typography component="div" variant="caption" color="text.secondary" sx={{ mt: 0.5 }}>
                          {opt.hint}
                        </Typography>
                      )}
                    </>
                  }
                />
              </ListItemButton>
            );
          })}
        </List>
      </DialogContent>
      <DialogActions sx={{ p: 2 }}>
        <Button onClick={onClose}>Đóng</Button>
      </DialogActions>
    </Dialog>
  );
}
