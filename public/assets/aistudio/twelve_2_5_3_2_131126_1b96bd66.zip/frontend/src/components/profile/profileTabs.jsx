import React from "react";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import ArticleOutlinedIcon from "@mui/icons-material/ArticleOutlined";
import AutoStoriesOutlinedIcon from "@mui/icons-material/AutoStoriesOutlined";
import ProfileHomeTab from "./ProfileHomeTab";
import ProfilePostsTab from "./ProfilePostsTab";
import ProfileBlogTab from "./ProfileBlogTab";

/**
 * ==== v2.4.1 — CÂY TAB của trang Profile (nguồn duy nhất) ====
 * Trang Profile không biết có những tab nào: nó đọc cây này qua `useTabTree` + `TabTreeBars` (hệ thống tab dùng chung với Cài đặt và Xu hướng).
 *   • Thêm TAB mới   = thêm một mục vào mảng;
 *   • Thêm SUB-TAB   = thêm `children: [...]` vào mục cha (hàng sub-tab tự xuất hiện bên dưới hàng tab, URL `?tab=…&sub=…`);
 *   • Tab chỉ chủ hồ sơ thấy = `visible: (ctx) => ctx.isOwn` (ctx do PublicProfilePage truyền);
 *   • Tab chỉ có ở hồ sơ tài khoản SA (v2.5.2: "Blog") = `visible: (ctx) => ctx.isSA` — `isSA` là bậc của CHỦ HỒ SƠ đang xem (không phải của người xem).
 * Mỗi mục: { key, label, icon?, Component, children?, visible? }. `Component` của node SÂU NHẤT đang mở được vẽ, nhận { uid, isOwn, user }.
 * Node cha có `children` thì không cần `Component`.
 */
export const PROFILE_TABS = [
  { key: "home", label: "Trang chủ", icon: <HomeOutlinedIcon fontSize="small" />, Component: ProfileHomeTab },
  { key: "posts", label: "Bài viết", icon: <ArticleOutlinedIcon fontSize="small" />, Component: ProfilePostsTab },
  // v2.5.2: bài Blog đã đăng trên trang Blog — chỉ hồ sơ của tài khoản bậc SA (chỉ SA đăng được Blog). URL `?tab=blog`; hồ sơ không phải SA mở `?tab=blog` thì rơi về tab mặc định.
  { key: "blog", label: "Blog", icon: <AutoStoriesOutlinedIcon fontSize="small" />, Component: ProfileBlogTab, visible: (ctx) => ctx.isSA === true },
];
