import React from "react";
import { Box, TextField, MenuItem, Typography, RadioGroup, FormControlLabel, Radio } from "@mui/material";
import { BIO_MAX, BIO_MAX_LINES, bioStats } from "../utils/bio";

/**
 * ==== v2.2.0 — Các ô hồ sơ dùng chung (Đăng ký · Chào mừng · Cài đặt > Tài khoản > Thông tin) ====
 * Trước đây Tên hiển thị / Sinh nhật / Giới tính / Quốc gia được viết lại ở từng form. Nay mỗi ô là MỘT component; mỗi form tự bố cục
 * (Đăng ký xen Tag Name Search giữa các ô) hoặc dùng `ProfileFieldsGrid` (lưới 2 cột cho Chào mừng và Cài đặt).
 */
export const DisplayNameField = (props) => <TextField label="Tên hiển thị" fullWidth {...props} />;

export const BirthdayField = (props) => <TextField label="Sinh nhật" type="date" InputLabelProps={{ shrink: true }} fullWidth {...props} />;

export function GenderField({ value, onChange, required = false }) {
  return (
    <Box>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        Giới tính
      </Typography>
      <RadioGroup row value={value} onChange={onChange}>
        <FormControlLabel value="male" control={<Radio required={required} />} label="Nam" />
        <FormControlLabel value="female" control={<Radio />} label="Nữ" />
        <FormControlLabel value="other" control={<Radio />} label="Khác" />
      </RadioGroup>
    </Box>
  );
}

export function CountryField({ countries = [], value = "", ...props }) {
  // Danh sách quốc gia tải bất đồng bộ: trong lúc chờ (hoặc mã không có trong danh sách) hiện ô trống thay vì để MUI báo giá trị ngoài danh sách.
  const safeValue = countries.some((c) => c.code === value) ? value : "";
  return (
    <TextField select label="Quốc gia" fullWidth value={safeValue} {...props}>
      {countries.map((c) => (
        <MenuItem key={c.code} value={c.code}>
          {c.name}
        </MenuItem>
      ))}
    </TextField>
  );
}

/**
 * v2.5.2 — Tiểu sử (bio): nhiều dòng, đếm ký tự trực tiếp, báo đỏ khi quá giới hạn (xem utils/bio.js). Chỉ dùng ở Cài đặt > Tài khoản > Thông tin
 * (KHÔNG nằm trong ProfileFieldsGrid vì Đăng ký/Chào mừng không hỏi tiểu sử).
 */
export function BioField({ value = "", onChange, ...props }) {
  const st = bioStats(value);
  const error = !st.valid;
  return (
    <TextField
      label="Tiểu sử (Bio)"
      placeholder="Giới thiệu ngắn về bạn…"
      multiline
      minRows={3}
      maxRows={8}
      fullWidth
      value={value}
      onChange={onChange}
      error={error}
      helperText={
        st.tooManyLines
          ? `Tối đa ${BIO_MAX_LINES} dòng (hiện ${st.lines} dòng).`
          : `${st.chars}/${BIO_MAX} ký tự · tối đa ${BIO_MAX_LINES} dòng · hiện công khai trên hồ sơ của bạn`
      }
      inputProps={{ "data-testid": "bio-input" }}
      {...props}
    />
  );
}

/** form: { displayName, birthday, gender, country }; onChange(field) → (event) => void */
export function ProfileFieldsGrid({ form, onChange, countries }) {
  return (
    <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" }, gap: 2 }}>
      <DisplayNameField value={form.displayName} onChange={onChange("displayName")} />
      <BirthdayField value={form.birthday} onChange={onChange("birthday")} />
      <CountryField countries={countries} value={form.country} onChange={onChange("country")} />
      <Box sx={{ gridColumn: { xs: "1", sm: "1 / -1" } }}>
        <GenderField value={form.gender} onChange={onChange("gender")} />
      </Box>
    </Box>
  );
}
