import React from "react";
import { Divider, Typography } from "@mui/material";
import ArticleIcon from "@mui/icons-material/Article";
import FavoriteIcon from "@mui/icons-material/Favorite";
import { formatScore } from "../utils/number";
import StatsPopover, { StatRow } from "./StatsPopover";

/**
 * Hộp giải thích Điểm tài khoản (accountScore, v0.8.23) — mở khi bấm vào số
 * điểm tài khoản trong Menu (Navbar.jsx). Công thức: accountScore =
 * postsScoreSum + positiveScore (backend/src/utils/helpers.js).
 * v2.0.0: dùng StatsPopover chung → tự có neo vị trí snapshot như 2 popover kia.
 */
export default function AccountScorePopover({
  anchorEl,
  onClose,
  postsScoreSum = 0,
  positiveScore = 0,
  accountScore = 0,
}) {
  return (
    <StatsPopover anchorEl={anchorEl} onClose={onClose} title="Điểm tài khoản">
      <StatRow
        icon={<ArticleIcon fontSize="small" color="action" />}
        label="Điểm bài viết tổng"
        value={formatScore(postsScoreSum)}
        title={String(postsScoreSum)}
      />
      <StatRow
        icon={<FavoriteIcon fontSize="small" color="action" />}
        label="Điểm tích cực"
        value={formatScore(positiveScore)}
        title={String(positiveScore)}
      />
      <Divider />
      <StatRow
        label="Tổng điểm tài khoản"
        labelBold
        value={formatScore(accountScore)}
        valueBold
        title={String(accountScore)}
      />
      <Typography variant="caption" color="text.secondary">
        Điểm tài khoản = Điểm bài viết tổng + Điểm tích cực. Đây là số liệu cache dùng cho các tính năng xếp hạng sau
        này.
      </Typography>
    </StatsPopover>
  );
}
