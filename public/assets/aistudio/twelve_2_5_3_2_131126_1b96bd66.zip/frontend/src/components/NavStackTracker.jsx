import { useEffect } from "react";
import { useLocation, useNavigationType } from "react-router-dom";
import { trackLocation } from "../utils/navStack";

/**
 * v2.4.2 — ghi lại từng mục lịch sử điều hướng (xem utils/navStack.js). Đặt MỘT lần trong <Router>, không vẽ gì.
 */
export default function NavStackTracker() {
  const location = useLocation();
  const navType = useNavigationType();
  useEffect(() => {
    trackLocation(location, navType);
  }, [location, navType]);
  return null;
}
