import React, { useState, useRef, useLayoutEffect, useCallback, useMemo } from "react";
import {
  Card,
  CardHeader,
  CardMedia,
  CardContent,
  CardActions,
  Typography,
  IconButton,
  Button,
  Box,
  Popover,
  Stack,
  Divider,
} from "@mui/material";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import ThumbUpOffAltIcon from "@mui/icons-material/ThumbUpOffAlt";
import ThumbDownIcon from "@mui/icons-material/ThumbDown";
import ThumbDownOffAltIcon from "@mui/icons-material/ThumbDownOffAlt";
import ChatBubbleOutlineIcon from "@mui/icons-material/ChatBubbleOutline";
import VisibilityIcon from "@mui/icons-material/Visibility";
import ShareIcon from "@mui/icons-material/Share";
import GradeIcon from "@mui/icons-material/Grade";
import PushPinIcon from "@mui/icons-material/PushPin";
import PushPinOutlinedIcon from "@mui/icons-material/PushPinOutlined";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { useNavigate } from "react-router-dom";
import { formatRelativeTime } from "../utils/time";
import { formatCount, formatScore } from "../utils/number";
import useContentEngagement from "../hooks/useContentEngagement";
import usePinPost from "../hooks/usePinPost";
import ViewStatsPopover from "./ViewStatsPopover";
import PostScorePopover from "./PostScorePopover";
import { UserAvatar, UserName, UserTagChip } from "./UserIdentity";
import HashtagChips from "./HashtagChips";

/**
 * Metric row: ưu tiên hiển thị like → dislike → comment → view → share → score.
 * Khi thiếu chỗ, ẩn từ phải sang trái vào nút "..." (bấm hiện đủ chỉ số).
 * View trong menu "..." vẫn mở được ViewStatsPopover. Share trong menu "..."
 * vẫn bấm tạo link chia sẻ được bình thường. Score mở PostScorePopover giải
 * thích công thức tính điểm (xem utils/postScore.js).
 *
 * v2.4.0 — nút GHIM bài lên trang cá nhân là một "chỉ số" nữa của hàng này (CHỈ hiện cho tác giả, bài viết — không phải Blog), ưu tiên
 * thấp nhất, không có số đếm. Nhờ cơ chế đo/ẩn vào "..." sẵn có, thiếu chỗ thì nút tự chuyển vào menu "..." chứ không làm vỡ giao diện.
 * (Trên trang POST nút ghim nằm ở headZone — xem PostDetailPage — không nằm ở hàng chỉ số.)
 */
export default function PostCard({ post, api, detailPath, onOpenComments }) {
  const navigate = useNavigate();

  // v2.0.0: state số đếm + myReaction + realtime + like/dislike/share + điểm bài
  // nằm trong hook dùng chung với PostDetailPage (trước đây chép ở cả 2 nơi).
  const collectionName = detailPath === "/blog" ? "blogs" : "posts";
  const {
    likeCount,
    dislikeCount,
    commentCount,
    shareCount,
    viewCount,
    aiViewCount,
    myReaction,
    busy,
    score,
    react: handleReact,
    share,
  } = useContentEngagement({ api, collectionName, id: post.id, initial: post });
  const handleShare = useCallback(() => share(post.title), [share, post.title]);

  // v2.4.0: ghim lên trang cá nhân — Blog không có ghim.
  const pin = usePinPost(post, { enabled: detailPath !== "/blog" });
  const pinnedMark = pin.canPin ? pin.isPinned : !!post.isPinned;

  const [viewStatsAnchor, setViewStatsAnchor] = useState(null);
  const [scoreAnchor, setScoreAnchor] = useState(null);
  const [moreAnchor, setMoreAnchor] = useState(null);

  // Số metric hiển thị trực tiếp. Phần còn lại vào "...".
  // Khởi tạo thấp để tránh nháy icon cắt nửa trước khi đo xong.
  const [visibleCount, setVisibleCount] = useState(3);

  const containerRef = useRef(null);
  const measureRefs = useRef([]);

  const metrics = useMemo(
    () => [
      {
        key: "like",
        priority: 0,
        count: likeCount,
        renderIcon: (active) =>
          active ? <ThumbUpIcon fontSize="small" color="primary" /> : <ThumbUpOffAltIcon fontSize="small" />,
        active: myReaction === "like",
        onClick: () => handleReact("like"),
      },
      {
        key: "dislike",
        priority: 1,
        count: dislikeCount,
        renderIcon: (active) =>
          active ? <ThumbDownIcon fontSize="small" color="error" /> : <ThumbDownOffAltIcon fontSize="small" />,
        active: myReaction === "dislike",
        onClick: () => handleReact("dislike"),
      },
      {
        key: "comment",
        priority: 2,
        count: commentCount,
        renderIcon: () => <ChatBubbleOutlineIcon fontSize="small" />,
        onClick: () => onOpenComments(post),
      },
      {
        key: "view",
        priority: 3,
        count: viewCount,
        renderIcon: () => <VisibilityIcon fontSize="small" />,
        onClick: (e) => setViewStatsAnchor(e.currentTarget),
      },
      {
        key: "share",
        priority: 4,
        count: shareCount,
        renderIcon: () => <ShareIcon fontSize="small" />,
        onClick: () => handleShare(),
      },
      {
        key: "score",
        priority: 5,
        count: score,
        renderIcon: () => <GradeIcon fontSize="small" />,
        onClick: (e) => setScoreAnchor(e.currentTarget),
      },
      // v2.4.0: chỉ tác giả thấy. Không có số đếm (count: null) — renderMetric/đo/menu "..." đều bỏ qua phần số khi count null.
      ...(pin.canPin
        ? [
            {
              key: "pin",
              priority: 6,
              count: null,
              label: pin.isPinned ? "Gỡ ghim khỏi trang cá nhân" : "Ghim lên trang cá nhân",
              renderIcon: (active) =>
                active ? <PushPinIcon fontSize="small" color="primary" /> : <PushPinOutlinedIcon fontSize="small" />,
              active: pin.isPinned,
              disabled: pin.busy,
              onClick: () => pin.toggle(),
            },
          ]
        : []),
    ],
    // handleReact/handleShare ổn định (useCallback trong hook) — không stale auth.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [likeCount, dislikeCount, commentCount, viewCount, shareCount, score, myReaction, post, handleReact, handleShare, onOpenComments, pin.canPin, pin.isPinned, pin.busy, pin.toggle]
  );

  const checkOverflow = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;
    const available = container.clientWidth;
    if (available <= 0) return;

    // getBoundingClientRect chính xác hơn offsetWidth; margin không nằm trong width
    // nên cộng thêm GAP (khớp ml: 0.5 ≈ 4px trên theme mặc định).
    const GAP = 4;
    const widths = metrics.map((_, i) => {
      const el = measureRefs.current[i];
      if (!el) return 0;
      const w = el.getBoundingClientRect().width;
      return w;
    });
    // Chưa đo được (font/icon chưa layout) → thử lại frame sau, tránh nhét quá nhiều → icon cắt nửa
    if (widths.some((w) => w < 8)) {
      requestAnimationFrame(() => checkOverflow());
      return;
    }
    const moreEl = measureRefs.current[metrics.length];
    const moreW = moreEl ? Math.max(moreEl.getBoundingClientRect().width, 32) : 40;

    // Chọn số metric lớn nhất sao cho: sum(widths + gap) + (còn ẩn ? moreW : 0) <= available
    // Không cho “lọt” metric cuối bị CSS overflow:hidden cắt một nửa.
    let canShow = 0;
    for (let n = metrics.length; n >= 0; n--) {
      let used = 0;
      for (let i = 0; i < n; i++) {
        used += widths[i] + (i > 0 ? GAP : 0);
      }
      const needMore = n < metrics.length ? moreW + (n > 0 ? GAP : 0) : 0;
      if (used + needMore <= available - 2) {
        canShow = n;
        break;
      }
    }
    setVisibleCount(canShow);
  }, [metrics]);

  useLayoutEffect(() => {
    checkOverflow();
    const container = containerRef.current;
    if (!container || typeof ResizeObserver === "undefined") return undefined;
    const ro = new ResizeObserver(() => {
      checkOverflow();
    });
    ro.observe(container);
    // Font icon MUI có thể load chậm → đo lại sau một nhịp
    const t = window.setTimeout(() => checkOverflow(), 100);
    return () => {
      ro.disconnect();
      window.clearTimeout(t);
    };
  }, [checkOverflow]);

  const visible = metrics.slice(0, visibleCount);
  const hidden = metrics.slice(visibleCount);

  const renderMetric = (m, opts = {}) => (
    <Box
      key={m.key}
      sx={{
        display: "inline-flex",
        alignItems: "center",
        gap: 0.25,
        flexShrink: 0,
        ml: opts.first ? 0 : 0.5,
      }}
    >
      <IconButton
        size="small"
        onClick={m.onClick}
        disabled={!!m.disabled || (busy && (m.key === "like" || m.key === "dislike"))}
        aria-label={m.label || m.key}
        title={m.label || undefined}
      >
        {m.renderIcon(m.active)}
      </IconButton>
      {m.count != null && (
        <Typography
          variant="body2"
          title={String(m.count)}
          sx={{
            fontVariantNumeric: "tabular-nums",
            whiteSpace: "nowrap",
            flexShrink: 0,
          }}
        >
          {m.key === "score" ? formatScore(m.count) : formatCount(m.count)}
        </Typography>
      )}
    </Box>
  );

  return (
    <Card sx={{ mb: 2 }}>
      <CardHeader
        avatar={<UserAvatar user={post.author} />}
        title={
          <Box sx={{ display: "flex", alignItems: "center", gap: 1, flexWrap: "wrap" }}>
            <UserName user={post.author} />
            <UserTagChip user={post.author} />
          </Box>
        }
        subheader={
          <Box component="span" sx={{ display: "inline-flex", alignItems: "center", gap: 0.75, flexWrap: "wrap" }}>
            <span>{formatRelativeTime(post.createdAt)}</span>
            {/* Bài đang được ghim lên trang cá nhân của tác giả: chỉ icon (v2.4.1 bỏ chữ "Đã ghim"); nhãn có trong title + trình đọc màn hình */}
            {pinnedMark && (
              <PushPinIcon data-testid="pinned-mark" titleAccess="Đã ghim" color="primary" sx={{ fontSize: 14 }} />
            )}
          </Box>
        }
      />

      {post.coverImageUrl && (
        <CardMedia
          component="img"
          src={post.coverImageUrl}
          alt={post.title}
          sx={{ aspectRatio: "16 / 9", objectFit: "cover" }}
        />
      )}

      <CardContent sx={{ pb: 1 }}>
        <Typography
          variant="h6"
          sx={{
            cursor: "pointer",
            wordBreak: "break-word",
            overflowWrap: "break-word",
            display: "-webkit-box",
            WebkitLineClamp: 5,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
          onClick={() => navigate(`${detailPath}/${post.id}`)}
        >
          {post.title}
        </Typography>
        {post.excerpt && (
          <Typography
            variant="body2"
            color="text.secondary"
            sx={{
              mt: 0.5,
              wordBreak: "break-word",
              display: "-webkit-box",
              WebkitLineClamp: 3,
              WebkitBoxOrient: "vertical",
              overflow: "hidden",
            }}
          >
            {post.excerpt}
          </Typography>
        )}
        <HashtagChips hashtags={post.hashtags} gap={0.5} sx={{ mt: 1 }} />
      </CardContent>

      <CardActions sx={{ justifyContent: "space-between", px: 2, pb: 1.5, gap: 1, flexWrap: "nowrap" }}>
        <Box
          ref={containerRef}
          sx={{
            display: "flex",
            alignItems: "center",
            minWidth: 0,
            flex: "1 1 auto",
            overflow: "hidden",
          }}
        >
          {visible.map((m, i) => renderMetric(m, { first: i === 0 }))}

          {hidden.length > 0 && (
            <IconButton
              size="small"
              sx={{ ml: 0.5, flexShrink: 0 }}
              onClick={(e) => setMoreAnchor(e.currentTarget)}
              aria-label="Thêm chỉ số"
            >
              <MoreHorizIcon fontSize="small" />
            </IconButton>
          )}
        </Box>

        {/* Bản đo ẩn từng metric + nút "..." để tính overflow */}
        <Box
          aria-hidden="true"
          sx={{
            position: "absolute",
            left: -9999,
            top: 0,
            visibility: "hidden",
            pointerEvents: "none",
            display: "flex",
            alignItems: "center",
            whiteSpace: "nowrap",
            // Không height:0 / overflow:hidden — nếu không, width đo ra 0 → nhét quá nhiều metric
          }}
        >
          {metrics.map((m, i) => (
            <Box
              key={m.key}
              ref={(el) => {
                measureRefs.current[i] = el;
              }}
              sx={{ display: "inline-flex", alignItems: "center", gap: 0.25, ml: i ? 0.5 : 0 }}
            >
              <IconButton size="small" tabIndex={-1}>
                {m.renderIcon(false)}
              </IconButton>
              {m.count != null && <Typography variant="body2">{m.key === "score" ? formatScore(m.count) : formatCount(m.count)}</Typography>}
            </Box>
          ))}
          <Box
            ref={(el) => {
              measureRefs.current[metrics.length] = el;
            }}
            sx={{ display: "inline-flex", ml: 0.5 }}
          >
            <IconButton size="small" tabIndex={-1}>
              <MoreHorizIcon fontSize="small" />
            </IconButton>
          </Box>
        </Box>

        <Button size="small" onClick={() => navigate(`${detailPath}/${post.id}`)} sx={{ flexShrink: 0 }}>
          Xem bài
        </Button>
      </CardActions>

      {/* Menu "..." — các chỉ số bị ẩn vì thiếu chỗ */}
      <Popover
        open={!!moreAnchor}
        anchorEl={moreAnchor}
        onClose={() => setMoreAnchor(null)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        transformOrigin={{ vertical: "bottom", horizontal: "center" }}
        onClick={(e) => e.stopPropagation()}
      >
        <Box sx={{ p: 1.5, minWidth: 180 }}>
          <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>
            Chỉ số
          </Typography>
          <Stack spacing={0.5}>
            {hidden.map((m) => (
              <Box
                key={m.key}
                onClick={(e) => {
                  setMoreAnchor(null);
                  m.onClick?.(e);
                }}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 2,
                  px: 1,
                  py: 0.75,
                  borderRadius: 1,
                  cursor: "pointer",
                  "&:hover": { bgcolor: "action.hover" },
                }}
              >
                <Stack direction="row" spacing={1} alignItems="center">
                  {m.renderIcon(m.active)}
                  <Typography variant="body2" sx={{ textTransform: m.label ? "none" : "capitalize" }}>
                    {m.label
                      ? m.label
                      : m.key === "like"
                      ? "Thích"
                      : m.key === "dislike"
                        ? "Không thích"
                        : m.key === "comment"
                          ? "Bình luận"
                          : m.key === "share"
                            ? "Chia sẻ"
                            : m.key === "score"
                              ? "Điểm bài viết"
                              : "Lượt xem"}
                  </Typography>
                </Stack>
                {m.count != null && (
                  <Typography variant="body2" fontWeight={600} title={String(m.count)}>
                    {m.key === "score" ? formatScore(m.count) : formatCount(m.count)}
                  </Typography>
                )}
              </Box>
            ))}
          </Stack>
          {hidden.some((m) => m.key === "view") && (
            <>
              <Divider sx={{ my: 1 }} />
              <Typography variant="caption" color="text.secondary">
                Chạm “Lượt xem” để xem chi tiết Bot A.I
              </Typography>
            </>
          )}
        </Box>
      </Popover>

      <ViewStatsPopover
        anchorEl={viewStatsAnchor}
        onClose={() => setViewStatsAnchor(null)}
        viewCount={viewCount}
        aiViewCount={aiViewCount}
      />

      <PostScorePopover
        anchorEl={scoreAnchor}
        onClose={() => setScoreAnchor(null)}
        viewCount={viewCount}
        likeCount={likeCount}
        dislikeCount={dislikeCount}
        commentCount={commentCount}
        shareCount={shareCount}
        score={score}
      />
    </Card>
  );
}
