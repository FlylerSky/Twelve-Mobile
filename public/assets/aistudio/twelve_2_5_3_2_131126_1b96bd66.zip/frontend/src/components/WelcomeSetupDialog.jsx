import React, { useEffect, useState } from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, Avatar, Stack, Typography, useMediaQuery, useTheme } from "@mui/material";
import { useAuth } from "../context/AuthContext";
import { useSnackbar } from "../context/SnackbarContext";
import { updateMe } from "../api/users.api";
import { listCountries } from "../api/countries.api";
import AvatarCropper from "./AvatarCropper";
import useAvatarUpload from "../hooks/useAvatarUpload";
import { ProfileFieldsGrid } from "./ProfileFields";

/**
 * v2.2.0: màn hình Chào mừng dùng lại các khối chung với Cài đặt > Tài khoản > Thông tin (ProfileFieldsGrid, useAvatarUpload).
 * Tên thật KHÔNG còn ở đây: người dùng đã khai lúc đăng ký, và từ 2.2.0 chỉ xem/đổi được ở Cài đặt sau khi nhập lại mật khẩu
 * (backend cũng từ chối `fullName` ở PATCH /users/me).
 */
export default function WelcomeSetupDialog() {
  const { showWelcome, dismissWelcome, profile, refreshProfile } = useAuth();
  const snackbar = useSnackbar();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const [countries, setCountries] = useState([]);
  const [form, setForm] = useState({ displayName: "", birthday: "", gender: "", country: "" });
  const [avatarUrl, setAvatarUrl] = useState(null);
  const [cropperOpen, setCropperOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (showWelcome && profile) {
      setForm({
        displayName: profile.displayName || "",
        birthday: profile.birthday || "",
        gender: profile.gender || "",
        country: profile.country || "",
      });
      setAvatarUrl(profile.avatarUrl || null);
      listCountries().then(setCountries).catch(() => {});
    }
  }, [showWelcome, profile]);

  const handleChange = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  const handleCropped = useAvatarUpload({ onUploaded: setAvatarUrl });

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateMe(form);
      await refreshProfile();
      snackbar.success("Thiết lập tài khoản hoàn tất. Chào mừng bạn đến với Twelve!");
      dismissWelcome();
    } catch (err) {
      snackbar.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <Dialog
        open={!!showWelcome}
        onClose={dismissWelcome}
        fullWidth
        maxWidth="md"
        fullScreen={isMobile}
        PaperProps={{
          sx: isMobile ? { borderRadius: 0 } : { m: 2, width: { sm: "90vw" }, maxWidth: 720 },
        }}
      >
        <DialogTitle>Chào mừng bạn đến với Twelve 🎉</DialogTitle>
        <DialogContent dividers>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Đây là lần đăng nhập đầu tiên của bạn. Hãy hoàn thiện hồ sơ trước khi bắt đầu (email và mật khẩu không thể thay đổi ở đây; có thể đổi sau
            trong Cài đặt &gt; Tài khoản).
          </Typography>

          <Stack alignItems="center" sx={{ mb: 3 }}>
            <Avatar src={avatarUrl} sx={{ width: 96, height: 96, mb: 1 }}>
              {form.displayName?.[0]}
            </Avatar>
            <Button size="small" onClick={() => setCropperOpen(true)}>
              Chọn / chỉnh ảnh đại diện
            </Button>
          </Stack>

          <ProfileFieldsGrid form={form} onChange={handleChange} countries={countries} />
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={dismissWelcome}>Để sau</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving}>
            {saving ? "Đang lưu..." : "Hoàn tất"}
          </Button>
        </DialogActions>
      </Dialog>

      <AvatarCropper open={cropperOpen} onClose={() => setCropperOpen(false)} onCropped={handleCropped} />
    </>
  );
}
