import React from "react";
import { Box, Stack, Typography, Paper, CircularProgress, Divider } from "@mui/material";
import EmojiEventsIcon from "@mui/icons-material/EmojiEvents";
import useIncrementalReveal from "../hooks/useIncrementalReveal";

const MEDAL = [
  { color: "#FFD700", glow: "rgba(255, 215, 0, 0.35)", label: "Vàng" },
  { color: "#C0C0C0", glow: "rgba(192, 192, 192, 0.3)", label: "Bạc" },
  { color: "#CD7F32", glow: "rgba(205, 127, 50, 0.3)", label: "Đồng" },
];

/**
 * ==== v2.0.0 — Bảng xếp hạng TỔNG QUÁT (podium top 3 + hạng 4–10 + 11–100) ====
 * RankingList (người dùng) và HashtagRankingList (hashtag) trước đây là 2 file
 * ~260 dòng gần như giống hệt nhau (chỉ khác avatar/tên/dòng phụ/cách bấm).
 * Toàn bộ layout + tải dần nằm ở đây; 2 danh sách kia chỉ còn truyền "cách vẽ".
 *
 * props:
 *  - ranking: [{ rank, ... }]
 *  - getKey(item): khoá React
 *  - getName(item): tên hiển thị
 *  - renderNameExtra(item): (v2.4.0, tuỳ chọn) phần gắn cạnh tên — vd. huy hiệu; bấm vào đó không kích hoạt onSelect
 *  - getSubtitle(item): dòng phụ (null → ẩn)
 *  - getScoreText(item): điểm đã định dạng
 *  - renderAvatar(item, { size, color }): avatar (color = màu huy chương ở podium)
 *  - onSelect(item): khi bấm 1 dòng/thẻ
 */
export default function RankingBoard({
  ranking = [],
  loading = false,
  emptyHint = "Chưa có dữ liệu xếp hạng.",
  scoreLabel,
  getKey,
  getName,
  getSubtitle,
  getScoreText,
  renderAvatar,
  renderNameExtra,
  onSelect,
}) {
  const restTier = ranking.filter((x) => x.rank >= 11 && x.rank <= 100);
  // v0.10.8.2 — Hook PHẢI gọi trước mọi return sớm bên dưới (Rules of Hooks).
  const { visibleCount, sentinelRef, hasMore } = useIncrementalReveal(restTier.length, 20);

  if (loading) {
    return (
      <Box sx={{ py: 6, display: "flex", flexDirection: "column", alignItems: "center", gap: 1.5 }}>
        <CircularProgress size={28} />
        <Typography variant="body2" color="text.secondary">
          Đang tải bảng xếp hạng…
        </Typography>
      </Box>
    );
  }

  if (!ranking.length) {
    return (
      <Typography variant="body2" color="text.secondary" sx={{ py: 4, textAlign: "center" }}>
        {emptyHint}
      </Typography>
    );
  }

  const top1 = ranking.find((x) => x.rank === 1);
  const top2 = ranking.find((x) => x.rank === 2);
  const top3 = ranking.find((x) => x.rank === 3);
  const topTier = ranking.filter((x) => x.rank >= 4 && x.rank <= 10);
  const visibleRestTier = restTier.slice(0, visibleCount);

  const common = { getName, getSubtitle, getScoreText, renderAvatar, renderNameExtra, scoreLabel };

  return (
    <Box>
      {/* Podium: thứ tự hiển thị 2 — 1 — 3 */}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", sm: "1fr 1.15fr 1fr" },
          gap: 1.5,
          alignItems: "end",
          mb: 3,
        }}
      >
        {/* Rank 2 — left on desktop, second on mobile */}
        <Box sx={{ order: { xs: 2, sm: 1 } }}>
          {top2 ? (
            <PodiumCard item={top2} medal={MEDAL[1]} onClick={() => onSelect?.(top2)} size="md" {...common} />
          ) : (
            <Box sx={{ minHeight: 40 }} />
          )}
        </Box>
        {/* Rank 1 — center */}
        <Box sx={{ order: { xs: 1, sm: 2 } }}>
          {top1 ? (
            <PodiumCard item={top1} medal={MEDAL[0]} onClick={() => onSelect?.(top1)} size="lg" {...common} />
          ) : null}
        </Box>
        {/* Rank 3 */}
        <Box sx={{ order: { xs: 3, sm: 3 } }}>
          {top3 ? (
            <PodiumCard item={top3} medal={MEDAL[2]} onClick={() => onSelect?.(top3)} size="md" {...common} />
          ) : (
            <Box sx={{ minHeight: 40 }} />
          )}
        </Box>
      </Box>

      {topTier.length > 0 && (
        <Paper variant="outlined" sx={{ borderRadius: 1, mb: 2, overflow: "hidden" }}>
          <TierHeader>Hạng 4 – 10</TierHeader>
          <Divider />
          {topTier.map((x, i) => (
            <RankRow
              key={getKey(x)}
              item={x}
              onClick={() => onSelect?.(x)}
              emphasized
              last={i === topTier.length - 1}
              {...common}
            />
          ))}
        </Paper>
      )}

      {restTier.length > 0 && (
        <Paper variant="outlined" sx={{ borderRadius: 1, overflow: "hidden" }}>
          <TierHeader>Hạng 11 – 100</TierHeader>
          <Divider />
          {visibleRestTier.map((x, i) => (
            <RankRow
              key={getKey(x)}
              item={x}
              onClick={() => onSelect?.(x)}
              last={i === visibleRestTier.length - 1 && !hasMore}
              {...common}
            />
          ))}
          {hasMore && (
            <Box ref={sentinelRef} sx={{ display: "flex", justifyContent: "center", py: 1.5 }}>
              <CircularProgress size={18} />
            </Box>
          )}
        </Paper>
      )}
    </Box>
  );
}

function TierHeader({ children }) {
  return (
    <Box sx={{ px: 2, py: 1, bgcolor: "action.hover" }}>
      <Typography variant="caption" fontWeight={700} color="text.secondary">
        {children}
      </Typography>
    </Box>
  );
}

function PodiumCard({ item, medal, onClick, size = "md", getName, getSubtitle, getScoreText, renderAvatar, renderNameExtra, scoreLabel }) {
  const lg = size === "lg";
  const subtitle = getSubtitle?.(item);
  return (
    <Paper
      onClick={onClick}
      variant="outlined"
      sx={{
        p: lg ? 2.25 : 1.75,
        textAlign: "center",
        cursor: "pointer",
        borderRadius: 1,
        borderColor: medal.color,
        borderWidth: lg ? 2 : 1,
        boxShadow: `0 0 0 1px ${medal.glow}`,
        transition: "transform 0.15s, box-shadow 0.15s",
        "&:hover": { transform: "translateY(-3px)", boxShadow: `0 6px 20px ${medal.glow}` },
      }}
    >
      <EmojiEventsIcon sx={{ color: medal.color, fontSize: lg ? 36 : 28, mb: 0.5 }} />
      <Box sx={{ mx: "auto", mb: 1, width: "fit-content" }}>
        {renderAvatar(item, { size: lg ? 72 : 56, color: medal.color })}
      </Box>
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 0.5, minWidth: 0 }}>
        <Typography variant={lg ? "subtitle1" : "body2"} fontWeight={700} noWrap sx={{ minWidth: 0 }}>
          #{item.rank} {getName(item)}
        </Typography>
        {renderNameExtra?.(item)}
      </Box>
      {subtitle && (
        <Typography variant="caption" color="text.secondary" display="block" noWrap>
          {subtitle}
        </Typography>
      )}
      <Typography variant={lg ? "h5" : "h6"} fontWeight={800} sx={{ mt: 0.75, color: medal.color, lineHeight: 1.2 }}>
        {getScoreText(item)}
      </Typography>
      <Typography variant="caption" color="text.secondary">
        {scoreLabel}
      </Typography>
    </Paper>
  );
}

function RankRow({
  item,
  onClick,
  emphasized = false,
  last = false,
  getName,
  getSubtitle,
  getScoreText,
  renderAvatar,
  renderNameExtra,
  scoreLabel,
}) {
  const subtitle = getSubtitle?.(item);
  return (
    <Stack
      direction="row"
      alignItems="center"
      spacing={1.25}
      onClick={onClick}
      sx={{
        px: 1.75,
        py: emphasized ? 1.15 : 0.85,
        cursor: "pointer",
        borderBottom: last ? "none" : "1px solid",
        borderColor: "divider",
        "&:hover": { bgcolor: "action.hover" },
      }}
    >
      <Typography
        variant="body2"
        fontWeight={700}
        color="text.secondary"
        sx={{ width: 28, flexShrink: 0, textAlign: "center", fontVariantNumeric: "tabular-nums" }}
      >
        {item.rank}
      </Typography>
      {renderAvatar(item, { size: emphasized ? 40 : 32 })}
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, minWidth: 0 }}>
          <Typography variant={emphasized ? "subtitle2" : "body2"} fontWeight={emphasized ? 700 : 500} noWrap sx={{ minWidth: 0 }}>
            {getName(item)}
          </Typography>
          {renderNameExtra?.(item)}
        </Box>
        {subtitle && (
          <Typography variant="caption" color="text.secondary" noWrap display="block">
            {subtitle}
          </Typography>
        )}
      </Box>
      <Box sx={{ textAlign: "right", flexShrink: 0 }}>
        <Typography variant="body2" fontWeight={700} color={emphasized ? "primary.main" : "text.primary"}>
          {getScoreText(item)}
        </Typography>
        <Typography variant="caption" color="text.secondary" sx={{ display: { xs: "none", sm: "block" } }}>
          {scoreLabel}
        </Typography>
      </Box>
    </Stack>
  );
}
