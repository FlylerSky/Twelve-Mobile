import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Box,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import useCommentThread from "../hooks/useCommentThread";
import CommentThread from "./comments/CommentThread";
import CommentComposer from "./comments/CommentComposer";
import { UserAvatar } from "./UserIdentity";
import { profilePath } from "../utils/profilePath";

/**
 * Hộp bình luận mở từ card bài viết (danh sách).
 * v2.0.0: phần LOGIC (tải/realtime/gửi/sửa/xóa) nằm ở `useCommentThread`, phần
 * GIAO DIỆN (thẻ bình luận, danh sách, ô soạn) nằm ở `components/comments/*` —
 * dùng chung với trang chi tiết bài viết (PostDetailPage). File này chỉ còn là
 * "vỏ" Dialog.
 *
 * props:
 * - open, onClose
 * - post: { id, commentCount }
 * - api: postsApi hoặc blogsApi
 * - onCommentCountChange: (delta) => void
 */
export default function CommentModal({ open, onClose, post, api, onCommentCountChange, collectionName = "posts" }) {
  const { isLoggedIn, profile } = useAuth();
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const thread = useCommentThread({
    api,
    id: post?.id,
    collectionName,
    active: open && !!post,
    onCountChange: onCommentCountChange,
  });

  // Bấm vào người dùng: đóng hộp bình luận rồi mới chuyển sang trang cá nhân.
  // v2.4.2.1: nhận ĐỐI TƯỢNG người dùng và đi tới /u/@<tag> (không còn /u/<UID>).
  const goToProfile = (user) => {
    const path = profilePath(user);
    if (!path) return;
    onClose?.();
    navigate(path);
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth
      maxWidth="sm"
      fullScreen={isMobile}
      PaperProps={{
        sx: isMobile ? { borderRadius: 0 } : { m: 2, width: { sm: "90vw" }, maxWidth: 600 },
      }}
    >
      {/* Avatar người đang đăng nhập đứng TRƯỚC chữ "Bình luận" (giống header ở PostDetailPage). */}
      <DialogTitle sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 1.25 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.25, minWidth: 0, flex: 1 }}>
          {isLoggedIn && <UserAvatar user={profile} size={36} onProfileClick={goToProfile} />}
          <Box component="span" sx={{ minWidth: 0 }}>
            Bình luận
          </Box>
        </Box>
        <IconButton onClick={onClose} edge="end" aria-label="Đóng" sx={{ flexShrink: 0 }}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent
        dividers
        ref={thread.containerRef}
        sx={{ maxHeight: isMobile ? "none" : "60vh", flex: isMobile ? 1 : undefined, overflowY: "auto" }}
      >
        <CommentThread
          thread={thread}
          onProfileClick={goToProfile}
          emptyText="Chưa có bình luận nào. Hãy là người đầu tiên bình luận!"
          spinnerPy={4}
        />
      </DialogContent>

      <Box sx={{ p: 1.5, borderTop: "1px solid", borderColor: "divider" }}>
        <CommentComposer onSubmit={thread.send} sending={thread.sending} gateAlign="center" />
      </Box>
    </Dialog>
  );
}
