/**
 * ==== v2.0.7 — Kho font chữ của Twelve ====
 *
 * Phân loại (xem Settings > Ứng dụng > Font chữ):
 *   #1   Font chữ chính thức (do nền tảng hỗ trợ sẵn)
 *     #1.1 Font chữ server — SA cài trên server (link ngoài hoặc file có sẵn trên server). [v2.0.8]
 *     #1.2 Font chữ client — khai báo cứng trong mã nguồn frontend (file trong public/fonts) hoặc link ngoài. [v2.0.7]
 *   #2   Font tuỳ chỉnh qua URL trực tiếp do người dùng nhập (lưu trên thiết bị).                          [v2.0.8]
 *
 * Mỗi font trong danh sách có `source` ("client" | "server" | "custom") để các nguồn sau này dùng chung
 * giao diện chọn font và `ensureFont()` mà không phải sửa lại logic áp dụng.
 *
 * CÁCH THÊM FONT CHỮ CLIENT (#1.2):
 *   1. Đặt file .woff2 vào frontend/public/fonts/ (hoặc dùng URL https ngoài — nhớ mở `font-src` trong CSP).
 *   2. Thêm 1 phần tử vào CLIENT_FONTS bên dưới. `family` là TÊN ĐỊNH DANH CSS duy nhất của font.
 *   3. Font phải hỗ trợ đủ tiếng Việt (dấu ă â ê ô ơ ư đ + thanh dấu) — các ký tự thiếu sẽ rơi về FALLBACK_STACK.
 */

export const FALLBACK_STACK = '"Google Sans", "Roboto", "Helvetica", "Arial", sans-serif';
export const DEFAULT_FONT_ID = "default";

export const FONT_SOURCE_LABELS = {
  client: "Font chữ có sẵn trong ứng dụng",
  server: "Font chữ do quản trị viên cài đặt",
  custom: "Font chữ tuỳ chỉnh",
};

/** @type {Array<{id:string,label:string,source:"client",family:string,stack:string,note?:string,faces:Array<{url:string,weight:string,style:string}>}>} */
export const CLIENT_FONTS = [
  {
    id: DEFAULT_FONT_ID,
    label: "Mặc định (Google Sans)",
    source: "client",
    stack: FALLBACK_STACK,
    note: "Font mặc định của Twelve.",
    faces: [], // nạp từ Google Fonts trong index.html
  },
  {
    id: "svn-headliner-no45",
    label: "SVN-Headliner No. 45",
    source: "client",
    family: "SVN-Headliner No. 45",
    stack: `"SVN-Headliner No. 45", ${FALLBACK_STACK}`,
    note: "Font trang trí (display) hỗ trợ tiếng Việt — đẹp ở tiêu đề, nhưng khó đọc nếu dùng cho đoạn văn dài.",
    faces: [
      // Font chỉ có 1 độ đậm (Regular). Khai báo khoảng 100–900 để trình duyệt KHÔNG tự "làm đậm giả"
      // (faux bold) ở các chỗ giao diện dùng fontWeight 500/600/700 — chữ sẽ giữ nguyên nét thật của font.
      { url: "/fonts/svn-headliner-no45.woff2", weight: "100 900", style: "normal" },
    ],
  },
];

/** Danh sách đầy đủ (hiện chỉ gồm font client; #1.1 và #2 sẽ được ghép vào đây ở các bản sau). */
export function getAllFonts(serverFonts = [], customFonts = []) {
  return [...CLIENT_FONTS, ...serverFonts, ...customFonts];
}

export function findFont(id, list = CLIENT_FONTS) {
  return list.find((f) => f.id === id) || null;
}

/** Id không hợp lệ / font đã bị gỡ => về font mặc định (không bao giờ ném lỗi). */
export function resolveFont(id, list = CLIENT_FONTS) {
  return findFont(id, list) || findFont(DEFAULT_FONT_ID, CLIENT_FONTS);
}

// ------------------------------------------------------------------ Dựng định nghĩa font từ nguồn ngoài
const FORMAT_BY_EXT = { woff2: "woff2", woff: "woff", ttf: "truetype", otf: "opentype" };

export function formatFromUrl(url) {
  try {
    const m = /\.([A-Za-z0-9]+)$/.exec(new URL(url).pathname);
    return m ? FORMAT_BY_EXT[m[1].toLowerCase()] || null : null;
  } catch (_) {
    return null;
  }
}

/** Tên font CSS nội bộ — duy nhất theo id nên không đụng tên font hệ thống. */
function internalFamily(id) {
  return `Twelve ${id}`;
}

function buildExternalFont({ id, label, source, url, format, weight, note }) {
  const family = internalFamily(id);
  return {
    id,
    label,
    source,
    family,
    stack: `"${family}", ${FALLBACK_STACK}`,
    note: note || "",
    // Khoảng 100–900 mặc định: font 1 độ đậm không bị trình duyệt "làm đậm giả" (xem ghi chú ở CLIENT_FONTS).
    faces: [{ url, weight: weight || "100 900", style: "normal", format: format || formatFromUrl(url) || null }],
  };
}

// ------------------------------------------------------------------ #1.1 Font server
const SERVER_CACHE_KEY = "twelve_server_fonts";

/** Chuyển bản ghi công khai từ backend (GET /api/fonts) thành định nghĩa font; `apiBase` để ghép URL file tương đối. */
export function fontFromServerEntry(entry, apiBase) {
  if (!entry || typeof entry.id !== "string" || typeof entry.url !== "string") return null;
  let url = entry.url;
  if (entry.relative) {
    const base = String(apiBase || "").replace(/\/$/, "");
    if (!base) return null;
    url = base + entry.url;
  }
  if (!/^https?:\/\//i.test(url)) return null; // bỏ qua mọi thứ không phải http(s)
  return buildExternalFont({ id: entry.id, label: String(entry.label || entry.id), source: "server", url, format: entry.format, weight: entry.weight, note: entry.note });
}

/** Cache danh sách font server (bản ghi công khai thô) để lần mở sau dùng được font đã chọn ngay từ khung hình đầu. */
export function readServerFontsCache(apiBase) {
  try {
    const raw = JSON.parse(localStorage.getItem(SERVER_CACHE_KEY) || "[]");
    return Array.isArray(raw) ? raw.map((e) => fontFromServerEntry(e, apiBase)).filter(Boolean) : [];
  } catch (_) {
    return [];
  }
}

export function writeServerFontsCache(entries) {
  try {
    localStorage.setItem(SERVER_CACHE_KEY, JSON.stringify(entries));
  } catch (_) {
    /* bỏ qua */
  }
}

// ------------------------------------------------------------------ #2 Font tuỳ chỉnh (URL do người dùng nhập)
const CUSTOM_KEY = "twelve_custom_fonts";
export const MAX_CUSTOM_FONTS = 5;

/** Kiểm tra form thêm font tuỳ chỉnh. Trả { label, url } đã chuẩn hoá hoặc { error }. */
export function validateCustomFontInput(input, existing = []) {
  const url = String((input && input.url) || "").trim();
  if (!url) return { error: "Hãy nhập link trực tiếp tới file font." };
  if (url.length > 500) return { error: "Link quá dài (tối đa 500 ký tự)." };
  let u;
  try {
    u = new URL(url);
  } catch (_) {
    return { error: "Link không hợp lệ." };
  }
  if (u.protocol !== "https:") return { error: "Link phải bắt đầu bằng https://." };
  if (u.username || u.password) return { error: "Link không được chứa tên đăng nhập/mật khẩu." };
  const host = u.hostname.toLowerCase();
  if (!host.includes(".") || host.endsWith(".local") || /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(":") || host.startsWith("[")) {
    return { error: "Link phải dùng tên miền công khai (không dùng localhost hoặc địa chỉ IP)." };
  }
  const ext = (/\.([A-Za-z0-9]+)$/.exec(u.pathname) || [])[1];
  if (host === "fonts.googleapis.com" || (ext && ext.toLowerCase() === "css")) {
    return { error: "Đây là link CSS. Hãy dùng link trực tiếp tới FILE font (.woff2/.woff/.ttf/.otf)." };
  }
  if (ext && !FORMAT_BY_EXT[ext.toLowerCase()] && /^[A-Za-z0-9]{2,5}$/.test(ext)) {
    return { error: "Định dạng không được hỗ trợ. Dùng .woff2, .woff, .ttf hoặc .otf." };
  }
  if (existing.some((f) => f.faces && f.faces[0] && f.faces[0].url === u.toString())) {
    return { error: "Bạn đã thêm font này rồi." };
  }
  if (existing.length >= MAX_CUSTOM_FONTS) return { error: `Tối đa ${MAX_CUSTOM_FONTS} font tuỳ chỉnh. Hãy xoá bớt trước khi thêm.` };

  let label = String((input && input.label) || "").replace(/\s+/g, " ").trim().slice(0, 40);
  if (!label) {
    const file = decodeURIComponent((u.pathname.split("/").pop() || "").replace(/\.[A-Za-z0-9]+$/, "")).replace(/[-_]+/g, " ").trim();
    label = (file || "Font tuỳ chỉnh").slice(0, 40);
  }
  return { label, url: u.toString() };
}

export function newCustomFontId() {
  return `custom-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

export function customFontFromRecord(rec) {
  if (!rec || typeof rec.id !== "string" || !rec.id.startsWith("custom-") || typeof rec.url !== "string") return null;
  if (!/^https:\/\//i.test(rec.url)) return null;
  return buildExternalFont({ id: rec.id, label: String(rec.label || "Font tuỳ chỉnh").slice(0, 40), source: "custom", url: rec.url, format: rec.format });
}

export function readCustomFonts() {
  try {
    const raw = JSON.parse(localStorage.getItem(CUSTOM_KEY) || "[]");
    return Array.isArray(raw) ? raw.map(customFontFromRecord).filter(Boolean).slice(0, MAX_CUSTOM_FONTS) : [];
  } catch (_) {
    return [];
  }
}

export function writeCustomFonts(fonts) {
  try {
    const records = fonts.map((f) => ({ id: f.id, label: f.label, url: f.faces[0].url, format: f.faces[0].format || null }));
    localStorage.setItem(CUSTOM_KEY, JSON.stringify(records));
  } catch (_) {
    /* bỏ qua */
  }
}

/** Dựng font tuỳ chỉnh mới từ form đã hợp lệ (chưa kiểm tra tải được hay chưa — xem verifyFontLoads). */
export function buildCustomFont({ label, url }) {
  return buildExternalFont({ id: newCustomFontId(), label, source: "custom", url });
}

/** Thử tải font để chắc chắn link dùng được trước khi lưu. Ném Error có thông báo tiếng Việt nếu lỗi. */
export async function verifyFontLoads(font) {
  const ok = await ensureFont(font);
  if (!ok) {
    throw new Error(
      "Không tải được font từ link này. Hãy kiểm tra: link trỏ thẳng tới file font (.woff2/.woff/.ttf/.otf), " +
        "file còn tồn tại, và máy chủ cho phép tải từ trang web khác (CORS)."
    );
  }
}

const loading = new Map(); // fontId -> Promise<boolean>

/**
 * Nạp font (chỉ tải file khi thật sự cần — người dùng chọn font hoặc mở trang xem trước).
 * Dùng FontFace API (không chèn thẻ <style>) nên không phụ thuộc `style-src` của CSP, chỉ cần `font-src`.
 * Trả về Promise<boolean>: true nếu đã sẵn sàng, false nếu lỗi/không hỗ trợ (giao diện vẫn dùng fallback).
 */
export function ensureFont(font) {
  if (!font || !font.faces || font.faces.length === 0) return Promise.resolve(true);
  if (typeof window === "undefined" || typeof FontFace === "undefined" || !document.fonts) return Promise.resolve(false);
  if (loading.has(font.id)) return loading.get(font.id);

  const job = Promise.all(
    font.faces.map((face) => {
      const src = face.format === undefined ? `url("${face.url}") format("woff2")` : face.format ? `url("${face.url}") format("${face.format}")` : `url("${face.url}")`;
      const ff = new FontFace(font.family, src, {
        weight: face.weight,
        style: face.style,
        display: "swap",
      });
      return ff.load().then((loaded) => {
        document.fonts.add(loaded);
      });
    })
  )
    .then(() => true)
    .catch((err) => {
      console.error(`Không tải được font "${font.label}":`, err);
      loading.delete(font.id); // cho phép thử lại lần sau
      return false;
    });

  loading.set(font.id, job);
  return job;
}
