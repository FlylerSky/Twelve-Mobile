import React, { Suspense, lazy, useEffect, useState } from "react";
import useSeo from "./hooks/useSeo";
import { Routes, Route, useNavigate } from "react-router-dom";
import { Container, Typography, Button, Box, CircularProgress } from "@mui/material";
import Navbar from "./components/Navbar";
import PendingSessionGate from "./components/PendingSessionGate";
import NavStackTracker from "./components/NavStackTracker";
import IndexPage from "./pages/IndexPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import BlogPage from "./pages/BlogPage";

// ==== v2.0.11 [Báo cáo bảo mật Phiên 2 — G4] Tách mã theo trang ====
// Trước đây toàn bộ ứng dụng (MUI, Firebase, Quill, react-easy-crop, các panel quản trị…) nằm trong MỘT file JS ~1,46 MB.
// Nay các trang không nằm trên đường vào đầu tiên (Index/Login/Register/Blog) và modal soạn bài (chứa Quill) được tải khi cần.
// Nếu tải chunk thất bại (vd. sau khi deploy bản mới, hash cũ không còn): main.jsx tự tải lại trang 1 lần (`vite:preloadError`).
const PostDetailPage = lazy(() => import("./pages/PostDetailPage"));
const PublicProfilePage = lazy(() => import("./pages/PublicProfilePage"));
const SettingsPage = lazy(() => import("./pages/SettingsPage"));
const TrendingPage = lazy(() => import("./pages/TrendingPage"));
const CreatePostModal = lazy(() => import("./components/CreatePostModal"));

function RouteFallback() {
  return (
    <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "50vh" }} role="status" aria-label="Đang tải trang">
      <CircularProgress />
    </Box>
  );
}
import { postsApi, blogsApi } from "./api/content.api";
import { useCreatePost } from "./context/CreatePostContext";

function NotFoundPage() {
  useSeo({ title: "404 — Không tìm thấy trang | Twelve", robots: "noindex, nofollow" });
  const navigate = useNavigate();
  return (
    <>
      <Navbar />
      <Container maxWidth="sm" sx={{ py: 8, textAlign: "center" }}>
        <Typography variant="h3" fontWeight={700} sx={{ mb: 2 }}>
          404
        </Typography>
        <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
          Không tìm thấy trang bạn yêu cầu.
        </Typography>
        <Box>
          <Button variant="contained" onClick={() => navigate("/")}>
            Về trang chủ
          </Button>
        </Box>
      </Container>
    </>
  );
}

export default function App() {
  const navigate = useNavigate();
  const { open, closeModal, notifyCreated } = useCreatePost();
  // Modal soạn bài (chứa Quill ~chục trăm KB) chỉ được tải lần đầu khi người dùng mở nó; sau đó giữ mount để có hiệu ứng đóng/mở.
  const [modalEverOpened, setModalEverOpened] = useState(false);
  useEffect(() => {
    if (open) setModalEverOpened(true);
  }, [open]);

  const handleCreated = (id) => {
    notifyCreated(id);
    // Sau khi đăng bài thành công, luôn đưa người dùng về trang INDEX để họ
    // thấy ngay bài viết mới — dù trước đó đang đứng ở bất kỳ trang nào.
    navigate("/");
  };

  return (
    <>
      {/* Giám sát toàn cục: nếu có session Firebase nhưng tài khoản chưa
          active (pending), đưa người dùng về /login ở BẤT KỲ route nào —
          không phụ thuộc cách họ vào app (tab mới, URL trực tiếp...). */}
      <PendingSessionGate />
      {/* v2.4.2: ghi lại lịch sử điều hướng để nút Back đi lên đúng (utils/navStack.js) */}
      <NavStackTracker />

      <Suspense fallback={<RouteFallback />}>
      <Routes>
        <Route path="/" element={<IndexPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/trending" element={<TrendingPage />} />
        <Route path="/post/:id" element={<PostDetailPage api={postsApi} backPath="/" />} />
        <Route path="/blog/:id" element={<PostDetailPage api={blogsApi} backPath="/blog" />} />
        <Route path="/u/:ref" element={<PublicProfilePage />} />
        <Route path="/settings" element={<SettingsPage />} />
        {/* v2.1.0: /settings/<tab>/<mục>/<mục con>… — phần sau <tab> do cây Cài đặt (settings/registry.jsx) giải nghĩa */}
        <Route path="/settings/:tab/*" element={<SettingsPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
      </Suspense>

      {/* Modal đăng bài viết được mount 1 lần duy nhất ở đây, có thể mở từ
          Navbar tại BẤT KỲ trang nào thông qua CreatePostContext. */}
      {modalEverOpened && (
        <Suspense fallback={null}>
        <CreatePostModal
          open={open}
          onClose={closeModal}
          api={postsApi}
          onCreated={handleCreated}
          title="Tạo bài viết mới"
        />
        </Suspense>
      )}
    </>
  );
}
