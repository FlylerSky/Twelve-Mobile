import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { canGoBack, planUp } from "../utils/navStack";

/**
 * ==== v2.4.2 — Điều hướng "đi lên" / "quay lại" thống nhất ====
 * Xem utils/navStack.js để biết vì sao: nút Back ở headZone (lùi theo lịch sử) trộn với nút "quay lại" riêng trong trang (liên kết tiến) gây quay vòng.
 *
 *  • useGoUp()  → goUp(target): đi lên trang `target` mà KHÔNG sinh mục lịch sử mới (lùi thẳng nếu đã có, không thì thay thế). Dùng cho MỌI
 *    điều khiển "lên cấp": đường dẫn (breadcrumb), bấm lại tab về gốc, chuyển trang sau khi xoá/không tìm thấy…
 *  • useHeaderBack(pageHeader) → handleBack cho nút Back DUY NHẤT ở headZone. Thứ tự:
 *      1. `pageHeader.onBack()` — trang tự xử lý trạng thái nội bộ (vd. đang xem chi tiết hashtag → về danh sách); trả true = đã xử lý;
 *      2. `pageHeader.backTo` — đường dẫn trang cha (vd. Cài đặt › mục con → mục cha) → goUp;
 *      3. mặc định: lùi lịch sử; vào thẳng (không có gì để lùi) → Trang chủ.
 *    Trang KHÔNG được tự vẽ nút back trong nội dung (tốn diện tích, và là nguồn gây quay vòng) — khai báo `backTo`/`onBack` ở useRegisterPageHeader.
 */
export function useGoUp() {
  const navigate = useNavigate();
  return useCallback(
    (target) => {
      const plan = planUp(target);
      if (plan.type === "pop") navigate(plan.delta);
      else navigate(target, { replace: true });
    },
    [navigate]
  );
}

export function useHeaderBack(pageHeader) {
  const navigate = useNavigate();
  const goUp = useGoUp();
  const backTo = pageHeader?.backTo || null;
  const onBack = pageHeader?.onBack || null;
  return useCallback(() => {
    if (onBack && onBack()) return;
    if (backTo) {
      goUp(backTo);
      return;
    }
    if (canGoBack()) navigate(-1);
    else navigate("/");
  }, [onBack, backTo, goUp, navigate]);
}
