// ==== SEO động cho SPA ====
// v2.0.1: cập nhật document.title / description / robots theo từng trang.
// v2.0.4: bổ sung <link rel="canonical">, Open Graph + Twitter Card, và DỌN LẠI khi rời trang
//         (trước đây thẻ do trang trước đặt — vd. noindex — còn sót lại khi chuyển route).
//
//  - title, description : chuỗi (bỏ qua nếu falsy)
//  - robots   : ví dụ "noindex, nofollow" cho /login,/register,/settings,404; bỏ trống = indexable
//  - canonical: đường dẫn ("/blog", "/trending?tab=hashtag&hashtag=%23a") hoặc URL tuyệt đối.
//               Mặc định = origin + pathname hiện tại (bỏ query/hash). Trang noindex không đặt canonical.
//  - image    : URL ảnh OG tuyệt đối hoặc đường dẫn; mặc định /og-default.png
//  - ogType   : mặc định "website"
import { useEffect } from "react";

const DEFAULT_OG_IMAGE_PATH = "/og-default.png";

function absoluteUrl(value) {
  try {
    return new URL(value, window.location.origin).toString();
  } catch (_) {
    return window.location.origin;
  }
}

/** Gán thẻ <meta>/<link>; trả về hàm hoàn nguyên (khôi phục giá trị cũ hoặc xoá thẻ do mình tạo). */
function setTag(tagName, matchAttr, matchValue, valueAttr, value) {
  const selector = `${tagName}[${matchAttr}="${matchValue}"]`;
  let el = document.head.querySelector(selector);
  const created = !el;
  const previous = el ? el.getAttribute(valueAttr) : null;
  if (!el) {
    el = document.createElement(tagName);
    el.setAttribute(matchAttr, matchValue);
    document.head.appendChild(el);
  }
  el.setAttribute(valueAttr, value);
  return () => {
    if (created) el.parentNode && el.parentNode.removeChild(el);
    else if (previous === null) el.removeAttribute(valueAttr);
    else el.setAttribute(valueAttr, previous);
  };
}

export default function useSeo({ title, description, robots, canonical, image, ogType } = {}) {
  useEffect(() => {
    const reverts = [];
    const noindex = !!robots && /noindex/i.test(robots);

    let previousTitle = null;
    if (title) {
      previousTitle = document.title;
      document.title = title;
    }
    if (description) reverts.push(setTag("meta", "name", "description", "content", description));
    if (robots) reverts.push(setTag("meta", "name", "robots", "content", robots));

    if (!noindex) {
      const canonicalHref = canonical
        ? absoluteUrl(canonical)
        : `${window.location.origin}${window.location.pathname}`;
      reverts.push(setTag("link", "rel", "canonical", "href", canonicalHref));

      reverts.push(setTag("meta", "property", "og:url", "content", canonicalHref));
      reverts.push(setTag("meta", "property", "og:type", "content", ogType || "website"));
      reverts.push(setTag("meta", "property", "og:site_name", "content", "Twelve"));
      const imageUrl = absoluteUrl(image || DEFAULT_OG_IMAGE_PATH);
      reverts.push(setTag("meta", "property", "og:image", "content", imageUrl));
      reverts.push(setTag("meta", "name", "twitter:card", "content", "summary_large_image"));
      reverts.push(setTag("meta", "name", "twitter:image", "content", imageUrl));
      if (title) {
        reverts.push(setTag("meta", "property", "og:title", "content", title));
        reverts.push(setTag("meta", "name", "twitter:title", "content", title));
      }
      if (description) {
        reverts.push(setTag("meta", "property", "og:description", "content", description));
        reverts.push(setTag("meta", "name", "twitter:description", "content", description));
      }
    }

    return () => {
      reverts.reverse().forEach((revert) => revert());
      if (previousTitle !== null) document.title = previousTitle;
    };
  }, [title, description, robots, canonical, image, ogType]);
}
