import { useEffect, useState } from "react";

/**
 * ==== v2.0.0 — Chụp vị trí anchor lúc mở popover ====
 * Neo bằng `anchorPosition` (snapshot) thay vì `anchorEl` — tránh popover nhảy
 * lên góc trái trên khi realtime re-render làm DOM của nút metric bị thay
 * (anchorEl detached, getBoundingClientRect = 0×0). Trước đây logic này bị chép
 * ở ViewStatsPopover và PostScorePopover (v0.10.9) còn AccountScorePopover quên
 * áp dụng; giờ cả ba cùng dùng hook này.
 */
export default function useSnapshotAnchor(anchorEl) {
  const [position, setPosition] = useState(null);

  useEffect(() => {
    if (!anchorEl) {
      setPosition(null);
      return;
    }
    try {
      const r = anchorEl.getBoundingClientRect();
      // Node đã unmount / detached thường ra 0×0 — giữ vị trí cũ
      if (r.width === 0 && r.height === 0) return;
      setPosition({ top: r.top, left: r.left + r.width / 2 });
    } catch {
      /* ignore */
    }
  }, [anchorEl]);

  return position;
}
