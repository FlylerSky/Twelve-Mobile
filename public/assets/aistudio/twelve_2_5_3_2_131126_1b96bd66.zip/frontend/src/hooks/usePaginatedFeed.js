import { useCallback, useEffect, useState } from "react";
import { useSnackbar } from "../context/SnackbarContext";

/**
 * ==== v2.0.0 — Feed phân trang (cursor) dùng chung cho Trang chủ + Blog ====
 * IndexPage và BlogPage trước đây chép cùng một khuôn: state items/cursor/
 * hasMore/loading/loadingMore, loadInitial, loadMore, "đợi isAuthReady", và
 * handleCommentCountChange. Chỉ khác nguồn API + tên field trả về.
 *
 * v0.8.21.2: ĐỢI `isAuthReady === true` mới tải trang đầu — Firebase auth state
 * chưa ổn định lúc mount sẽ làm request không có token → không có myReaction.
 *
 * @param {object} p
 * @param {object} p.api postsApi | blogsApi (cần .list(cursor, limit))
 * @param {string} p.listKey tên field mảng trong response ("posts" | "blogs")
 * @param {boolean} p.isAuthReady
 * @param {number} [p.pageSize=10]
 */
export default function usePaginatedFeed({ api, listKey, isAuthReady, pageSize = 10 }) {
  const snackbar = useSnackbar();
  const [items, setItems] = useState([]);
  const [cursor, setCursor] = useState(null);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  // Tăng sau MỖI lần tải lại trang đầu thành công — để nơi khác (vd. banner "có
  // bài mới") biết "người dùng vừa xem bản mới nhất".
  const [version, setVersion] = useState(0);

  const loadInitial = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.list(null, pageSize);
      const list = res[listKey] || [];
      setItems(list);
      setCursor(res.nextCursor);
      setHasMore(!!res.nextCursor && list.length > 0);
      setVersion((v) => v + 1);
    } catch (err) {
      snackbar.error(err.message);
    } finally {
      setLoading(false);
    }
  }, [api, listKey, pageSize, snackbar]);

  useEffect(() => {
    if (!isAuthReady) return;
    loadInitial();
  }, [isAuthReady, loadInitial]);

  const loadMore = useCallback(async () => {
    if (!cursor) return;
    setLoadingMore(true);
    try {
      const res = await api.list(cursor, pageSize);
      const list = res[listKey] || [];
      setItems((prev) => [...prev, ...list]);
      setCursor(res.nextCursor);
      setHasMore(!!res.nextCursor && list.length > 0);
    } catch (err) {
      snackbar.error(err.message);
    } finally {
      setLoadingMore(false);
    }
  }, [api, listKey, pageSize, cursor, snackbar]);

  /** Cộng/trừ số bình luận của 1 bài trong danh sách (khi gửi/xoá bình luận ở hộp bình luận). */
  const adjustCommentCount = useCallback((postId, delta) => {
    setItems((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, commentCount: (p.commentCount || 0) + delta } : p))
    );
  }, []);

  return {
    items,
    loading,
    loadingMore,
    hasMore,
    loadInitial,
    loadMore,
    adjustCommentCount,
    version,
    headId: items[0]?.id ?? null,
  };
}
