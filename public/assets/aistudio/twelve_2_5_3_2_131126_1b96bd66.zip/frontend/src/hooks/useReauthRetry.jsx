import React, { useCallback, useRef, useState } from "react";
import PasswordConfirmDialog from "../components/PasswordConfirmDialog";
import { isReauthRequired } from "../utils/reauth";

/**
 * ==== v2.5.3 [TW-09] — Gọi API "ghi" của SA, tự mở hộp nhập lại mật khẩu khi backend đòi (403 REAUTH_REQUIRED) rồi THỬ LẠI đúng thao tác đó ====
 * Backend (routes/admin.routes.js) nay bắt `requireRecentAuth` cho PUT /admin/embed-domains, PUT /admin/fonts, DELETE /admin/csp-reports: phiên SA bị lấy không đủ để
 * mở rộng allowlist iframe/ảnh, thêm font ngoài hay xoá bằng chứng CSP. Người dùng thật chỉ thấy một hộp mật khẩu (hiệu lực ~5 phút) rồi thao tác chạy tiếp.
 *
 *   const { run, reauthDialog } = useReauthRetry({ title, description, confirmText });
 *   run(() => updateEmbedDomains(body)).then(ok).catch((err) => { if (!err?.reauthCancelled) showError(err); });
 *   return <>…{reauthDialog}</>;
 *
 * - `run(fn)` gọi `fn()`; lỗi KHÁC REAUTH_REQUIRED ném lại nguyên vẹn; REAUTH_REQUIRED ⇒ mở hộp, sau khi mật khẩu đúng thì chạy lại `fn()` và trả kết quả của lần chạy lại.
 * - Người dùng bấm Hủy ⇒ promise bị từ chối bằng Error có `reauthCancelled: true` (caller bỏ qua, không hiện lỗi).
 * - Lỗi của lần chạy lại (vd. 400 do dữ liệu sai) hiện ngay trong hộp mật khẩu (PasswordConfirmDialog) để người dùng sửa/hủy.
 */
export default function useReauthRetry({ title = "Xác nhận để tiếp tục", description = "Thao tác quản trị này cần nhập lại mật khẩu (hiệu lực 5 phút) để chắc người thực hiện chính là bạn.", confirmText = "Xác nhận và thực hiện" } = {}) {
  const [open, setOpen] = useState(false);
  const pendingRef = useRef(null); // { fn, resolve, reject, settled }

  const run = useCallback(async (fn) => {
    try {
      return await fn();
    } catch (err) {
      if (!isReauthRequired(err)) throw err;
      // Một hộp tại một thời điểm: nếu còn thao tác đang chờ, huỷ nó trước khi nhận thao tác mới.
      if (pendingRef.current && !pendingRef.current.settled) {
        pendingRef.current.settled = true;
        pendingRef.current.reject(Object.assign(new Error("Đã huỷ."), { reauthCancelled: true }));
      }
      return new Promise((resolve, reject) => {
        pendingRef.current = { fn, resolve, reject, settled: false };
        setOpen(true);
      });
    }
  }, []);

  const handleConfirm = useCallback(async () => {
    const p = pendingRef.current;
    if (!p || p.settled) return;
    const result = await p.fn(); // ném lỗi ⇒ PasswordConfirmDialog hiện trong hộp, hộp giữ nguyên
    p.settled = true;
    p.resolve(result);
  }, []);

  const handleClose = useCallback(() => {
    const p = pendingRef.current;
    if (p && !p.settled) {
      p.settled = true;
      p.reject(Object.assign(new Error("Đã huỷ."), { reauthCancelled: true }));
    }
    pendingRef.current = null;
    setOpen(false);
  }, []);

  const reauthDialog = <PasswordConfirmDialog open={open} title={title} description={description} confirmText={confirmText} onConfirm={handleConfirm} onClose={handleClose} />;
  return { run, reauthDialog };
}
