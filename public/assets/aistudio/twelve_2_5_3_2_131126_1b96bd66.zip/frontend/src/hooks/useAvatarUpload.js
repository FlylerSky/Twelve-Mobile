import { useCallback } from "react";
import { useAuth } from "../context/AuthContext";
import { useSnackbar } from "../context/SnackbarContext";
import { uploadAvatar } from "../api/users.api";

/**
 * ==== v2.2.0 — Tải ảnh đại diện (dùng chung Chào mừng + Cài đặt > Tài khoản) ====
 * Trả về hàm `onCropped(blob)` đưa thẳng cho <AvatarCropper onCropped>. Ném lại lỗi để AvatarCropper biết upload thất bại.
 * `onUploaded(avatarUrl)` (tuỳ chọn): để form tự cập nhật ảnh xem trước.
 */
export default function useAvatarUpload({ onUploaded } = {}) {
  const { refreshProfile } = useAuth();
  const snackbar = useSnackbar();

  return useCallback(
    async (blob) => {
      try {
        const res = await uploadAvatar(blob);
        if (onUploaded) onUploaded(res.avatarUrl);
        snackbar.success("Đã cập nhật ảnh đại diện.");
        await refreshProfile();
      } catch (err) {
        console.error("uploadAvatar failed:", err);
        const msg = err?.message || err?.response?.data?.error || "Không thể tải ảnh đại diện. Kiểm tra Cloudinary / kết nối mạng.";
        snackbar.error(msg);
        throw err;
      }
    },
    [onUploaded, refreshProfile, snackbar]
  );
}
