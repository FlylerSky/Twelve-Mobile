import { useEffect, useRef, useState } from "react";
import { collection, query, where, orderBy, limit, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";

/**
 * ==== v2.0.0 — Đếm "có bài mới" realtime (banner kiểu Facebook/Twitter) ====
 * Tách khỏi IndexPage (v0.8.24) để Blog hay trang nào khác muốn có banner chỉ
 * cần gọi hook. Không tự chèn bài vào đầu feed (tránh xáo trộn vị trí đang
 * đọc) — chỉ đếm; người dùng bấm để tải lại.
 *
 * Query: bài mới nhất (`orderBy createdAt desc, limit 1`). Listener kích hoạt
 * ngay lần đầu với bài hiện tại (bỏ qua vì feed vừa tải); v0.8.24.1: CHỈ tăng
 * bộ đếm khi id bài mới nhất THỰC SỰ đổi (bài hoàn toàn mới), không phải khi
 * bài cũ chỉ cập nhật chỉ số (like/comment…). Lỗi quyền/mạng: fail-soft.
 *
 * @param {object} p
 * @param {string} p.collectionName "posts" | "blogs"
 * @param {boolean} p.isAuthReady
 * @param {number} p.feedVersion  `version` của usePaginatedFeed (đổi = vừa tải lại)
 * @param {string|null} p.headId  id bài đầu danh sách (mốc so sánh)
 * @returns {number} số bài mới chưa xem
 */
export default function useNewContentBanner({ collectionName, isAuthReady, feedVersion, headId }) {
  const [count, setCount] = useState(0);
  const headIdRef = useRef(null);
  const readyRef = useRef(false);

  // Feed vừa (tải lại) xong → người dùng đã xem bản mới nhất: reset + đặt mốc.
  useEffect(() => {
    if (feedVersion > 0) {
      readyRef.current = true;
      headIdRef.current = headId;
      setCount(0);
    }
  }, [feedVersion, headId]);

  useEffect(() => {
    if (!isAuthReady) return undefined;
    // v2.0.4: Firestore rules chỉ cho list blog ĐÃ XUẤT BẢN => truy vấn blogs phải kèm
    // where("isPublished","==",true) (index isPublished+createdAt đã có trong firestore.indexes.json).
    const q =
      collectionName === "blogs"
        ? query(collection(db, collectionName), where("isPublished", "==", true), orderBy("createdAt", "desc"), limit(1))
        : query(collection(db, collectionName), orderBy("createdAt", "desc"), limit(1));
    const unsub = onSnapshot(
      q,
      (snap) => {
        if (!readyRef.current) return; // lần đầu: bỏ qua
        if (snap.empty) return;
        const newLatestId = snap.docs[0].id;
        if (headIdRef.current && newLatestId !== headIdRef.current) {
          headIdRef.current = newLatestId;
          setCount((prev) => prev + 1);
        }
        // Chưa có mốc (hiếm) — đặt để có điểm so sánh sau này.
        if (!headIdRef.current) headIdRef.current = newLatestId;
      },
      (err) => {
        console.error(`useNewContentBanner onSnapshot error (${collectionName}):`, err.code, err.message);
      }
    );
    return () => unsub();
  }, [isAuthReady, collectionName]);

  return count;
}
