import { useCallback, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useSnackbar } from "../context/SnackbarContext";
import { postsApi } from "../api/content.api";

/**
 * ==== v2.4.0 — Ghim / gỡ ghim một bài lên Trang chủ hồ sơ của chính mình ====
 * Trạng thái ghim lấy từ `profile.pinnedPostIds` (hồ sơ của CHÍNH MÌNH, đã nghe realtime ở AuthContext) nên mọi thẻ bài của mình ở bất cứ
 * trang nào (Trang chủ, Xu hướng, Profile…) đều biết bài nào đang ghim mà không gọi API thêm; ghim ở đâu thì nơi khác đổi theo.
 *
 * `canPin`: chỉ TÁC GIẢ của bài, đang đăng nhập — SA cũng không ghim hộ người khác (backend từ chối 403). Blog không có ghim:
 * nơi gọi truyền `enabled=false` cho Blog.
 *
 * @param {object|null} post bài (cần `id`, `author.uid`)
 * @param {{ enabled?: boolean }} opts
 * @returns {{ canPin: boolean, isPinned: boolean, busy: boolean, toggle: () => Promise<void> }}
 */
export default function usePinPost(post, { enabled = true } = {}) {
  const { profile, isLoggedIn, patchProfile } = useAuth();
  const snackbar = useSnackbar();
  const [busy, setBusy] = useState(false);

  const postId = post?.id || null;
  const canPin = !!enabled && !!isLoggedIn && !!postId && !!profile?.uid && post?.author?.uid === profile.uid;
  const pinned = Array.isArray(profile?.pinnedPostIds) ? profile.pinnedPostIds : [];
  const isPinned = !!postId && pinned.includes(postId);

  const toggle = useCallback(async () => {
    if (!canPin || busy) return;
    setBusy(true);
    try {
      const res = isPinned ? await postsApi.unpin(postId) : await postsApi.pin(postId);
      if (Array.isArray(res?.pinnedPostIds)) patchProfile({ pinnedPostIds: res.pinnedPostIds });
      snackbar.success(isPinned ? "Đã gỡ ghim bài viết." : "Đã ghim bài viết lên trang cá nhân.");
    } catch (err) {
      // Vượt giới hạn (PIN_LIMIT_REACHED) và các lỗi khác: backend đã trả câu thông báo tiếng Việt rõ ràng.
      snackbar.error(err?.message || "Không thể thay đổi ghim. Vui lòng thử lại.");
    } finally {
      setBusy(false);
    }
  }, [canPin, busy, isPinned, postId, patchProfile, snackbar]);

  return { canPin, isPinned, busy, toggle };
}
