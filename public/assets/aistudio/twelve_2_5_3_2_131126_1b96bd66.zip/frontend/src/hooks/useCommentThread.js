import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useSnackbar } from "../context/SnackbarContext";
import usePaginatedComments from "./usePaginatedComments";

/**
 * ==== v2.0.0 — Toàn bộ logic 1 luồng bình luận (tải/realtime + gửi/sửa/xóa) ====
 * Trước đây CommentModal và PostDetailPage mỗi nơi tự giữ state
 * editingId/editValue/menuAnchor/menuComment + handleSend/saveEdit/handleDelete,
 * và đã lệch nhau (chỉ modal gọi refreshProfile sau khi gửi/xóa). Gom về một hook:
 * hành vi của hai nơi giờ LUÔN giống nhau.
 *
 * @param {object} p
 * @param {object} p.api postsApi | blogsApi
 * @param {string} p.id id bài viết/blog
 * @param {string} p.collectionName "posts" | "blogs"
 * @param {boolean} p.active modal đang mở / trang đã có id
 * @param {(delta:number)=>void} [p.onCountChange] báo cho danh sách cha (+1 / -1)
 */
export default function useCommentThread({ api, id, collectionName, active, onCountChange }) {
  const { profile, refreshProfile } = useAuth();
  const snackbar = useSnackbar();

  const list = usePaginatedComments({ api, id, collectionName, active, profile });

  const [sending, setSending] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editValue, setEditValue] = useState("");
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [menuComment, setMenuComment] = useState(null);

  /** @returns {Promise<boolean>} true nếu gửi thành công (để composer xoá nháp). */
  const send = async (raw) => {
    const content = (raw || "").trim();
    if (!content) return false;
    setSending(true);
    try {
      const res = await api.addComment(id, content);
      // v0.10.17: optimistic ngay (dedupe theo id với listener realtime trong hook phân trang)
      const nowIso = new Date().toISOString();
      list.appendOwnComment({
        id: res.commentId,
        content,
        createdAt: nowIso,
        updatedAt: nowIso,
        isEdited: false,
        author: profile,
      });
      onCountChange?.(1);
      refreshProfile?.();
      return true;
    } catch (err) {
      snackbar.error(err.message);
      return false;
    } finally {
      setSending(false);
    }
  };

  const openMenu = (e, comment) => {
    setMenuAnchor(e.currentTarget);
    setMenuComment(comment);
  };
  const closeMenu = () => {
    setMenuAnchor(null);
    setMenuComment(null);
  };

  const startEdit = () => {
    if (!menuComment) return;
    setEditingId(menuComment.id);
    setEditValue(menuComment.content);
    closeMenu();
  };
  const cancelEdit = () => setEditingId(null);

  const saveEdit = async (commentId) => {
    const content = editValue.trim();
    if (!content) return;
    try {
      await api.editComment(id, commentId, content);
      list.updateOwnComment(commentId, { content, isEdited: true });
      setEditingId(null);
    } catch (err) {
      snackbar.error(err.message);
    }
  };

  const remove = async () => {
    if (!menuComment) return;
    const commentId = menuComment.id;
    closeMenu();
    try {
      await api.deleteComment(id, commentId);
      list.removeComment(commentId);
      onCountChange?.(-1);
      refreshProfile?.();
    } catch (err) {
      snackbar.error(err.message);
    }
  };

  const isMine = (c) => !!profile && c.author?.uid === profile.uid;

  return {
    ...list,
    sending,
    send,
    editingId,
    editValue,
    setEditValue,
    startEdit,
    cancelEdit,
    saveEdit,
    remove,
    menuAnchor,
    openMenu,
    closeMenu,
    isMine,
  };
}
