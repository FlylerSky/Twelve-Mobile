import { useCallback, useRef } from "react";
import { useAuth } from "../context/AuthContext";
import { useSnackbar } from "../context/SnackbarContext";
import { resolveAuthActionGate } from "../utils/authGate";
import { dlog, snapshotAuth } from "../utils/debugLog";

/**
 * ==== v2.0.0 — Cổng đăng nhập dùng chung cho mọi thao tác ghi ====
 * Trước đây khối "chưa đăng nhập → resolveAuthActionGate → dlog → snackbar →
 * refreshProfile" bị chép ở PostCard và PostDetailPage (và phần hiển thị
 * thông báo ở CommentModal / PostDetailPage). Gom về đây:
 *  - `requireLogin(action, extra)`: gọi trước thao tác ghi; trả về true nếu
 *    được phép, false nếu bị chặn (đã báo snackbar). Callback ỔN ĐỊNH (đọc
 *    auth qua ref) nên dùng được trong useCallback/useMemo mà không stale
 *    closure (cùng mục đích `liveRef` của PostCard v0.8.12).
 *  - `gate`: kết quả resolveAuthActionGate hiện tại, để render thông báo
 *    (vd. ô soạn bình luận khi chưa đăng nhập).
 */
export default function useAuthGate() {
  const auth = useAuth();
  const snackbar = useSnackbar();
  const live = useRef({});
  live.current = { auth, snackbar };

  const toGate = (a) =>
    resolveAuthActionGate({
      isLoggedIn: a.isLoggedIn,
      hasSession: a.hasSession,
      loadingProfile: a.loadingProfile,
      profile: a.profile,
      profileError: a.profileError,
    });

  const requireLogin = useCallback((action, extra = {}) => {
    const { auth: a, snackbar: sb } = live.current;
    if (a.isLoggedIn) return true;
    const g = toGate(a);
    dlog.warn(
      "ui",
      `${action} blocked`,
      snapshotAuth({
        ...extra,
        kind: g.kind,
        hasSession: a.hasSession,
        loadingProfile: a.loadingProfile,
        profileError: a.profileError || null,
        profileStatus: a.profile?.status ?? null,
      })
    );
    sb.warning(g.message);
    if (g.shouldRefresh) a.refreshProfile?.();
    return false;
  }, []);

  return { requireLogin, gate: toGate(auth) };
}
