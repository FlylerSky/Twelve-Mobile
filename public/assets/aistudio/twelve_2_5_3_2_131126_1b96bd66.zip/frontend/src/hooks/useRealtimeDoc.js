import { useEffect, useRef } from "react";
import { doc, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";

/**
 * ==== v2.0.0 — Listener realtime 1 document (posts/blogs) dùng chung ====
 * Thay cho 2 đoạn onSnapshot + liveUnsubRef giống hệt ở PostCard và
 * PostDetailPage. `onData(data)` được giữ qua ref nên đổi callback không làm
 * huỷ/đăng ký lại listener.
 */
export default function useRealtimeDoc(collectionName, id, onData, label = "useRealtimeDoc") {
  const cbRef = useRef(onData);
  cbRef.current = onData;

  useEffect(() => {
    if (!id) return undefined;
    const unsub = onSnapshot(
      doc(db, collectionName, id),
      (snap) => {
        if (!snap.exists()) return;
        cbRef.current?.(snap.data());
      },
      (err) => {
        console.error(`${label} onSnapshot error (${collectionName}/${id}):`, err.code);
      }
    );
    return () => unsub();
  }, [collectionName, id, label]);
}
