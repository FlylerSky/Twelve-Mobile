import { useEffect, useState } from "react";
import { checkTagName } from "../api/auth.api";

const TAG_RE = /^[a-zA-Z0-9_]{3,20}$/;

/**
 * ==== v2.2.0 — Kiểm tra Tag Name Search (dùng chung Đăng ký + Cài đặt > Tài khoản) ====
 * Trước đây logic debounce + gọi /auth/check-tagname nằm riêng trong RegisterPage. Trả về:
 *   null | "checking" | "available" | "taken" | "invalid" | "same" (trùng chính tag hiện tại của người dùng — chỉ khi truyền `currentTag`)
 */
export default function useTagNameAvailability(value, { currentTag = null, debounceMs = 500 } = {}) {
  const [status, setStatus] = useState(null);

  useEffect(() => {
    const v = String(value || "").replace(/^@/, "");
    if (!v.trim()) {
      setStatus(null);
      return undefined;
    }
    if (!TAG_RE.test(v)) {
      setStatus("invalid");
      return undefined;
    }
    if (currentTag && v.toLowerCase() === String(currentTag).replace(/^@/, "").toLowerCase()) {
      setStatus("same");
      return undefined;
    }
    setStatus("checking");
    let cancelled = false;
    const timer = setTimeout(async () => {
      try {
        const res = await checkTagName(v);
        if (!cancelled) setStatus(res.available ? "available" : "taken");
      } catch {
        if (!cancelled) setStatus(null);
      }
    }, debounceMs);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [value, currentTag, debounceMs]);

  return status;
}
