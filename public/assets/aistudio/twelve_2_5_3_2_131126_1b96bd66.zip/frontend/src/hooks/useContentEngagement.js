import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useSnackbar } from "../context/SnackbarContext";
import { computePostScore } from "../utils/postScore";
import useAuthGate from "./useAuthGate";
import useRealtimeDoc from "./useRealtimeDoc";

const COUNT_KEYS = ["likeCount", "dislikeCount", "commentCount", "shareCount", "viewCount", "aiViewCount"];

const pickCounts = (src) => {
  const out = {};
  COUNT_KEYS.forEach((k) => {
    out[k] = (src && src[k]) || 0;
  });
  return out;
};

const pickDefinedCounts = (src) => {
  const out = {};
  COUNT_KEYS.forEach((k) => {
    if (src && src[k] !== undefined) out[k] = src[k] || 0;
  });
  return out;
};

/**
 * ==== v2.0.0 — Chỉ số tương tác của 1 bài (like/dislike/comment/share/view) ====
 * MỘT nơi duy nhất giữ: state số đếm + myReaction, realtime Firestore,
 * thả tim/không thích (cập nhật lạc quan + rollback), chia sẻ (Web Share API →
 * clipboard) và điểm bài viết. PostCard (danh sách) và PostDetailPage (chi
 * tiết) cùng dùng — sửa ở đây là cả hai hưởng theo.
 *
 * QUAN TRỌNG (giữ từ v0.8.24): KHÔNG cập nhật `myReaction` từ snapshot —
 * document bài không lưu reaction của user hiện tại.
 *
 * @param {object} p
 * @param {object} p.api  postsApi | blogsApi
 * @param {string} p.collectionName "posts" | "blogs"
 * @param {string} p.id
 * @param {object|null} p.initial post (kèm myReaction) — đồng bộ lại khi thay đổi
 * @param {(fresh:object)=>void} [p.onData] nhận nguyên document realtime (vd. để merge field khác)
 */
export default function useContentEngagement({ api, collectionName, id, initial, onData }) {
  const { refreshProfile } = useAuth();
  const snackbar = useSnackbar();
  const { requireLogin } = useAuthGate();

  const [myReaction, setMyReaction] = useState(initial?.myReaction || null);
  const [counts, setCounts] = useState(() => pickCounts(initial));
  const [busy, setBusy] = useState(false);

  // v2.0.6 [SỬA LỖI like/dislike nhảy loạn]: trước đây MỌI thay đổi của `initial` (kể cả chỉ `commentCount`
  // do hộp bình luận gọi adjustCommentCount ở danh sách) đều reset CẢ `myReaction` lẫn số like về giá trị
  // CŨ của lần tải danh sách (chưa có lượt like vừa bấm) => nút mất màu, số sai, bấm tiếp bị đảo ngược.
  // Nay:
  //  - Đổi `id` (thẻ dùng cho bài khác): reset toàn bộ.
  //  - `myReaction`: chỉ nhận từ `initial` khi CHÍNH giá trị đó trong `initial` đổi (vd. tải lại danh sách sau
  //    khi đăng nhập). `initial` cũ không bao giờ ghi đè lượt bấm cục bộ.
  //  - Số đếm: sau khi listener realtime đã trả dữ liệu đầu tiên thì realtime là nguồn đúng duy nhất; trước đó
  //    (hoặc khi listener lỗi) mới đồng bộ từng trường từ `initial` khi trường đó đổi.
  const prevInitialRef = useRef({ id, initial });
  const realtimeSeenRef = useRef(false);
  useEffect(() => {
    const prev = prevInitialRef.current;
    prevInitialRef.current = { id, initial };

    if (prev.id !== id) {
      realtimeSeenRef.current = false;
      setMyReaction(initial?.myReaction || null);
      setCounts(pickCounts(initial));
      return;
    }
    if ((prev.initial?.myReaction || null) !== (initial?.myReaction || null)) {
      setMyReaction(initial?.myReaction || null);
    }
    if (!realtimeSeenRef.current) {
      const changed = {};
      COUNT_KEYS.forEach((k) => {
        if ((prev.initial?.[k] || 0) !== (initial?.[k] || 0)) changed[k] = initial?.[k] || 0;
      });
      if (Object.keys(changed).length) setCounts((c) => ({ ...c, ...changed }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    id,
    initial?.myReaction,
    initial?.likeCount,
    initial?.dislikeCount,
    initial?.commentCount,
    initial?.shareCount,
    initial?.viewCount,
    initial?.aiViewCount,
  ]);

  useRealtimeDoc(
    collectionName,
    id,
    (fresh) => {
      realtimeSeenRef.current = true;
      setCounts((prev) => ({ ...prev, ...pickDefinedCounts(fresh) }));
      onData?.(fresh);
    },
    "useContentEngagement"
  );

  const live = useRef({});
  live.current = { api, id, myReaction, counts, busy, refreshProfile, snackbar };

  const react = useCallback(
    async (type) => {
      if (!requireLogin("react", { type, postId: live.current.id })) return;
      const s = live.current;
      if (s.busy) return;
      setBusy(true);

      const prevType = s.myReaction;
      const prevCounts = s.counts;
      let nextLike = prevCounts.likeCount;
      let nextDislike = prevCounts.dislikeCount;
      if (prevType === "like") nextLike -= 1;
      if (prevType === "dislike") nextDislike -= 1;

      let nextType = type;
      if (prevType === type) {
        nextType = null;
      } else {
        if (type === "like") nextLike += 1;
        if (type === "dislike") nextDislike += 1;
      }

      setMyReaction(nextType);
      setCounts((c) => ({ ...c, likeCount: nextLike, dislikeCount: nextDislike }));

      try {
        const result = await s.api.react(s.id, type);
        // v2.0.6: server trả trạng thái reaction THẬT => tự sửa nếu UI lệch (vd. mạng/đua giữa 2 thiết bị).
        if (result && Object.prototype.hasOwnProperty.call(result, "myReaction")) {
          setMyReaction(result.myReaction || null);
        }
        // v0.8.23.1: like/dislike đổi positiveScore → đồng bộ profile để Navbar đúng ngay.
        s.refreshProfile?.();
      } catch (err) {
        setMyReaction(prevType);
        setCounts((c) => ({
          ...c,
          likeCount: prevCounts.likeCount,
          dislikeCount: prevCounts.dislikeCount,
        }));
        s.snackbar.error(err.message || "Thao tác thất bại.");
      } finally {
        setBusy(false);
      }
    },
    [requireLogin]
  );

  // SHARE: chỉ tạo link (lượt share thật được tính khi có người mở link ở trang
  // chi tiết — xem PostDetailPage / backend share.controller). Ưu tiên Web Share
  // API; không có (hầu hết desktop) thì copy clipboard.
  const share = useCallback(async (title) => {
    const s = live.current;
    try {
      const { shareUrl } = await s.api.share(s.id);
      if (navigator.share) {
        try {
          await navigator.share({ title, url: shareUrl });
          return;
        } catch (shareErr) {
          if (shareErr?.name === "AbortError") return; // người dùng tự hủy
          // Web Share API lỗi thật → rơi xuống copy clipboard
        }
      }
      await navigator.clipboard.writeText(shareUrl);
      s.snackbar.success("Đã sao chép link chia sẻ.");
    } catch (err) {
      s.snackbar.error(err.message || "Không thể tạo link chia sẻ.");
    }
  }, []);

  const score = useMemo(() => computePostScore(counts), [counts]);

  return { ...counts, myReaction, busy, score, react, share };
}
