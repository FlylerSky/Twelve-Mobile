import React, { Suspense, useEffect, useMemo } from "react";
import useSeo from "../hooks/useSeo";
import { useParams, useNavigate, Link as RouterLink } from "react-router-dom";
import { Container, Box, Typography, Button, CircularProgress } from "@mui/material";
import Navbar from "../components/Navbar";
import StickyTabs from "../components/tabs/StickyTabs";
import { useRegisterPageHeader } from "../context/PageHeaderContext";
import { useGoUp } from "../hooks/useBack";
import { useAuth } from "../context/AuthContext";
import { SETTINGS_TABS } from "./settings/registry";
import { buildAccess, buildHref, resolvePath } from "./settings/settingsTree";
import { SettingsRows, SettingsHeaderBar } from "./settings/SettingsNav";

/**
 * ==== v0.10.5 — Settings ====
 * Đồng bộ khung tab với Xu hướng:
 * - Tab sticky dưới AppBar/headZone, không bọc Paper ngoài.
 * - Nhiều tab cấp 1: scrollable ngang.
 *
 * ==== v2.1.0 — Cài đặt theo "hệ thống thư mục" ====
 * Trang này KHÔNG còn biết có những tuỳ chọn nào: nó đọc cây khai báo ở settings/registry.jsx và vẽ theo quy tắc chung
 * (settings/settingsTree.js):
 *   - Gốc tab / thư mục → danh sách chỉ có TÊN mục (SettingsRows). Bấm vào để mở.
 *   - Mục lá (một tuỳ chọn duy nhất) → hiện luôn nội dung.
 *   - Mỗi cấp sâu hơn gốc tab có thanh quay lại + đường dẫn (SettingsHeaderBar), nên luôn biết mình đang ở đâu và
 *     mục này bắt đầu/kết thúc ở đâu (mỗi màn hình = đúng một mục).
 * URL phản ánh vị trí: /settings/<tab>/<mục>/<mục con> — nút Back của trình duyệt đi lên đúng một cấp, link chia sẻ được.
 * /settings, /settings/app, /settings/admin vẫn dùng được như cũ.
 *
 * ==== v2.4.1 — hàng tab dùng component chung `StickyTabs` (cùng Xu hướng và Profile), không còn bản sao riêng ====
 *
 * ==== v2.4.2 — KHÔNG còn nút "quay lại" riêng trong trang; Back là nút DUY NHẤT ở headZone ====
 * Trước đây thanh đường dẫn có nút ← là liên kết `to=<mục cha>` (TIẾN thêm một mục lịch sử) còn Back ở headZone lùi theo lịch sử → trộn hai
 * loại là quay vòng (Ứng dụng › Chế độ giao diện → ← trong trang → Back ở headZone → lại vào Chế độ giao diện). Nay trang khai báo `backTo` =
 * mục cha (null ở gốc tab) và Back ở headZone "đi lên" đúng một cấp mà không sinh mục lịch sử mới (xem hooks/useBack.js, utils/navStack.js).
 * Cùng nguyên tắc cho đường dẫn (breadcrumb) và bấm lại tab đang mở: đều "đi lên", không đẩy thêm mục lịch sử.
 *
 * ==== v2.2.0 — thêm tab "Tài khoản" (chỉ người đã đăng nhập: `requires: "user"` trong registry; khách vẫn mở được tab Ứng dụng) ====
 */

function Centered({ children, minHeight = "30vh" }) {
  return (
    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight, textAlign: "center", gap: 2 }}>
      {children}
    </Box>
  );
}

export default function SettingsPage() {
  useSeo({ title: "Cài đặt | Twelve", robots: "noindex, nofollow" });
  const { tab, "*": rest } = useParams();
  const navigate = useNavigate();
  const { isSA, isLoggedIn, isAuthReady, loadingProfile, firebaseUser, profile, profileError } = useAuth();
  const goUp = useGoUp();

  const restPath = rest || "";
  const resolved = useMemo(
    () => resolvePath(SETTINGS_TABS, buildAccess({ isSA, isLoggedIn }), tab, restPath.split("/").filter(Boolean)),
    [isSA, isLoggedIn, tab, restPath]
  );

  // Hồ sơ (và quyền SA) có thể chưa tải xong: đừng vội báo "không có quyền" — nếu không, SA tải lại trang ở /settings/admin/… sẽ bị báo nhầm.
  const authPending = !isAuthReady || loadingProfile || (!!firebaseUser && !profile && !profileError);

  const { tabs } = resolved;
  const activeKey = resolved.tab?.key;
  const atRoot = resolved.ok && resolved.trail.length === 0;

  // Back ở headZone: trong mục con → lên mục cha; ở gốc tab (hoặc đường dẫn không hợp lệ) → lùi lịch sử như mọi trang.
  const backTo = resolved.ok && resolved.trail.length > 0 ? buildHref(resolved.tab.key, resolved.trail.slice(0, -1).map((n) => n.key)) : null;
  useRegisterPageHeader({ title: "Cài đặt", isBrand: false, actions: [], backTo });

  const pathKey = resolved.ok ? [resolved.tab.key, ...resolved.trail.map((n) => n.key)].join("/") : "—";
  useEffect(() => {
    // Sang mục khác thì về đầu trang (tab sticky nên vẫn thấy).
    try {
      window.scrollTo(0, 0);
    } catch (_e) {
      /* môi trường không hỗ trợ cuộn — bỏ qua */
    }
  }, [pathKey]);

  const handleTabClick = (t) => {
    if (t.key === activeKey && atRoot) return; // đang ở gốc tab này rồi
    // Đổi sang tab khác: thay thế lịch sử (như trước). Bấm lại tab đang mở khi đang ở sâu: ĐI LÊN gốc tab (v2.4.2: không đẩy mục lịch sử mới —
    // trước đây đẩy mục mới nên Back ở headZone quay lại đúng chỗ sâu vừa rời: chính là kiểu quay vòng người dùng báo).
    if (t.key === activeKey) goUp(buildHref(t.key));
    else navigate(buildHref(t.key), { replace: true });
  };

  let content;
  if (resolved.ok) {
    const { node, kind, items, trail } = resolved;
    content = (
      <>
        {trail.length > 0 && <SettingsHeaderBar tabKey={resolved.tab.key} trail={trail} />}
        {kind === "folder" ? (
          <SettingsRows items={items} tabKey={resolved.tab.key} parentKeys={trail.map((n) => n.key)} />
        ) : (
          // key = vị trí: hai mục lá dùng CHUNG một component (vd. 3 nhóm font) vẫn được dựng lại từ đầu khi chuyển qua lại.
          <Suspense
            key={pathKey}
            fallback={
              <Centered>
                <CircularProgress aria-label="Đang tải mục cài đặt" />
              </Centered>
            }
          >
            <node.component {...(node.props || {})} />
          </Suspense>
        )}
      </>
    );
  } else if (authPending) {
    content = (
      <Centered>
        <CircularProgress aria-label="Đang tải" />
      </Centered>
    );
  } else {
    content = (
      <Centered>
        <Typography variant="body1" color="text.secondary">
          Mục cài đặt này không tồn tại hoặc bạn không có quyền xem.
        </Typography>
        <Button variant="outlined" component={RouterLink} to={resolved.tab ? buildHref(resolved.tab.key) : "/settings"}>
          Về Cài đặt
        </Button>
      </Centered>
    );
  }

  return (
    <>
      <Navbar />

      {/* Tab sticky dưới head — component chung với Xu hướng/Profile. onTabClick (không phải onChange): bấm lại tab đang mở khi đang ở sâu → về gốc tab. */}
      <StickyTabs
        tabs={tabs.map((t) => ({ key: t.key, label: t.title, icon: t.icon }))}
        value={activeKey}
        onTabClick={(t) => handleTabClick(tabs.find((x) => x.key === t.key))}
      />

      <Container maxWidth="md" sx={{ py: { xs: 2, sm: 3 }, px: { xs: 1.5, sm: 3 } }}>
        {content}
      </Container>
    </>
  );
}
