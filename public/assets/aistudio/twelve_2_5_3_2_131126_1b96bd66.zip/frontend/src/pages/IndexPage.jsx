import React, { Suspense, lazy, useEffect, useRef } from "react";
import useSeo from "../hooks/useSeo";
import { Container, Box, Typography } from "@mui/material";
import Navbar from "../components/Navbar";
import { useRegisterPageHeader } from "../context/PageHeaderContext";
import FeedList from "../components/FeedList";
import { postsApi } from "../api/content.api";
import { useAuth } from "../context/AuthContext";
import { useCreatePost } from "../context/CreatePostContext";
import usePaginatedFeed from "../hooks/usePaginatedFeed";
import useNewContentBanner from "../hooks/useNewContentBanner";

// v2.0.11 [G4]: hộp thoại thiết lập (kéo theo react-easy-crop) tải sau lần vẽ đầu tiên.
const WelcomeSetupDialog = lazy(() => import("../components/WelcomeSetupDialog"));

/**
 * Trang chủ. v2.0.0: logic feed (tải/phân trang/số bình luận) nằm ở
 * usePaginatedFeed, phần thân ở FeedList (dùng chung với BlogPage), banner "có
 * bài mới" ở useNewContentBanner — file này chỉ còn phần riêng của Trang chủ.
 */
export default function IndexPage() {
  useSeo({
    title: "Twelve — Nền tảng mạng xã hội chia sẻ bài viết",
    description:
      "Twelve là nền tảng mạng xã hội chia sẻ bài viết, bình luận và xếp hạng nội dung theo tuần. Khám phá bài viết mới, blog và bảng xu hướng.",
  });
  useRegisterPageHeader({ title: "Twelve", isBrand: true, actions: [] });

  const { isLoggedIn, isAuthReady } = useAuth();
  const { lastCreated } = useCreatePost();
  const isFirstRender = useRef(true);

  const feed = usePaginatedFeed({ api: postsApi, listKey: "posts", isAuthReady });
  const newPostCount = useNewContentBanner({
    collectionName: "posts",
    isAuthReady,
    feedVersion: feed.version,
    headId: feed.headId,
  });

  // Modal "Đăng bài viết" có thể mở từ bất kỳ trang nào → tải lại khi có bài mới đăng.
  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    if (lastCreated) feed.loadInitial();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lastCreated]);

  return (
    <>
      <Navbar />
      {isLoggedIn && (
        <Suspense fallback={null}>
          <WelcomeSetupDialog />
        </Suspense>
      )}
      {/* v0.8.24: Banner thông báo có bài viết mới — giống Facebook/Twitter. */}
      {newPostCount > 0 && (
        <Box
          sx={{
            position: "sticky",
            top: 56,
            zIndex: 10,
            bgcolor: "primary.main",
            color: "primary.contrastText",
            py: 1,
            textAlign: "center",
            cursor: "pointer",
            "&:hover": { bgcolor: "primary.dark" },
            transition: "background-color 0.15s",
          }}
          onClick={feed.loadInitial}
        >
          <Typography variant="body2" fontWeight={600}>
            {newPostCount === 1
              ? "Có 1 bài viết mới — nhấn để xem"
              : `Có ${newPostCount} bài viết mới — nhấn để xem`}
          </Typography>
        </Box>
      )}
      <Container maxWidth="sm" sx={{ py: 3 }}>
        <FeedList
          feed={feed}
          api={postsApi}
          detailPath="/post"
          collectionName="posts"
          emptyText="Chưa có bài viết nào. Hãy là người đầu tiên chia sẻ trên Twelve!"
        />
      </Container>
    </>
  );
}
