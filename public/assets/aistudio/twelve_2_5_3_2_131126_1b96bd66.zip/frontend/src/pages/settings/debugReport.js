/**
 * ==== v2.3.0 — Hàm thuần cho panel "Gỡ lỗi" (định dạng báo cáo, nhãn, đếm trạng thái) ====
 * Tách khỏi JSX để test được và để "Sao chép" cho ra cùng một văn bản với phần "Văn bản" đang hiển thị.
 */
export const STATUS_META = {
  pass: { label: "Đạt", color: "success" },
  fail: { label: "Không đạt", color: "error" },
  warn: { label: "Cảnh báo", color: "warning" },
  skip: { label: "Bỏ qua", color: "default" },
  manual: { label: "Cần kiểm tay", color: "info" },
  error: { label: "Lỗi khi chạy", color: "error" },
  timeout: { label: "Quá thời gian", color: "error" },
};
export const SEVERITY_META = {
  high: { label: "Cao", color: "error" },
  medium: { label: "Trung bình", color: "warning" },
  low: { label: "Thấp", color: "info" },
  info: { label: "Thông tin", color: "default" },
};
export const MODE_LABELS = {
  static: "Đọc cấu hình",
  unit: "Hàm thuần",
  isolated: "Cô lập (tiến trình con)",
  "live-safe": "Gọi ngoài, chỉ GET",
  manual: "Kiểm tay",
};
export const statusLabel = (s) => (STATUS_META[s] ? STATUS_META[s].label : "Chưa chạy");

/** Lỗi do backend đòi nhập lại mật khẩu (requireRecentAuth) → panel mở hộp mật khẩu thay vì báo lỗi. */
export const isReauthError = (err) => err?.response?.data?.code === "REAUTH_REQUIRED";

export const fmtTime = (ms) => (ms ? new Date(ms).toLocaleString("vi-VN") : "—");
export const fmtDuration = (ms) => (ms < 1000 ? `${Math.round(ms)} ms` : `${(ms / 1000).toFixed(1)} s`);

/** Văn bản đầy đủ của MỘT kết quả — hiển thị ở tab "Văn bản" và là thứ nút "Sao chép" đưa vào clipboard. */
export function formatResultText(r) {
  if (!r) return "";
  const lines = [];
  lines.push(`[${r.ref || r.id}] ${r.title}`);
  lines.push(`Trạng thái: ${statusLabel(r.status)} — ${r.summary || ""}`);
  lines.push(`Phiên bản chạy: v${r.appVersion} · ghi nhận ở v${r.recordedIn}${r.fixedIn ? ` · đã vá ở v${r.fixedIn}` : ""} · ${fmtDuration(r.durationMs)} · ${fmtTime(r.startedAt)}`);
  if (r.reason) lines.push(`Lý do bỏ qua: ${r.reason}`);
  if (r.steps && r.steps.length) {
    lines.push("", "Việc cần kiểm tay:");
    r.steps.forEach((s, i) => lines.push(`${i + 1}. ${s.title} — ${s.how}`));
  }
  if (r.checks && r.checks.length) {
    lines.push("", "Kiểm tra:");
    r.checks.forEach((c) => lines.push(`${c.ok ? "✔" : c.level === "warn" ? "⚠" : "✖"} ${c.name}${c.detail ? ` — ${c.detail}` : ""}`));
  }
  if (r.metrics && r.metrics.length) {
    lines.push("", "Số đo:");
    r.metrics.forEach((m) => lines.push(`${m.name}: ${m.value}${m.unit ? ` ${m.unit}` : ""}`));
  }
  if (r.logs && r.logs.length) {
    lines.push("", "Log:");
    r.logs.forEach((l) => lines.push(`+${String(l.t).padStart(5)}ms ${String(l.level).toUpperCase().padEnd(5)} ${l.msg}`));
  }
  if (r.truncated) lines.push("", "(kết quả đã bị cắt bớt vì vượt giới hạn dung lượng)");
  return lines.join("\n");
}

/** Trạng thái hiện hành của một module: kết quả vừa chạy trong phiên này, nếu chưa có thì lần chạy gần nhất (đã lưu). */
export const currentStatus = (m, results) => (results && results[m.id] ? results[m.id].status : m.lastRun ? m.lastRun.status : null);

export function countStatuses(modules, results) {
  const out = { pass: 0, fail: 0, warn: 0, skip: 0, manual: 0, error: 0, timeout: 0, never: 0 };
  for (const m of modules || []) {
    const s = currentStatus(m, results);
    if (s && s in out) out[s] += 1;
    else out.never += 1;
  }
  return out;
}

/** Báo cáo tổng (markdown) cho mọi module — nút "Sao chép báo cáo tổng". */
export function formatSummaryMarkdown({ appVersion, modules, results, at = Date.now() }) {
  const lines = [`# Báo cáo Gỡ lỗi — Twelve v${appVersion}`, `Tạo lúc ${fmtTime(at)}`, "", "| Mã | Lỗi | Mức | Ghi nhận | Đã vá | Kết quả | Chi tiết |", "|---|---|---|---|---|---|---|"];
  for (const m of modules || []) {
    const r = results && results[m.id];
    const last = r || m.lastRun;
    const st = last ? `${statusLabel(last.status)}${last.appVersion ? ` (v${last.appVersion})` : ""}` : "Chưa chạy";
    const detail = last && last.summary ? String(last.summary).replace(/\|/g, "\\|") : "";
    lines.push(`| ${m.ref || m.id} | ${m.title.replace(/\|/g, "\\|")} | ${(SEVERITY_META[m.severity] || {}).label || m.severity} | v${m.recordedIn} | ${m.fixedIn ? `v${m.fixedIn}` : "—"} | ${st} | ${detail} |`);
  }
  const bad = (modules || []).filter((m) => ["fail", "error", "timeout"].includes(currentStatus(m, results)));
  lines.push("", bad.length ? `**Cần xem lại (${bad.length}):** ${bad.map((m) => m.ref || m.id).join(", ")}` : "Không có module nào không đạt.");
  return lines.join("\n");
}

/** v2.4.2.2: `copyText` nay nằm ở utils/clipboard.js (dùng chung); giữ export này để nơi import cũ không phải đổi. */
export { copyText } from "../../utils/clipboard";
