import React, { useEffect, useRef, useState } from "react";
import { Alert, Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Paper, Stack, TextField, Typography } from "@mui/material";
import CloudUploadOutlinedIcon from "@mui/icons-material/CloudUploadOutlined";
import LinkIcon from "@mui/icons-material/Link";
import CropOutlinedIcon from "@mui/icons-material/CropOutlined";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import ProfileCover from "../../components/profile/ProfileCover";
import CoverAdjustDialog from "../../components/profile/CoverAdjustDialog";
import { useAuth } from "../../context/AuthContext";
import { useSnackbar } from "../../context/SnackbarContext";
import { removeCover, setCoverCrop, setCoverUrl, uploadCover } from "../../api/users.api";
import { COVER_MIMES, prepareCoverImage } from "../../utils/imageDownscale";

/**
 * ==== Cài đặt > Tài khoản > Thông tin > Ảnh bìa ====
 * Ảnh bìa hiện ở đầu trang Profile của bạn (khổ 3:1). Bốn việc:
 *   • Tải ảnh lên — chọn ảnh (tự thu nhỏ nếu quá lớn), KÉO + THU PHÓNG để chọn phần hiển thị như ảnh đại diện, rồi lưu;
 *   • Dùng đường dẫn — dán URL ảnh ở nơi khác (https, domain phải nằm trong danh sách SA cho phép), lưu xong mở luôn hộp kéo/thu phóng;
 *   • Điều chỉnh — mở lại hộp kéo/thu phóng cho ảnh bìa ĐANG CÓ (tải lên hay URL ngoài đều được), không phải tải lại ảnh;
 *   • Gỡ ảnh bìa — về nền mặc định.
 * (v2.4.1: ảnh được lưu NGUYÊN + khung hiển thị `coverCrop`, không còn cắt cứng 1500x500 như 2.4.0 — nên mới chỉnh lại được và dùng được cho URL ngoài.)
 * Sau mỗi thao tác hồ sơ được vá ngay (patchProfile) — listener realtime sẽ xác nhận bằng đúng giá trị đó.
 */
export default function CoverImageRow() {
  const { profile, patchProfile } = useAuth();
  const snackbar = useSnackbar();
  const fileInputRef = useRef(null);
  const [urlOpen, setUrlOpen] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [preparing, setPreparing] = useState(false);
  const [previewFailed, setPreviewFailed] = useState(false);
  // Hộp kéo/thu phóng: { mode: "upload" | "existing", src, blob?, initialCrop }
  const [adjust, setAdjust] = useState(null);
  const coverUrl = profile?.coverUrl || null;
  const coverCrop = profile?.coverCrop || null;
  useEffect(() => setPreviewFailed(false), [coverUrl]);

  const closeAdjust = () => {
    setAdjust((a) => {
      if (a?.mode === "upload" && a.src) URL.revokeObjectURL(a.src);
      return null;
    });
  };

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // cho phép chọn lại đúng file đó lần sau
    if (!file) return;
    setPreparing(true);
    try {
      const blob = await prepareCoverImage(file);
      setAdjust({ mode: "upload", src: URL.createObjectURL(blob), blob, initialCrop: null });
    } catch (err) {
      snackbar.error(err?.message || "Không đọc được ảnh này.");
    } finally {
      setPreparing(false);
    }
  };

  const handleAdjustSave = async (crop) => {
    try {
      if (adjust.mode === "upload") {
        const res = await uploadCover(adjust.blob, crop);
        patchProfile({ coverUrl: res.coverUrl, coverCrop: res.coverCrop ?? crop });
        snackbar.success("Đã cập nhật ảnh bìa.");
      } else {
        const res = await setCoverCrop(crop);
        patchProfile({ coverCrop: res.coverCrop ?? crop });
        snackbar.success("Đã lưu vị trí ảnh bìa.");
      }
    } catch (err) {
      console.error("cover save failed:", err);
      throw err; // CoverAdjustDialog hiện lỗi trong hộp và GIỮ hộp mở để thử lại
    }
  };

  const handleRemove = async () => {
    setRemoving(true);
    try {
      await removeCover();
      patchProfile({ coverUrl: null, coverCrop: null });
      snackbar.success("Đã gỡ ảnh bìa.");
    } catch (err) {
      snackbar.error(err?.message || "Không thể gỡ ảnh bìa.");
    } finally {
      setRemoving(false);
    }
  };

  return (
    <Paper variant="outlined" sx={{ p: 2, borderRadius: 1 }} data-testid="cover-row">
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Ảnh bìa
      </Typography>
      <Box sx={{ mb: 1.5 }}>
        <ProfileCover url={coverUrl} crop={coverCrop} alt="Ảnh bìa hiện tại" testId="cover-preview" onLoadError={() => setPreviewFailed(true)} />
      </Box>
      {coverUrl && previewFailed && (
        <Alert severity="warning" sx={{ mb: 1.5 }}>
          Không tải được ảnh bìa từ đường dẫn hiện tại. Hãy chọn ảnh khác hoặc gỡ ảnh bìa.
        </Alert>
      )}
      <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
        <Button size="small" variant="outlined" startIcon={<CloudUploadOutlinedIcon />} onClick={() => fileInputRef.current?.click()} disabled={preparing}>
          {preparing ? "Đang xử lý ảnh..." : "Tải ảnh lên"}
        </Button>
        <input ref={fileInputRef} type="file" accept={COVER_MIMES.join(",")} hidden onChange={handleFile} data-testid="cover-file-input" />
        <Button size="small" variant="outlined" startIcon={<LinkIcon />} onClick={() => setUrlOpen(true)}>
          Dùng đường dẫn
        </Button>
        {coverUrl && !previewFailed && (
          <Button size="small" variant="outlined" startIcon={<CropOutlinedIcon />} onClick={() => setAdjust({ mode: "existing", src: coverUrl, initialCrop: coverCrop })}>
            Điều chỉnh
          </Button>
        )}
        {coverUrl && (
          <Button size="small" color="error" startIcon={<DeleteOutlineIcon />} onClick={handleRemove} disabled={removing}>
            {removing ? "Đang gỡ..." : "Gỡ ảnh bìa"}
          </Button>
        )}
      </Stack>

      <CoverAdjustDialog
        open={!!adjust}
        onClose={closeAdjust}
        imageSrc={adjust?.src || null}
        initialCrop={adjust?.initialCrop || null}
        onSave={handleAdjustSave}
        title={adjust?.mode === "upload" ? "Ảnh bìa mới" : "Điều chỉnh ảnh bìa"}
        saveLabel={adjust?.mode === "upload" ? "Lưu ảnh bìa" : "Lưu vị trí"}
      />

      <CoverUrlDialog
        open={urlOpen}
        onClose={() => setUrlOpen(false)}
        onSubmit={async (url) => {
          const res = await setCoverUrl(url);
          patchProfile({ coverUrl: res.coverUrl, coverCrop: res.coverCrop ?? null });
          snackbar.success("Đã cập nhật ảnh bìa.");
          // Mở luôn hộp kéo/thu phóng để chọn phần hiển thị (có thể bấm Hủy để giữ khung mặc định).
          setAdjust({ mode: "existing", src: res.coverUrl, initialCrop: null });
        }}
      />
    </Paper>
  );
}

/** Hộp dán URL ảnh bìa. Lỗi của backend (không https, domain chưa được phép…) hiện ngay trong hộp để người dùng sửa. */
function CoverUrlDialog({ open, onClose, onSubmit }) {
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setUrl("");
      setBusy(false);
      setError("");
    }
  }, [open]);

  const submit = async (e) => {
    e.preventDefault();
    if (busy || !url.trim()) return;
    setBusy(true);
    setError("");
    try {
      await onSubmit(url.trim());
      onClose();
    } catch (err) {
      setError(err?.message || "Không đặt được ảnh bìa từ đường dẫn này.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={!!open} onClose={busy ? undefined : onClose} maxWidth="sm" fullWidth>
      <form onSubmit={submit}>
        <DialogTitle>Dùng ảnh bìa từ đường dẫn</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ pt: 1 }}>
            <TextField
              label="Đường dẫn ảnh (https://…)"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              autoFocus
              fullWidth
              inputProps={{ "aria-label": "Đường dẫn ảnh bìa" }}
            />
            {url.trim().startsWith("https://") && (
              <ProfileCover url={url.trim()} alt="Xem trước" testId="cover-url-preview" />
            )}
            <Typography variant="caption" color="text.secondary">
              Chỉ nhận đường dẫn https từ các domain Twelve cho phép nhúng (Quản trị viên quản lý danh sách này). Nếu bị từ chối, hãy dùng “Tải ảnh lên”.
            </Typography>
            {error && <Alert severity="error">{error}</Alert>}
          </Stack>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={onClose} disabled={busy}>
            Hủy
          </Button>
          <Button type="submit" variant="contained" disabled={busy || !url.trim()}>
            {busy ? "Đang lưu..." : "Lưu ảnh bìa"}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
}
