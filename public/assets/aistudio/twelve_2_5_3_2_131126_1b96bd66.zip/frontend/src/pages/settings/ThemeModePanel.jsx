import React from "react";
import { Box, Typography, Paper, List, ListItemButton, ListItemIcon, ListItemText, Radio, Divider } from "@mui/material";
import LightModeIcon from "@mui/icons-material/LightMode";
import DarkModeIcon from "@mui/icons-material/DarkMode";
import SettingsBrightnessIcon from "@mui/icons-material/SettingsBrightness";
import { useThemeMode } from "../../context/ThemeModeContext";

/**
 * ==== Settings > Ứng dụng > Chế độ giao diện ====
 * v2.1.0: tách ra từ SettingsPage (trước đây nằm trong AppTab). Là mục LÁ — một tuỳ chọn duy nhất nên mở ra là thấy luôn.
 * Tiêu đề do khung Cài đặt vẽ; component này chỉ vẽ mô tả + các lựa chọn.
 */
const OPTIONS = [
  {
    value: "light",
    label: "Sáng",
    icon: <LightModeIcon />,
    desc: "Luôn dùng giao diện sáng, bất kể cài đặt hệ thống.",
  },
  {
    value: "dark",
    label: "Tối",
    icon: <DarkModeIcon />,
    desc: "Luôn dùng giao diện tối, bất kể cài đặt hệ thống.",
  },
  {
    value: "system",
    label: "Theo trình duyệt",
    icon: <SettingsBrightnessIcon />,
    desc: "Tự động theo chế độ Sáng/Tối của trình duyệt hoặc hệ điều hành.",
  },
];

export default function ThemeModePanel() {
  const { mode, setMode } = useThemeMode();

  return (
    <Box>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Chọn cách Twelve hiển thị trên thiết bị này.
      </Typography>

      <Paper variant="outlined" sx={{ borderRadius: 1, overflow: "hidden" }}>
        <List disablePadding>
          {OPTIONS.map((opt, i) => (
            <React.Fragment key={opt.value}>
              {i > 0 && <Divider component="li" />}
              <ListItemButton selected={mode === opt.value} onClick={() => setMode(opt.value)} sx={{ py: 1.5, px: 2 }}>
                <ListItemIcon sx={{ minWidth: 44, color: mode === opt.value ? "primary.main" : "text.secondary" }}>{opt.icon}</ListItemIcon>
                <ListItemText primary={opt.label} secondary={opt.desc} primaryTypographyProps={{ fontWeight: mode === opt.value ? 700 : 500 }} />
                <Radio checked={mode === opt.value} onChange={() => setMode(opt.value)} sx={{ ml: 1 }} inputProps={{ "aria-label": opt.label }} />
              </ListItemButton>
            </React.Fragment>
          ))}
        </List>
      </Paper>
    </Box>
  );
}
