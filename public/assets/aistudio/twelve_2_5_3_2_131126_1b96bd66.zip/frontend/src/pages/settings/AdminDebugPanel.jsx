import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  Box, Typography, Paper, Stack, Button, Chip, CircularProgress, Alert, Collapse, ToggleButton, ToggleButtonGroup, LinearProgress, Divider,
} from "@mui/material";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import PlaylistPlayIcon from "@mui/icons-material/PlaylistPlay";
import RefreshIcon from "@mui/icons-material/Refresh";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";
import { listDebugModules, runDebugModule } from "../../api/admin.api";
import { useSnackbar } from "../../context/SnackbarContext";
import PasswordConfirmDialog from "../../components/PasswordConfirmDialog";
import {
  STATUS_META, SEVERITY_META, MODE_LABELS, statusLabel, isReauthError, fmtTime, fmtDuration,
  formatResultText, formatSummaryMarkdown, countStatuses, currentStatus, copyText,
} from "./debugReport";

/**
 * ==== v2.3.0 — Quản trị > Gỡ lỗi (chỉ SA) ====
 * Mỗi thẻ là MỘT lỗi bảo mật đã từng gặp (module ở backend/src/debug/modules/): tên lỗi, phiên bản ghi nhận/đã vá, mô tả, nút chạy thử và kết quả
 * (dạng trực quan hoặc văn bản sao chép được). Mục đích: sau mỗi lần nâng phiên bản, quản trị viên bấm "Chạy tất cả" để biết lỗi cũ có tái xuất không.
 * Panel KHÔNG biết gì về từng module cụ thể — thêm lỗi mới chỉ là thêm một tệp ở backend, không sửa gì ở đây.
 * Chạy module đòi nhập lại mật khẩu (hiệu lực 5 phút): hết hạn thì mở hộp mật khẩu rồi chạy tiếp phần còn lại.
 */
function StatusChip({ status, size = "small" }) {
  const meta = STATUS_META[status];
  return <Chip size={size} color={meta ? meta.color : "default"} variant={meta ? "filled" : "outlined"} label={meta ? meta.label : "Chưa chạy"} />;
}

function CheckIcon({ check }) {
  if (check.ok) return <CheckCircleOutlineIcon fontSize="small" color="success" aria-label="đạt" />;
  if (check.level === "warn") return <WarningAmberIcon fontSize="small" color="warning" aria-label="cảnh báo" />;
  return <ErrorOutlineIcon fontSize="small" color="error" aria-label="không đạt" />;
}

function VisualResult({ result }) {
  const maxByUnit = useMemo(() => {
    const m = {};
    (result.metrics || []).forEach((x) => { m[x.unit] = Math.max(m[x.unit] || 0, Math.abs(x.value)); });
    return m;
  }, [result]);
  return (
    <Stack spacing={1.5} data-testid="debug-visual">
      {result.status === "skip" && <Alert severity="info">Bỏ qua: {result.reason || result.summary}</Alert>}
      {result.status === "error" && <Alert severity="error">{result.summary}</Alert>}
      {result.status === "timeout" && <Alert severity="error">Module chạy quá thời gian cho phép nên đã bị dừng.</Alert>}
      {result.steps && result.steps.length > 0 && (
        <Box component="ol" sx={{ m: 0, pl: 3 }}>
          {result.steps.map((s) => (
            <li key={s.title}>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>{s.title}</Typography>
              <Typography variant="body2" color="text.secondary">{s.how}</Typography>
            </li>
          ))}
        </Box>
      )}
      {result.checks.length > 0 && (
        <Stack spacing={0.75}>
          {result.checks.map((c, i) => (
            <Stack key={`${c.name}-${i}`} direction="row" spacing={1} alignItems="flex-start">
              <Box sx={{ pt: 0.25 }}><CheckIcon check={c} /></Box>
              <Box sx={{ minWidth: 0 }}>
                <Typography variant="body2" sx={{ wordBreak: "break-word" }}>{c.name}</Typography>
                {c.detail && <Typography variant="caption" color="text.secondary" sx={{ wordBreak: "break-word" }}>{c.detail}</Typography>}
              </Box>
            </Stack>
          ))}
        </Stack>
      )}
      {result.metrics.length > 0 && (
        <Box>
          <Divider sx={{ mb: 1 }} />
          <Typography variant="caption" color="text.secondary">Số đo</Typography>
          {result.metrics.map((m, i) => {
            const max = maxByUnit[m.unit] || 1;
            return (
              <Box key={`${m.name}-${i}`} sx={{ mt: 0.75 }}>
                <Stack direction="row" justifyContent="space-between" spacing={1}>
                  <Typography variant="body2" sx={{ wordBreak: "break-word" }}>{m.name}</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, whiteSpace: "nowrap" }}>{m.value}{m.unit ? ` ${m.unit}` : ""}</Typography>
                </Stack>
                <LinearProgress variant="determinate" value={Math.min(100, (Math.abs(m.value) / max) * 100)} aria-label={m.name} sx={{ height: 4, borderRadius: 2 }} />
              </Box>
            );
          })}
        </Box>
      )}
      {result.truncated && <Alert severity="warning">Kết quả đã bị cắt bớt vì vượt giới hạn dung lượng.</Alert>}
    </Stack>
  );
}

function ModuleCard({ m, result, running, disabled, open, view, onRun, onToggle, onView, onCopy }) {
  const status = currentStatus(m, result ? { [m.id]: result } : {});
  const last = m.lastRun;
  return (
    <Paper variant="outlined" sx={{ p: 2 }} data-testid={`debug-card-${m.id}`}>
      <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
        <Chip size="small" variant="outlined" label={m.ref || m.id} />
        <Typography variant="subtitle1" sx={{ fontWeight: 600, flex: 1, minWidth: 160 }}>{m.title}</Typography>
        <Chip size="small" variant="outlined" color={(SEVERITY_META[m.severity] || {}).color || "default"} label={`Mức ${(SEVERITY_META[m.severity] || {}).label || m.severity}`} />
        <StatusChip status={status} />
      </Stack>
      <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 0.5 }}>
        Ghi nhận ở v{m.recordedIn} · {m.fixedIn ? `đã vá ở v${m.fixedIn}` : "không gắn với một bản vá (cấu hình / kiểm tay)"} · {MODE_LABELS[m.mode] || m.mode}
        {m.knownOpen ? " · LỖI CÒN MỞ" : ""}
      </Typography>
      <Typography variant="body2" sx={{ mt: 1 }}>{m.description}</Typography>
      <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mt: 1.5 }}>
        <Button
          size="small"
          variant="contained"
          startIcon={running ? <CircularProgress size={14} color="inherit" /> : <PlayArrowIcon />}
          disabled={disabled}
          onClick={onRun}
          aria-label={`Chạy thử ${m.title}`}
        >
          {running ? "Đang chạy…" : "Chạy thử"}
        </Button>
        {result && (
          <Button size="small" onClick={onToggle} endIcon={<ExpandMoreIcon sx={{ transform: open ? "rotate(180deg)" : "none", transition: "transform .2s" }} />} aria-expanded={open}>
            {open ? "Ẩn kết quả" : "Xem kết quả"}
          </Button>
        )}
        <Typography variant="caption" color="text.secondary">
          {result ? `Vừa chạy · ${fmtDuration(result.durationMs)} · ${result.summary}` : last ? `Lần cuối: ${fmtTime(last.startedAt)} · v${last.appVersion} · ${statusLabel(last.status)} — ${last.summary}` : "Chưa chạy lần nào"}
        </Typography>
      </Stack>
      {result && (
        <Collapse in={open} unmountOnExit>
          <Divider sx={{ my: 1.5 }} />
          <Stack direction="row" spacing={1} alignItems="center" justifyContent="space-between" flexWrap="wrap" useFlexGap sx={{ mb: 1 }}>
            <ToggleButtonGroup size="small" exclusive value={view} onChange={(_e, v) => v && onView(v)} aria-label="Cách hiển thị kết quả">
              <ToggleButton value="visual">Trực quan</ToggleButton>
              <ToggleButton value="text">Văn bản</ToggleButton>
            </ToggleButtonGroup>
            <Button size="small" startIcon={<ContentCopyIcon />} onClick={onCopy} aria-label={`Sao chép kết quả ${m.title}`}>Sao chép</Button>
          </Stack>
          {view === "text" ? (
            <Box
              component="pre"
              data-testid="debug-text"
              sx={{ m: 0, p: 1.5, bgcolor: "action.hover", borderRadius: 1, fontFamily: "monospace", fontSize: 12, whiteSpace: "pre-wrap", wordBreak: "break-word", maxHeight: 360, overflow: "auto" }}
            >
              {formatResultText(result)}
            </Box>
          ) : (
            <VisualResult result={result} />
          )}
        </Collapse>
      )}
    </Paper>
  );
}

export default function AdminDebugPanel() {
  const snackbar = useSnackbar();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [results, setResults] = useState({});
  const [running, setRunning] = useState(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(null);
  const [openIds, setOpenIds] = useState({});
  const [views, setViews] = useState({});
  const [reauth, setReauth] = useState({ open: false, ids: [] });

  const load = useCallback((silent = false) => {
    if (!silent) setLoading(true);
    return listDebugModules()
      .then((d) => {
        setData(d);
        setError("");
      })
      .catch((err) => setError(err.message || "Không tải được danh sách module."))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const execute = async (id) => {
    setRunning(id);
    try {
      const r = await runDebugModule(id);
      setResults((p) => ({ ...p, [id]: r }));
      setOpenIds((p) => ({ ...p, [id]: true }));
      return r;
    } finally {
      setRunning(null);
    }
  };

  // Chạy tuần tự (tránh quá tải máy chủ miễn phí; backend cũng chỉ cho một module một lúc). Hết hạn mật khẩu → hộp mật khẩu, rồi chạy tiếp phần còn lại.
  const runSequence = async (ids) => {
    setBusy(true);
    try {
      for (let i = 0; i < ids.length; i++) {
        setProgress({ done: i, total: ids.length });
        try {
          await execute(ids[i]);
        } catch (err) {
          if (isReauthError(err)) {
            setReauth({ open: true, ids: ids.slice(i) });
            return;
          }
          snackbar.error(err.message || "Không chạy được module.");
          return;
        }
      }
      setProgress({ done: ids.length, total: ids.length });
    } finally {
      setBusy(false);
      load(true);
    }
  };

  const modules = data ? data.modules : [];
  const counts = useMemo(() => countStatuses(modules, results), [modules, results]);
  const canRun = !!(data && data.enabled) && !busy;

  const copyOne = async (m) => {
    const ok = await copyText(formatResultText(results[m.id]));
    if (ok) snackbar.success("Đã sao chép kết quả.");
    else snackbar.error("Không sao chép được — hãy chọn văn bản và sao chép thủ công.");
  };
  const copyAll = async () => {
    const ok = await copyText(formatSummaryMarkdown({ appVersion: data.appVersion, modules, results }));
    if (ok) snackbar.success("Đã sao chép báo cáo tổng.");
    else snackbar.error("Không sao chép được.");
  };

  return (
    <Box>
      {/* tiêu đề do khung Cài đặt vẽ (registry.jsx: "Gỡ lỗi") */}
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Mỗi mục là một lỗi bảo mật đã từng gặp. Sau mỗi lần nâng phiên bản, bấm <b>Chạy tất cả</b> để biết lỗi cũ có tái xuất không. Các kiểm tra chỉ chạy trên dữ liệu giả
        hoặc chỉ đọc (những kiểm tra có thể làm sập máy chủ chạy trong tiến trình riêng). Chạy cần nhập lại mật khẩu; kết quả chỉ lưu bản tóm tắt.
      </Typography>

      {loading && <CircularProgress size={16} aria-label="Đang tải" sx={{ mb: 1 }} />}
      {error && (
        <Alert severity="error" sx={{ mb: 2 }} action={<Button color="inherit" size="small" onClick={() => load()}>Thử lại</Button>}>
          {error}
        </Alert>
      )}
      {data && !data.enabled && (
        <Alert severity="warning" sx={{ mb: 2 }}>Chạy module đang bị tắt trên máy chủ (DEBUG_PANEL_ENABLED=off). Chỉ xem được danh sách.</Alert>
      )}
      {data && data.loadErrors > 0 && (
        <Alert severity="error" sx={{ mb: 2 }}>{data.loadErrors} module bị lỗi khai báo nên đã bị bỏ qua — xem log máy chủ.</Alert>
      )}

      {data && (
        <>
          <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mb: 1.5 }}>
            <Button
              variant="contained"
              startIcon={busy ? <CircularProgress size={16} color="inherit" /> : <PlaylistPlayIcon />}
              disabled={!canRun || modules.length === 0}
              onClick={() => runSequence(modules.map((m) => m.id))}
            >
              {busy && progress ? `Đang chạy ${Math.min(progress.done + 1, progress.total)}/${progress.total}…` : "Chạy tất cả"}
            </Button>
            <Button startIcon={<ContentCopyIcon />} onClick={copyAll} disabled={modules.length === 0}>Sao chép báo cáo tổng</Button>
            <Button startIcon={<RefreshIcon />} onClick={() => load()} disabled={busy}>Tải lại</Button>
            <Typography variant="caption" color="text.secondary" sx={{ ml: "auto" }}>Phiên bản máy chủ: v{data.appVersion}</Typography>
          </Stack>
          <Stack direction="row" spacing={0.75} flexWrap="wrap" useFlexGap sx={{ mb: 2 }} data-testid="debug-counts">
            <Chip size="small" color="success" label={`Đạt ${counts.pass}`} />
            <Chip size="small" color={counts.fail + counts.error + counts.timeout ? "error" : "default"} label={`Không đạt ${counts.fail + counts.error + counts.timeout}`} />
            <Chip size="small" color={counts.warn ? "warning" : "default"} label={`Cảnh báo ${counts.warn}`} />
            <Chip size="small" label={`Bỏ qua/kiểm tay ${counts.skip + counts.manual}`} />
            <Chip size="small" variant="outlined" label={`Chưa chạy ${counts.never}`} />
          </Stack>
          <Stack spacing={1.5}>
            {modules.map((m) => (
              <ModuleCard
                key={m.id}
                m={m}
                result={results[m.id]}
                running={running === m.id}
                disabled={!canRun}
                open={!!openIds[m.id]}
                view={views[m.id] || "visual"}
                onRun={() => runSequence([m.id])}
                onToggle={() => setOpenIds((p) => ({ ...p, [m.id]: !p[m.id] }))}
                onView={(v) => setViews((p) => ({ ...p, [m.id]: v }))}
                onCopy={() => copyOne(m)}
              />
            ))}
          </Stack>
        </>
      )}

      <PasswordConfirmDialog
        open={reauth.open}
        title="Xác nhận để chạy kiểm tra"
        description="Chạy module Gỡ lỗi cần nhập lại mật khẩu (hiệu lực 5 phút) để chắc người chạy chính là bạn."
        confirmText="Xác nhận và chạy"
        onConfirm={async () => {
          const [first, ...rest] = reauth.ids;
          setBusy(true);
          try {
            await execute(first); // lỗi ném ra → hiện trong hộp mật khẩu
          } catch (err) {
            setBusy(false);
            throw err;
          }
          setBusy(false);
          if (rest.length) runSequence(rest);
          else load(true);
        }}
        onClose={() => setReauth({ open: false, ids: [] })}
      />
    </Box>
  );
}
