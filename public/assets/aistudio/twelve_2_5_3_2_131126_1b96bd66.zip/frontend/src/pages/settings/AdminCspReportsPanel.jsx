import React, { useCallback, useEffect, useState } from "react";
import { Box, Typography, Paper, Stack, Button, Divider, CircularProgress, Alert, Chip } from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";
import { getCspReports, resetCspReports } from "../../api/admin.api";
import { useSnackbar } from "../../context/SnackbarContext";
import useReauthRetry from "../../hooks/useReauthRetry";

/**
 * ==== v2.0.11 — Quản trị > Báo cáo CSP (chỉ SA) — Báo cáo bảo mật Phiên 2, G1 ====
 * CSP của SPA đang ở chế độ Report-Only: trình duyệt người dùng gửi báo cáo vi phạm về backend (xem vercel.json
 * `report-uri /csp-report`). Panel này hiển thị thống kê gom nhóm để quyết định KHI NÀO chuyển sang enforcing:
 * khi vài ngày liền không còn dòng "đáng lo" nào (script-src / script-src-elem / frame-src bị chặn bởi nguồn lạ).
 * Thống kê nằm trong RAM của server → mất khi server khởi động lại.
 */
const fmt = (ms) => (ms ? new Date(ms).toLocaleString("vi-VN") : "—");

export default function AdminCspReportsPanel() {
  const snackbar = useSnackbar();
  // v2.5.3 [TW-09]: DELETE /admin/csp-reports (xoá bảng báo cáo = xoá bằng chứng) đòi vừa nhập lại mật khẩu — hook mở hộp mật khẩu rồi thử lại.
  const { run: runWithReauth, reauthDialog } = useReauthRetry({ title: "Xác nhận để đặt lại báo cáo CSP", description: "Đặt lại sẽ xoá toàn bộ thống kê vi phạm CSP đang có (thao tác được ghi vào nhật ký). Cần nhập lại mật khẩu (hiệu lực 5 phút).", confirmText: "Xác nhận và đặt lại" });
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    setLoading(true);
    getCspReports()
      .then((d) => {
        setData(d);
        setError("");
      })
      .catch((err) => setError(err.message || "Không tải được báo cáo CSP."))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const reset = () =>
    runWithReauth(() => resetCspReports())
      .then(() => {
        snackbar.success("Đã bắt đầu lại cửa sổ quan sát.");
        load();
      })
      .catch((err) => {
        if (err?.reauthCancelled) return; // người dùng bấm Hủy ở hộp mật khẩu — không phải lỗi
        snackbar.error(err.message || "Không đặt lại được.");
      });

  return (
    <Box>
      {/* v2.1.0: tiêu đề do khung Cài đặt vẽ (registry.jsx: "Báo cáo vi phạm CSP") */}
      {loading && <CircularProgress size={16} aria-label="Đang tải" sx={{ mb: 1 }} />}
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        CSP của trang web chính đang ở chế độ <b>chỉ báo cáo</b> (không chặn). Khi nhiều ngày liền không còn vi phạm đáng lo
        (đặc biệt <code>script-src</code>, <code>script-src-elem</code>, <code>frame-src</code>), có thể chuyển sang chế độ chặn thật
        bằng cách đổi tên header <code>Content-Security-Policy-Report-Only</code> thành <code>Content-Security-Policy</code> trong
        <code> vercel.json</code>. Số liệu chỉ nằm trong bộ nhớ máy chủ nên mất khi máy chủ khởi động lại.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} action={<Button color="inherit" size="small" onClick={load}>Thử lại</Button>}>
          {error}
        </Alert>
      )}

      {data && (
        <>
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ mb: 1.5 }}>
            <Chip size="small" label={`Từ ${fmt(data.startedAt)}`} />
            <Chip size="small" label={`${data.total} báo cáo`} />
            <Chip size="small" color={data.uniqueViolations ? "warning" : "success"} label={`${data.uniqueViolations} loại vi phạm`} />
            <Chip size="small" variant="outlined" label={`${data.ignoredExtensions} từ tiện ích trình duyệt (bỏ qua)`} />
            {data.overflow > 0 && (
              // v2.2.1: bảng đầy thì báo cáo mới KHÔNG còn đẩy báo cáo cũ ra — bị bỏ và đếm ở đây (có thể do bị bơm nhiễu; "Bắt đầu lại" để mở cửa sổ mới).
              <Chip size="small" color="error" variant="outlined" label={`${data.overflow} báo cáo bị bỏ vì bảng đầy`} />
            )}
            {data.throttled > 0 && (
              // v2.2.2: một nguồn gửi tạo quá nhiều khoá MỚI nên phần vượt bị bỏ — dấu hiệu bơm nhiễu từ một nguồn.
              <Chip size="small" color="warning" variant="outlined" label={`${data.throttled} báo cáo bị bỏ vì một nguồn gửi quá nhiều khoá mới`} />
            )}
          </Stack>
          <Paper variant="outlined" sx={{ borderRadius: 1, overflow: "hidden", mb: 2 }}>
            {data.entries.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ p: 2 }}>
                Chưa có vi phạm nào trong cửa sổ quan sát này.
              </Typography>
            ) : (
              <Stack divider={<Divider />}>
                {data.entries.map((e) => (
                  <Box key={`${e.directive}|${e.blocked}`} sx={{ px: 2, py: 1.25 }}>
                    <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
                      <Chip size="small" color="warning" label={e.directive} />
                      <Typography variant="body2" sx={{ wordBreak: "break-all" }}>
                        chặn <b>{e.blocked}</b>
                      </Typography>
                      <Chip size="small" variant="outlined" label={`${e.count}×`} />
                    </Stack>
                    <Typography variant="caption" color="text.secondary" sx={{ display: "block", mt: 0.5, wordBreak: "break-all" }}>
                      tại {e.document}{e.otherDocuments > 0 ? ` (+${e.otherDocuments} lần ở trang khác)` : ""} · {e.reporters || 1} nguồn báo cáo · lần cuối {fmt(e.lastSeen)}
                      {e.sample ? ` · mẫu: ${e.sample}` : ""}
                    </Typography>
                  </Box>
                ))}
              </Stack>
            )}
          </Paper>
        </>
      )}

      <Stack direction="row" spacing={1}>
        <Button variant="outlined" startIcon={<RefreshIcon />} onClick={load} disabled={loading}>
          Làm mới
        </Button>
        <Button variant="text" color="inherit" onClick={reset} disabled={loading}>
          Bắt đầu lại cửa sổ quan sát
        </Button>
      </Stack>
      {reauthDialog}
    </Box>
  );
}
