import React, { useCallback, useEffect, useState } from "react";
import { Button, TextField } from "@mui/material";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import VisibilityOffOutlinedIcon from "@mui/icons-material/VisibilityOffOutlined";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import InfoRow from "./InfoRow";
import PasswordConfirmDialog from "../../components/PasswordConfirmDialog";
import { getRealName, updateRealName } from "../../api/users.api";
import { useSnackbar } from "../../context/SnackbarContext";

/**
 * ==== v2.2.0 — Tên thật: ẩn mặc định, xem/đổi phải nhập lại mật khẩu ====
 * Tên thật KHÔNG có trong dữ liệu hồ sơ gửi xuống trình duyệt (backend để ở collection riêng, xem services/userPrivate.js) — nên "ẩn"
 * ở đây là thật chứ không chỉ che giao diện. Sau khi nhập mật khẩu, tên hiện trong REVEAL_MS rồi tự ẩn lại.
 */
export const REVEAL_MS = 60 * 1000;

export default function RealNameRow() {
  const snackbar = useSnackbar();
  const [revealed, setRevealed] = useState(null); // null = đang ẩn
  const [dialog, setDialog] = useState(null); // null | "reveal" | "edit"
  const [newName, setNewName] = useState("");

  useEffect(() => {
    if (revealed === null) return undefined;
    const t = setTimeout(() => setRevealed(null), REVEAL_MS);
    return () => clearTimeout(t);
  }, [revealed]);

  const closeDialog = useCallback(() => setDialog(null), []);

  const handleReveal = async () => {
    const name = await getRealName();
    setRevealed(name || "(chưa có)");
  };

  const handleEdit = async () => {
    await updateRealName(newName.trim());
    setRevealed(null); // lần xem tiếp theo sẽ đọc lại giá trị mới
    setNewName("");
    snackbar.success("Đã cập nhật tên thật.");
  };

  return (
    <>
      <InfoRow
        label="Tên thật"
        helper="Chỉ dùng để xác minh tài khoản, không hiển thị công khai. Cần nhập mật khẩu để xem hoặc đổi."
        actions={
          <>
            {revealed === null ? (
              <Button size="small" startIcon={<VisibilityOutlinedIcon />} onClick={() => setDialog("reveal")}>
                Hiện
              </Button>
            ) : (
              <Button size="small" startIcon={<VisibilityOffOutlinedIcon />} onClick={() => setRevealed(null)}>
                Ẩn
              </Button>
            )}
            <Button
              size="small"
              startIcon={<EditOutlinedIcon />}
              onClick={() => {
                setNewName("");
                setDialog("edit");
              }}
            >
              Đổi
            </Button>
          </>
        }
      >
        {revealed === null ? "••••••••••" : revealed}
      </InfoRow>

      <PasswordConfirmDialog
        open={dialog === "reveal"}
        title="Hiện tên thật"
        description="Nhập mật khẩu để xem tên thật. Tên sẽ tự ẩn lại sau 1 phút."
        confirmText="Hiện tên thật"
        onConfirm={handleReveal}
        onClose={closeDialog}
      />

      <PasswordConfirmDialog
        open={dialog === "edit"}
        title="Đổi tên thật"
        description="Nhập tên thật mới và mật khẩu để xác nhận."
        confirmText="Lưu tên thật"
        confirmDisabled={!newName.trim()}
        onConfirm={handleEdit}
        onClose={closeDialog}
      >
        <TextField label="Tên thật mới" value={newName} onChange={(e) => setNewName(e.target.value)} inputProps={{ maxLength: 100 }} fullWidth autoComplete="off" />
      </PasswordConfirmDialog>
    </>
  );
}
