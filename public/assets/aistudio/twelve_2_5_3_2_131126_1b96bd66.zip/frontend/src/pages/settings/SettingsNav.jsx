import React from "react";
import { Link as RouterLink } from "react-router-dom";
import { Box, Paper, List, ListItemButton, ListItemIcon, ListItemText, Divider, Breadcrumbs, Link, Typography } from "@mui/material";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import { buildHref } from "./settingsTree";
import { useGoUp } from "../../hooks/useBack";

/**
 * ==== v2.1.0 — Hai khối giao diện DÙNG CHUNG cho mọi cấp của trang Cài đặt ====
 * - SettingsRows: danh sách các mục (chỉ có TÊN + mũi tên), dùng cho gốc tab lẫn mọi thư mục.
 *   Mỗi hàng là một liên kết thật (<a>) nên mở tab mới/sao chép link được.
 * - SettingsHeaderBar: đường dẫn các cấp, hiện ở mọi cấp sâu hơn gốc tab. v2.4.2: KHÔNG còn nút ← riêng — nút Back duy nhất nằm ở headZone
 *   (SettingsPage khai báo `backTo`); các cấp cha trong đường dẫn cũng "đi lên" chứ không đẩy mục lịch sử mới (xem hooks/useBack.js).
 * Không khối nào biết gì về nội dung cụ thể — thêm mục mới không phải sửa file này.
 */

export function SettingsRows({ items, tabKey, parentKeys = [] }) {
  // Nếu có ít nhất một hàng có icon thì mọi hàng cùng danh sách chừa chỗ icon → tên luôn thẳng hàng.
  const reserveIcon = items.some((it) => it.icon);
  return (
    <Paper variant="outlined" sx={{ borderRadius: 1, overflow: "hidden" }}>
      <List disablePadding aria-label="Danh sách mục cài đặt">
        {items.map((it, i) => (
          <React.Fragment key={it.key}>
            {i > 0 && <Divider component="li" />}
            <ListItemButton component={RouterLink} to={buildHref(tabKey, [...parentKeys, it.key])} sx={{ py: 1.75, px: 2 }}>
              {reserveIcon && <ListItemIcon sx={{ minWidth: 44, color: "text.secondary" }}>{it.icon || null}</ListItemIcon>}
              <ListItemText primary={it.title} primaryTypographyProps={{ fontWeight: 600 }} />
              <ChevronRightIcon sx={{ color: "text.disabled", ml: 1 }} />
            </ListItemButton>
          </React.Fragment>
        ))}
      </List>
    </Paper>
  );
}

/**
 * @param tabKey  khoá tab hiện tại
 * @param trail   các nút từ sau tab tới mục hiện tại (không rỗng — gốc tab không vẽ thanh này)
 */
export function SettingsHeaderBar({ tabKey, trail }) {
  const goUp = useGoUp();
  const keys = trail.map((n) => n.key);
  const current = trail[trail.length - 1];
  return (
    <Box sx={{ display: "flex", alignItems: "center", mb: 2, minWidth: 0 }}>
      <Breadcrumbs separator={<NavigateNextIcon fontSize="small" />} aria-label="Đường dẫn mục cài đặt" sx={{ minWidth: 0 }}>
        {trail.slice(0, -1).map((n, i) => {
          const href = buildHref(tabKey, keys.slice(0, i + 1));
          return (
            <Link
              key={n.key}
              component={RouterLink}
              to={href}
              // Bấm trái thường = ĐI LÊN (không đẩy mục lịch sử mới); bấm giữa/Ctrl/⌘/Shift giữ hành vi liên kết thật (mở tab mới…).
              onClick={(e) => {
                if (e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) {
                  e.preventDefault();
                  goUp(href);
                }
              }}
              underline="hover"
              color="text.secondary"
              variant="subtitle1"
            >
              {n.title}
            </Link>
          );
        })}
        <Typography variant="subtitle1" fontWeight={700} color="text.primary" aria-current="page">
          {current.title}
        </Typography>
      </Breadcrumbs>
    </Box>
  );
}
