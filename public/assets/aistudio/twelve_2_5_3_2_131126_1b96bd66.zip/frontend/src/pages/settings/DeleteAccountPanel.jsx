import React, { useState } from "react";
import { Alert, Box, Button, Checkbox, FormControlLabel, List, ListItem, ListItemText, Paper, Typography } from "@mui/material";
import DeleteForeverOutlinedIcon from "@mui/icons-material/DeleteForeverOutlined";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { useSnackbar } from "../../context/SnackbarContext";
import { requestAccountDeletion } from "../../api/users.api";
import PasswordConfirmDialog from "../../components/PasswordConfirmDialog";

/**
 * ==== Settings > Tài khoản > Bảo mật > Xoá tài khoản (v2.2.0) ====
 * Nhập lại mật khẩu → backend ghi nhớ yêu cầu + khoá tài khoản rồi trả 202 NGAY. Phần xoá thật (bài viết, blog, ảnh trên Cloudinary, hồ sơ)
 * chạy NỀN trên server và vẫn tiếp tục nếu người dùng đóng trình duyệt/mất mạng; server sập giữa chừng cũng tự xoá tiếp (xem backend
 * services/accountDeletion.js). Khi nhận 202 giao diện đăng xuất ngay.
 */
export default function DeleteAccountPanel() {
  const { signOut, isSA } = useAuth();
  const snackbar = useSnackbar();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [understood, setUnderstood] = useState(false);

  const finishLocally = async () => {
    await signOut();
    snackbar.success("Đã tiếp nhận yêu cầu xoá tài khoản. Dữ liệu của bạn đang được xoá.");
    navigate("/", { replace: true });
  };

  const handleConfirm = async () => {
    try {
      await requestAccountDeletion();
    } catch (err) {
      const code = err?.response?.data?.code;
      if (code === "ACCOUNT_DELETING") {
        // Yêu cầu trước đó đã được tiếp nhận (vd. mất mạng lúc nhận phản hồi) — coi như thành công.
        await finishLocally();
        return;
      }
      if (!err?.response) {
        throw new Error(
          "Không nhận được phản hồi từ máy chủ. Nếu bạn vừa bị đăng xuất thì yêu cầu xoá đã được tiếp nhận; nếu không, hãy thử lại."
        );
      }
      throw err;
    }
    await finishLocally();
  };

  return (
    <Box>
      <Alert severity="error" sx={{ mb: 2 }}>
        Xoá tài khoản là <strong>vĩnh viễn và không thể hoàn tác</strong>.
      </Alert>
      <Paper variant="outlined" sx={{ p: 2, borderRadius: 1 }}>
        <Typography variant="subtitle2" fontWeight={700}>
          Những gì sẽ bị xoá
        </Typography>
        <List dense disablePadding sx={{ mb: 2 }}>
          <ListItem disableGutters>
            <ListItemText primary="Toàn bộ bài viết và blog của bạn (kể cả bản nháp), cùng bình luận, lượt thích và lượt xem trên các bài đó." />
          </ListItem>
          <ListItem disableGutters>
            <ListItemText primary="Ảnh đại diện và mọi tệp bạn đã tải lên." />
          </ListItem>
          <ListItem disableGutters>
            <ListItemText primary="Hồ sơ, Tag Name Search (được giải phóng cho người khác), điểm tài khoản và tài khoản đăng nhập." />
          </ListItem>
        </List>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Bình luận bạn đã viết trên bài của người khác vẫn được giữ lại và hiển thị là “Người dùng Twelve”. Việc xoá chạy nền trên máy chủ: sau khi xác nhận,
          bạn sẽ bị đăng xuất ngay và có thể đóng trình duyệt.
        </Typography>
        {isSA && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            Tài khoản quản trị (SA) không thể tự xoá. Hãy hạ quyền tài khoản này trước.
          </Alert>
        )}
        <Button variant="contained" color="error" startIcon={<DeleteForeverOutlinedIcon />} disabled={isSA} onClick={() => { setUnderstood(false); setOpen(true); }}>
          Xoá tài khoản
        </Button>
      </Paper>

      <PasswordConfirmDialog
        open={open}
        title="Xác nhận xoá tài khoản"
        description="Nhập mật khẩu để xác nhận. Sau bước này, tài khoản sẽ bị khoá ngay và dữ liệu bị xoá vĩnh viễn."
        confirmText="Xoá vĩnh viễn"
        confirmColor="error"
        confirmDisabled={!understood}
        onConfirm={handleConfirm}
        onClose={() => setOpen(false)}
      >
        <FormControlLabel
          control={<Checkbox checked={understood} onChange={(e) => setUnderstood(e.target.checked)} />}
          label="Tôi hiểu rằng việc này không thể hoàn tác."
        />
      </PasswordConfirmDialog>
    </Box>
  );
}
