import React, { useEffect, useState, useCallback } from "react";
import {
  Box,
  Typography,
  Paper,
  Stack,
  TextField,
  IconButton,
  Button,
  Divider,
  CircularProgress,
  Alert,
  Chip,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import SaveIcon from "@mui/icons-material/Save";
import { getAdminFonts, updateAdminFonts } from "../../api/fonts.api";
import { useSnackbar } from "../../context/SnackbarContext";
import { useThemeMode } from "../../context/ThemeModeContext";
import useReauthRetry from "../../hooks/useReauthRetry";

/**
 * ==== v2.0.8 — Quản trị > Font chữ trên server (#1.1, chỉ SA) ====
 * Danh sách font "chính thức" mọi người dùng sẽ thấy ở Cài đặt > Ứng dụng > Font chữ.
 * Hai nguồn: (1) link https trực tiếp tới file font; (2) file nằm sẵn trong thư mục backend/fonts của server.
 */
export default function AdminFontsPanel() {
  const snackbar = useSnackbar();
  const { refreshServerFonts } = useThemeMode();
  // v2.5.3 [TW-09]: PUT /admin/fonts đòi vừa nhập lại mật khẩu (403 REAUTH_REQUIRED) — hook mở hộp mật khẩu rồi thử lại đúng lần lưu này.
  const { run: runWithReauth, reauthDialog } = useReauthRetry({ title: "Xác nhận để lưu font", description: "Thêm/đổi font từ máy chủ ngoài ảnh hưởng mọi người dùng, nên cần nhập lại mật khẩu (hiệu lực 5 phút).", confirmText: "Xác nhận và lưu" });
  const [loadError, setLoadError] = useState("");
  const [visibleCount, setVisibleCount] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [fonts, setFonts] = useState([]);
  const [availableFiles, setAvailableFiles] = useState([]);
  const [maxFonts, setMaxFonts] = useState(20);
  const [newUrl, setNewUrl] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [newFile, setNewFile] = useState("");

  const apply = (data) => {
    setFonts(Array.isArray(data.fonts) ? data.fonts : []);
    setAvailableFiles(Array.isArray(data.availableFiles) ? data.availableFiles : []);
    if (data.limits && data.limits.maxFonts) setMaxFonts(data.limits.maxFonts);
    setVisibleCount(typeof data.visibleCount === "number" ? data.visibleCount : null);
    setLoadError("");
  };

  const load = useCallback(() => {
    setLoading(true);
    getAdminFonts()
      .then(apply)
      .catch((err) => {
        // v2.0.9: báo lỗi NGAY TRÊN trang (trước đây chỉ có snackbar thoáng qua rồi hiện "Chưa có font nào" gây hiểu nhầm).
        const msg = err.message || "Không tải được cấu hình font.";
        setLoadError(msg);
        snackbar.error(msg);
      })
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const usedFiles = new Set(fonts.filter((f) => f.kind === "file").map((f) => f.file));
  const freeFiles = availableFiles.filter((f) => !usedFiles.has(f.name));
  const full = fonts.length >= maxFonts;

  const addUrl = () => {
    const url = newUrl.trim();
    if (!url) return;
    setFonts((prev) => [...prev, { kind: "url", url, label: newLabel.trim() || "Font mới", weight: "100 900" }]);
    setNewUrl("");
    setNewLabel("");
  };

  const addFile = () => {
    if (!newFile) return;
    setFonts((prev) => [...prev, { kind: "file", file: newFile, label: newLabel.trim() || newFile.replace(/\.[^.]+$/, ""), weight: "100 900" }]);
    setNewFile("");
    setNewLabel("");
  };

  const change = (i, field, value) => setFonts((prev) => prev.map((f, idx) => (idx === i ? { ...f, [field]: value } : f)));
  const remove = (i) => setFonts((prev) => prev.filter((_, idx) => idx !== i));

  const save = () => {
    setSaving(true);
    // Chỉ gửi các field backend nhận (bỏ field chỉ-đọc như fileMissing).
    const payload = fonts.map((f) => ({ id: f.id, label: f.label, kind: f.kind, url: f.url, file: f.file, weight: f.weight, note: f.note }));
    runWithReauth(() => updateAdminFonts(payload))
      .then((data) => {
        apply(data);
        refreshServerFonts(); // cập nhật ngay danh sách ở Cài đặt > Ứng dụng của chính SA
        snackbar.success("Đã lưu danh sách font.");
      })
      .catch((err) => {
        if (err?.reauthCancelled) return; // người dùng bấm Hủy ở hộp mật khẩu — không phải lỗi
        snackbar.error(err.message || "Không lưu được danh sách font.");
      })
      .finally(() => setSaving(false));
  };

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (loadError) {
    return (
      <Box>
        <Alert severity="error" action={<Button color="inherit" size="small" onClick={load}>Thử lại</Button>}>
          Không tải được cấu hình font: {loadError}. Nếu lỗi là "Not found"/404, có thể backend chưa được deploy bản có tính năng font server.
        </Alert>
      </Box>
    );
  }

  return (
    <Box>
      {/* v2.1.0: tiêu đề do khung Cài đặt vẽ (registry.jsx: "Font chữ trên server") */}
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Font do bạn cài sẽ hiện cho mọi người dùng trong Cài đặt &gt; Ứng dụng &gt; Font chữ. Có thể dùng link https trực tiếp tới file font
        (.woff2/.woff/.ttf/.otf — máy chủ đó phải cho phép CORS), hoặc file đã đặt sẵn trong thư mục <code>backend/fonts</code> trên server.
        Font phải hỗ trợ đủ tiếng Việt. Độ đậm: nhập "400" nếu font có đúng một độ đậm cố định, để "100 900" nếu muốn trình duyệt không tự làm đậm giả.
      </Typography>

      <Paper variant="outlined" sx={{ borderRadius: 1, overflow: "hidden", mb: 2 }}>
        <Box sx={{ px: 2, py: 1.25, bgcolor: "action.hover" }}>
          <Typography variant="caption" fontWeight={700} color="text.secondary">
            Danh sách font ({fonts.length}/{maxFonts}){visibleCount !== null ? ` — đang hiển thị với người dùng: ${visibleCount}` : ""}
          </Typography>
        </Box>
        <Divider />
        {fonts.length === 0 ? (
          <Typography variant="body2" color="text.secondary" sx={{ p: 2 }}>
            Chưa có font nào.
          </Typography>
        ) : (
          <Stack divider={<Divider />}>
            {fonts.map((f, i) => (
              <Stack key={f.id || `new-${i}`} spacing={1} sx={{ px: 2, py: 1.5 }}>
                <Stack direction="row" spacing={1} alignItems="center">
                  <TextField size="small" label="Tên hiển thị" value={f.label || ""} onChange={(e) => change(i, "label", e.target.value)} inputProps={{ maxLength: 40 }} sx={{ flex: 1, minWidth: 0 }} />
                  <TextField size="small" label="Độ đậm" value={f.weight || ""} onChange={(e) => change(i, "weight", e.target.value)} sx={{ width: 110 }} />
                  <IconButton size="small" color="error" onClick={() => remove(i)} aria-label={`Xoá font ${f.label}`}>
                    <DeleteOutlineIcon fontSize="small" />
                  </IconButton>
                </Stack>
                <Stack direction="row" spacing={1} alignItems="center">
                  <Chip size="small" label={f.kind === "file" ? "File trên server" : "Link"} />
                  {f.kind === "url" ? (
                    <TextField size="small" label="Link file font" value={f.url || ""} onChange={(e) => change(i, "url", e.target.value)} fullWidth />
                  ) : (
                    <Typography variant="body2" sx={{ wordBreak: "break-all" }}>
                      {f.file}
                    </Typography>
                  )}
                </Stack>
                {f.hiddenReason && <Alert severity="warning">Font này đang bị ẨN với người dùng: {f.hiddenReason}</Alert>}
              </Stack>
            ))}
          </Stack>
        )}
      </Paper>

      <Paper variant="outlined" sx={{ borderRadius: 1, p: 2, mb: 2 }}>
        <Typography variant="body2" fontWeight={600} sx={{ mb: 1 }}>
          Thêm font
        </Typography>
        <Stack spacing={1.25}>
          <TextField size="small" label="Tên hiển thị" value={newLabel} onChange={(e) => setNewLabel(e.target.value)} inputProps={{ maxLength: 40 }} />
          <Stack direction={{ xs: "column", sm: "row" }} spacing={1}>
            <TextField size="small" label="Link file font (https://…)" value={newUrl} onChange={(e) => setNewUrl(e.target.value)} sx={{ flex: 1 }} />
            <Button variant="outlined" startIcon={<AddIcon />} onClick={addUrl} disabled={!newUrl.trim() || full}>
              Thêm từ link
            </Button>
          </Stack>
          <Stack direction={{ xs: "column", sm: "row" }} spacing={1}>
            <FormControl size="small" sx={{ flex: 1 }} disabled={freeFiles.length === 0}>
              <InputLabel id="font-file-label">{freeFiles.length ? "File trên server" : "Không có file nào chưa dùng trong backend/fonts"}</InputLabel>
              <Select labelId="font-file-label" label={freeFiles.length ? "File trên server" : "Không có file nào chưa dùng trong backend/fonts"} value={newFile} onChange={(e) => setNewFile(e.target.value)}>
                {freeFiles.map((f) => (
                  <MenuItem key={f.name} value={f.name}>
                    {f.name} ({Math.round(f.size / 1024)} KB)
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <Button variant="outlined" startIcon={<AddIcon />} onClick={addFile} disabled={!newFile || full}>
              Thêm từ file
            </Button>
          </Stack>
        </Stack>
      </Paper>

      <Button variant="contained" startIcon={saving ? <CircularProgress size={16} color="inherit" /> : <SaveIcon />} onClick={save} disabled={saving}>
        Lưu danh sách font
      </Button>
      {reauthDialog}
    </Box>
  );
}
