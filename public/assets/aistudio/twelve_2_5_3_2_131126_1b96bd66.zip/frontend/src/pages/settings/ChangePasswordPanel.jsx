import React, { useState } from "react";
import { Alert, Box, Button, Link, Paper, Stack, TextField, Typography } from "@mui/material";
import { updatePassword } from "firebase/auth";
import { auth } from "../../firebase";
import { useAuth } from "../../context/AuthContext";
import { useSnackbar } from "../../context/SnackbarContext";
import { reauthWithPassword, describeAuthError } from "../../utils/reauth";
import ForgotPasswordDialog from "../../components/ForgotPasswordDialog";

/**
 * ==== Settings > Tài khoản > Bảo mật > Đổi mật khẩu (v2.2.0) ====
 * Nhập mật khẩu cũ → Firebase xác nhận (reauthenticateWithCredential) → updatePassword. Mật khẩu mới theo quy tắc đăng ký (8–128 ký tự).
 * Quên mật khẩu cũ: "Quên mật khẩu?" mở đúng hộp dùng ở trang Đăng nhập (email khoá theo tài khoản đang đăng nhập).
 * Firebase thu hồi các phiên khác khi đổi mật khẩu; backend Twelve từ chối token cũ trong ≤60 giây (xem middleware/auth.js, F6).
 */
export const PASSWORD_MIN = 8;
export const PASSWORD_MAX = 128;

export function validateNewPassword({ current, next, confirm }) {
  if (!current) return "Vui lòng nhập mật khẩu hiện tại.";
  if (next.length < PASSWORD_MIN) return `Mật khẩu mới phải có ít nhất ${PASSWORD_MIN} ký tự.`;
  if (next.length > PASSWORD_MAX) return `Mật khẩu mới tối đa ${PASSWORD_MAX} ký tự.`;
  if (next === current) return "Mật khẩu mới phải khác mật khẩu hiện tại.";
  if (next !== confirm) return "Mật khẩu nhập lại không khớp.";
  return "";
}

const EMPTY = { current: "", next: "", confirm: "" };

export default function ChangePasswordPanel() {
  const { firebaseUser } = useAuth();
  const snackbar = useSnackbar();
  const [form, setForm] = useState(EMPTY);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [forgotOpen, setForgotOpen] = useState(false);

  const handleChange = (field) => (e) => {
    setForm((f) => ({ ...f, [field]: e.target.value }));
    setError("");
  };

  const submit = async (e) => {
    e.preventDefault();
    const problem = validateNewPassword(form);
    if (problem) {
      setError(problem);
      return;
    }
    setBusy(true);
    setError("");
    try {
      await reauthWithPassword(form.current);
      await updatePassword(auth.currentUser, form.next);
      setForm(EMPTY);
      snackbar.success("Đã đổi mật khẩu.");
    } catch (err) {
      setError(err?.code && err.code.startsWith("auth/") ? describeAuthError(err) : err?.message || "Đổi mật khẩu thất bại.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Box>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Nhập mật khẩu hiện tại để đặt mật khẩu mới. Các thiết bị khác có thể bị yêu cầu đăng nhập lại.
      </Typography>
      <Paper variant="outlined" sx={{ p: 2, borderRadius: 1 }}>
        <Box component="form" onSubmit={submit}>
          <Stack spacing={2}>
            <TextField label="Mật khẩu hiện tại" type="password" value={form.current} onChange={handleChange("current")} autoComplete="current-password" fullWidth />
            <Box sx={{ mt: "-8px !important", textAlign: "right" }}>
              <Link component="button" type="button" variant="body2" underline="hover" onClick={() => setForgotOpen(true)}>
                Quên mật khẩu?
              </Link>
            </Box>
            <TextField
              label="Mật khẩu mới"
              type="password"
              value={form.next}
              onChange={handleChange("next")}
              autoComplete="new-password"
              helperText={`Tối thiểu ${PASSWORD_MIN} ký tự.`}
              fullWidth
            />
            <TextField label="Nhập lại mật khẩu mới" type="password" value={form.confirm} onChange={handleChange("confirm")} autoComplete="new-password" fullWidth />
            {error && <Alert severity="error">{error}</Alert>}
            <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
              <Button type="submit" variant="contained" disabled={busy || !form.current || !form.next || !form.confirm}>
                {busy ? "Đang đổi..." : "Đổi mật khẩu"}
              </Button>
            </Box>
          </Stack>
        </Box>
      </Paper>

      <ForgotPasswordDialog open={forgotOpen} onClose={() => setForgotOpen(false)} initialEmail={firebaseUser?.email || ""} emailLocked />
    </Box>
  );
}
