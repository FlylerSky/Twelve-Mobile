/**
 * ==== v2.1.0 — Cây mục Cài đặt (logic thuần, không phụ thuộc React) ====
 *
 * Toàn bộ trang Cài đặt là MỘT cây khai báo (xem registry.jsx), giống hệ thống thư mục:
 *
 *   tab (gốc)  ─┬─ mục LÁ     (có `component`)  → mở ra là thấy nội dung tuỳ chọn
 *               └─ mục THƯ MỤC (có `children`)   → mở ra là thấy danh sách tên các mục con
 *
 * Hình dạng một nút:
 *   {
 *     key:        string  — đoạn URL, chữ thường/số/gạch ngang, duy nhất trong cùng cấp
 *     title:      string  — tên hiển thị (hàng, đường dẫn, nhãn tab)
 *     icon?:      ReactNode
 *     requires?:  "sa" | "user" — điều kiện quyền (SA / đã đăng nhập); nút (và mọi thứ bên dưới) ẩn nếu không đạt
 *     component?: React component (nên là React.lazy)  — chỉ ở nút LÁ
 *     props?:     object  — truyền cho component (một component dùng lại cho nhiều mục)
 *     children?:  Node[]  — chỉ ở nút THƯ MỤC
 *   }
 *
 * Quy tắc tự động (không ai phải nhớ khi thêm mục mới):
 *   1. Có `children` ⇒ thư mục; có `component` ⇒ lá; không được có cả hai hoặc không có gì (validateTree báo lỗi).
 *   2. Nút không đạt `requires` bị ẩn khỏi danh sách VÀ không mở được bằng URL trực tiếp.
 *   3. Thư mục không còn mục con nào hiển thị được thì tự biến mất.
 *   4. Thư mục chỉ còn ĐÚNG MỘT mục con hiển thị được thì mở ra là thấy luôn nội dung/mục con đó
 *      ("một tuỳ chọn thì hiện luôn") — không bắt người dùng bấm thêm một tầng vô nghĩa.
 *
 * Lưu ý: ẩn theo quyền ở đây chỉ là lớp giao diện. Backend (requireSA) mới là nơi thực sự chặn.
 */

const KEY_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

/**
 * Bảng quyền → hàm kiểm tra. Thêm quyền mới ở đây (vd. "mod") rồi dùng `requires: "mod"` trong registry (và thêm vào KNOWN_REQUIRES).
 * v2.2.0: thêm "user" = đã đăng nhập (trang Cài đặt mở được cho khách để chỉnh giao diện/font, nhưng tab Tài khoản chỉ dành cho người đã đăng nhập).
 */
export function buildAccess({ isSA = false, isLoggedIn = false } = {}) {
  return { sa: isSA === true, user: isLoggedIn === true };
}

const KNOWN_REQUIRES = ["sa", "user"];

export const isFolder = (node) => Array.isArray(node?.children);

/** Nút này có được phép thấy không? Quyền lạ/gõ sai ⇒ KHÔNG cho thấy (từ chối mặc định). */
export function isAllowed(node, access) {
  if (!node.requires) return true;
  return access?.[node.requires] === true;
}

/** Các mục con hiển thị được của một thư mục: đạt quyền, và (nếu là thư mục) còn ít nhất một mục con hiển thị được. */
export function visibleChildren(node, access) {
  return (node?.children || []).filter(
    (c) => isAllowed(c, access) && (!isFolder(c) || visibleChildren(c, access).length > 0)
  );
}

/** Đường dẫn URL tới một mục: /settings/<tab>/<khoá>/<khoá>… */
export function buildHref(tabKey, keys = []) {
  return ["/settings", tabKey, ...keys].join("/");
}

/**
 * Tìm mục theo URL.
 * @param tabs     cây gốc (mảng các tab)
 * @param access   kết quả buildAccess()
 * @param tabKey   đoạn URL thứ nhất (undefined ⇒ tab đầu tiên)
 * @param segments các đoạn URL còn lại
 * @returns { ok:false, tabs, tab?, trail? }  khi không tìm thấy / không đủ quyền
 *       hoặc { ok:true, tabs, tab, trail, node, kind:"folder"|"leaf", items }
 *   - tabs : các tab hiển thị được
 *   - trail: các nút TỪ SAU tab tới mục hiện tại (rỗng ⇒ đang ở gốc tab)
 *   - node : nút sẽ được vẽ (đã áp dụng quy tắc 4 — thư mục một con được thay bằng nội dung của con đó)
 *   - items: nếu kind="folder" — các mục con để vẽ thành hàng
 */
export function resolvePath(tabs, access, tabKey, segments = []) {
  const visibleTabs = visibleChildren({ children: tabs }, access);
  const tab = tabKey == null ? visibleTabs[0] : visibleTabs.find((t) => t.key === tabKey);
  if (!tab) return { ok: false, tabs: visibleTabs };

  const trail = [];
  let node = tab;
  for (const seg of segments) {
    if (!isFolder(node)) return { ok: false, tabs: visibleTabs, tab, trail };
    const next = visibleChildren(node, access).find((c) => c.key === seg);
    if (!next) return { ok: false, tabs: visibleTabs, tab, trail };
    trail.push(next);
    node = next;
  }

  // Quy tắc 4: thư mục (không phải gốc tab) chỉ có một con hiển thị được ⇒ vẽ luôn con đó, giữ tên/khoá của thư mục.
  while (node !== tab && isFolder(node)) {
    const kids = visibleChildren(node, access);
    if (kids.length !== 1) break;
    node = { ...kids[0], key: node.key, title: node.title, icon: node.icon };
  }

  if (isFolder(node)) return { ok: true, tabs: visibleTabs, tab, trail, node, kind: "folder", items: visibleChildren(node, access) };
  return { ok: true, tabs: visibleTabs, tab, trail, node, kind: "leaf", items: [] };
}

/**
 * Kiểm tra cây khai báo — chạy trong test (tests/settingsTree.test.js) để mục thêm sau này sai quy ước là báo đỏ ngay.
 * @returns string[] danh sách lỗi (rỗng = hợp lệ)
 */
export function validateTree(tabs) {
  const errors = [];
  const walk = (nodes, path) => {
    const seen = new Set();
    nodes.forEach((n, i) => {
      const where = [...path, n?.key ?? `#${i}`].join("/");
      if (!n || typeof n !== "object") return errors.push(`${where}: không phải object`);
      if (typeof n.key !== "string" || !KEY_RE.test(n.key)) errors.push(`${where}: key phải là chữ thường/số, nối bằng gạch ngang`);
      if (seen.has(n.key)) errors.push(`${where}: trùng key trong cùng cấp`);
      seen.add(n.key);
      if (typeof n.title !== "string" || !n.title.trim()) errors.push(`${where}: thiếu title`);
      if (n.requires !== undefined && !KNOWN_REQUIRES.includes(n.requires)) errors.push(`${where}: requires "${n.requires}" chưa được hỗ trợ (xem buildAccess)`);
      const hasKids = Array.isArray(n.children);
      const hasComp = n.component != null;
      if (hasKids && hasComp) errors.push(`${where}: vừa có children vừa có component`);
      if (!hasKids && !hasComp) errors.push(`${where}: phải có children (thư mục) hoặc component (mục lá)`);
      if (hasKids) {
        if (n.children.length === 0) errors.push(`${where}: thư mục rỗng`);
        walk(n.children, [...path, n.key]);
      }
    });
  };
  walk(tabs, []);
  return errors;
}
