import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Box, Paper, Avatar, Button, Stack, Typography, CircularProgress, Dialog, DialogTitle, DialogContent, DialogActions, Alert, AlertTitle } from "@mui/material";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import { useAuth } from "../../context/AuthContext";
import { useSnackbar } from "../../context/SnackbarContext";
import { updateMe, updateTagName } from "../../api/users.api";
import { listCountries } from "../../api/countries.api";
import AvatarCropper from "../../components/AvatarCropper";
import useAvatarUpload from "../../hooks/useAvatarUpload";
import useTagNameAvailability from "../../hooks/useTagNameAvailability";
import TagNameField from "../../components/TagNameField";
import { ProfileFieldsGrid, BioField } from "../../components/ProfileFields";
import { bioStats } from "../../utils/bio";
import { normalizeTag } from "../../utils/profilePath";
import InfoRow from "./InfoRow";
import CoverImageRow from "./CoverImageRow";
import RealNameRow from "./RealNameRow";
import ProfileExtrasCard from "./ProfileExtrasCard";

/**
 * ==== Settings > Tài khoản > Thông tin (v2.2.0) ====
 * Hiển thị thông tin Twelve đã thu thập khi tạo tài khoản và cho sửa lại. Mỗi loại sửa theo cách riêng vì rủi ro khác nhau:
 *   - Ảnh đại diện: AvatarCropper + upload (dùng chung với màn hình Chào mừng).
 *   - Ảnh bìa (v2.4.0): CoverImageRow — tải lên (cắt 3:1) / dán đường dẫn / gỡ.
 *   - Tên hiển thị / Sinh nhật / Giới tính / Quốc gia / Tiểu sử (v2.5.2): một form, nút Lưu chỉ sáng khi có thay đổi (PATCH /users/me — chỉ gửi trường đã đổi).
 *     Tiểu sử hiện công khai ở đầu trang Profile; quá giới hạn ký tự/dòng thì báo đỏ và nút Lưu bị khoá (xem utils/bio.js).
 *   - Tag Name Search: hộp riêng có kiểm tra trùng trực tiếp (khoá duy nhất, đổi trong 1 transaction ở backend). v2.4.2.1: bước XÁC NHẬN có cảnh báo —
 *     URL hồ sơ là /u/@<tag> nên đổi tag làm các link hồ sơ đã chia sẻ ra ngoài hết hiệu lực, và tag cũ có thể bị người khác nhận.
 *   - Tên thật: ẩn, xem/đổi phải nhập lại mật khẩu (RealNameRow).
 *   - Thông tin mở rộng (v2.5.2): ProfileExtrasCard — công tắc chọn mục hiển thị trong hộp "Xem thêm" của hồ sơ (áp dụng ngay, không qua nút Lưu).
 */
const FIELDS = ["displayName", "birthday", "gender", "country", "bio"];
const pick = (p) => Object.fromEntries(FIELDS.map((f) => [f, (p && p[f]) || ""]));

export default function AccountInfoPanel() {
  const { profile, refreshProfile } = useAuth();
  const snackbar = useSnackbar();

  const [countries, setCountries] = useState([]);
  const [baseline, setBaseline] = useState(() => pick(profile));
  const [form, setForm] = useState(() => pick(profile));
  const [saving, setSaving] = useState(false);
  const [cropperOpen, setCropperOpen] = useState(false);
  const [tagOpen, setTagOpen] = useState(false);
  const [tagValue, setTagValue] = useState("");

  // Hồ sơ cập nhật realtime (điểm số...) — chỉ nạp vào form MỘT lần khi hồ sơ xuất hiện, kẻo ghi đè thứ người dùng đang gõ.
  const initialised = useRef(!!profile);
  useEffect(() => {
    if (profile && !initialised.current) {
      initialised.current = true;
      setBaseline(pick(profile));
      setForm(pick(profile));
    }
  }, [profile]);

  useEffect(() => {
    listCountries().then(setCountries).catch(() => {});
  }, []);

  const dirtyFields = useMemo(() => FIELDS.filter((f) => form[f] !== baseline[f]), [form, baseline]);
  const bioValid = bioStats(form.bio).valid;
  const handleChange = useCallback((field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value })), []);

  const handleSave = async () => {
    const changes = Object.fromEntries(dirtyFields.map((f) => [f, form[f]]));
    setSaving(true);
    try {
      await updateMe(changes);
      setBaseline(form);
      await refreshProfile();
      snackbar.success("Đã lưu thông tin tài khoản.");
    } catch (err) {
      snackbar.error(err?.message || "Lưu thất bại.");
    } finally {
      setSaving(false);
    }
  };

  const handleCropped = useAvatarUpload();

  const currentTag = profile?.tagName || "";
  const tagStatus = useTagNameAvailability(tagValue, { currentTag });
  const handleTagSave = async () => {
    await updateTagName(tagValue.replace(/^@/, ""));
    await refreshProfile();
    snackbar.success("Đã đổi Tag Name Search.");
  };

  if (!profile) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}>
        <CircularProgress aria-label="Đang tải thông tin tài khoản" />
      </Box>
    );
  }

  return (
    <Stack spacing={2.5}>
      <Paper variant="outlined" sx={{ p: 2, borderRadius: 1 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <Avatar src={profile.avatarUrl || undefined} sx={{ width: 72, height: 72 }}>
            {profile.displayName?.[0]}
          </Avatar>
          <Box>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
              Ảnh đại diện
            </Typography>
            <Button size="small" variant="outlined" onClick={() => setCropperOpen(true)}>
              Chọn / chỉnh ảnh đại diện
            </Button>
          </Box>
        </Box>
      </Paper>

      <CoverImageRow />

      <Paper variant="outlined" sx={{ px: 2, borderRadius: 1 }}>
        <RealNameRow />
        <InfoRow
          label="Tag Name Search"
          actions={
            <Button
              size="small"
              startIcon={<EditOutlinedIcon />}
              onClick={() => {
                setTagValue("");
                setTagOpen(true);
              }}
            >
              Đổi
            </Button>
          }
        >
          {currentTag}
        </InfoRow>
      </Paper>

      <Paper variant="outlined" sx={{ p: 2, borderRadius: 1 }}>
        <ProfileFieldsGrid form={form} onChange={handleChange} countries={countries} />
        <Box sx={{ mt: 2 }}>
          <BioField value={form.bio} onChange={handleChange("bio")} />
        </Box>
        <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
          <Button variant="contained" onClick={handleSave} disabled={saving || dirtyFields.length === 0 || !bioValid}>
            {saving ? "Đang lưu..." : "Lưu thay đổi"}
          </Button>
        </Box>
      </Paper>

      <ProfileExtrasCard />

      <AvatarCropper open={cropperOpen} onClose={() => setCropperOpen(false)} onCropped={handleCropped} />

      <TagNameDialog
        open={tagOpen}
        currentTag={currentTag}
        value={tagValue}
        onChange={(e) => setTagValue(e.target.value)}
        status={tagStatus}
        onConfirm={handleTagSave}
        onClose={() => setTagOpen(false)}
      />
    </Stack>
  );
}

/**
 * Hộp đổi Tag Name Search (2 bước). Không cần mật khẩu (khác tên thật); nút chỉ sáng khi tag hợp lệ và chưa có người dùng.
 *  - Bước "edit": nhập tag mới (kiểm tra trùng trực tiếp) → "Đổi tag" chưa đổi gì, chỉ sang bước xác nhận.
 *  - Bước "confirm" (v2.4.2.1): CẢNH BÁO hậu quả với link hồ sơ đã chia sẻ — URL hồ sơ là /u/@<tag> nên link cũ báo "không tìm thấy", và tag cũ được trả lại
 *    nên người khác có thể nhận đúng tag đó (khi ấy link cũ mở hồ sơ của họ). Chỉ "Vẫn đổi tag" mới gọi API. Lỗi từ máy chủ (vd. tag vừa bị người khác lấy)
 *    đưa người dùng về bước "edit" kèm thông báo.
 */
function TagNameDialog({ open, currentTag, value, onChange, status, onConfirm, onClose }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState("edit");
  useEffect(() => {
    if (open) {
      setBusy(false);
      setError("");
      setStep("edit");
    }
  }, [open]);

  const oldTag = normalizeTag(currentTag);
  const newTag = normalizeTag(value);
  const origin = typeof window !== "undefined" ? window.location.origin : "";

  const submit = async (e) => {
    e.preventDefault();
    if (status !== "available" || busy) return;
    if (step === "edit") {
      setError("");
      setStep("confirm");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await onConfirm();
      onClose();
    } catch (err) {
      setError(err?.message || "Đổi Tag Name Search thất bại.");
      setStep("edit");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={!!open} onClose={busy ? undefined : onClose} maxWidth="xs" fullWidth>
      <form onSubmit={submit}>
        {step === "edit" ? (
          <>
            <DialogTitle>Đổi Tag Name Search</DialogTitle>
            <DialogContent>
              <Stack spacing={2} sx={{ pt: 1 }}>
                <TagNameField value={value} onChange={onChange} status={status} autoFocus />
                {error && <Alert severity="error">{error}</Alert>}
              </Stack>
            </DialogContent>
            <DialogActions sx={{ p: 2 }}>
              <Button onClick={onClose} disabled={busy}>
                Hủy
              </Button>
              <Button type="submit" variant="contained" disabled={busy || status !== "available"}>
                Đổi tag
              </Button>
            </DialogActions>
          </>
        ) : (
          <>
            <DialogTitle>Đổi Tag Name Search?</DialogTitle>
            <DialogContent>
              <Stack spacing={2} sx={{ pt: 1 }}>
                <Alert severity="warning">
                  <AlertTitle>Link hồ sơ bạn đã chia sẻ sẽ không còn dùng được</AlertTitle>
                  Link hồ sơ Twelve chứa Tag Name Search của bạn, nên đổi tag là đổi luôn link.
                </Alert>
                <Box sx={{ fontSize: 14 }}>
                  <Typography variant="body2" color="text.secondary">
                    Link hiện tại (sẽ ngừng hoạt động)
                  </Typography>
                  <Typography variant="body2" sx={{ fontFamily: "monospace", wordBreak: "break-all" }} data-testid="tag-old-link">
                    {`${origin}/u/@${oldTag}`}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Link mới
                  </Typography>
                  <Typography variant="body2" sx={{ fontFamily: "monospace", wordBreak: "break-all" }} data-testid="tag-new-link">
                    {`${origin}/u/@${newTag}`}
                  </Typography>
                </Box>
                <Typography component="ul" variant="body2" sx={{ m: 0, pl: 2.5, "& li + li": { mt: 0.75 } }}>
                  <li>
                    Link cũ bạn đã gửi hoặc đăng ở ngoài Twelve (mạng xã hội, tin nhắn, chữ ký, kết quả tìm kiếm…) sẽ báo “Không tìm thấy người dùng”.
                  </li>
                  <li>Tag cũ được trả lại: người khác có thể đăng ký đúng tag đó, và khi ấy link cũ sẽ mở ra hồ sơ của họ.</li>
                  <li>Bài viết, bình luận và điểm của bạn được giữ nguyên; hồ sơ của bạn trong Twelve vẫn mở bình thường.</li>
                </Typography>
              </Stack>
            </DialogContent>
            <DialogActions sx={{ p: 2 }}>
              <Button onClick={() => setStep("edit")} disabled={busy}>
                Quay lại
              </Button>
              <Button type="submit" variant="contained" color="warning" disabled={busy || status !== "available"}>
                {busy ? "Đang lưu..." : "Vẫn đổi tag"}
              </Button>
            </DialogActions>
          </>
        )}
      </form>
    </Dialog>
  );
}
