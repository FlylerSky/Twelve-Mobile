import React, { useCallback, useEffect, useRef, useState } from "react";
import { Box, Typography, Paper, Stack, Button, Divider, CircularProgress, Alert, Chip, Table, TableBody, TableCell, TableHead, TableRow } from "@mui/material";
import SpeedOutlinedIcon from "@mui/icons-material/SpeedOutlined";
import { getIpTopology } from "../../api/admin.api";

/**
 * ==== v2.5.3.2 — Quản trị > Nhận diện IP (chỉ SA) — báo cáo bảo mật 2.5.3, TW-01 / V-01 / V-02 ====
 * Limiter theo IP và khoá chống đếm trùng view/share đều dựa vào "IP client" mà backend tính (utils/clientIp.js#getClientKey). Phía trước app có Cloudflare → proxy của Render nên cách tính đúng
 * phụ thuộc topology thật — thứ chỉ đo được, không đoán được. Panel này gọi `GET /api/admin/ip-topology` vài lần (mỗi lần backend mô tả CHÍNH request đó: địa chỉ socket, chuỗi
 * X-Forwarded-For, CF-Connecting-IP) và cho biết khoá hiện tại có bằng IP thật mà Cloudflare thấy không, nếu không thì đặt biến nào trên Render để sửa. Chỉ ĐỌC — không đổi gì.
 * Lưu ý: trình duyệt dùng lại kết nối nên "khoá ổn định qua 5 lần đo" chưa chứng minh được sự ổn định qua nhiều đường đi; phần đối chiếu với CF-Connecting-IP mới là kết luận chính.
 */
const CALLS = 5;

const settingLabel = (s) => Object.entries(s).map(([k, v]) => `${k}=${v}`).join(" ");
const isCurrentSetting = (s, current) => {
  if (s.TRUST_PROXY_MODE) return current.trustProxyMode === "cloudflare";
  return current.trustProxyMode === "hops" && current.trustProxyHops === s.TRUST_PROXY_HOPS;
};

const VERDICTS = {
  OK: { severity: "success", title: "Nhận diện IP đang đúng", text: "Khoá IP hiện tại trùng với IP mà Cloudflare báo (CF-Connecting-IP) — limiter và khoá chống đếm trùng view/share đang dùng đúng IP của bạn." },
  MISMATCH_FIXABLE: { severity: "warning", title: "Khoá IP hiện tại KHÁC IP thật", text: "Limiter và khoá chống đếm trùng đang dùng địa chỉ không phải IP của người dùng (thường là IP edge Cloudflare hoặc một proxy nội bộ — dùng chung cho nhiều người hoặc đổi theo đường đi). Có cấu hình cho ra đúng IP:" },
  MISMATCH_UNKNOWN: { severity: "error", title: "Khoá IP hiện tại KHÁC IP thật và chưa có cấu hình ứng viên nào sửa được", text: "Thử thêm dải IP của proxy vào CLOUDFLARE_EXTRA_RANGES (nếu là Cloudflare) hoặc TRUST_PROXY_EXTRA (nếu là proxy nội bộ), rồi đo lại. Xem PATCH-26-NOTES.md." },
  NO_CF_HEADER: { severity: "info", title: "Chưa có gì để đối chiếu", text: "Request này không mang CF-Connecting-IP hợp lệ (không đi qua Cloudflare?) nên không biết IP thật là gì. Thử lại khi mở trang qua địa chỉ chính thức." },
};

export default function AdminIpTopologyPanel() {
  const [results, setResults] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);

  const measure = useCallback(async () => {
    setLoading(true);
    setError("");
    const got = [];
    try {
      for (let i = 0; i < CALLS; i++) {
        got.push(await getIpTopology());
        if (!alive.current) return;
      }
      setResults(got);
    } catch (err) {
      if (alive.current) setError(err?.message || "Không đo được nhận diện IP.");
    } finally {
      if (alive.current) setLoading(false);
    }
  }, []);

  const last = results.length ? results[results.length - 1] : null;
  const keys = [...new Set(results.map((r) => r.current.key))];
  const verdict = last ? VERDICTS[last.verdict.code] || VERDICTS.NO_CF_HEADER : null;

  return (
    <Box>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Đo xem backend nhận diện <b>IP của bạn</b> có đúng không. Limiter tốc độ và việc chống đếm trùng lượt xem/chia sẻ của khách ẩn danh đều dựa vào IP này; nếu sai (ví dụ trùng với IP của Cloudflare
        hoặc của proxy nội bộ) thì nhiều người dùng chung một bộ đếm hoặc một người đổi khoá liên tục. Bấm <b>Đo ngay</b> — panel gọi backend {CALLS} lần và chỉ <b>đọc</b>, không đổi gì.
      </Typography>

      <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
        <Button variant="contained" startIcon={loading ? <CircularProgress size={16} color="inherit" /> : <SpeedOutlinedIcon />} onClick={measure} disabled={loading}>
          Đo ngay
        </Button>
      </Stack>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {last && verdict && (
        <>
          <Alert severity={verdict.severity} sx={{ mb: 1.5 }}>
            <b>{verdict.title}.</b> {verdict.text}
            {last.verdict.code === "MISMATCH_FIXABLE" && (
              <Box component="ul" sx={{ m: 0, mt: 0.5, pl: 2.5 }}>
                {last.verdict.suggestions.map((s) => (
                  <li key={settingLabel(s)}>
                    <code>{settingLabel(s)}</code>
                    {s.TRUST_PROXY_MODE ? " — không phụ thuộc số hop (ưu tiên)" : " — cố định theo topology hiện tại"}
                  </li>
                ))}
              </Box>
            )}
            {last.verdict.code === "MISMATCH_FIXABLE" && (
              <Typography variant="caption" sx={{ display: "block", mt: 0.5 }}>
                Đặt biến trên Render rồi khởi động lại dịch vụ, đo lại ở đây, và theo dõi số đếm trong vài ngày. Đọc PATCH-26-NOTES.md trước khi đổi.
              </Typography>
            )}
          </Alert>

          {keys.length > 1 ? (
            <Alert severity="error" sx={{ mb: 1.5 }}>
              <b>Khoá IP thay đổi giữa {results.length} lần đo liên tiếp</b> ({keys.join(" · ")}) — đúng triệu chứng của việc khoá phụ thuộc đường đi qua Cloudflare.
            </Alert>
          ) : (
            <Typography variant="caption" color="text.secondary" sx={{ display: "block", mb: 1.5 }}>
              Khoá giữ nguyên <b>{keys[0]}</b> qua {results.length} lần đo (trình duyệt dùng lại kết nối nên chưa chứng minh được ổn định qua mọi đường đi).
            </Typography>
          )}

          <Paper variant="outlined" sx={{ borderRadius: 1, overflow: "hidden", mb: 2 }}>
            <Stack divider={<Divider />}>
              <Row label="Khoá IP đang dùng" value={last.current.key} bold />
              <Row label="CF-Connecting-IP (IP thật Cloudflare thấy)" value={last.cfConnectingIp || "— (không có)"} />
              <Row label="Địa chỉ kết nối sát app (peer)" value={`${last.peer || "—"}${last.peer ? (last.peerTrusted ? " · thuộc dải tin cậy" : " · KHÔNG thuộc dải nội bộ/Cloudflare") : ""}`} />
              <Row label="Chuỗi X-Forwarded-For (từ client → proxy)" value={last.xff.length ? last.xff.join(" → ") : "— (trống)"} />
              <Row label="Chuỗi server duyệt (gần app → xa)" value={last.chain.join(" → ") || "—"} />
              <Row label="Cấu hình hiện tại" value={`TRUST_PROXY_MODE=${last.current.trustProxyMode}${last.current.trustProxyHops !== null ? ` · TRUST_PROXY_HOPS=${last.current.trustProxyHops}` : ""} · CLIENT_IP_MODE=${last.current.clientIpMode}`} />
              <Row label="Express chọn (req.ip) / hop đó thuộc Cloudflare?" value={`${last.current.reqIp || "—"} / ${last.current.hopIsCloudflare ? "có" : "không"}`} />
            </Stack>
          </Paper>

          <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
            Khoá sẽ ra gì nếu đặt từng cấu hình
          </Typography>
          <Paper variant="outlined" sx={{ borderRadius: 1, overflowX: "auto", mb: 2 }}>
            <Table size="small" aria-label="Ứng viên cấu hình">
              <TableHead>
                <TableRow>
                  <TableCell>Cấu hình</TableCell>
                  <TableCell>Địa chỉ được chọn</TableCell>
                  <TableCell>Khoá</TableCell>
                  <TableCell>Đúng IP thật?</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {last.candidates.map((c) => {
                  const right = !!last.cfConnectingIp && c.key === last.cfConnectingIp;
                  return (
                    <TableRow key={settingLabel(c.setting)} selected={isCurrentSetting(c.setting, last.current)}>
                      <TableCell>
                        <code>{settingLabel(c.setting)}</code>
                        {isCurrentSetting(c.setting, last.current) && <Chip size="small" label="đang dùng" sx={{ ml: 1 }} />}
                      </TableCell>
                      <TableCell>{c.address || "—"}</TableCell>
                      <TableCell>{c.key}</TableCell>
                      <TableCell>
                        {last.cfConnectingIp ? (right ? "✓" : "✗") : "?"}
                        {!c.usable && <Typography component="span" variant="caption" color="warning.main"> chưa dùng được (peer không thuộc dải tin cậy)</Typography>}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </Paper>
        </>
      )}
    </Box>
  );
}

function Row({ label, value, bold }) {
  return (
    <Box sx={{ px: 2, py: 1 }}>
      <Typography variant="caption" color="text.secondary" sx={{ display: "block" }}>
        {label}
      </Typography>
      <Typography variant="body2" sx={{ wordBreak: "break-all", fontWeight: bold ? 600 : 400 }}>
        {value}
      </Typography>
    </Box>
  );
}
