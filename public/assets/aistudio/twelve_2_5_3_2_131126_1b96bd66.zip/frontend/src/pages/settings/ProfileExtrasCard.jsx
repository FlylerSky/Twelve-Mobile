import React, { useEffect, useMemo, useState } from "react";
import { Box, Chip, Divider, Paper, Stack, Switch, Typography } from "@mui/material";
import { useAuth } from "../../context/AuthContext";
import { useSnackbar } from "../../context/SnackbarContext";
import { updateProfileExtras } from "../../api/users.api";
import { EXTRA_FIELDS, resolveExtras } from "../../utils/profileExtras";

/**
 * ==== v2.5.2 — Cài đặt > Tài khoản > Thông tin > "Thông tin mở rộng" ====
 * Chọn những mục hiển thị trong hộp "Xem thêm" trên hồ sơ của bạn. Danh sách mục + mặc định ở utils/profileExtras.js (phản chiếu backend, nơi việc ẩn/hiện được ÁP DỤNG:
 * mục đang tắt không bao giờ rời máy chủ tới người khác).
 *
 * Công tắc ÁP DỤNG NGAY (không có nút Lưu): với thông tin riêng tư, "tắt rồi quên bấm Lưu" nghĩa là vẫn đang công khai — khuôn mẫu nguy hiểm. Mỗi lần bật/tắt gửi RIÊNG khoá
 * đó (PUT /users/me/extras); công tắc đổi ngay (lạc quan), bị khoá trong lúc gửi, và QUAY LẠI trạng thái cũ kèm thông báo lỗi nếu máy chủ từ chối.
 * Trạng thái gốc lấy từ hồ sơ realtime (AuthContext, Firestore onSnapshot) nên đổi từ thiết bị khác cũng cập nhật ở đây; giá trị vừa đặt được giữ cho tới khi hồ sơ
 * realtime phản ánh kịp (tránh công tắc nhảy lại trạng thái cũ trong khoảng trễ ngắn).
 */
export default function ProfileExtrasCard() {
  const { profile } = useAuth();
  const snackbar = useSnackbar();
  const stored = useMemo(() => resolveExtras(profile?.profileExtras), [profile?.profileExtras]);
  const [overrides, setOverrides] = useState({}); // khoá → giá trị vừa đặt, chờ hồ sơ realtime theo kịp
  const [busy, setBusy] = useState({}); // khoá → đang gửi

  useEffect(() => {
    setOverrides((o) => {
      const done = Object.keys(o).filter((k) => !busy[k] && stored[k] === o[k]);
      if (done.length === 0) return o;
      const next = { ...o };
      done.forEach((k) => delete next[k]);
      return next;
    });
  }, [stored, busy]);

  const checked = (key) => (key in overrides ? overrides[key] : stored[key]);

  const toggle = async (key, next) => {
    setOverrides((o) => ({ ...o, [key]: next }));
    setBusy((b) => ({ ...b, [key]: true }));
    try {
      await updateProfileExtras({ [key]: next });
    } catch (err) {
      setOverrides((o) => {
        const rest = { ...o };
        delete rest[key];
        return rest;
      });
      snackbar.error(err?.message || "Không lưu được thay đổi.");
    } finally {
      setBusy((b) => {
        const rest = { ...b };
        delete rest[key];
        return rest;
      });
    }
  };

  return (
    <Paper variant="outlined" sx={{ borderRadius: 1 }} data-testid="profile-extras-card">
      <Box sx={{ px: 2, pt: 2, pb: 1.5 }}>
        <Typography variant="subtitle1" fontWeight={700}>
          Thông tin mở rộng
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Chọn những mục hiển thị khi người khác bấm “Xem thêm” trên hồ sơ của bạn. Thay đổi được lưu ngay.
        </Typography>
      </Box>
      <Divider />
      {EXTRA_FIELDS.map((f, i) => (
        <React.Fragment key={f.key}>
          {i > 0 && <Divider />}
          <Stack direction="row" alignItems="center" spacing={1.5} sx={{ px: 2, py: 1.25 }} data-testid={`extra-row-${f.key}`}>
            <Box sx={{ minWidth: 0, flex: 1 }}>
              <Stack direction="row" alignItems="center" spacing={1} flexWrap="wrap" useFlexGap>
                <Typography variant="body1" fontWeight={600}>
                  {f.label}
                </Typography>
                {f.private && <Chip size="small" variant="outlined" label="Riêng tư" sx={{ height: 20, fontSize: 11 }} />}
              </Stack>
              <Typography variant="caption" color="text.secondary" component="div">
                {f.hint}
              </Typography>
            </Box>
            <Switch
              checked={!!checked(f.key)}
              disabled={!!busy[f.key]}
              onChange={(e) => toggle(f.key, e.target.checked)}
              // Tên truy cập nêu rõ việc công tắc làm — không trùng tên với ô nhập cùng nhãn ở form phía trên (vd. "Tên hiển thị") khiến trình đọc màn hình đọc hai điều khiển y hệt nhau.
              inputProps={{ "aria-label": `Hiện ${f.label} trong hộp Xem thêm`, "data-testid": `extra-switch-${f.key}` }}
            />
          </Stack>
        </React.Fragment>
      ))}
      <Divider />
      <Typography variant="caption" color="text.secondary" component="div" sx={{ px: 2, py: 1.5 }}>
        Mục đánh dấu “Riêng tư” mặc định tắt và chỉ được chia sẻ khi bạn bật. Các mục còn lại là thông tin vốn đã hiện ở nơi khác trên Twelve (bài viết, huy hiệu, bảng xếp hạng…), nên tắt ở đây chỉ ẩn
        chúng khỏi hộp “Xem thêm”.
      </Typography>
    </Paper>
  );
}
