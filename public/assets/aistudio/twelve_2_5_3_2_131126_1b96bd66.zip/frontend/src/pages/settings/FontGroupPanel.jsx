import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Paper,
  List,
  ListItemButton,
  ListItemText,
  Radio,
  Divider,
  Chip,
  Stack,
  CircularProgress,
  TextField,
  Button,
  IconButton,
  Alert,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import { useThemeMode } from "../../context/ThemeModeContext";
import { ensureFont, MAX_CUSTOM_FONTS } from "../../theme/fonts";

/**
 * ==== Settings > Ứng dụng > Font chữ > <một trong 3 nhóm> ====
 * v2.0.7: nhóm #1.2 font client.  v2.0.8: thêm nhóm #1.1 font server (SA cài) và #2 font tuỳ chỉnh từ URL.
 * Mỗi tên font được vẽ bằng CHÍNH font đó để xem trước.
 *
 * v2.1.0: trước đây MỘT component vẽ cả 3 nhóm xếp dọc. Nay mỗi nhóm là một mục lá riêng trong cây Cài đặt
 * (xem registry.jsx) và dùng chung component này qua `props: { source }`. Lợi ích: chỉ tải font xem trước của
 * ĐÚNG nhóm đang mở, chỉ hỏi server danh sách font khi mở nhóm "do quản trị viên cài đặt".
 * Tiêu đề do khung Cài đặt vẽ (đường dẫn trên cùng) — component này không tự vẽ tiêu đề.
 */
const PREVIEW_TEXT = "Twelve — Nhà ở ven đường, gió thổi qua ngõ";

function FontRow({ f, selected, onSelect, onRemove, first }) {
  return (
    <React.Fragment>
      {!first && <Divider component="li" />}
      <ListItemButton selected={selected} onClick={() => onSelect(f.id)} sx={{ py: 1.5, px: 2 }}>
        <ListItemText
          disableTypography
          primary={
            <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
              <Typography sx={{ fontFamily: f.stack, fontSize: "1.125rem", fontWeight: selected ? 700 : 500 }}>{f.label}</Typography>
              {selected && <Chip size="small" color="primary" label="Đang dùng" />}
            </Stack>
          }
          secondary={
            <Box sx={{ mt: 0.5 }}>
              <Typography sx={{ fontFamily: f.stack }} color="text.primary">
                {PREVIEW_TEXT}
              </Typography>
              {f.note && (
                <Typography variant="caption" color="text.secondary" sx={{ display: "block", mt: 0.5 }}>
                  {f.note}
                </Typography>
              )}
            </Box>
          }
        />
        {onRemove && (
          <IconButton
            size="small"
            color="error"
            aria-label={`Xoá font ${f.label}`}
            onClick={(e) => {
              e.stopPropagation();
              onRemove(f.id);
            }}
          >
            <DeleteOutlineIcon fontSize="small" />
          </IconButton>
        )}
        <Radio checked={selected} onChange={() => onSelect(f.id)} sx={{ ml: 1 }} inputProps={{ "aria-label": f.label }} />
      </ListItemButton>
    </React.Fragment>
  );
}

function CustomFontForm() {
  const { addCustomFont, setFontId, fonts } = useThemeMode();
  const [label, setLabel] = useState("");
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const count = fonts.filter((f) => f.source === "custom").length;

  const handleAdd = async () => {
    setBusy(true);
    setError("");
    try {
      const created = await addCustomFont({ label, url });
      setLabel("");
      setUrl("");
      setFontId(created.id); // thêm xong dùng luôn
    } catch (err) {
      setError(err.message || "Không thêm được font.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Paper variant="outlined" sx={{ borderRadius: 1, p: 2, mt: 1.5 }}>
      <Typography variant="body2" fontWeight={600} sx={{ mb: 0.5 }}>
        Thêm font từ URL
      </Typography>
      <Typography variant="caption" color="text.secondary" sx={{ display: "block", mb: 1.5 }}>
        Dán link trực tiếp tới file font (.woff2, .woff, .ttf hoặc .otf, bắt đầu bằng https://). Không dùng link CSS của Google
        Fonts. Máy chủ chứa font phải cho phép tải từ trang web khác (CORS). Font chỉ lưu trên thiết bị này, tối đa {MAX_CUSTOM_FONTS} font.
      </Typography>
      <Stack spacing={1.25}>
        <TextField size="small" label="Link file font" placeholder="https://…/ten-font.woff2" value={url} onChange={(e) => setUrl(e.target.value)} fullWidth disabled={busy} />
        <TextField size="small" label="Tên hiển thị (tuỳ chọn)" value={label} onChange={(e) => setLabel(e.target.value)} inputProps={{ maxLength: 40 }} fullWidth disabled={busy} />
        {error && <Alert severity="error">{error}</Alert>}
        <Box>
          <Button variant="contained" startIcon={busy ? <CircularProgress size={16} color="inherit" /> : <AddIcon />} onClick={handleAdd} disabled={busy || !url.trim() || count >= MAX_CUSTOM_FONTS}>
            {busy ? "Đang kiểm tra…" : "Thêm và dùng"}
          </Button>
        </Box>
      </Stack>
    </Paper>
  );
}

const SOURCE_HELP = {
  client: "Các font đi kèm Twelve. Chọn một font để dùng trên thiết bị này.",
  server: "Các font do quản trị viên cài đặt cho mọi người dùng. Chọn một font để dùng trên thiết bị này.",
  custom: "Font do bạn tự thêm từ link. Chọn một font để dùng trên thiết bị này.",
};

/** @param {{ source: "client" | "server" | "custom" }} props */
export default function FontGroupPanel({ source }) {
  const { fontId, setFontId, fontLoading, fonts, removeCustomFont, refreshServerFonts, serverFontsStatus, serverFontsError } = useThemeMode();
  const isServer = source === "server";
  const isCustom = source === "custom";
  const items = fonts.filter((f) => f.source === source);

  // v2.0.9: mỗi lần mở mục này lấy lại danh sách font server (SA có thể vừa thêm/gỡ). v2.1.0: chỉ nhóm "server" cần.
  useEffect(() => {
    if (isServer) refreshServerFonts();
  }, [isServer, refreshServerFonts]);

  // Tải trước các font của NHÓM NÀY để vẽ xem trước (mỗi font chỉ tải 1 lần, cache trong phiên).
  useEffect(() => {
    items.forEach((f) => ensureFont(f));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fonts, source]);

  return (
    <Box>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <Typography variant="body2" color="text.secondary">
          {SOURCE_HELP[source] || "Chọn font chữ hiển thị trên thiết bị này."}
        </Typography>
        {fontLoading && <CircularProgress size={16} aria-label="Đang tải font" />}
      </Stack>

      {isServer && serverFontsStatus === "error" && (
        <Alert severity="warning" sx={{ mb: 2 }} action={<Button color="inherit" size="small" onClick={refreshServerFonts}>Thử lại</Button>}>
          Không tải được danh sách font do quản trị viên cài ({serverFontsError}).
        </Alert>
      )}

      {items.length > 0 && (
        <Paper variant="outlined" sx={{ borderRadius: 1, overflow: "hidden" }}>
          <List disablePadding>
            {items.map((f, i) => (
              <FontRow key={f.id} f={f} first={i === 0} selected={fontId === f.id} onSelect={setFontId} onRemove={isCustom ? removeCustomFont : null} />
            ))}
          </List>
        </Paper>
      )}

      {isServer && items.length === 0 && serverFontsStatus === "ok" && (
        <Typography variant="body2" color="text.secondary">
          Quản trị viên chưa cài font nào.
        </Typography>
      )}

      {isCustom && <CustomFontForm />}
    </Box>
  );
}
