import React from "react";
import { Box, Typography, Divider } from "@mui/material";

/**
 * ==== v2.2.0 — Một hàng "nhãn · giá trị · nút" của Cài đặt > Tài khoản > Thông tin ====
 * Dùng chung cho Tên thật và Tag Name Search (và mọi trường hợp tương tự sau này) để các hàng luôn thẳng hàng, cùng khoảng cách.
 */
export default function InfoRow({ label, children, actions, helper }) {
  return (
    <Box>
      <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, py: 1.5, flexWrap: "wrap" }}>
        <Box sx={{ minWidth: 0, flex: "1 1 200px" }}>
          <Typography variant="caption" color="text.secondary">
            {label}
          </Typography>
          <Typography variant="body1" fontWeight={600} sx={{ wordBreak: "break-word" }} component="div">
            {children}
          </Typography>
          {helper && (
            <Typography variant="caption" color="text.secondary">
              {helper}
            </Typography>
          )}
        </Box>
        <Box sx={{ display: "flex", gap: 1, flexShrink: 0 }}>{actions}</Box>
      </Box>
      <Divider />
    </Box>
  );
}
