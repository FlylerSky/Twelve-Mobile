import React, { lazy } from "react";
import TuneIcon from "@mui/icons-material/Tune";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";
import Brightness6OutlinedIcon from "@mui/icons-material/Brightness6Outlined";
import TextFieldsIcon from "@mui/icons-material/TextFields";
import Inventory2OutlinedIcon from "@mui/icons-material/Inventory2Outlined";
import DnsOutlinedIcon from "@mui/icons-material/DnsOutlined";
import LinkIcon from "@mui/icons-material/Link";
import LanguageOutlinedIcon from "@mui/icons-material/LanguageOutlined";
import ShieldOutlinedIcon from "@mui/icons-material/ShieldOutlined";
import BugReportOutlinedIcon from "@mui/icons-material/BugReportOutlined";
import SpeedOutlinedIcon from "@mui/icons-material/SpeedOutlined";
import CloudOutlinedIcon from "@mui/icons-material/CloudOutlined";
import ManageAccountsOutlinedIcon from "@mui/icons-material/ManageAccountsOutlined";
import BadgeOutlinedIcon from "@mui/icons-material/BadgeOutlined";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import PasswordOutlinedIcon from "@mui/icons-material/PasswordOutlined";
import DeleteForeverOutlinedIcon from "@mui/icons-material/DeleteForeverOutlined";
import { FONT_SOURCE_LABELS } from "../../theme/fonts";

/**
 * ==== v2.1.0 — Cây mục Cài đặt: NƠI DUY NHẤT khai báo trang Cài đặt ====
 *
 * Muốn thêm một tuỳ chọn mới? Chỉ thêm MỘT nút vào đây — danh sách, đường dẫn, URL, chặn quyền, tải lười
 * đều tự có (quy tắc đầy đủ ở settingsTree.js):
 *
 *   • Một tuỳ chọn duy nhất      → nút LÁ:       { key, title, icon, component }
 *   • Nhiều tuỳ chọn cùng chủ đề → nút THƯ MỤC:  { key, title, icon, children: [ …các nút lá hoặc thư mục con… ] }
 *   • Chỉ dành cho SA            → thêm `requires: "sa"` (đặt ở tab/thư mục thì áp dụng cho mọi thứ bên dưới)
 *   • Chỉ cho người đã đăng nhập → thêm `requires: "user"` (v2.2.0 — tab Tài khoản; khách vẫn dùng được tab Ứng dụng)
 *   • Dùng lại một component cho nhiều mục → `props: { … }` (ví dụ 3 nhóm font bên dưới)
 *
 * `component` LUÔN dùng React.lazy: người dùng thường không tải mã của panel quản trị, và chỉ panel đang mở mới
 * tải/gọi API (trước v2.1.0 cả 4 panel quản trị gọi API cùng lúc ngay khi mở tab).
 * `key` là một đoạn của URL (/settings/<tab>/<key>/<key>…) nên đừng đổi tuỳ tiện — đổi là gãy liên kết đã lưu.
 * Tiêu đề trang do khung vẽ từ `title`; panel KHÔNG tự vẽ tiêu đề.
 * tests/settingsTree.test.js kiểm tra cả cây này (key trùng, thiếu component…) nên khai báo sai sẽ báo đỏ.
 */

// Một chunk dùng chung cho cả 3 mục font.
const FontGroupPanel = lazy(() => import("./FontGroupPanel"));

export const SETTINGS_TABS = [
  {
    key: "app",
    title: "Ứng dụng",
    icon: <TuneIcon fontSize="small" />,
    children: [
      {
        key: "theme",
        title: "Chế độ giao diện",
        icon: <Brightness6OutlinedIcon />,
        component: lazy(() => import("./ThemeModePanel")),
      },
      {
        key: "font",
        title: "Font chữ",
        icon: <TextFieldsIcon />,
        children: [
          { key: "client", title: FONT_SOURCE_LABELS.client, icon: <Inventory2OutlinedIcon />, component: FontGroupPanel, props: { source: "client" } },
          { key: "server", title: FONT_SOURCE_LABELS.server, icon: <DnsOutlinedIcon />, component: FontGroupPanel, props: { source: "server" } },
          { key: "custom", title: FONT_SOURCE_LABELS.custom, icon: <LinkIcon />, component: FontGroupPanel, props: { source: "custom" } },
        ],
      },
    ],
  },
  {
    // v2.2.0 — Tài khoản. Gốc tab hiện 2 mục: "Thông tin" (lá) và "Bảo mật" (thư mục: Đổi mật khẩu, Xoá tài khoản).
    key: "account",
    title: "Tài khoản",
    icon: <ManageAccountsOutlinedIcon fontSize="small" />,
    requires: "user",
    children: [
      { key: "info", title: "Thông tin", icon: <BadgeOutlinedIcon />, component: lazy(() => import("./AccountInfoPanel")) },
      {
        key: "security",
        title: "Bảo mật",
        icon: <LockOutlinedIcon />,
        children: [
          { key: "password", title: "Đổi mật khẩu", icon: <PasswordOutlinedIcon />, component: lazy(() => import("./ChangePasswordPanel")) },
          { key: "delete", title: "Xóa tài khoản", icon: <DeleteForeverOutlinedIcon />, component: lazy(() => import("./DeleteAccountPanel")) },
        ],
      },
    ],
  },
  {
    // Chỉ thêm vào danh sách khi tài khoản thuộc nhóm SA (xem buildAccess/isSA). Đây là lớp ẩn giao diện, KHÔNG phải
    // lớp bảo mật — backend (middleware requireSA) mới thực sự chặn, phòng trường hợp ai đó gõ thẳng URL.
    key: "admin",
    title: "Quản trị",
    icon: <AdminPanelSettingsIcon fontSize="small" />,
    requires: "sa",
    children: [
      { key: "embed-domains", title: "Domain nhúng media", icon: <LanguageOutlinedIcon />, component: lazy(() => import("./AdminEmbedDomainsPanel")) },
      { key: "fonts", title: "Font chữ trên server", icon: <DnsOutlinedIcon />, component: lazy(() => import("./AdminFontsPanel")) },
      { key: "csp-reports", title: "Báo cáo vi phạm CSP", icon: <ShieldOutlinedIcon />, component: lazy(() => import("./AdminCspReportsPanel")) },
      { key: "assets", title: "Tài nguyên người dùng upload", icon: <CloudOutlinedIcon />, component: lazy(() => import("./AdminAssetsPanel")) },
      // v2.5.3.2 [TW-01] — đo backend có nhận diện đúng IP của người dùng không (limiter + chống đếm trùng view/share dựa vào đó). Chỉ đọc.
      { key: "ip-topology", title: "Nhận diện IP", icon: <SpeedOutlinedIcon />, component: lazy(() => import("./AdminIpTopologyPanel")) },
      // v2.3.0 — hồi quy các lỗi bảo mật đã từng gặp: mỗi lỗi là một module ở backend/src/debug/modules/, panel này không cần sửa khi thêm lỗi mới.
      { key: "debug", title: "Gỡ lỗi", icon: <BugReportOutlinedIcon />, component: lazy(() => import("./AdminDebugPanel")) },
    ],
  },
];
