import React, { Suspense, lazy, useEffect, useMemo, useState } from "react";
import useSeo from "../hooks/useSeo";
import { Container } from "@mui/material";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import Navbar from "../components/Navbar";
import FeedList from "../components/FeedList";
import { blogsApi } from "../api/content.api";
import { useAuth } from "../context/AuthContext";
import { useRegisterPageHeader } from "../context/PageHeaderContext";
import usePaginatedFeed from "../hooks/usePaginatedFeed";

// v2.0.11 [G4]: modal soạn bài (kéo theo Quill) chỉ tải khi SA mở lần đầu.
const CreatePostModal = lazy(() => import("../components/CreatePostModal"));

/**
 * Trang Blog. v2.0.0: dùng chung usePaginatedFeed + FeedList với Trang chủ —
 * file này chỉ còn phần riêng của Blog (nút "Viết Blog" cho SA + modal tạo bài).
 */
export default function BlogPage() {
  useSeo({
    title: "Blog | Twelve",
    description: "Danh sách bài viết blog trên Twelve, cập nhật mới nhất.",
  });
  const { isSA, isAuthReady } = useAuth();
  const [createOpen, setCreateOpen] = useState(false);
  const [createEverOpened, setCreateEverOpened] = useState(false);
  useEffect(() => {
    if (createOpen) setCreateEverOpened(true);
  }, [createOpen]);

  const feed = usePaginatedFeed({ api: blogsApi, listKey: "blogs", isAuthReady });

  // Module 1.0: tên trang + "Viết Blog" lên head (chỉ SA)
  const headerActions = useMemo(
    () =>
      isSA
        ? [
            {
              key: "write-blog",
              label: "Viết Blog",
              icon: <AddCircleIcon />,
              onClick: () => setCreateOpen(true),
            },
          ]
        : [],
    [isSA]
  );
  useRegisterPageHeader({ title: "Blog", isBrand: false, actions: headerActions });

  return (
    <>
      <Navbar />

      <Container maxWidth="sm" sx={{ py: 3 }}>
        <FeedList
          feed={feed}
          api={blogsApi}
          detailPath="/blog"
          collectionName="blogs"
          emptyText="Chưa có bài Blog nào."
        />
      </Container>

      {isSA && createEverOpened && (
        <Suspense fallback={null}>
          <CreatePostModal
            open={createOpen}
            onClose={() => setCreateOpen(false)}
            api={blogsApi}
            onCreated={feed.loadInitial}
            title="Tạo bài Blog mới"
          />
        </Suspense>
      )}
    </>
  );
}
