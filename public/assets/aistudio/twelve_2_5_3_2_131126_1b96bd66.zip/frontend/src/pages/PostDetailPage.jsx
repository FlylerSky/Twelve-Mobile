import React, { useEffect, useMemo, useState } from "react";
import useSeo from "../hooks/useSeo";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import {
  Container,
  Box,
  Typography,
  Stack,
  IconButton,
  CircularProgress,
  Divider,
  Paper,
  Menu,
  MenuItem,
} from "@mui/material";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import ThumbUpOffAltIcon from "@mui/icons-material/ThumbUpOffAlt";
import ThumbDownIcon from "@mui/icons-material/ThumbDown";
import ThumbDownOffAltIcon from "@mui/icons-material/ThumbDownOffAlt";
import VisibilityIcon from "@mui/icons-material/Visibility";
import ShareIcon from "@mui/icons-material/Share";
import GradeIcon from "@mui/icons-material/Grade";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import PushPinIcon from "@mui/icons-material/PushPin";
import PushPinOutlinedIcon from "@mui/icons-material/PushPinOutlined";
import Navbar from "../components/Navbar";
import { useRegisterPageHeader } from "../context/PageHeaderContext";
import MediaLightbox, { collectMediaSlides, findSlideIndex } from "../components/MediaLightbox";
import PostContent from "../components/PostContent";
import ConfirmDialog from "../components/ConfirmDialog";
import ViewStatsPopover from "../components/ViewStatsPopover";
import PostScorePopover from "../components/PostScorePopover";
import EngagementPills from "../components/EngagementPills";
import HashtagChips from "../components/HashtagChips";
import { UserAvatar, UserName, UserTagChip } from "../components/UserIdentity";
import CommentThread from "../components/comments/CommentThread";
import CommentComposer from "../components/comments/CommentComposer";
import { formatRelativeTime } from "../utils/time";
import { formatCount } from "../utils/number";
import { getSessionId } from "../utils/session";
import { useAuth } from "../context/AuthContext";
import { useSnackbar } from "../context/SnackbarContext";
import useCommentThread from "../hooks/useCommentThread";
import useContentEngagement from "../hooks/useContentEngagement";
import usePinPost from "../hooks/usePinPost";
import { useGoUp } from "../hooks/useBack";

/**
 * props:
 * - api: postsApi hoặc blogsApi
 * - backPath: nơi quay lại khi không tìm thấy bài viết ("/" hoặc "/blog")
 *
 * LƯU Ý: Trang này là bản React (CSR) tương tác đầy đủ, dùng khi người dùng
 * thật điều hướng trong app. Backend (Node/Express) còn có route SSR riêng
 * (/post/:id, /blog/:id trả về HTML tĩnh) phục vụ Google Bot index nội dung —
 * phần bình luận cố ý KHÔNG được SSR bên đó để tránh nặng tải.
 */
export default function PostDetailPage({ api, backPath = "/" }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const goUp = useGoUp();
  const location = useLocation();
  const { isLoggedIn, profile, refreshProfile, isAuthReady } = useAuth();
  const snackbar = useSnackbar();

  const [post, setPost] = useState(null);
  const [myReaction0, setMyReaction0] = useState(null); // myReaction từ lần tải đầu (nguồn cho hook engagement)
  const [loading, setLoading] = useState(true);

  // v0.10.17: collection Firestore của bài viết/blog — dùng chung cho listener
  // `post` LẪN luồng bình luận.
  const collectionName = location.pathname.startsWith("/blog") ? "blogs" : "posts";

  // v2.4.0 — GHIM bài lên trang cá nhân: trên trang POST nút nằm ở HEADZONE (không đặt vào khu thông số bài như thẻ ở danh sách).
  // Chỉ hiện cho TÁC GIẢ của một bài viết (Blog không có ghim). `actions` bọc useMemo theo quy ước headZone — nếu không header sẽ nháy mỗi lần render.
  const pin = usePinPost(post, { enabled: collectionName === "posts" });
  const headActions = useMemo(
    () =>
      pin.canPin
        ? [
            {
              key: "pin-post",
              label: pin.isPinned ? "Gỡ ghim khỏi trang cá nhân" : "Ghim lên trang cá nhân",
              icon: pin.isPinned ? <PushPinIcon /> : <PushPinOutlinedIcon />,
              color: pin.isPinned ? "primary" : "inherit",
              disabled: pin.busy,
              onClick: pin.toggle,
            },
          ]
        : [],
    [pin.canPin, pin.isPinned, pin.busy, pin.toggle]
  );
  useRegisterPageHeader({ title: "Bài viết", isBrand: false, actions: headActions });

  const [postMenuAnchor, setPostMenuAnchor] = useState(null);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [viewStatsAnchor, setViewStatsAnchor] = useState(null);
  const [scoreAnchor, setScoreAnchor] = useState(null);
  useSeo({
    title: post ? `${post.title} | Twelve` : "Twelve",
    description: post && post.excerpt ? post.excerpt : undefined,
    // v2.0.4: OG/Twitter dùng ảnh bìa của bài (nếu có), loại "article".
    image: post && post.coverImageUrl ? post.coverImageUrl : undefined,
    ogType: "article",
  });

  // v2.0.0: chỉ số tương tác (số đếm, myReaction, realtime, like/dislike/share,
  // điểm) dùng CHUNG hook với PostCard. `onData` merge các field còn lại của
  // document realtime vào `post` như trước (giữ field `author` — document
  // Firestore chỉ lưu `authorUid`).
  const engagement = useContentEngagement({
    api,
    collectionName,
    id,
    initial: post ? { ...post, myReaction: myReaction0 } : null,
    onData: (fresh) => setPost((prev) => (prev ? { ...prev, ...fresh } : fresh)),
  });

  // v2.0.0: luồng bình luận (tải phân trang + realtime + gửi/sửa/xóa) dùng CHUNG
  // hook với hộp bình luận ở danh sách. Trang này đã có realtime trên document
  // bài nên không cần `onCountChange`. `active: !!id` — tải song song với bài.
  const thread = useCommentThread({ api, id, collectionName, active: !!id });

  // Gallery media của bài (cover + img/video trong content)
  const mediaSlides = React.useMemo(
    () => collectMediaSlides(post?.contentHtml, post?.coverImageUrl),
    [post?.contentHtml, post?.coverImageUrl]
  );

  const openMediaAt = (src) => {
    const idx = findSlideIndex(mediaSlides, src);
    setLightboxIndex(idx);
    setLightboxOpen(true);
  };

  useEffect(() => {
    // ==== VÁ v0.8.26 [BẢO MẬT/DỮ LIỆU] ====
    // TRƯỚC ĐÂY effect này chạy NGAY khi mount (dependency chỉ có [id]),
    // KHÔNG chờ `isAuthReady`. Khi người dùng B mở link share lần đầu (tab
    // mới/từ app nhắn tin), Firebase SDK chưa kịp khôi phục session từ
    // IndexedDB — `auth.currentUser` trong interceptor (client.js) vẫn là
    // `null` — nên request `api.getOne(id, shareQuery)` gửi đi KHÔNG kèm
    // Authorization header, dù B đã đăng nhập thật. Backend (`optionalAuth`)
    // coi đây là khách ẩn danh -> `viewerUid = null` -> `registerShare`
    // không cộng +8 positiveScore / externalPostScore cho người share, dù
    // view/shareCount/postScore vẫn tăng bình thường (không cần viewerUid).
    // Vì query `?idu=&s=` bị xoá khỏi URL ngay sau lần gọi đầu tiên (dù có
    // ăn điểm hay không), cơ hội ghi công BỊ MẤT VĨNH VIỄN nếu trúng đúng
    // khoảnh khắc race-condition này — không có cách nào retry.
    //
    // FIX: chờ `isAuthReady === true` (đúng thời điểm interceptor đã có thể
    // đính token nếu có) mới gọi API — cùng cách đã áp dụng cho
    // IndexPage.jsx/BlogPage.jsx.
    if (!isAuthReady) return;

    setLoading(true);

    // SHARE: nếu URL đang mở có ?idu=uid hoặc ?shared=1 (link do nút Share
    // tạo ra), chuyển tiếp cho backend để tính 1 lượt share đúng lúc tính
    // view (xem backend/src/controllers/posts.controller.js#getPost). Đọc
    // trực tiếp từ URL thật (location.search) — không phụ thuộc react-router
    // parse lại — để không bỏ sót khi người dùng dán thẳng link vào trình
    // duyệt (không qua <Link>).
    const searchParams = new URLSearchParams(location.search);
    const idu = searchParams.get("idu");
    const shared = searchParams.get("shared");
    // v0.8.21: đọc và truyền cả chữ ký HMAC `s` lên backend — nếu thiếu,
    // registerShare coi sharerUid không hợp lệ và không cộng +8 positiveScore
    // cho người tạo link share (xem backend/utils/helpers.js#verifyShareSignature).
    const sig = searchParams.get("s");
    // Kèm sid khi mở link share: mỗi trình duyệt/phiên = tối đa 1 share;
    // người khác (sid khác) vẫn được đếm — không khóa cả đời theo IP.
    const shareQuery =
      idu || shared
        ? {
            ...(idu ? { idu } : { shared }),
            ...(sig ? { s: sig } : {}),
            sid: getSessionId(),
          }
        : undefined;

    api
      .getOne(id, shareQuery)
      .then((detail) => {
        setPost(detail.post || detail.blog);
        setMyReaction0(detail.myReaction || null);

        // Đã tính share (nếu có) — dọn query khỏi thanh địa chỉ để: (1) tải
        // lại trang không bị tính share thêm lần nữa, (2) người dùng không
        // vô tình copy nguyên link kèm ?idu=... của người khác đi chia sẻ tiếp.
        if (shareQuery) {
          navigate(location.pathname, { replace: true });
        }
      })
      .catch((err) => {
        snackbar.error(err.message || "Không tìm thấy bài viết.");
        // v2.4.2: "đi lên" thay vì navigate(backPath) (đẩy mục mới): đẩy mới thì Back ở headZone lại rơi vào chính URL lỗi này rồi bị đẩy đi tiếp — bẫy quay vòng.
        goUp(backPath);
      })
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, isAuthReady]);

  const handleDeletePost = () => {
    setPostMenuAnchor(null);
    setConfirmDeleteOpen(true);
  };

  const confirmDeletePost = async () => {
    setConfirmDeleteOpen(false);
    try {
      await api.remove(id);
      // v0.8.23.1: xóa bài làm đổi positiveScore và postsScoreSum → accountScore
      refreshProfile();
      snackbar.success("Đã xóa bài viết.");
      goUp(backPath); // v2.4.2: rút gọn lịch sử (không để Back quay lại URL của bài vừa xoá)
    } catch (err) {
      snackbar.error(err.message);
    }
  };

  const canManagePost = post && profile && (profile.uid === post.author?.uid || profile.accountGroup === "SA");

  if (loading) {
    return (
      <>
        <Navbar />
        <Box sx={{ display: "flex", justifyContent: "center", py: 8 }}>
          <CircularProgress />
        </Box>
      </>
    );
  }

  if (!post) return null;

  return (
    <>
      <Navbar />
      <Container maxWidth="sm" sx={{ py: 3 }}>
        <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
          <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 2 }}>
            <UserAvatar user={post.author} />
            <Box>
              <Stack direction="row" spacing={1} alignItems="center">
                <UserName user={post.author} variant="subtitle1" />
                <UserTagChip user={post.author} />
              </Stack>
              <Typography variant="caption" color="text.secondary">
                {formatRelativeTime(post.createdAt)}
              </Typography>
            </Box>
          </Stack>

          {canManagePost && (
            <>
              <IconButton onClick={(e) => setPostMenuAnchor(e.currentTarget)}>
                <MoreVertIcon />
              </IconButton>
              <Menu anchorEl={postMenuAnchor} open={!!postMenuAnchor} onClose={() => setPostMenuAnchor(null)}>
                <MenuItem onClick={handleDeletePost} sx={{ color: "error.main" }}>
                  Xóa bài viết
                </MenuItem>
              </Menu>
            </>
          )}
        </Stack>

        <Typography
          variant="h4"
          sx={{ mb: 2, fontWeight: 700, wordBreak: "break-word", overflowWrap: "break-word" }}
        >
          {post.title}
        </Typography>

        <HashtagChips hashtags={post.hashtags} gap={0.75} sx={{ mb: 2 }} />

        {post.coverImageUrl && (
          <Box
            component="img"
            src={post.coverImageUrl}
            alt={post.title}
            onClick={() => openMediaAt(post.coverImageUrl)}
            sx={{
              width: "100%",
              aspectRatio: "16 / 9",
              objectFit: "cover",
              borderRadius: "12px",
              mb: 3,
              cursor: "zoom-in",
            }}
          />
        )}

        {/* Nội dung Quill: đủ format snow + media responsive; bấm ảnh mở gallery */}
        <PostContent html={post.contentHtml} onMediaClick={(src) => openMediaAt(src)} />

        <MediaLightbox
          open={lightboxOpen}
          slides={mediaSlides}
          index={lightboxIndex}
          onClose={() => setLightboxOpen(false)}
        />

        {/* Viên thuốc 2 cột: đủ 2 mục/hàng; mục lẻ cuối span full (= 2) */}
        <EngagementPills
          items={[
            {
              key: "like",
              icon: engagement.myReaction === "like" ? <ThumbUpIcon color="primary" /> : <ThumbUpOffAltIcon />,
              count: engagement.likeCount,
              active: engagement.myReaction === "like",
              onClick: () => engagement.react("like"),
              ariaLabel: "Thích",
              title: String(engagement.likeCount),
            },
            {
              key: "dislike",
              icon: engagement.myReaction === "dislike" ? <ThumbDownIcon color="error" /> : <ThumbDownOffAltIcon />,
              count: engagement.dislikeCount,
              active: engagement.myReaction === "dislike",
              onClick: () => engagement.react("dislike"),
              ariaLabel: "Không thích",
              title: String(engagement.dislikeCount),
            },
            {
              key: "view",
              icon: <VisibilityIcon />,
              count: engagement.viewCount,
              onClick: (e) => setViewStatsAnchor(e.currentTarget),
              ariaLabel: "Thống kê lượt xem",
              title: String(engagement.viewCount),
            },
            {
              key: "share",
              icon: <ShareIcon />,
              count: engagement.shareCount,
              onClick: () => engagement.share(post?.title),
              ariaLabel: "Chia sẻ",
              title: String(engagement.shareCount),
            },
            {
              key: "score",
              icon: <GradeIcon />,
              count: engagement.score,
              // postScore có thể ÂM (1 dislike = -2 điểm) — bắt buộc dùng
              // formatScore thay vì formatCount trong EngagementPills, nếu
              // không sẽ hiển thị sai thành "0" (bug đã gặp ở v0.8.6).
              signed: true,
              onClick: (e) => setScoreAnchor(e.currentTarget),
              ariaLabel: "Điểm bài viết",
              title: String(engagement.score),
            },
          ]}
        />

        <ViewStatsPopover
          anchorEl={viewStatsAnchor}
          onClose={() => setViewStatsAnchor(null)}
          viewCount={engagement.viewCount}
          aiViewCount={engagement.aiViewCount}
        />

        <PostScorePopover
          anchorEl={scoreAnchor}
          onClose={() => setScoreAnchor(null)}
          viewCount={engagement.viewCount}
          likeCount={engagement.likeCount}
          dislikeCount={engagement.dislikeCount}
          commentCount={engagement.commentCount}
          shareCount={engagement.shareCount}
          score={engagement.score}
        />

        <Paper variant="outlined" sx={{ borderRadius: 1, overflow: "hidden", mb: 2 }}>
          {/* Header: avatar (nếu đăng nhập) + "Bình luận (N)" */}
          <Stack direction="row" alignItems="center" spacing={1.25} sx={{ px: { xs: 1.5, sm: 2 }, pt: 1.5, pb: 1.25 }}>
            {isLoggedIn && <UserAvatar user={profile} size={36} />}
            <Typography variant="subtitle1" fontWeight={700} sx={{ flex: 1, minWidth: 0 }}>
              Bình luận ({formatCount(engagement.commentCount)})
            </Typography>
          </Stack>
          <Divider />
          <Box sx={{ px: { xs: 1.5, sm: 2 }, py: 1.5 }}>
            <CommentComposer onSubmit={thread.send} sending={thread.sending} />
          </Box>
        </Paper>

        {/* Trang cuộn theo cả trang (không có container riêng) → IntersectionObserver
            trong usePaginatedComments dùng root mặc định (viewport). */}
        <Box sx={{ mb: 2 }}>
          <CommentThread thread={thread} />
        </Box>
      </Container>

      <ConfirmDialog
        open={confirmDeleteOpen}
        title="Xóa bài viết"
        message="Bạn có chắc muốn xóa bài viết này? Hành động này không thể hoàn tác."
        confirmText="Xóa bài viết"
        onConfirm={confirmDeletePost}
        onCancel={() => setConfirmDeleteOpen(false)}
      />
    </>
  );
}
