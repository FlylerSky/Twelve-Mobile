import React, { useEffect, useMemo, useState } from "react";
import useSeo from "../hooks/useSeo";
import { Navigate, useLocation, useNavigate, useParams } from "react-router-dom";
import { Container, Box, Typography, CircularProgress } from "@mui/material";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import LinkOutlinedIcon from "@mui/icons-material/LinkOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import Navbar from "../components/Navbar";
import ProfileHeader from "../components/profile/ProfileHeader";
import CopyProfileUrlDialog from "../components/profile/CopyProfileUrlDialog";
import ProfileMoreDialog from "../components/profile/ProfileMoreDialog";
import ProfileVisitorsDialog from "../components/profile/ProfileVisitorsDialog";
import { PROFILE_TABS } from "../components/profile/profileTabs";
import TabTreeBars from "../components/tabs/TabTreeBars";
import useTabTree from "../components/tabs/useTabTree";
import { useRegisterPageHeader } from "../context/PageHeaderContext";
import { getPublicProfile, getPublicProfileByTag, recordProfileVisit } from "../api/users.api";
import { SELF_PROFILE_PATH, classifyProfileRef, normalizeTag, profilePath } from "../utils/profilePath";
import { useAuth } from "../context/AuthContext";
import { useSnackbar } from "../context/SnackbarContext";

export { PROFILE_TABS };

/**
 * ==== Trang Profile (/u/:ref) ====
 * v2.4.2.1: URL hồ sơ dùng TAG NAME SEARCH (`/u/@flylersky`) thay cho UID (`/u/EZRx…KQ22`): ngắn gọn và không lộ UID tài khoản. "@" là bắt buộc —
 * nó phân định tag với `/u/myProfile` và mọi route phụ sau này (xem utils/profilePath.js). `:ref` có 4 dạng:
 *   • `@<tag>`    => tra qua GET /users/by-tag/:tag;
 *   • `myProfile` => HỒ SƠ CỦA NGƯỜI ĐANG ĐĂNG NHẬP (tra theo UID trong phiên, không phụ thuộc tag). Chưa đăng nhập => chuyển tới /login rồi quay lại.
 *     Dùng dạng này vì URL theo tag chết khi chủ hồ sơ đổi Tag Name: lịch sử trình duyệt giữ `/u/@tag-cũ` thì Back về hồ sơ mình sẽ báo "không tìm thấy";
 *   • `<UID>`     => link CŨ đã lan truyền; tra qua GET /users/:uid;
 *   • `@` + tag sai định dạng => "không tìm thấy" (không gọi API).
 * Tra xong, trang tự đưa URL về dạng chuẩn bằng THAY (replace — không thêm mục lịch sử, Back không "bắt" lại UID/tag cũ), giữ nguyên `?tab=…&sub=…` và `#hash`:
 *   link UID cũ hoặc `/u/@Abc` => `/u/@abc`; hồ sơ trùng với tài khoản đang đăng nhập (dù vào bằng tag hay UID) => `/u/myProfile`.
 * UID chỉ còn nằm trong bộ nhớ (`user.uid`) để gọi API bài viết/ghim và so với tài khoản đang đăng nhập — không bao giờ ở thanh địa chỉ.
 *
 *   • danh sách tab/sub-tab nằm ở components/profile/profileTabs.jsx (cây khai báo) — trang này không biết có tab nào;
 *   • hàng tab sticky dưới head, nhiều cấp (sub-tab) đè lên nhau khi cuộn; URL `?tab=posts&sub=…`, tab mặc định giữ URL sạch;
 *   • chỉ tab đang mở được dựng (và gọi API).
 * Bề rộng nội dung "sm" (như feed Trang chủ); hàng tab dùng CÙNG bề rộng nên tab thẳng hàng với nội dung.
 *
 * headZone (v2.4.2.2): MỌI hồ sơ (của mình lẫn người khác) có nút "Sao chép URL Profile" (hiện khi hồ sơ đã tải) → hộp chọn 2 loại:
 *   URL Ngắn (Tag Name Search) `/u/@tag` và URL cố định (UID) `/u/<uid>` — xem components/profile/CopyProfileUrlDialog.jsx. URL UID chỉ là lựa chọn sao chép thêm
 *   (link UID vẫn được hỗ trợ điều hướng và tự chuyển sang URL Tag Name như mô tả ở trên); URL hồ sơ chính của hệ thống KHÔNG đổi.
 *   Chủ hồ sơ có thêm nút "Chỉnh sửa hồ sơ" (đứng trước) → Cài đặt > Tài khoản > Thông tin (nơi đổi ảnh bìa, avatar, tên…).
 *
 * v2.5.2:
 *   • Tab "Blog" chỉ có ở hồ sơ tài khoản SA (ctx.isSA = bậc của CHỦ HỒ SƠ — xem profileTabs.jsx);
 *   • Tiểu sử hiện ở đầu trang (ProfileHeader); nút "Xem thêm" ở đó mở hộp thông tin mở rộng (ProfileMoreDialog — mục do chủ hồ sơ chọn, backend lọc);
 *   • headZone của CHỦ hồ sơ có thêm "Khách ghé thăm" (giữa "Chỉnh sửa hồ sơ" và "Sao chép URL Profile") → ProfileVisitorsDialog (tối đa 50 người gần nhất);
 *   • người ĐÃ ĐĂNG NHẬP mở hồ sơ NGƯỜI KHÁC thì trang báo lượt ghé thăm một lần (POST /users/:uid/visit, fire-and-forget — lỗi/giới hạn tần suất không ảnh hưởng gì).
 */
const PROFILE_WIDTH = "sm";

/** Mô tả trang hồ sơ: có Tiểu sử thì nêu Tiểu sử (gộp một dòng, cắt ~160 ký tự), không thì câu chung. Khớp tinh thần bản SSR (backend utils/seoMeta.js#buildProfileMeta). */
function profileSeoDescription(user) {
  const head = `Hồ sơ ${user.displayName || "người dùng"} ${user.tagName || ""} trên Twelve`.trim();
  const bio = String(user.bio || "").replace(/\s+/g, " ").trim();
  const text = bio ? `${head}. ${bio}` : `${head} — bài viết, điểm số và thành tích.`;
  return text.length <= 160 ? text : `${text.slice(0, 159).trimEnd()}…`;
}

export default function PublicProfilePage() {
  const { ref } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { profile: me, isAuthReady, isLoggedIn, loadingProfile } = useAuth();
  const snackbar = useSnackbar();
  // Hồ sơ đã tải KÈM khoá của URL nó thuộc về: đổi URL sang người khác thì `user` tự về null ngay (không bao giờ hiện nhầm/ canonical hoá nhầm bằng dữ liệu người trước),
  // còn khi chính trang này thay URL sang dạng chuẩn thì cập nhật khoá cùng lúc => không tải lại lần hai.
  const [loaded, setLoaded] = useState({ key: null, user: null });

  const parsed = useMemo(() => classifyProfileRef(ref), [ref]);
  const selfMode = parsed.kind === "self";
  const meUid = me?.uid || null;
  const fetchKey = selfMode ? `self:${meUid || ""}` : ref;
  const user = loaded.key === fetchKey ? loaded.user : null;
  const settled = loaded.key === fetchKey; // đã có kết quả (thành công hoặc không tìm thấy) cho URL này
  // Biết "của chính mình" càng sớm càng tốt (trước cả khi tải xong): `myProfile`, hoặc theo UID khi link cũ, hoặc theo Tag Name khi link mới.
  const isOwn =
    !!meUid &&
    (selfMode ||
      (user ? meUid === user.uid : parsed.kind === "uid" ? meUid === parsed.uid : parsed.kind === "tag" && normalizeTag(me.tagName) === parsed.tag));
  // v2.5.2: `isSA` = CHỦ HỒ SƠ thuộc bậc SA (không phải người xem) — quyết định tab "Blog". Chưa tải xong hồ sơ => false (các hàng tab chỉ vẽ khi đã có hồ sơ).
  const isSA = user?.accountGroup === "SA";
  const tabTree = useTabTree(PROFILE_TABS, { ctx: { isOwn, isSA } });
  const Active = tabTree.active?.Component;

  // v2.4.2.2: hộp "Sao chép URL Profile". Đóng khi chuyển sang hồ sơ người khác (so theo uid — uid không đổi khi trang chỉ thay URL sang dạng chuẩn).
  const [copyUrlOpen, setCopyUrlOpen] = useState(false);
  // v2.5.2: hộp "Xem thêm" và hộp "Khách ghé thăm" — đóng cùng lúc khi chuyển sang hồ sơ khác.
  const [moreOpen, setMoreOpen] = useState(false);
  const [visitorsOpen, setVisitorsOpen] = useState(false);
  const hasUser = !!user;
  useEffect(() => {
    setCopyUrlOpen(false);
    setMoreOpen(false);
    setVisitorsOpen(false);
  }, [user?.uid]);

  // v2.5.2: báo lượt ghé thăm — chỉ khi ĐÃ ĐĂNG NHẬP và xem hồ sơ NGƯỜI KHÁC; một lần cho mỗi hồ sơ mở ra (phụ thuộc uid, không phụ thuộc đối tượng `user` hay URL
  // nên việc trang tự thay URL sang dạng chuẩn không báo lần hai). Backend còn tự bỏ qua lượt lặp của người đang đứng đầu danh sách. Lỗi nuốt im: không đáng làm phiền người xem.
  const visitUid = user?.uid;
  useEffect(() => {
    if (!visitUid || !isLoggedIn || isOwn) return;
    recordProfileVisit(visitUid).catch(() => {});
  }, [visitUid, isLoggedIn, isOwn]);

  const headActions = useMemo(() => {
    const acts = [];
    if (isOwn) acts.push({ key: "edit-profile", label: "Chỉnh sửa hồ sơ", icon: <EditOutlinedIcon />, onClick: () => navigate("/settings/account/info") });
    // v2.5.2: chỉ chủ hồ sơ thấy ai đã ghé thăm.
    if (isOwn) acts.push({ key: "profile-visitors", label: "Khách ghé thăm", icon: <VisibilityOutlinedIcon />, onClick: () => setVisitorsOpen(true) });
    // Chỉ hiện khi đã có hồ sơ (cần tagName/uid để dựng link). Có ở hồ sơ của mình và của mọi người khác.
    if (hasUser) acts.push({ key: "copy-profile-url", label: "Sao chép URL Profile", icon: <LinkOutlinedIcon />, onClick: () => setCopyUrlOpen(true) });
    return acts;
  }, [isOwn, hasUser, navigate]);
  useRegisterPageHeader({ title: "Hồ sơ", isBrand: false, actions: headActions });

  useSeo({
    title: user ? `${user.displayName || "Người dùng"} ${user.tagName || ""} | Twelve`.trim() : "Hồ sơ người dùng | Twelve",
    description: user ? profileSeoDescription(user) : undefined,
    image: user ? user.coverUrl || user.avatarUrl || undefined : undefined,
    // v2.4.2.1: canonical luôn là /u/@<tag> (link chia sẻ/SEO) kể cả khi vào bằng /u/myProfile, link UID cũ hoặc /u/@Abc.
    canonical: user ? profilePath(user) || undefined : undefined,
  });

  // 1) Tải hồ sơ theo URL.
  useEffect(() => {
    if (selfMode && !meUid) return undefined; // chờ phiên đăng nhập sẵn sàng (hoặc <Navigate> bên dưới đã chuyển tới /login)
    if (loaded.key === fetchKey) return undefined; // đã có đúng hồ sơ này (vd. vừa thay URL sang dạng chuẩn)
    let cancelled = false;
    let request;
    if (selfMode) request = getPublicProfile(meUid);
    else if (parsed.kind === "tag") request = getPublicProfileByTag(parsed.tag);
    else if (parsed.kind === "uid") request = getPublicProfile(parsed.uid);
    else request = Promise.reject({ message: "Không tìm thấy người dùng." });
    request
      .then((u) => {
        if (!cancelled) setLoaded({ key: fetchKey, user: u });
      })
      .catch((err) => {
        if (cancelled) return;
        setLoaded({ key: fetchKey, user: null });
        snackbar.error(err.message);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchKey]);

  // 2) Đưa thanh địa chỉ về dạng chuẩn (THAY, không đẩy mục lịch sử): hồ sơ của chính mình => /u/myProfile; còn lại => /u/@<tag> (link UID cũ, chữ hoa…).
  //    Hồ sơ không có tag hợp lệ thì profilePath trả /u/<uid> = giữ nguyên. Chạy lại khi phiên đăng nhập tải xong muộn hơn hồ sơ.
  useEffect(() => {
    if (!user || selfMode) return;
    const mine = !!meUid && user.uid === meUid;
    const canonical = mine ? SELF_PROFILE_PATH : profilePath(user);
    if (!canonical) return;
    const target = decodeURIComponent(canonical.slice(3));
    if (target === ref) return;
    setLoaded({ key: mine ? `self:${meUid}` : target, user });
    navigate({ pathname: canonical, search: location.search, hash: location.hash }, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, meUid, selfMode, ref]);

  // /u/myProfile khi chưa đăng nhập: sang /login, đăng nhập xong quay lại đúng đây (cùng cách các trang cần đăng nhập khác).
  if (selfMode && isAuthReady && !loadingProfile && !isLoggedIn) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return (
    <>
      <Navbar />
      {user && <CopyProfileUrlDialog open={copyUrlOpen} onClose={() => setCopyUrlOpen(false)} user={user} />}
      {user && <ProfileMoreDialog open={moreOpen} onClose={() => setMoreOpen(false)} user={user} isOwn={isOwn} />}
      {isOwn && <ProfileVisitorsDialog open={visitorsOpen} onClose={() => setVisitorsOpen(false)} />}
      <Container maxWidth={PROFILE_WIDTH} sx={{ pt: { xs: 2, sm: 3 } }}>
        {!settled ? (
          <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}>
            <CircularProgress />
          </Box>
        ) : !user ? (
          <Typography textAlign="center" color="text.secondary" sx={{ py: 6 }}>
            Không tìm thấy người dùng.
          </Typography>
        ) : (
          <ProfileHeader user={user} onOpenMore={() => setMoreOpen(true)} />
        )}
      </Container>

      {/* Các hàng tab ở GỐC trang (anh em với Container) để sticky chạy suốt chiều dài trang — như Xu hướng. */}
      {user && <TabTreeBars tabTree={tabTree} maxWidth={PROFILE_WIDTH} ariaLabel="Các tab hồ sơ" />}

      {user && Active && (
        <Container maxWidth={PROFILE_WIDTH} sx={{ py: { xs: 2, sm: 3 } }}>
          {/* key theo uid + đường dẫn tab: đổi người/tab là dựng lại sạch, không dính dữ liệu của người trước. `uid` lấy từ hồ sơ đã tải (không từ URL). */}
          <Active key={`${user.uid}:${tabTree.path.map((n) => n.key).join("/")}`} uid={user.uid} isOwn={isOwn} user={user} />
        </Container>
      )}
    </>
  );
}
