/**
 * ==== v2.4.2 — Bản ghi lịch sử điều hướng trong phiên (để nút Back "đi lên" đúng, không quay vòng) ====
 *
 * VẤN ĐỀ (người dùng báo): nút Back ở headZone chạy `navigate(-1)` — LÙI THEO LỊCH SỬ — trong khi các nút "quay lại" riêng trong trang
 * (Cài đặt, Xu hướng) là liên kết `to=<mục cha>` — TIẾN thêm một mục mới vào lịch sử. Trộn hai loại thì quay vòng: Cài đặt › Ứng dụng ›
 * Chế độ giao diện → bấm "quay lại" trong trang (lịch sử: …, theme, ỨNG DỤNG) → bấm Back ở headZone (lùi một mục) → rơi lại vào Chế độ giao diện.
 *
 * CÁCH SỬA: mọi động tác "đi lên" (nút Back ở headZone khi trang khai báo trang cha, đường dẫn/breadcrumb, bấm lại tab…) đều đi qua `planUp`:
 * nếu trang cha ĐÃ nằm sẵn trong lịch sử phía sau và mọi mục giữa chúng đều là con cháu của nó thì LÙI THẲNG tới đó (lịch sử rút gọn lại, không
 * sinh mục mới nên không còn gì để "chui lại"); nếu không thì THAY mục hiện tại bằng trang cha (replace). Trình duyệt không cho đọc nội dung
 * lịch sử nên ta tự ghi lại mỗi mục (khoá + đường dẫn) khi điều hướng. Tải lại trang thì bản ghi trống → luôn rơi về replace (vẫn đúng, chỉ không rút gọn được).
 *
 * Không phụ thuộc `window.history.state.idx` nên chạy được cả với MemoryRouter (test). Trạng thái ở cấp module (một ứng dụng = một lịch sử).
 */
let stack = []; // [{ key, path }]
let ptr = -1; // vị trí mục hiện tại trong `stack`

const pathOf = (location) => `${location.pathname || "/"}${location.search || ""}`;
const pathnameOf = (p) => String(p).split("?")[0].split("#")[0].replace(/\/+$/, "") || "/";

/** Gọi mỗi khi location đổi (NavStackTracker). navType: "PUSH" | "REPLACE" | "POP". */
export function trackLocation(location, navType) {
  const entry = { key: location.key, path: pathOf(location) };
  if (ptr >= 0 && stack[ptr]?.key === entry.key) {
    stack[ptr] = entry; // render lại cùng một mục
    return;
  }
  if (navType === "PUSH") {
    stack = stack.slice(0, ptr + 1); // đẩy mục mới = bỏ các mục "tiến tới" cũ (đúng ngữ nghĩa lịch sử trình duyệt)
    stack.push(entry);
    ptr = stack.length - 1;
  } else if (navType === "REPLACE") {
    if (ptr < 0) {
      stack = [entry];
      ptr = 0;
    } else {
      stack[ptr] = entry;
    }
  } else {
    // POP (lùi/tiến, hoặc lần tải đầu): tìm mục theo khoá; không có (vd. sau khi tải lại trang) → bắt đầu bản ghi mới từ mục này.
    const i = stack.findIndex((e) => e.key === entry.key);
    if (i >= 0) {
      ptr = i;
      stack[i] = entry;
    } else {
      stack = [entry];
      ptr = 0;
    }
  }
}

function isDescendant(path, target) {
  const p = pathnameOf(path);
  const t = pathnameOf(target);
  return t === "/" ? p !== "/" : p.startsWith(`${t}/`);
}

/**
 * Kế hoạch đi lên `target`:
 *  - { type: "pop", delta }  — lùi `delta` (< 0) mục: trang cha đã có trong lịch sử, các mục giữa đều là con cháu của nó;
 *  - { type: "replace" }     — thay mục hiện tại bằng `target` (không có mục cha trong lịch sử, hoặc giữa chừng có trang lạ không nên lùi xuyên qua).
 */
export function planUp(target) {
  const t = pathnameOf(target);
  for (let j = ptr - 1; j >= 0; j--) {
    const p = pathnameOf(stack[j].path);
    if (p === t) return { type: "pop", delta: j - ptr };
    if (!isDescendant(stack[j].path, target)) break;
  }
  return { type: "replace" };
}

/** Có mục nào phía sau để lùi (theo bản ghi của ta, hoặc theo chỉ số của react-router sau khi tải lại trang)? */
export function canGoBack() {
  if (ptr > 0) return true;
  try {
    const idx = window.history.state?.idx;
    return typeof idx === "number" && idx > 0;
  } catch (_e) {
    return false;
  }
}

/** Dành cho test. */
export function resetNavStack() {
  stack = [];
  ptr = -1;
}
export function __debugNavStack() {
  return { paths: stack.map((e) => e.path), ptr };
}
