/**
 * v2.4.2.2: chuyển từ pages/settings/debugReport.js ra đây để dùng chung (Gỡ lỗi, Sao chép URL Profile…).
 * Sao chép vào clipboard; trả true/false. Có đường dự phòng cho trình duyệt/ngữ cảnh không có navigator.clipboard (http, WebView cũ). */
export async function copyText(text) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (_e) {
    /* rơi xuống đường dự phòng */
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return !!ok;
  } catch (_e) {
    return false;
  }
}
