import { signInWithEmailAndPassword } from "firebase/auth";

/**
 * ==== v2.0.5 [SỬA LỖI] — tương thích tài khoản đăng ký trước khi vá `normalizeEmail` ====
 * Trước bản vá, backend lưu email Gmail đã BỎ DẤU CHẤM và phần "+tag" (John.Doe+x@gmail.com được lưu là
 * johndoe@gmail.com) nên người dùng đăng nhập bằng email gốc bị báo sai. Tài khoản mới nay lưu đúng email
 * đã gõ (chữ thường). Hàm này giúp tài khoản CŨ vẫn đăng nhập được: thử email người dùng gõ trước; nếu
 * Firebase báo không tìm thấy/sai thông tin và dạng "chuẩn hoá kiểu cũ" khác với email đã gõ thì thử lại một lần.
 */
const GMAIL = new Set(["gmail.com", "googlemail.com"]);
const PLUS_ADDRESSING = new Set(["gmail.com", "googlemail.com", "outlook.com", "hotmail.com", "live.com", "yahoo.com", "icloud.com", "me.com"]);

export function legacyNormalizeEmail(raw) {
  const email = String(raw || "").trim().toLowerCase();
  const at = email.lastIndexOf("@");
  if (at < 1) return email;
  let local = email.slice(0, at);
  let domain = email.slice(at + 1);
  if (PLUS_ADDRESSING.has(domain)) local = local.split("+")[0];
  if (GMAIL.has(domain)) {
    local = local.replace(/\./g, "");
    domain = "gmail.com";
  }
  return `${local}@${domain}`;
}

const RETRYABLE = new Set(["auth/invalid-credential", "auth/user-not-found", "auth/invalid-login-credentials"]);

export async function signInWithEmailCompat(auth, rawEmail, password) {
  const typed = String(rawEmail || "").trim();
  try {
    return await signInWithEmailAndPassword(auth, typed, password);
  } catch (err) {
    const legacy = legacyNormalizeEmail(typed);
    if (RETRYABLE.has(err && err.code) && legacy && legacy !== typed.toLowerCase()) {
      try {
        return await signInWithEmailAndPassword(auth, legacy, password);
      } catch (_) {
        /* báo lỗi gốc, không lộ email nào tồn tại */
      }
    }
    throw err;
  }
}
