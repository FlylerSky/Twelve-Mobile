/**
 * ==== v2.0.11 — Giới hạn mềm cho `contentHtml` phía client (Báo cáo bảo mật Phiên 2, G5) ====
 *
 * Backend (v2.0.10, F1) TỰ CHẶN nội dung quá dài/quá phức tạp bằng HTTP 422 — đó mới là lớp bắt buộc. Đây chỉ là lớp
 * UX: báo ngay tại chỗ (bộ đếm + chặn nút Đăng) thay vì chờ backend từ chối. Các hằng số PHẢI khớp
 * `backend/src/utils/constants.js#CONTENT_LIMITS` (có test đối chiếu: tests/contentLimits.test.js).
 */
export const CONTENT_LIMITS = {
  HTML_MAX_CHARS: 250000,
  HTML_MAX_ELEMENTS: 5000,
  HTML_MAX_MEDIA: 200,
};

const WARN_RATIO = 0.8;
const MEDIA_TAGS = new Set(["img", "video", "audio", "source", "iframe"]);
const nf = new Intl.NumberFormat("vi-VN");

/**
 * Phân tích nhanh HTML do Quill sinh ra (chỉ đếm, không dựng DOM).
 * @returns {{chars:number, elements:number, media:number, ratio:number, severity:"ok"|"warn"|"error", message:string}}
 *   ratio = mức dùng cao nhất trong các giới hạn (0..>1); message rỗng khi ổn.
 */
export function assessContent(html) {
  const text = typeof html === "string" ? html : "";
  const chars = text.length;
  let elements = 0;
  let media = 0;
  const re = /<([A-Za-z][A-Za-z0-9:-]*)/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    elements++;
    if (MEDIA_TAGS.has(m[1].toLowerCase())) media++;
  }

  const L = CONTENT_LIMITS;
  const usage = [
    { ratio: chars / L.HTML_MAX_CHARS, over: `Nội dung quá dài (${nf.format(chars)} / ${nf.format(L.HTML_MAX_CHARS)} ký tự). Hãy rút gọn trước khi đăng.` },
    { ratio: elements / L.HTML_MAX_ELEMENTS, over: `Nội dung có quá nhiều thành phần định dạng (${nf.format(elements)} / ${nf.format(L.HTML_MAX_ELEMENTS)}). Hãy bỏ bớt định dạng.` },
    { ratio: media / L.HTML_MAX_MEDIA, over: `Nội dung chứa quá nhiều ảnh/video/âm thanh (${media} / ${L.HTML_MAX_MEDIA}).` },
  ];
  const worst = usage.reduce((a, b) => (b.ratio > a.ratio ? b : a));
  const severity = worst.ratio > 1 ? "error" : worst.ratio >= WARN_RATIO ? "warn" : "ok";
  const message = severity === "error" ? worst.over : severity === "warn" ? `Sắp chạm giới hạn nội dung (${Math.round(worst.ratio * 100)}%).` : "";
  return { chars, elements, media, ratio: worst.ratio, severity, message };
}
