import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";
import CodeIcon from "@mui/icons-material/Code";
import GavelIcon from "@mui/icons-material/Gavel";
import DiamondIcon from "@mui/icons-material/Diamond";
import ScienceIcon from "@mui/icons-material/Science";
import HistoryIcon from "@mui/icons-material/History";
import VerifiedIcon from "@mui/icons-material/Verified";
import ShieldIcon from "@mui/icons-material/Shield";

/**
 * ==== v2.4.0 — Hệ thống HUY HIỆU (phía hiển thị) ====
 * Backend (backend/src/utils/badges.js) quyết định NGƯỜI NÀY CÓ HUY HIỆU NÀO (danh sách id, đúng thứ tự); file này quyết định
 * HUY HIỆU ĐÓ TRÔNG RA SAO: icon + màu + tên + mô tả. Giao diện chỉ vẽ ICON (tiết kiệm chỗ — bản cũ dùng chip chữ dài);
 * tên và mô tả chỉ hiện khi bấm vào huy hiệu (UserBadges).
 *
 * THÊM HUY HIỆU MỚI: thêm id ở backend/src/utils/badges.js, rồi thêm một mục vào BADGE_CATALOG dưới đây. Id lạ (backend mới hơn frontend)
 * vẫn hiện được bằng huy hiệu chung (UNKNOWN_BADGE) thay vì mất hoặc làm hỏng giao diện.
 *
 * `color`: khoá màu của theme MUI (palette.<color>.main) để huy hiệu đúng cả sáng/tối.
 */
export const BADGE_CATALOG = Object.freeze({
  sa: { icon: ShieldIcon, color: "primary", label: "Tài khoản cấp cao", description: "Thuộc nhóm tài khoản cấp cao (SA) của Twelve." },
  admin: { icon: AdminPanelSettingsIcon, color: "error", label: "Quản trị viên", description: "Quản trị Twelve — toàn quyền quản lý hệ thống." },
  dev: { icon: CodeIcon, color: "info", label: "Lập trình viên", description: "Thành viên đội phát triển Twelve." },
  moderator: { icon: GavelIcon, color: "primary", label: "Điều hành viên", description: "Giữ gìn nội dung và trật tự cộng đồng Twelve." },
  pro: { icon: DiamondIcon, color: "secondary", label: "Người dùng Pro", description: "Tài khoản Pro của Twelve." },
  tester: { icon: ScienceIcon, color: "success", label: "Tài khoản thử nghiệm", description: "Tài khoản dùng để thử nghiệm, không tham gia xếp hạng." },
  legacy: { icon: HistoryIcon, color: "warning", label: "Thành viên Twelve cũ", description: "Đã đồng hành cùng Twelve từ phiên bản đầu tiên." },
});

export const UNKNOWN_BADGE = Object.freeze({ icon: VerifiedIcon, color: "default", label: "Huy hiệu", description: "Huy hiệu của Twelve." });

// Phải khớp backend badges.js (test dùng chung một bảng ca cho hai phía).
const STAFF_BADGE_BY_ROLE = Object.freeze({ admin: "admin", dev: "dev", moderator: "moderator" });
const ROLE_TO_GROUP = Object.freeze({ admin: "SA", dev: "SA", moderator: "SA", pro_user: "RA", user: "RA", test: "LLA" });

/**
 * Suy danh sách id huy hiệu từ các trường hồ sơ — cùng luật với backend badgeIdsForUser (xem backend/src/utils/badges.js):
 * NHÓM (accountGroup) là căn cứ chính vì mọi quyền hạn của Twelve dựa vào nó; vai trò (accountRole) chỉ làm rõ thêm trong nhóm.
 * SA → admin/dev/moderator nếu vai trò nói rõ, không thì "sa"; LLA → tester; RA → pro nếu pro_user, còn lại không có huy hiệu.
 */
export function deriveBadgeIds(user) {
  if (!user || typeof user !== "object") return [];
  const ids = [];
  const group = user.accountGroup || ROLE_TO_GROUP[user.accountRole] || null;
  if (group === "SA") ids.push(STAFF_BADGE_BY_ROLE[user.accountRole] || "sa");
  else if (group === "LLA") ids.push("tester");
  else if (group === "RA" && user.accountRole === "pro_user") ids.push("pro");
  if (user.isLegacyMember === true) ids.push("legacy");
  return ids;
}

/**
 * Danh sách id huy hiệu CỦA MỘT NGƯỜI để hiển thị.
 * - Có `badges` (backend đã tính: mọi hồ sơ công khai, dòng bảng xếp hạng, và hồ sơ của chính mình — AuthContext tính lại mỗi khi
 *   hồ sơ đổi trên Firestore) → dùng đúng danh sách đó, để mọi nơi hiện CÙNG một kết quả.
 * - Chưa có (đối tượng dựng tay, dữ liệu rất cũ) → suy từ các trường hồ sơ.
 */
export function resolveBadgeIds(user) {
  if (!user || typeof user !== "object") return [];
  if (Array.isArray(user.badges)) return user.badges.filter((id) => typeof id === "string");
  return deriveBadgeIds(user);
}

/** Cỡ icon huy hiệu theo cỡ chữ của tên đứng cạnh (theo `variant` của Typography) — một bảng duy nhất để mọi nơi đồng nhất. */
const BADGE_SIZE_BY_VARIANT = Object.freeze({ caption: 14, body2: 16, body1: 18, subtitle2: 18, subtitle1: 20, h6: 22, h5: 24, h4: 28 });
export function badgeSizeForVariant(variant) {
  return BADGE_SIZE_BY_VARIANT[variant] || 18;
}

export function getBadgeInfo(id) {
  return BADGE_CATALOG[id] ? { id, ...BADGE_CATALOG[id] } : { id, ...UNKNOWN_BADGE };
}
