/**
 * ==== v2.5.2 — Tiểu sử (bio): giới hạn + kiểm tra phía giao diện ====
 * Phản chiếu backend (backend/src/utils/constants.js PROFILE.BIO_MAX / BIO_MAX_LINES và utils/input.js#cleanBio) để người dùng thấy lỗi NGAY khi gõ thay vì sau khi bấm Lưu.
 * Backend vẫn là nơi quyết định cuối cùng (làm sạch + kiểm tra lại); `normalizeBio` ở đây chỉ làm phần chính (xuống dòng, khoảng trắng thừa, dòng trống liên tiếp)
 * để con số hiện ra gần với con số backend sẽ đếm — không bao giờ chặn oan thứ backend chấp nhận. Test kiểm hằng số khớp backend.
 */
export const BIO_MAX = 300;
export const BIO_MAX_LINES = 6;

export function normalizeBio(value) {
  return String(value ?? "")
    .replace(/\r\n?|[\u2028\u2029]/g, "\n")
    .split("\n")
    .map((line) => line.replace(/[^\S\n]+/g, " ").trim())
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** { chars, lines, tooLong, tooManyLines, valid } theo bản đã chuẩn hoá. Ký tự đếm theo code point (emoji đơn = 1), như backend. */
export function bioStats(value) {
  const text = normalizeBio(value);
  const chars = Array.from(text).length;
  const lines = text === "" ? 0 : text.split("\n").length;
  const tooLong = chars > BIO_MAX;
  const tooManyLines = lines > BIO_MAX_LINES;
  return { chars, lines, tooLong, tooManyLines, valid: !tooLong && !tooManyLines };
}
