/**
 * ==== v2.4.1 — Thu nhỏ ảnh trước khi tải lên làm ảnh bìa ====
 * Ảnh bìa lưu NGUYÊN ảnh (không cắt cứng) nên ảnh chụp điện thoại 5–12 MB sẽ vượt giới hạn 3 MB của backend. Ở trình duyệt, thu cạnh dài về
 * tối đa `maxSide` (khớp Cloudinary: giới hạn 2400px) và nén JPEG; ảnh đã nhỏ, đúng định dạng thì giữ nguyên (không nén lại, không đổi màu/trong suốt).
 */
export const COVER_MAX_SIDE = 2400;
export const COVER_MAX_BYTES = 3 * 1024 * 1024; // khớp backend ASSET_LIMITS.cover.MAX_BYTES
const KEEP_AS_IS_BYTES = 2.5 * 1024 * 1024; // chừa dư so với giới hạn backend
export const COVER_MIMES = ["image/jpeg", "image/png", "image/webp"];

/** Kích thước sau khi thu để cạnh dài ≤ maxSide (không phóng to). */
export function fitWithin(width, height, maxSide = COVER_MAX_SIDE) {
  const longest = Math.max(width, height);
  if (!longest || longest <= maxSide) return { width, height, scaled: false };
  const k = maxSide / longest;
  return { width: Math.max(1, Math.round(width * k)), height: Math.max(1, Math.round(height * k)), scaled: true };
}

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Không đọc được ảnh này. Hãy chọn ảnh JPEG, PNG hoặc WebP khác."));
    };
    img.src = url;
  });
}

const toBlob = (canvas, type, quality) => new Promise((resolve) => canvas.toBlob(resolve, type, quality));

/** @returns {Promise<Blob>} ảnh sẵn sàng tải lên (≤ COVER_MAX_BYTES) hoặc ném Error có thông báo tiếng Việt */
export async function prepareCoverImage(file) {
  if (!file || !COVER_MIMES.includes(file.type)) throw new Error("Chỉ nhận ảnh JPEG, PNG hoặc WebP.");
  const img = await loadImage(file);
  const target = fitWithin(img.naturalWidth, img.naturalHeight);
  if (!target.scaled && file.size <= KEEP_AS_IS_BYTES) return file;

  const canvas = document.createElement("canvas");
  canvas.width = target.width;
  canvas.height = target.height;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#ffffff"; // PNG/WebP trong suốt → JPEG không bị nền đen
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(img, 0, 0, target.width, target.height);
  for (const quality of [0.9, 0.8, 0.7, 0.55]) {
    const blob = await toBlob(canvas, "image/jpeg", quality);
    if (blob && blob.size > 0 && blob.size <= COVER_MAX_BYTES) return blob;
  }
  throw new Error("Ảnh quá lớn ngay cả sau khi thu nhỏ. Hãy chọn ảnh khác.");
}
