/**
 * ==== v2.5.3.121126 — "App Check không bao giờ được phép làm treo ứng dụng" ====
 *
 * Sự cố (2.5.3): đặt `VITE_FIREBASE_APPCHECK_SITE_KEY` trong khi CSP của `vercel.json` chưa mở reCAPTCHA (hoặc reCAPTCHA bị chặn/lỗi mạng/trình chặn quảng cáo) làm
 * ĐĂNG NHẬP, ĐĂNG KÝ và mọi lượt đọc Firestore treo vô hạn, trong khi backend vẫn trả lời bình thường (curl nhanh). Nguyên nhân nằm trong Firebase SDK 10.x:
 *   1. `loadReCAPTCHAV3Script()` của @firebase/app-check KHÔNG có `onerror` — script bị chặn thì `grecaptcha` không bao giờ có và Promise `initialized` không bao giờ resolve;
 *   2. `getToken()` của provider chờ Promise đó (không có timeout) và `state.exchangeTokenPromise` giữ nguyên Promise treo ấy cho MỌI lần gọi sau;
 *   3. Firebase Auth (`_getAppCheckToken`) và Firestore đều `await` token này TRƯỚC mỗi yêu cầu mạng ⇒ yêu cầu đăng nhập thậm chí không được gửi đi.
 * Chỉ các yêu cầu tới backend Express (axios) không bị ảnh hưởng, nên chỉ trang không cần phiên đăng nhập mới còn tải được.
 *
 * Hai lớp phòng thủ (cả hai chỉ chạy khi có site key — khi không đặt biến, module này không được gọi):
 *   - `waitForRecaptcha()`: tự nạp script reCAPTCHA (đúng URL mà SDK sẽ nạp, nên SDK thấy `grecaptcha` có sẵn và không nạp lại) với `onerror` + timeout, rồi chờ `grecaptcha.ready`.
 *     Chỉ khi xong mới gọi `initializeAppCheck`; thất bại ⇒ bỏ qua App Check cho phiên này (ghi cảnh báo), ứng dụng chạy như khi chưa bật.
 *   - `withTokenTimeout()`: bọc provider để `getToken()` quá hạn thì BÁO LỖI (SDK đổi thành token giả + lỗi và cho yêu cầu đi tiếp) thay vì treo; sau một lần quá hạn,
 *     tạm bỏ qua App Check trong `cooldownMs` để các yêu cầu kế tiếp không phải chờ lại.
 */

export const RECAPTCHA_SCRIPT_URL = {
  v3: "https://www.google.com/recaptcha/api.js",
  enterprise: "https://www.google.com/recaptcha/enterprise.js",
};

/**
 * Nạp script reCAPTCHA và chờ `grecaptcha.ready`. Resolve bằng đối tượng grecaptcha; reject (không bao giờ treo) khi script bị chặn/lỗi/quá hạn.
 * `doc`/`win` truyền vào được để test.
 */
export function waitForRecaptcha({ enterprise = false, timeoutMs = 8000, doc = document, win = window } = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    let timer = null;
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(value);
    };
    const getG = () => (enterprise ? win.grecaptcha && win.grecaptcha.enterprise : win.grecaptcha);
    const whenReady = () => {
      const g = getG();
      if (!g || typeof g.ready !== "function") {
        finish(reject, new Error("reCAPTCHA tải xong nhưng không dùng được"));
        return;
      }
      g.ready(() => finish(resolve, g));
    };
    timer = setTimeout(
      () => finish(reject, new Error(`reCAPTCHA chưa sẵn sàng sau ${timeoutMs}ms (script bị chặn bởi CSP, mạng, hoặc trình chặn quảng cáo)`)),
      timeoutMs
    );
    if (getG()) {
      whenReady();
      return;
    }
    const script = doc.createElement("script");
    script.src = enterprise ? RECAPTCHA_SCRIPT_URL.enterprise : RECAPTCHA_SCRIPT_URL.v3;
    script.async = true;
    script.onload = whenReady;
    script.onerror = () => finish(reject, new Error("không tải được script reCAPTCHA (CSP `script-src` chưa mở www.google.com/recaptcha và www.gstatic.com/recaptcha, hoặc bị chặn)"));
    doc.head.appendChild(script);
  });
}

/**
 * Bọc một provider App Check (ReCaptchaV3Provider/ReCaptchaEnterpriseProvider) để `getToken()` không treo quá `timeoutMs`.
 * SDK gọi `initialize(app)` và `isEqual(other)` trên provider (xem `_activate`/`initializeAppCheck` trong @firebase/app-check) nên cả hai được chuyển tiếp.
 */
export function withTokenTimeout(inner, { timeoutMs = 5000, cooldownMs = 60000, now = () => Date.now() } = {}) {
  let blockedUntil = 0;
  const wrapper = {
    __inner: inner,
    initialize: (...args) => inner.initialize(...args),
    isEqual: (other) => !!(other && other.__inner) && inner.isEqual(other.__inner),
    getToken() {
      if (now() < blockedUntil) {
        return Promise.reject(new Error("App Check tạm bỏ qua (lần lấy token trước quá hạn)"));
      }
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          blockedUntil = now() + cooldownMs;
          reject(new Error(`App Check getToken quá ${timeoutMs}ms — bỏ qua token cho yêu cầu này`));
        }, timeoutMs);
        let pending;
        try {
          pending = Promise.resolve(inner.getToken());
        } catch (err) {
          clearTimeout(timer);
          reject(err);
          return;
        }
        pending.then(
          (value) => {
            clearTimeout(timer);
            resolve(value);
          },
          (err) => {
            clearTimeout(timer);
            reject(err);
          }
        );
      });
    },
  };
  return wrapper;
}
