/**
 * v2.0.11 [G4] — phục hồi khi tải chunk JS động thất bại (thường do vừa deploy bản mới nên tên file băm cũ không còn).
 * Vite phát `vite:preloadError` trên window; ta tải lại trang ĐÚNG 1 lần (lấy index.html mới). Cờ trong sessionStorage chặn
 * vòng lặp reload nếu nguyên nhân là mất mạng. Trả về hàm gỡ listener (dùng cho test).
 */
export const CHUNK_RELOAD_FLAG = "twelve_chunk_reload";

export function installChunkReload(win = window) {
  const handler = (ev) => {
    ev.preventDefault();
    try {
      if (win.sessionStorage.getItem(CHUNK_RELOAD_FLAG) === "1") return;
      win.sessionStorage.setItem(CHUNK_RELOAD_FLAG, "1");
    } catch {
      return; // không có sessionStorage => không dám reload (tránh vòng lặp)
    }
    win.location.reload();
  };
  win.addEventListener("vite:preloadError", handler);
  return () => win.removeEventListener("vite:preloadError", handler);
}
