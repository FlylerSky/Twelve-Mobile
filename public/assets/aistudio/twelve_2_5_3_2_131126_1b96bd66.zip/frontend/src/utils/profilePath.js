/**
 * ==== v2.4.2.1 — URL hồ sơ dùng TAG NAME SEARCH (không còn UID) ====
 * Trước đây `/u/<UID>` — dài ~28 ký tự và làm lộ UID tài khoản qua thanh địa chỉ / link chia sẻ. Nay `/u/@<tag>`:
 * tag chữ thường 3-20 ký tự [a-z0-9_] (cùng luật với backend: helpers.js#isValidTagName). Tag Name là duy nhất trên mỗi tài khoản.
 *
 * DẤU "@" LÀ BẮT BUỘC trong URL: nó phân định tag với mọi đoạn đường dẫn khác dưới `/u/` — hiện là `/u/myProfile` (xem dưới) và sau này là bất kỳ
 * route phụ nào của trang Profile — nên route phụ không bao giờ trùng với tag của ai. Chuỗi KHÔNG có "@" không bao giờ là tag.
 *
 * `/u/myProfile` = HỒ SƠ CỦA NGƯỜI ĐANG ĐĂNG NHẬP. Lý do: URL theo tag chết khi chủ hồ sơ đổi Tag Name — nếu thanh địa chỉ/lịch sử trình duyệt giữ
 * `/u/@tag-cũ` thì bấm Back về hồ sơ của chính mình sẽ báo "không tìm thấy". `/u/myProfile` không phụ thuộc tag nên luôn đúng.
 *
 * MỌI chỗ dẫn tới hồ sơ phải đi qua `profilePath(user)` (hoặc SELF_PROFILE_PATH cho hồ sơ của chính mình) — đừng tự ghép chuỗi `/u/...`.
 * File này và backend/src/utils/helpers.js (profilePath, classifyProfileRef) phải giữ cùng quy tắc.
 */
const TAG_RE = /^[a-z0-9_]{3,20}$/;

/** Đoạn đường dẫn và đường dẫn đầy đủ của hồ sơ người đang đăng nhập. */
export const SELF_PROFILE_SEGMENT = "myProfile";
export const SELF_PROFILE_PATH = `/u/${SELF_PROFILE_SEGMENT}`;

/** "@Abc" / " abc " -> "abc" (chữ thường, bỏ "@"). Không kiểm tra hợp lệ. */
export function normalizeTag(raw) {
  if (typeof raw !== "string") return "";
  let t = raw.trim().toLowerCase();
  if (t.startsWith("@")) t = t.slice(1);
  return t;
}

/** Tag Name hợp lệ (nhận cả dạng có "@" như dữ liệu công khai "@abc" lẫn dạng lưu trữ "abc"). */
export function isValidTag(raw) {
  return TAG_RE.test(normalizeTag(raw));
}

/**
 * Phân loại tham số `:ref` của URL hồ sơ (`/u/:ref`):
 *  - { kind: "tag", tag }  — bắt đầu bằng "@" và phần sau là Tag Name hợp lệ (hoa/thường đều nhận);
 *  - { kind: "invalid" }   — bắt đầu bằng "@" nhưng phần sau không hợp lệ => "không tìm thấy", không gọi API;
 *  - { kind: "self" }      — `myProfile` (không phân biệt hoa/thường): hồ sơ của người đang đăng nhập;
 *  - { kind: "uid", uid }  — còn lại: link CŨ /u/<UID> (UID Firebase dài 28 ký tự). Không bao giờ nhập nhằng với tag vì tag luôn có "@".
 */
export function classifyProfileRef(raw) {
  const ref = typeof raw === "string" ? raw : "";
  if (ref.startsWith("@")) return isValidTag(ref) ? { kind: "tag", tag: normalizeTag(ref) } : { kind: "invalid" };
  if (ref.toLowerCase() === SELF_PROFILE_SEGMENT.toLowerCase()) return { kind: "self" };
  return { kind: "uid", uid: ref };
}

/**
 * Đường dẫn CÔNG KHAI của hồ sơ một người dùng (đối tượng có `tagName` và/hoặc `uid`): `/u/@<tag>`.
 * `tagName` nhận cả dạng công khai "@abc" lẫn dạng lưu trữ "abc". Hồ sơ hiếm hoi không có Tag Name hợp lệ thì rơi về `/u/<uid>`
 * (trang Profile tự chuyển sang URL tag nếu hồ sơ có tag) để liên kết không bao giờ chết; không có cả hai => null.
 * Lưu ý: đây là link để CHIA SẺ/SEO. Hồ sơ của chính mình trong app dùng SELF_PROFILE_PATH (trang Profile tự chuyển về đó).
 */
export function profilePath(user) {
  return profileTagPath(user) || profileUidPath(user);
}

/**
 * ==== v2.4.2.2 — các dạng link để SAO CHÉP (hộp "Sao chép URL Profile" ở headZone trang Profile) ====
 * URL Tag Name (`/u/@tag`) vẫn là URL hồ sơ CHÍNH của hệ thống. URL UID (`/u/<uid>`) chỉ là một lựa chọn sao chép thêm, tận dụng việc link UID cũ vẫn
 * được hỗ trợ: mở ra thì trang Profile (SPA) tự THAY sang `/u/@tag` / `/u/myProfile`, còn SSR cho bot trả 301 sang `/u/@tag` (xem PublicProfilePage + PATCH-19).
 * Hai hàm dưới đây KHÔNG thay đổi quy tắc của profilePath() — profilePath() vẫn ưu tiên tag, UID chỉ là đường lùi khi không có tag hợp lệ.
 */

/** `/u/@<tag>` nếu có Tag Name hợp lệ, ngược lại null (khác profilePath: KHÔNG rơi về UID). */
export function profileTagPath(user) {
  if (!user || !isValidTag(user.tagName)) return null;
  return `/u/@${normalizeTag(user.tagName)}`;
}

/** `/u/<uid>` — link CỐ ĐỊNH, không đổi theo Tag Name; null nếu không có uid. */
export function profileUidPath(user) {
  if (!user || !user.uid) return null;
  return `/u/${encodeURIComponent(user.uid)}`;
}

/**
 * Hai link tuyệt đối để sao chép: `{ tag, uid }` (mỗi giá trị null nếu hồ sơ thiếu dữ liệu tương ứng).
 * Dựng từ ĐỐI TƯỢNG hồ sơ, không từ thanh địa chỉ — vì hồ sơ của chính mình đang nằm ở `/u/myProfile` (link đó mở ra hồ sơ của NGƯỜI MỞ, không chia sẻ được).
 */
export function profileShareUrls(user, origin = typeof window !== "undefined" ? window.location.origin : "") {
  const tagPath = profileTagPath(user);
  const uidPath = profileUidPath(user);
  return { tag: tagPath ? `${origin}${tagPath}` : null, uid: uidPath ? `${origin}${uidPath}` : null };
}
