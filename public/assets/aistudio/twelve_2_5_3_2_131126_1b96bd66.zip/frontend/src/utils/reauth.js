import { EmailAuthProvider, reauthenticateWithCredential } from "firebase/auth";
import { auth } from "../firebase";

/**
 * ==== v2.2.0 — Nhập lại mật khẩu cho thao tác nhạy cảm (một nơi duy nhất) ====
 * Đổi mật khẩu, xem/đổi tên thật, xoá tài khoản đều cần "vừa nhập lại mật khẩu". Backend không kiểm được mật khẩu, nên: Firebase kiểm
 * (reauthenticateWithCredential) → cấp ID token có `auth_time` mới → backend (middleware requireRecentAuth) chỉ cần tin `auth_time` đó.
 * Mọi nơi dùng chung hàm này và `describeAuthError` để thông báo lỗi giống nhau.
 */
export function describeAuthError(err) {
  switch (err?.code) {
    case "auth/wrong-password":
    case "auth/invalid-credential":
    case "auth/invalid-login-credentials":
      return "Mật khẩu không đúng.";
    case "auth/too-many-requests":
      return "Bạn đã thử quá nhiều lần. Vui lòng đợi vài phút rồi thử lại.";
    case "auth/weak-password":
      return "Mật khẩu mới quá yếu. Hãy dùng ít nhất 8 ký tự.";
    case "auth/network-request-failed":
      return "Lỗi kết nối mạng. Vui lòng thử lại.";
    case "auth/user-disabled":
      return "Tài khoản đã bị vô hiệu hoá hoặc đang được xoá.";
    case "auth/requires-recent-login":
      return "Phiên đăng nhập đã cũ. Vui lòng nhập lại mật khẩu.";
    default:
      return err?.message || "Đã có lỗi xảy ra, vui lòng thử lại.";
  }
}

/** Xác nhận lại mật khẩu của người đang đăng nhập. Ném Error có `message` tiếng Việt (và `code` của Firebase) nếu thất bại. */
export async function reauthWithPassword(password) {
  const user = auth.currentUser;
  if (!user || !user.email) {
    throw Object.assign(new Error("Bạn cần đăng nhập để thực hiện thao tác này."), { code: "app/no-user" });
  }
  if (!password) {
    throw Object.assign(new Error("Vui lòng nhập mật khẩu."), { code: "app/empty-password" });
  }
  try {
    await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, password));
    // Bảo đảm request kế tiếp mang token MỚI (auth_time mới) chứ không phải token cũ còn cache.
    await user.getIdToken(true);
  } catch (err) {
    throw Object.assign(new Error(describeAuthError(err)), { code: err?.code });
  }
}

/**
 * v2.5.3 [TW-09] — Backend đòi "vừa nhập lại mật khẩu" (middleware requireRecentAuth → 403 `REAUTH_REQUIRED`). Dùng chung cho mọi nơi
 * cần mở hộp mật khẩu rồi thử lại thao tác (xem hooks/useReauthRetry.jsx; panel "Gỡ lỗi" dùng bản tương đương ở settings/debugReport.js).
 */
export const isReauthRequired = (err) => err?.response?.data?.code === "REAUTH_REQUIRED";
