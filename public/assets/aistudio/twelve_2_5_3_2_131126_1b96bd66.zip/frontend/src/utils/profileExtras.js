/**
 * ==== v2.5.2 — "THÔNG TIN MỞ RỘNG" của hồ sơ (hộp "Xem thêm") — phía hiển thị ====
 *
 * Backend (backend/src/utils/profileExtras.js) là NGUỒN SỰ THẬT về danh sách khoá + mặc định + việc ẩn/hiện (áp dụng ở máy chủ: dữ liệu của mục đang tắt
 * không bao giờ tới người khác). File này chỉ lo: nhãn/mô tả tiếng Việt, mặc định để công tắc ở Cài đặt hiện đúng trạng thái khi chủ chưa từng chỉnh,
 * và cách định dạng giá trị. Test (tests/profileExtras252.test.jsx) kiểm hai bảng KHỚP nhau.
 *
 * THÊM MỤC MỚI: thêm khoá + mặc định ở backend, rồi thêm một mục vào EXTRA_FIELDS dưới đây (đúng thứ tự muốn hiển thị).
 *
 * `private: true` = mục ngày trước HOÀN TOÀN riêng tư (ngày sinh, giới tính) hoặc chủ đích không lộ (trạng thái, UID) — mặc định TẮT; công tắc ghi chú rõ
 * "chỉ lộ ra khi bạn bật". Các mục còn lại (`private: false`) là dữ liệu vốn đã hiện ở nơi khác của Twelve (bài viết, huy hiệu, bảng xếp hạng…), nên công tắc
 * của chúng chỉ quyết định có hiện TRONG hộp "Xem thêm" hay không.
 */
export const EXTRA_FIELDS = Object.freeze([
  { key: "displayName", label: "Tên hiển thị", defaultOn: true, private: false, hint: "Tên bạn đang dùng trên Twelve." },
  { key: "accountGroup", label: "Nhóm tài khoản", defaultOn: true, private: false, hint: "Nhóm của tài khoản (SA, RA hoặc LLA)." },
  { key: "accountRole", label: "Vai trò tài khoản", defaultOn: true, private: false, hint: "Vai trò của tài khoản, ví dụ Người dùng, Người dùng Pro, Quản trị viên." },
  { key: "birthday", label: "Ngày sinh", defaultOn: false, private: true, hint: "Chỉ lộ ra khi bạn bật." },
  { key: "createdAt", label: "Ngày tham gia", defaultOn: true, private: false, hint: "Ngày bạn tạo tài khoản Twelve." },
  { key: "gender", label: "Giới tính", defaultOn: false, private: true, hint: "Chỉ lộ ra khi bạn bật." },
  { key: "status", label: "Trạng thái tài khoản", defaultOn: false, private: true, hint: "Đang hoạt động, bị tạm khóa… Chỉ lộ ra khi bạn bật." },
  { key: "uid", label: "UID", defaultOn: false, private: true, hint: "Mã định danh tài khoản. Chỉ lộ ra khi bạn bật." },
  { key: "achievements", label: "Thành tích", defaultOn: true, private: false, hint: "Điểm tài khoản và các tuần bạn lọt top 10 người tăng điểm mạnh nhất ở trang Xu hướng." },
]);

export const EXTRA_DEFAULTS = Object.freeze(Object.fromEntries(EXTRA_FIELDS.map((f) => [f.key, f.defaultOn])));

/** Cờ ĐÃ PHÂN GIẢI (đủ mọi khoá, đều boolean) từ `profile.profileExtras` (có thể thiếu khoá/undefined). Giá trị không phải boolean → mặc định (khớp backend). */
export function resolveExtras(stored) {
  const src = stored && typeof stored === "object" && !Array.isArray(stored) ? stored : {};
  return Object.fromEntries(EXTRA_FIELDS.map((f) => [f.key, typeof src[f.key] === "boolean" ? src[f.key] : f.defaultOn]));
}

// Khớp backend GROUP_LABELS / ROLE_LABELS (test kiểm). Giá trị lạ → hiện nguyên mã.
export const GROUP_LABELS = Object.freeze({ SA: "Tài khoản cấp cao (SA)", RA: "Tài khoản thường (RA)", LLA: "Tài khoản thử nghiệm (LLA)" });
export const ROLE_LABELS = Object.freeze({
  admin: "Quản trị viên",
  dev: "Lập trình viên",
  moderator: "Điều hành viên",
  pro_user: "Người dùng Pro",
  user: "Người dùng",
  test: "Tài khoản thử nghiệm",
});
export const GENDER_LABELS = Object.freeze({ male: "Nam", female: "Nữ", other: "Khác" });
export const STATUS_LABELS = Object.freeze({ active: "Đang hoạt động", suspended: "Bị tạm khóa", pending: "Chờ kích hoạt", deleting: "Đang xóa" });

/** "YYYY-MM-DD" → "DD/MM/YYYY" bằng cắt chuỗi (KHÔNG qua Date: tránh lệch múi giờ làm ngày sinh nhảy sang hôm trước/sau). Không đúng dạng → trả nguyên. */
export function formatBirthday(value) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ""));
  return m ? `${m[3]}/${m[2]}/${m[1]}` : String(value || "");
}

/** ISO → "D/M/YYYY" theo giờ địa phương của người xem. Không hợp lệ → "". */
export function formatJoinDate(iso) {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "" : `${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
}

/** Giá trị HIỂN THỊ của một trường vô hướng trong hộp "Xem thêm". */
export function formatExtraValue(key, value) {
  switch (key) {
    case "accountGroup":
      return GROUP_LABELS[value] || String(value);
    case "accountRole":
      return ROLE_LABELS[value] || String(value);
    case "birthday":
      return formatBirthday(value);
    case "createdAt":
      return formatJoinDate(value);
    case "gender":
      return GENDER_LABELS[value] || String(value);
    case "status":
      return STATUS_LABELS[value] || String(value);
    default:
      return String(value);
  }
}

/** Các hàng { key, label, value } của hộp "Xem thêm" theo ĐÚNG thứ tự EXTRA_FIELDS; chỉ mục backend đã trả và có giá trị hiển thị được. `achievements` không nằm ở đây (khối riêng). */
export function buildExtraRows(fields) {
  const src = fields && typeof fields === "object" ? fields : {};
  return EXTRA_FIELDS.filter((f) => f.key !== "achievements" && src[f.key] != null && src[f.key] !== "")
    .map((f) => ({ key: f.key, label: f.label, value: formatExtraValue(f.key, src[f.key]) }))
    .filter((r) => r.value !== "");
}

/** Mã tuần như trang Xu hướng hiển thị: "Tuần N.K.MM.YYYY". */
export const formatWeekLabel = (weekCode) => `Tuần ${weekCode}`;
