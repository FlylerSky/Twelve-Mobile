import apiClient from "./client";

// v2.0.8 — font chữ server (#1.1). Công khai: ai cũng lấy được danh sách font do SA cài.
export const getPublicFonts = () => apiClient.get("/fonts").then((r) => r.data);

// Chỉ SA (backend chặn 403 nếu không phải SA).
export const getAdminFonts = () => apiClient.get("/admin/fonts").then((r) => r.data);
export const updateAdminFonts = (fonts) => apiClient.put("/admin/fonts", { fonts }).then((r) => r.data);
