import apiClient from "./client";

// v0.10.15 — tab "Quản trị" (Settings, chỉ SA). Backend tự chặn 403 nếu gọi
// mà không phải SA — không cần kiểm tra quyền ở đây, chỉ gọi API.
export const getEmbedDomains = () => apiClient.get("/admin/embed-domains").then((r) => r.data);

// v2.0.5 — quét lại bài cũ chạy nền ở backend; hỏi tiến độ/kết quả bằng API này.
export const getEmbedRescanStatus = () => apiClient.get("/admin/embed-domains/rescan").then((r) => r.data);

// v2.0.11 — báo cáo vi phạm CSP của SPA (G1): xem thống kê gom nhóm / bắt đầu lại cửa sổ quan sát.
export const getCspReports = () => apiClient.get("/admin/csp-reports").then((r) => r.data);
export const resetCspReports = () => apiClient.delete("/admin/csp-reports").then((r) => r.data);

export const updateEmbedDomains = ({ enabled, domains }) =>
  apiClient.put("/admin/embed-domains", { enabled, domains }).then((r) => r.data);

// v2.5.3.2 — đo nhận diện IP client (TW-01): backend mô tả chính request này (chỉ đọc, chỉ SA). Dùng ở Cài đặt → Quản trị → Nhận diện IP.
export const getIpTopology = () => apiClient.get("/admin/ip-topology").then((r) => r.data); // backend trả Cache-Control: no-store

// v0.10.21 — giám sát tài nguyên Cloudinary do người dùng upload (backend cache 60 giây;
// refresh=true để bỏ cache và lấy số liệu mới nhất).
export const getAssetStats = ({ refresh = false } = {}) =>
  apiClient.get("/admin/assets/stats", { params: refresh ? { refresh: 1 } : undefined }).then((r) => r.data);

// v2.3.0 — mục "Gỡ lỗi" (Cài đặt → Quản trị): hồi quy các lỗi bảo mật đã từng gặp.
// Chạy module đòi nhập lại mật khẩu gần đây (403 code REAUTH_REQUIRED nếu hết hạn) — panel tự mở hộp mật khẩu rồi chạy tiếp.
export const listDebugModules = () => apiClient.get("/admin/debug/modules").then((r) => r.data);
export const runDebugModule = (id) => apiClient.post(`/admin/debug/modules/${encodeURIComponent(id)}/run`).then((r) => r.data);
