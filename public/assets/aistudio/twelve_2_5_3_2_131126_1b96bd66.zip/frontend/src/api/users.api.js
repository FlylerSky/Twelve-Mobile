import apiClient from "./client";

export const getMe = () => apiClient.get("/users/me").then((r) => r.data.user);

export const getPublicProfile = (uid) => apiClient.get(`/users/${uid}`).then((r) => r.data.user);

// v2.4.2.1 — hồ sơ theo Tag Name Search (URL hồ sơ là /u/@<tag>). Nhận "abc" hay "@abc"; backend chuẩn hoá chữ thường.
export const getPublicProfileByTag = (tag) => apiClient.get(`/users/by-tag/${encodeURIComponent(tag)}`).then((r) => r.data.user);

export const updateMe = (data) => apiClient.patch("/users/me", data).then((r) => r.data);

export const uploadAvatar = (fileBlob) => {
  if (!fileBlob || !(fileBlob instanceof Blob) || fileBlob.size === 0) {
    return Promise.reject({ message: "Ảnh không hợp lệ hoặc rỗng. Vui lòng chọn lại." });
  }
  const formData = new FormData();
  formData.append("avatar", fileBlob, "avatar.jpg");
  // QUAN TRỌNG: không tự set header Content-Type. Khi gửi FormData,
  // trình duyệt/axios cần tự sinh "multipart/form-data; boundary=..." — nếu set
  // cứng "multipart/form-data" (thiếu boundary) thì multer không parse được file.
  return apiClient
    .post("/users/me/avatar", formData, {
      // Đảm bảo không bị interceptor hoặc default gắn Content-Type sai
      headers: { "Content-Type": undefined },
      // Timeout dài hơn vì upload ảnh có thể chậm trên mạng yếu
      timeout: 60000,
    })
    .then((r) => r.data);
};

// ==== v2.2.0 — Cài đặt > Tài khoản ====
// Tên thật: cả xem lẫn đổi đều bị backend chặn (403 REAUTH_REQUIRED) nếu người dùng chưa vừa nhập lại mật khẩu — gọi sau utils/reauth.reauthWithPassword.
export const getRealName = () => apiClient.get("/users/me/real-name").then((r) => r.data.fullName);

export const updateRealName = (fullName) => apiClient.put("/users/me/real-name", { fullName }).then((r) => r.data);

export const updateTagName = (tagName) => apiClient.put("/users/me/tag-name", { tagName }).then((r) => r.data);

// Backend trả 202 ngay; việc xoá chạy nền bền vững phía server (kể cả khi người dùng đóng trình duyệt).
export const requestAccountDeletion = () => apiClient.post("/users/me/deletion", { confirm: true }).then((r) => r.data);

// ==== v2.4.0 — Trang Profile ====
// Tab "Bài viết" (phân trang cursor như feed Trang chủ) và khu "Đã ghim" của Trang chủ hồ sơ.
export const listUserPosts = (uid, cursor, limit = 10) =>
  apiClient.get(`/users/${uid}/posts`, { params: { cursor, limit } }).then((r) => r.data);

export const listPinnedPosts = (uid) => apiClient.get(`/users/${uid}/pinned`).then((r) => r.data.posts || []);

// Ảnh bìa (v2.4.1: lưu NGUYÊN ảnh + KHUNG hiển thị `crop` = { x, y, width, height } theo % ảnh gốc, nên chỉnh lại được không cần tải lại ảnh):
//   tải lên (blob đã thu nhỏ) · dán URL ngoài · chỉnh khung · gỡ.
export const uploadCover = (fileBlob, crop) => {
  if (!fileBlob || !(fileBlob instanceof Blob) || fileBlob.size === 0) {
    return Promise.reject({ message: "Ảnh không hợp lệ hoặc rỗng. Vui lòng chọn lại." });
  }
  const formData = new FormData();
  formData.append("cover", fileBlob, "cover.jpg");
  if (crop) formData.append("crop", JSON.stringify(crop));
  // Như uploadAvatar: KHÔNG tự set Content-Type (cần boundary do trình duyệt sinh).
  return apiClient.post("/users/me/cover", formData, { headers: { "Content-Type": undefined }, timeout: 60000 }).then((r) => r.data);
};

export const setCoverUrl = (url, crop) => apiClient.put("/users/me/cover", crop ? { url, crop } : { url }).then((r) => r.data);

export const setCoverCrop = (crop) => apiClient.put("/users/me/cover/crop", { crop }).then((r) => r.data);

export const removeCover = () => apiClient.delete("/users/me/cover").then((r) => r.data);

// ==== v2.5.2 — Hoàn thiện trang Profile ====
// Tab "Blog" của hồ sơ (bài Blog đã xuất bản của người này; phân trang cursor như listUserPosts).
export const listUserBlogs = (uid, cursor, limit = 10) =>
  apiClient.get(`/users/${uid}/blogs`, { params: { cursor, limit } }).then((r) => r.data);

// Hộp "Xem thêm": { fields, achievements } — backend CHỈ trả các mục chủ hồ sơ đang bật (mục tắt không bao giờ tới trình duyệt người khác).
export const getProfileExtraInfo = (uid) => apiClient.get(`/users/${uid}/extra-info`).then((r) => r.data);

// Bật/tắt mục thông tin mở rộng của CHÍNH MÌNH: { khoá: boolean } (gửi riêng khoá vừa đổi). Trả cờ đã phân giải đủ mọi khoá.
export const updateProfileExtras = (extras) => apiClient.put("/users/me/extras", { extras }).then((r) => r.data.profileExtras);

// Ghi nhận mình vừa ghé hồ sơ `uid` (fire-and-forget; backend bỏ qua nếu là hồ sơ của chính mình).
export const recordProfileVisit = (uid) => apiClient.post(`/users/${uid}/visit`).then((r) => r.data);

// Khách ghé thăm hồ sơ CỦA MÌNH: { visitors: [{...hồ sơ công khai, visitedAt}], max } — mới nhất trước.
export const listMyVisitors = () => apiClient.get("/users/me/visitors").then((r) => r.data);
