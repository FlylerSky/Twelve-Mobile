import React, { createContext, useCallback, useContext, useMemo, useState } from "react";

/**
 * ==== Module 1.0 — Smart Page Header ====
 * Mỗi trang đăng ký { title, isBrand, actions[] } vào context.
 * Navbar đọc config để hiển thị tên trang + nút chức năng trên AppBar.
 * Unmount trang → clear (tránh “dính” action của trang trước).
 *
 * action: { key, label, icon, onClick, disabled?, color? }
 *
 * ==== v2.4.2 — nút Back DUY NHẤT nằm ở headZone; trang khai báo "lên đâu" thay vì tự vẽ nút back ====
 *   backTo?: string          — đường dẫn trang CHA (vd. Cài đặt › mục con → mục cha). Back đi lên đó mà không sinh mục lịch sử mới.
 *   onBack?: () => boolean   — trang tự xử lý trạng thái nội bộ trước (vd. đang xem chi tiết hashtag → về danh sách); trả true = đã xử lý.
 * Không khai báo gì: Back lùi lịch sử như trước (vào thẳng thì về Trang chủ). Chi tiết: hooks/useBack.js, utils/navStack.js.
 */

const DEFAULT = {
  title: "Twelve",
  isBrand: true,
  actions: [],
  backTo: null,
  onBack: null,
};

const PageHeaderContext = createContext(null);

export function PageHeaderProvider({ children }) {
  const [config, setConfig] = useState(DEFAULT);

  const setPageHeader = useCallback((next) => {
    setConfig({
      title: next?.title ?? "Twelve",
      isBrand: next?.isBrand === true,
      actions: Array.isArray(next?.actions) ? next.actions : [],
      backTo: typeof next?.backTo === "string" && next.backTo ? next.backTo : null,
      onBack: typeof next?.onBack === "function" ? next.onBack : null,
    });
  }, []);

  const resetPageHeader = useCallback(() => {
    setConfig(DEFAULT);
  }, []);

  const value = useMemo(
    () => ({ config, setPageHeader, resetPageHeader }),
    [config, setPageHeader, resetPageHeader]
  );

  return <PageHeaderContext.Provider value={value}>{children}</PageHeaderContext.Provider>;
}

export function usePageHeader() {
  const ctx = useContext(PageHeaderContext);
  if (!ctx) throw new Error("usePageHeader phải dùng trong PageHeaderProvider.");
  return ctx;
}

/**
 * Đăng ký header khi mount, clear khi unmount.
 * pages gọi: useRegisterPageHeader({ title, isBrand, actions })
 */
export function useRegisterPageHeader({ title, isBrand = false, actions = [], backTo = null, onBack = null }) {
  const { setPageHeader, resetPageHeader } = usePageHeader();

  // ==== v2.0.13 [SỬA LỖI] Vòng lặp render vô hạn ====
  // Trước đây `actions` (mảng MỚI ở mỗi lần render, vd. `actions: []`) nằm trong deps của useEffect => effect chạy lại ở
  // MỌI lần render => setPageHeader => PageHeaderProvider render lại => trang (là consumer) render lại => lặp mãi (~hàng trăm
  // lần/giây). Vòng lặp này làm "đói" lượt render ưu tiên thấp của React (retry của Suspense) nên modal soạn bài (tải lười từ
  // v2.0.11) không bao giờ hiện cho tới khi đổi trang. Nay effect chỉ phụ thuộc `actionsKey` (nội dung hiển thị của actions);
  // `onClick` luôn gọi bản MỚI NHẤT qua ref nên không bị closure cũ.
  const actionsRef = React.useRef(actions);
  actionsRef.current = actions;
  const actionsKey = actions.map((a) => [a?.key, a?.label, a?.disabled ? 1 : 0, a?.color].join("~")).join("|");

  // v2.4.2: onBack cũng gọi bản MỚI NHẤT qua ref (đóng gói state của trang, đổi mỗi lần render) nên không đưa vào deps; chỉ có/không có mới đáng kể.
  const onBackRef = React.useRef(onBack);
  onBackRef.current = onBack;
  const hasOnBack = typeof onBack === "function";

  React.useEffect(() => {
    const stable = actionsRef.current.map((a) => ({
      ...a,
      onClick: (...args) => actionsRef.current.find((x) => x?.key === a.key)?.onClick?.(...args),
    }));
    setPageHeader({
      title,
      isBrand,
      actions: stable,
      backTo,
      onBack: hasOnBack ? (...args) => onBackRef.current?.(...args) : null,
    });
    return () => resetPageHeader();
  }, [title, isBrand, actionsKey, backTo, hasOnBack, setPageHeader, resetPageHeader]);
}
