import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { ThemeProvider, CssBaseline } from "@mui/material";
import { createAppTheme } from "../theme/theme";
import {
  DEFAULT_FONT_ID,
  findFont,
  resolveFont,
  ensureFont,
  getAllFonts,
  fontFromServerEntry,
  readServerFontsCache,
  writeServerFontsCache,
  readCustomFonts,
  writeCustomFonts,
  validateCustomFontInput,
  buildCustomFont,
  verifyFontLoads,
} from "../theme/fonts";
import { getPublicFonts } from "../api/fonts.api";
import apiClient from "../api/client";

/**
 * ==== v0.9.0 — Settings > Ứng dụng > Chế độ giao diện ====
 * Quản lý lựa chọn Chế độ giao diện của người dùng: "light" | "dark" | "system".
 *
 * - `mode`: lựa chọn NGƯỜI DÙNG đã chọn (kể cả "system") — hiển thị đúng trên
 *   UI Settings (radio nào đang được chọn).
 * - `resolvedMode`: giá trị THỰC TẾ đang áp dụng ("light" hoặc "dark") — khi
 *   `mode === "system"`, giá trị này theo `prefers-color-scheme` của trình
 *   duyệt/hệ điều hành và tự cập nhật real-time nếu người dùng đổi chế độ hệ
 *   thống trong lúc đang mở Twelve (không cần tải lại trang).
 *
 * Lưu lựa chọn vào localStorage — CHỈ áp dụng trên thiết bị/trình duyệt này
 * (chưa đồng bộ qua tài khoản/Firestore ở bản v0.9.0 này, có thể bổ sung sau
 * nếu cần đồng bộ đa thiết bị).
 */

const STORAGE_KEY = "twelve_theme_mode";
const VALID_MODES = ["light", "dark", "system"];

// ==== v2.0.7 — Font chữ ====
// Lưu id font trong localStorage (CHỈ áp dụng trên thiết bị/trình duyệt này, giống chế độ giao diện).
const FONT_STORAGE_KEY = "twelve_font_id";

// Id lưu có thể thuộc font server/tuỳ chỉnh (chưa nạp xong ở lần render đầu) nên KHÔNG kiểm tra ở đây —
// `resolveFont(fontId, danhSách)` bên dưới tự rơi về font mặc định nếu id không còn tồn tại.
function readStoredFontId() {
  try {
    return localStorage.getItem(FONT_STORAGE_KEY) || DEFAULT_FONT_ID;
  } catch {
    return DEFAULT_FONT_ID;
  }
}

const apiBase = () => String(apiClient.defaults.baseURL || "");

function readStoredMode() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return VALID_MODES.includes(raw) ? raw : "system";
  } catch {
    // localStorage có thể bị chặn (chế độ ẩn danh nghiêm ngặt, cookie bị tắt...)
    return "system";
  }
}

function getSystemPrefersDark() {
  return typeof window !== "undefined" && window.matchMedia
    ? window.matchMedia("(prefers-color-scheme: dark)").matches
    : false;
}

const ThemeModeContext = createContext(null);

export function ThemeModeProvider({ children }) {
  const [mode, setModeState] = useState(readStoredMode);
  const [systemPrefersDark, setSystemPrefersDark] = useState(getSystemPrefersDark);

  // Lắng nghe thay đổi chế độ SÁNG/TỐI của hệ điều hành/trình duyệt real-time
  // — chỉ cần thiết khi mode = "system", nhưng đăng ký sẵn không tốn kém, để
  // sẵn sàng ngay khi người dùng chuyển sang "system" mà không cần thêm logic.
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return undefined;
    const mql = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = (e) => setSystemPrefersDark(e.matches);
    // Safari cũ dùng addListener/removeListener thay vì addEventListener
    if (mql.addEventListener) mql.addEventListener("change", handler);
    else mql.addListener(handler);
    return () => {
      if (mql.removeEventListener) mql.removeEventListener("change", handler);
      else mql.removeListener(handler);
    };
  }, []);

  // ---- Font chữ (v2.0.7) ----
  const [fontId, setFontIdState] = useState(readStoredFontId);
  const [fontLoading, setFontLoading] = useState(false);
  // v2.0.8: #1.1 font server (cache localStorage để dùng ngay từ khung hình đầu, rồi làm mới từ API)
  //         và #2 font tuỳ chỉnh (chỉ lưu trên thiết bị này).
  const [serverFonts, setServerFonts] = useState(() => readServerFontsCache(apiBase()));
  const [customFonts, setCustomFonts] = useState(readCustomFonts);
  const fonts = useMemo(() => getAllFonts(serverFonts, customFonts), [serverFonts, customFonts]);
  const font = useMemo(() => resolveFont(fontId, fonts), [fontId, fonts]);

  // Làm mới danh sách font server. Lỗi mạng => GIỮ NGUYÊN danh sách đang có (không tự đổi font);
  // chỉ khi API trả về thành công mà thiếu font đang chọn thì font đó mới bị coi là đã gỡ (resolveFont → mặc định).
  // v2.0.9 [SỬA LỖI]: trước đây chỉ gọi MỘT LẦN lúc mở app nên SA lưu font mới xong, mục Ứng dụng vẫn không hiện
  // tới khi tải lại trang. Nay có thể gọi lại (mở Cài đặt, sau khi SA lưu) và theo dõi trạng thái để báo lỗi rõ ràng.
  const [serverFontsStatus, setServerFontsStatus] = useState("loading"); // loading | ok | error
  const [serverFontsError, setServerFontsError] = useState("");
  const refreshServerFonts = useCallback(() => {
    return getPublicFonts()
      .then((data) => {
        if (!data || !Array.isArray(data.fonts)) throw new Error("Phản hồi danh sách font không hợp lệ.");
        writeServerFontsCache(data.fonts);
        setServerFonts(data.fonts.map((e) => fontFromServerEntry(e, apiBase())).filter(Boolean));
        setServerFontsStatus("ok");
        setServerFontsError("");
      })
      .catch((err) => {
        setServerFontsStatus("error");
        setServerFontsError((err && err.message) || "Không tải được danh sách font từ máy chủ.");
      });
  }, []);
  useEffect(() => {
    refreshServerFonts();
  }, [refreshServerFonts]);

  // Tải file font khi đang dùng font đó. Trong lúc tải, trình duyệt hiển thị font dự phòng (font-display: swap)
  // rồi tự đổi sang font mới khi tải xong — giao diện không bị chặn.
  useEffect(() => {
    let cancelled = false;
    setFontLoading(true);
    ensureFont(font).finally(() => {
      if (!cancelled) setFontLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [font]);

  const setFontId = (next) => {
    if (!findFont(next, fonts)) return;
    setFontIdState(next);
    try {
      localStorage.setItem(FONT_STORAGE_KEY, next);
    } catch {
      // Không lưu được: lựa chọn vẫn có hiệu lực trong phiên hiện tại.
    }
  };

  /** #2 — thêm font tuỳ chỉnh từ URL: kiểm tra link, thử tải thật, rồi mới lưu. Ném Error (tiếng Việt) nếu lỗi. */
  const addCustomFont = async (input) => {
    const v = validateCustomFontInput(input, customFonts);
    if (v.error) throw new Error(v.error);
    const created = buildCustomFont(v);
    await verifyFontLoads(created);
    const next = [...customFonts, created];
    setCustomFonts(next);
    writeCustomFonts(next);
    return created;
  };

  const removeCustomFont = (id) => {
    const next = customFonts.filter((f) => f.id !== id);
    setCustomFonts(next);
    writeCustomFonts(next);
    if (fontId === id) {
      setFontIdState(DEFAULT_FONT_ID);
      try {
        localStorage.setItem(FONT_STORAGE_KEY, DEFAULT_FONT_ID);
      } catch {
        /* bỏ qua */
      }
    }
  };

  const setMode = (next) => {
    if (!VALID_MODES.includes(next)) return;
    setModeState(next);
    try {
      localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // Bỏ qua nếu không lưu được — lựa chọn vẫn có hiệu lực trong phiên hiện
      // tại (state React), chỉ không nhớ được sau khi tải lại trang.
    }
  };

  const resolvedMode = mode === "system" ? (systemPrefersDark ? "dark" : "light") : mode;

  // Đồng bộ màu thanh trạng thái + nền html/body để tránh “vệt” màu chế độ
  // cũ ở mép dưới khi đổi light↔dark (overscroll / safe-area trên mobile).
  useEffect(() => {
    const color = resolvedMode === "dark" ? "#141218" : "#FFFBFE";
    let meta = document.querySelector('meta[name="theme-color"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "theme-color");
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", color);
    document.documentElement.style.backgroundColor = color;
    document.documentElement.style.colorScheme = resolvedMode === "dark" ? "dark" : "light";
    if (document.body) document.body.style.backgroundColor = color;
    const root = document.getElementById("root");
    if (root) root.style.backgroundColor = color;
  }, [resolvedMode]);

  const theme = useMemo(() => createAppTheme(resolvedMode, font.stack), [resolvedMode, font.stack]);

  const value = useMemo(
    () => ({
      mode, resolvedMode, setMode, fontId: font.id, setFontId, fontLoading, fonts, addCustomFont, removeCustomFont,
      refreshServerFonts, serverFontsStatus, serverFontsError,
    }),
    [mode, resolvedMode, font, fontLoading, fonts, customFonts, refreshServerFonts, serverFontsStatus, serverFontsError]
  );

  return (
    <ThemeModeContext.Provider value={value}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        {children}
      </ThemeProvider>
    </ThemeModeContext.Provider>
  );
}

export function useThemeMode() {
  const ctx = useContext(ThemeModeContext);
  if (!ctx) throw new Error("useThemeMode phải được gọi bên trong ThemeModeProvider.");
  return ctx;
}
