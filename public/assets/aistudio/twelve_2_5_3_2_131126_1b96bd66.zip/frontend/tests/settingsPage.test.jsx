// v2.1.0: trang Cài đặt dạng "thư mục" — bấm vào mở ra, mục lá hiện luôn nội dung, quay lại/đường dẫn, quyền SA, tải lười.
// Chạy: npx vitest run tests/settingsPage.test.jsx
import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor, within } from "@testing-library/react";
import { MemoryRouter, Routes, Route, Link, useLocation } from "react-router-dom";

// Ghi lại panel nào đã được dựng — để kiểm "chỉ panel đang mở mới được tải/gọi API".
// Ghi nhận theo lúc MOUNT (không phải số lần render) — để phân biệt "dựng lại từ đầu" với "chỉ render lại".
const { mounts, panel } = vi.hoisted(() => {
  const mounts = [];
  const panel = (id, label) => async () => {
    const R = await import("react");
    return {
      default: ({ source } = {}) => {
        R.useEffect(() => { mounts.push(source ? `${id}:${source}` : id); }, []);
        return R.createElement("div", null, source ? `${label}:${source}` : label);
      },
    };
  };
  return { mounts, panel };
});

vi.mock("../src/components/Navbar", () => ({ default: () => <nav>NAVBAR</nav> }));
let authState;
vi.mock("../src/context/AuthContext", () => ({ useAuth: () => authState }));

vi.mock("../src/pages/settings/ThemeModePanel", panel("theme", "THEME-PANEL"));
vi.mock("../src/pages/settings/FontGroupPanel", panel("font", "FONT-PANEL"));
vi.mock("../src/pages/settings/AdminEmbedDomainsPanel", panel("embed", "EMBED-PANEL"));
vi.mock("../src/pages/settings/AdminFontsPanel", panel("admin-fonts", "ADMIN-FONTS-PANEL"));
vi.mock("../src/pages/settings/AdminCspReportsPanel", panel("csp", "CSP-PANEL"));
vi.mock("../src/pages/settings/AdminAssetsPanel", panel("assets", "ASSETS-PANEL"));
vi.mock("../src/pages/settings/AdminDebugPanel", panel("debug", "DEBUG-PANEL"));
vi.mock("../src/pages/settings/AccountInfoPanel", panel("account-info", "ACCOUNT-INFO-PANEL"));
vi.mock("../src/pages/settings/ChangePasswordPanel", panel("change-password", "CHANGE-PASSWORD-PANEL"));
vi.mock("../src/pages/settings/DeleteAccountPanel", panel("delete-account", "DELETE-ACCOUNT-PANEL"));

import SettingsPage from "../src/pages/SettingsPage";
import { PageHeaderProvider, usePageHeader } from "../src/context/PageHeaderContext";
import { useHeaderBack } from "../src/hooks/useBack";
import NavStackTracker from "../src/components/NavStackTracker";
import { resetNavStack } from "../src/utils/navStack";
import { FONT_SOURCE_LABELS } from "../src/theme/fonts";

const user = (extra = {}) => ({ isSA: false, isLoggedIn: false, isAuthReady: true, loadingProfile: false, firebaseUser: { uid: "u1" }, profile: { uid: "u1" }, profileError: null, ...extra });
const sa = () => user({ isSA: true });

function Loc() {
  return <div data-testid="loc">{useLocation().pathname}</div>;
}
// v2.4.2: nút Back DUY NHẤT nằm ở headZone (Navbar). Navbar bị mock ở đây nên dựng lại đúng cách Navbar dùng: useHeaderBack(config của trang).
function HeadZoneBack() {
  const { config } = usePageHeader();
  const back = useHeaderBack(config);
  return <button onClick={back}>HEADZONE-BACK</button>;
}
const headBack = () => fireEvent.click(screen.getByText("HEADZONE-BACK"));
// Cùng khai báo route như App.jsx
function at(path, entries = [path], index = entries.length - 1) {
  return render(
    <PageHeaderProvider>
      <MemoryRouter initialEntries={entries} initialIndex={index}>
        <NavStackTracker />
        <HeadZoneBack />
        <Routes>
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/settings/:tab/*" element={<SettingsPage />} />
        </Routes>
        <Loc />
        {/* Liên kết ngoài trang Cài đặt — để thử chuyển THẲNG từ mục lá này sang mục lá khác */}
        <Link to="/settings/app/font/server">GO-SERVER</Link>
      </MemoryRouter>
    </PageHeaderProvider>
  );
}
const loc = () => screen.getByTestId("loc").textContent;

beforeEach(() => {
  resetNavStack();
  mounts.length = 0;
  authState = user();
  window.scrollTo = vi.fn();
});
afterEach(() => cleanup());

describe("gốc tab: chỉ hiện TÊN các mục", () => {
  it("Ứng dụng: 'Chế độ giao diện' và 'Font chữ' — không lộ nội dung, không có nút quay lại trong trang, không có tab Quản trị", () => {
    at("/settings");
    expect(screen.getByText("Chế độ giao diện")).toBeTruthy();
    expect(screen.getByText("Font chữ")).toBeTruthy();
    expect(screen.queryByText("THEME-PANEL")).toBeNull();
    expect(screen.queryByLabelText("Quay lại")).toBeNull();
    expect(screen.queryByRole("tab", { name: "Quản trị" })).toBeNull();
    expect(mounts).toEqual([]); // chưa tải panel nào
  });

  it("đường dẫn cũ /settings/app vẫn dùng được", () => {
    at("/settings/app");
    expect(screen.getByText("Font chữ")).toBeTruthy();
  });
});

describe("mục lá (một tuỳ chọn duy nhất) mở ra là thấy luôn nội dung", () => {
  it("bấm 'Chế độ giao diện' → nội dung hiện luôn, URL đổi, Back ở headZone về gốc tab (KHÔNG có nút quay lại trong trang)", async () => {
    at("/settings");
    fireEvent.click(screen.getByText("Chế độ giao diện"));
    expect(await screen.findByText("THEME-PANEL")).toBeTruthy();
    expect(loc()).toBe("/settings/app/theme");
    expect(screen.getByLabelText("Đường dẫn mục cài đặt").textContent).toContain("Chế độ giao diện");
    expect(screen.queryByLabelText("Quay lại")).toBeNull(); // v2.4.2: nút ← trong trang đã bỏ — chỉ còn Back ở headZone

    headBack();
    await waitFor(() => expect(loc()).toBe("/settings/app"));
    expect(screen.queryByText("THEME-PANEL")).toBeNull();
    expect(screen.getByText("Font chữ")).toBeTruthy();
  });
});

describe("thư mục (nhiều tuỳ chọn) mở ra thành danh sách mục con", () => {
  it("'Font chữ' → 3 mục; bấm một mục mới thấy nội dung; đường dẫn và Back ở headZone hoạt động", async () => {
    at("/settings");
    fireEvent.click(screen.getByText("Font chữ"));
    await waitFor(() => expect(loc()).toBe("/settings/app/font"));
    // 3 mục, đúng tên, và CHƯA có nội dung font nào
    expect(screen.getByText(FONT_SOURCE_LABELS.client)).toBeTruthy();
    expect(screen.getByText(FONT_SOURCE_LABELS.server)).toBeTruthy();
    expect(screen.getByText(FONT_SOURCE_LABELS.custom)).toBeTruthy();
    expect(screen.queryByText(/FONT-PANEL/)).toBeNull();
    expect(mounts).toEqual([]);

    fireEvent.click(screen.getByText(FONT_SOURCE_LABELS.custom));
    expect(await screen.findByText("FONT-PANEL:custom")).toBeTruthy();
    expect(loc()).toBe("/settings/app/font/custom");
    expect(mounts).toEqual(["font:custom"]); // chỉ nhóm đang mở được dựng

    // đường dẫn: "Font chữ" (bấm được) › "Font chữ tuỳ chỉnh" (mục hiện tại)
    const crumbs = screen.getByLabelText("Đường dẫn mục cài đặt");
    fireEvent.click(within(crumbs).getByText("Font chữ"));
    await waitFor(() => expect(loc()).toBe("/settings/app/font"));
    expect(screen.getByText(FONT_SOURCE_LABELS.server)).toBeTruthy();

    // Back ở headZone từ thư mục → gốc tab
    headBack();
    await waitFor(() => expect(loc()).toBe("/settings/app"));
  });

  it("mở thẳng bằng URL sâu: /settings/app/font/server → hiện đúng nhóm; Back ở headZone lên đúng MỘT cấp", async () => {
    at("/settings/app/font/server");
    expect(await screen.findByText("FONT-PANEL:server")).toBeTruthy();
    headBack();
    await waitFor(() => expect(loc()).toBe("/settings/app/font"));
  });

  it("chuyển THẲNG giữa 2 mục lá dùng CHUNG một component thì dựng lại từ đầu (không dính trạng thái mục kia)", async () => {
    at("/settings/app/font/client");
    expect(await screen.findByText("FONT-PANEL:client")).toBeTruthy();
    fireEvent.click(screen.getByText("GO-SERVER"));
    expect(await screen.findByText("FONT-PANEL:server")).toBeTruthy();
    expect(screen.queryByText("FONT-PANEL:client")).toBeNull();
    expect(mounts).toEqual(["font:client", "font:server"]); // không có `key` thì chỉ mount 1 lần
  });
});

describe("tab", () => {
  it("bấm lại tab đang mở khi đang ở sâu → về gốc tab", async () => {
    at("/settings/app/font/custom");
    await screen.findByText("FONT-PANEL:custom");
    fireEvent.click(screen.getByRole("tab", { name: "Ứng dụng" }));
    await waitFor(() => expect(loc()).toBe("/settings/app"));
    expect(screen.getByText("Chế độ giao diện")).toBeTruthy();
  });

  it("đổi mục thì cuộn về đầu trang", async () => {
    at("/settings");
    window.scrollTo.mockClear();
    fireEvent.click(screen.getByText("Chế độ giao diện"));
    await screen.findByText("THEME-PANEL");
    expect(window.scrollTo).toHaveBeenCalledWith(0, 0);
  });
});

describe("tab Quản trị (SA)", () => {
  it("SA thấy 2 tab; Quản trị liệt kê 5 mục chỉ bằng tên và KHÔNG gọi/tải panel nào cho tới khi bấm", async () => {
    authState = sa();
    at("/settings");
    fireEvent.click(screen.getByRole("tab", { name: "Quản trị" }));
    await waitFor(() => expect(loc()).toBe("/settings/admin"));
    ["Domain nhúng media", "Font chữ trên server", "Báo cáo vi phạm CSP", "Tài nguyên người dùng upload", "Gỡ lỗi"].forEach((t) =>
      expect(screen.getByText(t)).toBeTruthy()
    );
    expect(mounts).toEqual([]); // trước v2.1.0 cả các panel gọi API cùng lúc ngay khi mở tab

    fireEvent.click(screen.getByText("Domain nhúng media"));
    expect(await screen.findByText("EMBED-PANEL")).toBeTruthy();
    expect(mounts).toEqual(["embed"]);
  });

  it("đường dẫn cũ /settings/admin hoạt động cho SA", () => {
    authState = sa();
    at("/settings/admin");
    expect(screen.getByText("Báo cáo vi phạm CSP")).toBeTruthy();
  });

  it("người thường gõ thẳng URL Quản trị → thông báo không có quyền, KHÔNG tải panel", () => {
    at("/settings/admin/fonts");
    expect(screen.getByText(/không tồn tại hoặc bạn không có quyền xem/)).toBeTruthy();
    expect(screen.queryByText("ADMIN-FONTS-PANEL")).toBeNull();
    expect(mounts).toEqual([]);
  });

  it("hồ sơ chưa tải xong: chờ (không báo nhầm 'không có quyền' cho SA tải lại trang ở URL Quản trị)", async () => {
    authState = user({ isAuthReady: false, firebaseUser: undefined, profile: null });
    const { unmount } = at("/settings/admin/fonts");
    expect(screen.queryByText(/không có quyền xem/)).toBeNull();
    expect(screen.getByLabelText("Đang tải")).toBeTruthy();
    unmount();

    authState = sa();
    at("/settings/admin/fonts");
    expect(await screen.findByText("ADMIN-FONTS-PANEL")).toBeTruthy();
  });
});

describe("đường dẫn không tồn tại", () => {
  it("báo rõ và có nút về gốc tab", () => {
    at("/settings/app/khong-co-muc-nay");
    expect(screen.getByText(/không tồn tại hoặc bạn không có quyền xem/)).toBeTruthy();
    expect(screen.getByText("Về Cài đặt").closest("a").getAttribute("href")).toBe("/settings/app");
  });
});


// ---------------------------------------------------------------- v2.2.0 — tab Tài khoản
describe("v2.2.0: tab Tài khoản", () => {
  const member = () => user({ isLoggedIn: true });

  beforeEach(() => { mounts.length = 0; });
  afterEach(() => cleanup());

  it("khách KHÔNG thấy tab Tài khoản và vào thẳng /settings/account bị từ chối", async () => {
    authState = user();
    at("/settings");
    await screen.findByText("Chế độ giao diện");
    expect(screen.queryByRole("tab", { name: /Tài khoản/ })).toBeNull();
    cleanup();
    at("/settings/account/security/delete");
    await screen.findByText(/không tồn tại hoặc bạn không có quyền xem/i);
    expect(mounts).not.toContain("delete-account");
  });

  it("người đã đăng nhập thấy tab Tài khoản; gốc tab chỉ hiện TÊN 2 mục (Thông tin, Bảo mật), chưa tải nội dung", async () => {
    authState = member();
    at("/settings/account");
    await screen.findByText("Thông tin");
    expect(screen.getByText("Bảo mật")).toBeTruthy();
    expect(screen.getByRole("tab", { name: /Tài khoản/ })).toBeTruthy();
    expect(mounts).toEqual([]);
  });

  it("Thông tin mở thẳng nội dung; Bảo mật là thư mục chứa Đổi mật khẩu và Xóa tài khoản — mỗi mục chỉ tải khi mở", async () => {
    authState = member();
    at("/settings/account/info");
    await screen.findByText("ACCOUNT-INFO-PANEL");
    expect(mounts).toEqual(["account-info"]);
    cleanup();
    mounts.length = 0;

    at("/settings/account/security");
    await screen.findByText("Đổi mật khẩu");
    expect(screen.getByText("Xóa tài khoản")).toBeTruthy();
    expect(mounts).toEqual([]);
    cleanup();

    at("/settings/account/security/password");
    await screen.findByText("CHANGE-PASSWORD-PANEL");
    cleanup();
    at("/settings/account/security/delete");
    await screen.findByText("DELETE-ACCOUNT-PANEL");
    expect(mounts).toEqual(["change-password", "delete-account"]);
  });
});
