import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, cleanup, waitFor } from "@testing-library/react";
import { existsSync, readFileSync } from "node:fs";
import { assessContent, CONTENT_LIMITS } from "../src/utils/contentLimits";

const snack = { success: vi.fn(), error: vi.fn(), warning: vi.fn(), info: vi.fn() };
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => snack }));
vi.mock("../src/context/AuthContext", () => ({ useAuth: () => ({ refreshProfile: vi.fn() }) }));
// Quill không chạy được trong jsdom và không phải đối tượng kiểm thử ở đây: thay bằng textarea.
vi.mock("../src/components/QuillEditor", () => ({
  default: ({ value, onChange }) => <textarea aria-label="noi-dung" value={value} onChange={(e) => onChange(e.target.value)} />,
}));
import CreatePostModal from "../src/components/CreatePostModal";

afterEach(() => cleanup());
beforeEach(() => Object.values(snack).forEach((f) => f.mockClear()));

describe("hằng số khớp backend (không để lệch khi một bên đổi)", () => {
  const file = "../backend/src/utils/constants.js";
  it.skipIf(!existsSync(file))("CONTENT_LIMITS frontend = backend", () => {
    const src = readFileSync(file, "utf8");
    const num = (name) => Number(new RegExp(`${name}:\\s*(\\d+)`).exec(src)[1]);
    expect(CONTENT_LIMITS.HTML_MAX_CHARS).toBe(num("HTML_MAX_CHARS"));
    expect(CONTENT_LIMITS.HTML_MAX_ELEMENTS).toBe(num("HTML_MAX_ELEMENTS"));
    expect(CONTENT_LIMITS.HTML_MAX_MEDIA).toBe(num("HTML_MAX_MEDIA"));
  });
});

describe("assessContent", () => {
  it("nội dung bình thường: ok, không cảnh báo", () => {
    const r = assessContent("<p>Xin chào <strong>bạn</strong></p>");
    expect(r).toMatchObject({ severity: "ok", message: "", elements: 2, media: 0 });
  });
  it("cảnh báo từ 80%, lỗi khi vượt", () => {
    expect(assessContent("<p>" + "a".repeat(210000) + "</p>").severity).toBe("warn");
    const over = assessContent("<p>" + "a".repeat(250001) + "</p>");
    expect(over.severity).toBe("error");
    expect(over.message).toMatch(/quá dài/);
  });
  it("đếm phần tử và media", () => {
    expect(assessContent("<p>a</p>".repeat(5001)).message).toMatch(/quá nhiều thành phần/);
    const media = assessContent('<img src="https://x.example/a.png">'.repeat(201));
    expect(media.media).toBe(201);
    expect(media.message).toMatch(/ảnh\/video/);
  });
  it("đầu vào không phải chuỗi không làm hỏng", () => {
    expect(assessContent(undefined).severity).toBe("ok");
    expect(assessContent(null).chars).toBe(0);
  });
});

describe("CreatePostModal (G5 + lỗi từ backend hiển thị đúng)", () => {
  const setup = (api) => render(<CreatePostModal open onClose={() => {}} api={api} onCreated={() => {}} />);
  const fill = (html) => {
    fireEvent.change(screen.getByLabelText("Tiêu đề bài viết"), { target: { value: "Tiêu đề hợp lệ" } });
    fireEvent.change(screen.getByLabelText("noi-dung"), { target: { value: html } });
  };

  it("nội dung vượt giới hạn: hiện cảnh báo, khoá nút Đăng, KHÔNG gọi API", async () => {
    const api = { create: vi.fn() };
    setup(api);
    fill("<p>" + "a".repeat(250001) + "</p>");
    expect(screen.getByRole("alert").textContent).toMatch(/quá dài/);
    const btn = screen.getByText("Đăng bài").closest("button");
    expect(btn.disabled).toBe(true);
    fireEvent.click(btn);
    expect(api.create).not.toHaveBeenCalled();
  });

  it("nội dung hợp lệ: gọi API và báo thành công", async () => {
    const api = { create: vi.fn().mockResolvedValue({ postId: "p1" }) };
    setup(api);
    fill("<p>Nội dung bình thường</p>");
    fireEvent.click(screen.getByText("Đăng bài"));
    await waitFor(() => expect(api.create).toHaveBeenCalled());
    expect(snack.success).toHaveBeenCalled();
  });

  it("backend từ chối (422) => hiện NGUYÊN thông báo tiếng Việt của backend, không phải lỗi chung chung", async () => {
    const msg = "Nội dung quá phức tạp để xử lý. Hãy rút gọn hoặc bỏ bớt định dạng.";
    const api = { create: vi.fn().mockRejectedValue({ status: 422, message: msg, code: "CONTENT_TOO_COMPLEX" }) };
    setup(api);
    fill("<p>Nội dung vẫn qua kiểm tra phía client</p>");
    fireEvent.click(screen.getByText("Đăng bài"));
    await waitFor(() => expect(snack.error).toHaveBeenCalledWith(msg));
  });
});
