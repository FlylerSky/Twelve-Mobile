// v2.5.0 [SEO/hiệu năng]: script Turnstile chỉ nạp khi widget xuất hiện (không còn nạp ở mọi trang);
// /assets/* (tên file có hash của Vite) được cache bất biến; tiêu đề/mô tả mặc định khớp bản SSR.
import React from "react";
import fs from "node:fs";
import path from "node:path";
import { describe, it, expect, afterEach, vi } from "vitest";
import { render, cleanup } from "@testing-library/react";

const root = path.resolve(__dirname, "..");

describe("v2.5.0 — Turnstile nạp theo nhu cầu", () => {
  afterEach(() => {
    cleanup();
    vi.unstubAllEnvs();
    document.head.querySelectorAll("script[data-turnstile-api]").forEach((n) => n.remove());
    delete window.turnstile;
  });

  it("index.html không còn nhúng script Turnstile", () => {
    const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
    expect(html).not.toMatch(/<script[^>]+challenges\.cloudflare\.com/);
  });

  it("có site key => widget tự nạp script đúng 1 lần (kể cả mount lại)", async () => {
    vi.stubEnv("VITE_TURNSTILE_SITE_KEY", "site-key-test");
    const { default: TurnstileWidget } = await import("../src/components/TurnstileWidget.jsx");
    const first = render(<TurnstileWidget onToken={() => {}} />);
    const tags = document.head.querySelectorAll("script[data-turnstile-api]");
    expect(tags).toHaveLength(1);
    expect(tags[0].getAttribute("src")).toBe("https://challenges.cloudflare.com/turnstile/v0/api.js");
    first.unmount();
    render(<TurnstileWidget onToken={() => {}} />);
    expect(document.head.querySelectorAll("script[data-turnstile-api]")).toHaveLength(1);
  });

  it("không có site key => không nạp script nào", async () => {
    vi.stubEnv("VITE_TURNSTILE_SITE_KEY", "");
    const { default: TurnstileWidget } = await import("../src/components/TurnstileWidget.jsx");
    render(<TurnstileWidget onToken={() => {}} />);
    expect(document.head.querySelectorAll("script[data-turnstile-api]")).toHaveLength(0);
  });
});

describe("v2.5.0 — cache tài nguyên tĩnh + tiêu đề mặc định", () => {
  it("vercel.json: /assets/* cache bất biến 1 năm", () => {
    const cfg = JSON.parse(fs.readFileSync(path.join(root, "vercel.json"), "utf8"));
    const rule = cfg.headers.find((h) => h.source === "/assets/(.*)");
    expect(rule).toBeTruthy();
    expect(rule.headers).toContainEqual({ key: "Cache-Control", value: "public, max-age=31536000, immutable" });
  });

  it("index.html: tiêu đề + mô tả mặc định khớp trang chủ (bản SSR dùng đúng chuỗi này)", () => {
    const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
    expect(html).toContain("<title>Twelve — Nền tảng mạng xã hội chia sẻ bài viết</title>");
    const page = fs.readFileSync(path.join(root, "src/pages/IndexPage.jsx"), "utf8");
    const desc = "Twelve là nền tảng mạng xã hội chia sẻ bài viết, bình luận và xếp hạng nội dung theo tuần. Khám phá bài viết mới, blog và bảng xu hướng.";
    expect(html).toContain(desc);
    expect(page).toContain(desc);
    const seoPath = path.join(root, "../backend/src/utils/seoMeta.js");
    if (fs.existsSync(seoPath)) expect(fs.readFileSync(seoPath, "utf8")).toContain(desc);
  });
});

describe("v2.5.1.1 — thẻ xác thực Google Search Console", () => {
  const tag = '<meta name="google-site-verification" content="xIyQYgOdTVuErxEiPFCfbG9LQRS1WJE_-PpELCCnzJQ" />';

  it("index.html có đúng 1 thẻ, nằm trong <head>", () => {
    const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
    expect(html.split(tag).length - 1).toBe(1);
    expect(html.indexOf(tag)).toBeLessThan(html.indexOf("</head>"));
  });

  it("bản SSR (top.ejs) có thẻ cùng mã — hai nơi không được lệch nhau", () => {
    const ejsPath = path.join(root, "../backend/src/views/partials/top.ejs");
    if (!fs.existsSync(ejsPath)) return; // frontend được tách riêng khỏi backend
    expect(fs.readFileSync(ejsPath, "utf8")).toContain(tag);
  });
});
