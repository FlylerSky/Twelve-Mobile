// v2.4.0 — Hệ huy hiệu (phía frontend). Bảng ca BADGE_CASES GIỐNG HỆT backend/test/profile-240.test.js: hai phía phải ra cùng kết quả.
// Chạy: npx vitest run tests/badges.test.js
import { describe, it, expect } from "vitest";
import { BADGE_CATALOG, UNKNOWN_BADGE, deriveBadgeIds, resolveBadgeIds, getBadgeInfo, badgeSizeForVariant } from "../src/utils/badges";

const BADGE_CASES = [
  [{ accountRole: "user" }, []],
  [{ accountRole: "admin" }, ["admin"]],
  [{ accountRole: "dev" }, ["dev"]],
  [{ accountRole: "moderator" }, ["moderator"]],
  [{ accountRole: "pro_user" }, ["pro"]],
  [{ accountRole: "test" }, ["tester"]],
  [{ accountRole: "user", isLegacyMember: true }, ["legacy"]],
  [{ accountRole: "admin", isLegacyMember: true }, ["admin", "legacy"]],
  [{ accountRole: "pro_user", isLegacyMember: true }, ["pro", "legacy"]],
  [{ accountRole: "ghost-role", isLegacyMember: false }, []],
  // v2.4.1 — NHÓM (accountGroup) là căn cứ chính: SA đặt tay thường vẫn mang accountRole "user" từ lúc đăng ký.
  [{ accountGroup: "SA", accountRole: "user" }, ["sa"]],
  [{ accountGroup: "SA" }, ["sa"]],
  [{ accountGroup: "SA", accountRole: "moderator" }, ["moderator"]],
  [{ accountGroup: "SA", accountRole: "pro_user" }, ["sa"]],
  [{ accountGroup: "SA", accountRole: "user", isLegacyMember: true }, ["sa", "legacy"]],
  [{ accountGroup: "RA", accountRole: "admin" }, []],
  [{ accountGroup: "RA", accountRole: "pro_user" }, ["pro"]],
  [{ accountGroup: "RA", accountRole: "user" }, []],
  [{ accountGroup: "LLA", accountRole: "user" }, ["tester"]],
  [{ accountGroup: "LLA" }, ["tester"]],
  [{ isLegacyMember: "true" }, []],
  [{}, []],
  [null, []],
  [undefined, []],
];

describe("huy hiệu — suy từ hồ sơ", () => {
  it("deriveBadgeIds đúng cho mọi ca (bảng dùng chung với backend)", () => {
    for (const [input, expected] of BADGE_CASES) expect(deriveBadgeIds(input), JSON.stringify(input)).toEqual(expected);
  });

  it("mọi id có thể sinh ra đều có mục trong danh mục hiển thị (icon + tên + mô tả)", () => {
    const roles = ["admin", "dev", "moderator", "pro_user", "test"];
    const ids = new Set(["legacy", ...roles.flatMap((r) => deriveBadgeIds({ accountRole: r })), ...deriveBadgeIds({ accountGroup: "SA" })]);
    expect(ids.has("sa")).toBe(true);
    for (const id of ids) {
      const b = BADGE_CATALOG[id];
      expect(b, id).toBeTruthy();
      expect(b.icon, id).toBeTruthy();
      expect(b.label, id).toMatch(/\S/);
      expect(b.description, id).toMatch(/\S/);
    }
  });

  it("resolveBadgeIds: có `badges` (backend đã tính) → dùng đúng danh sách đó — mọi nơi cùng một kết quả; phần tử lạ kiểu bị bỏ", () => {
    expect(resolveBadgeIds({ displayName: "A", badges: ["pro", "legacy"] })).toEqual(["pro", "legacy"]);
    expect(resolveBadgeIds({ accountGroup: "RA", accountRole: "user", badges: ["sa"] })).toEqual(["sa"]);
    expect(resolveBadgeIds({ badges: ["pro", 7, null] })).toEqual(["pro"]);
    expect(resolveBadgeIds({ badges: [] })).toEqual([]);
  });

  it("resolveBadgeIds: chưa có `badges` (đối tượng dựng tay, dữ liệu rất cũ) → suy từ nhóm/vai trò/thành viên cũ", () => {
    expect(resolveBadgeIds({ accountGroup: "SA", accountRole: "user" })).toEqual(["sa"]);
    expect(resolveBadgeIds({ accountRole: "admin", isLegacyMember: true })).toEqual(["admin", "legacy"]);
    expect(resolveBadgeIds({ displayName: "A" })).toEqual([]);
    expect(resolveBadgeIds(null)).toEqual([]);
  });

  it("cỡ icon theo kiểu chữ của tên đứng cạnh: một bảng duy nhất, kiểu lạ → mặc định", () => {
    expect(badgeSizeForVariant("subtitle2")).toBe(18);
    expect(badgeSizeForVariant("h5")).toBeGreaterThan(badgeSizeForVariant("subtitle1"));
    expect(badgeSizeForVariant("body2")).toBeLessThan(badgeSizeForVariant("subtitle1"));
    expect(badgeSizeForVariant(undefined)).toBe(18);
    expect(badgeSizeForVariant("khong-co")).toBe(18);
  });

  it("id lạ (backend mới hơn frontend) vẫn hiện được bằng huy hiệu chung, không ném lỗi", () => {
    const b = getBadgeInfo("huy-hieu-tuong-lai");
    expect(b.id).toBe("huy-hieu-tuong-lai");
    expect(b.label).toBe(UNKNOWN_BADGE.label);
    expect(b.icon).toBe(UNKNOWN_BADGE.icon);
  });
});
