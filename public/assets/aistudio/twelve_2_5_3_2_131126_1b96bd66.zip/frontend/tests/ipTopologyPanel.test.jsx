import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, cleanup, waitFor } from "@testing-library/react";

// v2.5.3.2 — panel Quản trị > Nhận diện IP (TW-01): chỉ đọc, chỉ gọi khi bấm "Đo ngay", hiển thị đúng kết luận của backend.
const getIpTopology = vi.fn();
vi.mock("../src/api/admin.api", () => ({ getIpTopology: (...a) => getIpTopology(...a) }));

import AdminIpTopologyPanel from "../src/pages/settings/AdminIpTopologyPanel";

const CLIENT = "203.0.113.9";
const payload = (over = {}) => ({
  current: { trustProxyMode: "hops", trustProxyHops: 1, clientIpMode: "auto", reqIp: "104.16.0.5", reqIps: [], hopIsCloudflare: true, chosen: CLIENT, key: CLIENT },
  peer: "10.0.0.1",
  peerTrusted: true,
  xff: [CLIENT, "104.16.0.5"],
  xffRaw: `${CLIENT}, 104.16.0.5`,
  cfConnectingIp: CLIENT,
  chain: ["10.0.0.1", "104.16.0.5", CLIENT],
  candidates: [
    { setting: { TRUST_PROXY_MODE: "cloudflare" }, address: CLIENT, isCloudflare: false, key: CLIENT, usable: true },
    { setting: { TRUST_PROXY_HOPS: 0 }, address: "10.0.0.1", isCloudflare: false, key: "10.0.0.1", usable: true },
    { setting: { TRUST_PROXY_HOPS: 1 }, address: "104.16.0.5", isCloudflare: true, key: CLIENT, usable: true },
  ],
  verdict: { code: "OK", suggestions: [] },
  ...over,
});

beforeEach(() => {
  getIpTopology.mockReset(); // chú ý: không `return` mock — vitest coi hàm trả về từ beforeEach là hàm dọn dẹp và sẽ GỌI nó sau test
});
afterEach(() => cleanup());

describe("AdminIpTopologyPanel", () => {
  it("không tự gọi backend khi mở; bấm 'Đo ngay' gọi đúng 5 lần và báo ĐÚNG khi khoá == CF-Connecting-IP", async () => {
    getIpTopology.mockResolvedValue(payload());
    render(<AdminIpTopologyPanel />);
    expect(getIpTopology).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole("button", { name: "Đo ngay" }));
    await waitFor(() => expect(screen.getByText(/Nhận diện IP đang đúng/)).toBeTruthy());
    expect(getIpTopology).toHaveBeenCalledTimes(5);
    expect(screen.getByText(/Khoá giữ nguyên/)).toBeTruthy();
    expect(screen.queryByText(/thay đổi giữa/)).toBeNull();
    // bảng ứng viên: cấu hình đang dùng (hop=1) được đánh dấu
    expect(screen.getByText("đang dùng")).toBeTruthy();
    expect(screen.getByText("TRUST_PROXY_HOPS=1")).toBeTruthy();
  });

  it("khoá khác IP thật ⇒ cảnh báo + gợi ý cấu hình (chế độ cloudflare ưu tiên, rồi số hop nhỏ nhất) + dặn đọc ghi chú trước khi đổi", async () => {
    getIpTopology.mockResolvedValue(
      payload({
        current: { trustProxyMode: "hops", trustProxyHops: 1, clientIpMode: "auto", reqIp: "10.9.8.7", reqIps: [], hopIsCloudflare: false, chosen: "10.9.8.7", key: "10.9.8.7" },
        peer: "10.0.0.2",
        chain: ["10.0.0.2", "10.9.8.7", "104.16.0.5", CLIENT],
        xff: [CLIENT, "104.16.0.5", "10.9.8.7"],
        verdict: { code: "MISMATCH_FIXABLE", suggestions: [{ TRUST_PROXY_MODE: "cloudflare" }, { TRUST_PROXY_HOPS: 2 }] },
      })
    );
    render(<AdminIpTopologyPanel />);
    fireEvent.click(screen.getByRole("button", { name: "Đo ngay" }));
    await waitFor(() => expect(screen.getByText(/Khoá IP hiện tại KHÁC IP thật/)).toBeTruthy());
    expect(screen.getAllByText("TRUST_PROXY_MODE=cloudflare").length).toBeGreaterThan(0);
    expect(screen.getAllByText("TRUST_PROXY_HOPS=2").length).toBeGreaterThan(0);
    expect(screen.getByText(/ưu tiên/)).toBeTruthy();
    expect(screen.getByText(/Đọc PATCH-26-NOTES\.md trước khi đổi/)).toBeTruthy();
  });

  it("khoá đổi giữa các lần đo ⇒ báo lỗi riêng (triệu chứng V-01)", async () => {
    let n = 0;
    getIpTopology.mockImplementation(() => Promise.resolve(payload({ current: { ...payload().current, key: n++ % 2 ? "104.16.0.5" : "104.16.7.7" } })));
    render(<AdminIpTopologyPanel />);
    fireEvent.click(screen.getByRole("button", { name: "Đo ngay" }));
    await waitFor(() => expect(screen.getByText(/Khoá IP thay đổi giữa 5 lần đo/)).toBeTruthy());
    expect(screen.queryByText(/Khoá giữ nguyên/)).toBeNull();
  });

  it("peer không thuộc dải tin cậy ⇒ ứng viên cloudflare ghi rõ 'chưa dùng được'; không có CF-Connecting-IP ⇒ báo chưa có gì để đối chiếu", async () => {
    getIpTopology.mockResolvedValue(
      payload({
        peer: "8.8.8.8",
        peerTrusted: false,
        cfConnectingIp: null,
        candidates: [{ setting: { TRUST_PROXY_MODE: "cloudflare" }, address: "8.8.8.8", isCloudflare: false, key: "8.8.8.8", usable: false }],
        verdict: { code: "NO_CF_HEADER", suggestions: [] },
      })
    );
    render(<AdminIpTopologyPanel />);
    fireEvent.click(screen.getByRole("button", { name: "Đo ngay" }));
    await waitFor(() => expect(screen.getByText(/Chưa có gì để đối chiếu/)).toBeTruthy());
    expect(screen.getByText(/chưa dùng được/)).toBeTruthy();
    expect(screen.getByText(/KHÔNG thuộc dải nội bộ\/Cloudflare/)).toBeTruthy();
  });

  it("lỗi từ backend (vd. 403/mạng) ⇒ hiện thông báo lỗi, nút Đo ngay dùng lại được, không crash", async () => {
    getIpTopology.mockRejectedValue({ message: "Bạn không có quyền thực hiện thao tác này." });
    render(<AdminIpTopologyPanel />);
    fireEvent.click(screen.getByRole("button", { name: "Đo ngay" }));
    await waitFor(() => expect(screen.getByText("Bạn không có quyền thực hiện thao tác này.")).toBeTruthy());
    expect(screen.getByRole("button", { name: "Đo ngay" }).disabled).toBe(false);
  });

  it("chỉ ĐỌC: API admin chỉ cung cấp hàm GET cho panel này (không có đường ghi)", async () => {
    const fs = await import("node:fs");
    const path = await import("node:path");
    const read = (rel) => fs.readFileSync(path.resolve(process.cwd(), rel), "utf8"); // vitest chạy từ thư mục frontend/
    const api = read("src/api/admin.api.js");
    const line = api.split("\n").find((l) => l.includes("export const getIpTopology"));
    expect(line).toMatch(/apiClient\.get\("\/admin\/ip-topology"\)/);
    const panel = read("src/pages/settings/AdminIpTopologyPanel.jsx");
    expect(panel).not.toMatch(/apiClient|\.(post|put|patch|delete)\(/);
    expect(panel).not.toMatch(/dangerouslySetInnerHTML/);
  });
});
