import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, waitFor, act } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { installChunkReload, CHUNK_RELOAD_FLAG } from "../src/utils/chunkReload";

// Trang eager và phần phụ thuộc nặng được thay bằng bản giả: chỉ kiểm tra việc nối tải-lười (lazy + Suspense) trong App.
vi.mock("../src/components/Navbar", () => ({ default: () => <nav>NAVBAR</nav> }));
vi.mock("../src/components/PendingSessionGate", () => ({ default: () => null }));
vi.mock("../src/pages/IndexPage", () => ({ default: () => <div>INDEX</div> }));
vi.mock("../src/pages/LoginPage", () => ({ default: () => <div>LOGIN</div> }));
vi.mock("../src/pages/RegisterPage", () => ({ default: () => <div>REGISTER</div> }));
vi.mock("../src/pages/BlogPage", () => ({ default: () => <div>BLOG</div> }));
vi.mock("../src/api/content.api", () => ({ postsApi: {}, blogsApi: {} }));
vi.mock("../src/pages/SettingsPage", () => ({ default: () => <div>SETTINGS</div> }));
vi.mock("../src/pages/TrendingPage", () => ({ default: () => <div>TRENDING</div> }));
vi.mock("../src/pages/PostDetailPage", () => ({ default: ({ backPath }) => <div>POST {backPath}</div> }));
vi.mock("../src/pages/PublicProfilePage", () => ({ default: () => <div>PROFILE</div> }));
const modalProps = vi.fn();
vi.mock("../src/components/CreatePostModal", () => ({ default: (p) => { modalProps(p); return <div>MODAL open={String(p.open)}</div>; } }));
let ctx = { open: false, closeModal: vi.fn(), notifyCreated: vi.fn() };
vi.mock("../src/context/CreatePostContext", () => ({ useCreatePost: () => ctx }));
import App from "../src/App";

const at = (path) => render(<MemoryRouter initialEntries={[path]}><App /></MemoryRouter>);
beforeEach(() => { ctx = { open: false, closeModal: vi.fn(), notifyCreated: vi.fn() }; modalProps.mockClear(); });
afterEach(() => cleanup());

describe("G4: tải lười theo trang", () => {
  it.each([
    ["/settings", "SETTINGS"],
    ["/settings/app", "SETTINGS"],
    ["/settings/app/font/custom", "SETTINGS"], // v2.1.0: đường dẫn lồng nhau của cây Cài đặt
    ["/trending", "TRENDING"],
    ["/u/abc", "PROFILE"],
    ["/post/abc", "POST /"],
    ["/blog/abc", "POST /blog"],
  ])("%s tải được trang đúng (có vòng chờ trong lúc tải)", async (path, text) => {
    at(path);
    await waitFor(() => expect(screen.getByText(text)).toBeTruthy());
  });
  it("trang eager vẫn hiển thị ngay, 404 cho đường dẫn lạ", async () => {
    at("/");
    expect(screen.getByText("INDEX")).toBeTruthy();
    cleanup();
    at("/khong-co-trang-nay");
    expect(screen.getByText("404")).toBeTruthy();
  });
  it("modal soạn bài: KHÔNG tải khi chưa mở; mở rồi thì mount và giữ mount sau khi đóng", async () => {
    const { rerender } = at("/");
    expect(screen.queryByText(/MODAL/)).toBeNull();
    expect(modalProps).not.toHaveBeenCalled();
    ctx = { ...ctx, open: true };
    await act(async () => rerender(<MemoryRouter initialEntries={["/"]}><App /></MemoryRouter>));
    await waitFor(() => expect(screen.getByText("MODAL open=true")).toBeTruthy());
    ctx = { ...ctx, open: false };
    await act(async () => rerender(<MemoryRouter initialEntries={["/"]}><App /></MemoryRouter>));
    expect(screen.getByText("MODAL open=false")).toBeTruthy();
  });
});

describe("G4: phục hồi khi tải chunk thất bại", () => {
  const fakeWin = (flag = null) => {
    const listeners = {};
    const store = flag ? { [CHUNK_RELOAD_FLAG]: flag } : {};
    return {
      listeners,
      reload: vi.fn(),
      addEventListener: (t, h) => (listeners[t] = h),
      removeEventListener: (t) => delete listeners[t],
      sessionStorage: { getItem: (k) => store[k] ?? null, setItem: (k, v) => (store[k] = v) },
      location: { reload: vi.fn() },
    };
  };
  it("lần đầu: preventDefault + reload đúng 1 lần; lần sau: không reload (chống vòng lặp)", () => {
    const w = fakeWin();
    installChunkReload(w);
    const ev = { preventDefault: vi.fn() };
    w.listeners["vite:preloadError"](ev);
    expect(ev.preventDefault).toHaveBeenCalled();
    expect(w.location.reload).toHaveBeenCalledTimes(1);
    w.listeners["vite:preloadError"]({ preventDefault: vi.fn() });
    expect(w.location.reload).toHaveBeenCalledTimes(1);
  });
  it("không có sessionStorage => không reload", () => {
    const w = fakeWin();
    w.sessionStorage = { getItem: () => { throw new Error("blocked"); }, setItem: () => {} };
    installChunkReload(w);
    w.listeners["vite:preloadError"]({ preventDefault: vi.fn() });
    expect(w.location.reload).not.toHaveBeenCalled();
  });
});
