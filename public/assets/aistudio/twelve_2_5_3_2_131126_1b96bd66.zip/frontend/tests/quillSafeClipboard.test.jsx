import { describe, it, expect, beforeEach } from "vitest";
import { Quill } from "react-quill";
import { sanitizePasteHtml, sanitizeStyleForPaste, SafeClipboard } from "../src/utils/quillSafeClipboard";
// Nạp QuillEditor để đăng ký blot video-file/audio-file của Twelve (cần cho đối chiếu nội dung thật).
import "../src/components/QuillEditor";

const Original = Object.getPrototypeOf(SafeClipboard.prototype).constructor; // Clipboard gốc của Quill 1.3.7

const newEditor = () => {
  document.body.innerHTML = '<div id="ed"></div>';
  return new Quill("#ed", { modules: { clipboard: { matchVisual: false } }, formats: ["header", "bold", "italic", "underline", "strike", "color", "background", "list", "align", "blockquote", "code-block", "link", "video", "image", "video-file", "audio-file"] });
};
const attrsWithHandlers = () => [];
const watchHandlers = () => {
  const seen = [];
  const mo = new MutationObserver((recs) => recs.forEach((r) => r.addedNodes.forEach((n) => {
    if (!n.querySelectorAll) return;
    [n, ...n.querySelectorAll("*")].forEach((e) => { if ([...(e.attributes || [])].some((a) => /^on/i.test(a.name))) seen.push(e.tagName); });
  })));
  mo.observe(document.body, { childList: true, subtree: true });
  return { seen, stop: async () => { await Promise.resolve(); mo.takeRecords(); mo.disconnect(); }, flush: () => mo.takeRecords() };
};

describe("G2: không còn gắn HTML có on* vào DOM đang hiển thị", () => {
  const payload = '<p>hello</p><img src="x" onloadstart="window.__p=1" onerror="window.__p=2"><a href="javascript:alert(1)" onclick="x()">l</a><script>window.__p=3</script>';

  it("mã gốc quill@1.3.7: convert() gắn phần tử có on* vào DOM (bằng chứng cơ chế CVE)", async () => {
    const quill = newEditor();
    const w = watchHandlers();
    Original.prototype.convert.call(quill.getModule("clipboard"), payload);
    const recs = w.flush();
    // MutationObserver đã gom bản ghi; đọc lại qua cách đồng bộ: dùng takeRecords trước khi disconnect
    expect(recs.length).toBeGreaterThan(0);
    const found = recs.some((r) => [...r.addedNodes].some((n) => n.querySelectorAll && [n, ...n.querySelectorAll("*")].some((e) => [...(e.attributes || [])].some((a) => /^on/i.test(a.name)))));
    expect(found).toBe(true);
  });

  it("sau vá: convert() và dangerouslyPasteHTML() KHÔNG bao giờ gắn phần tử có on* vào DOM", () => {
    const quill = newEditor();
    expect(quill.getModule("clipboard")).toBeInstanceOf(SafeClipboard);
    const w = watchHandlers();
    quill.clipboard.convert(payload);
    quill.clipboard.dangerouslyPasteHTML(0, payload, "user");
    const recs = w.flush();
    const bad = recs.some((r) => [...r.addedNodes].some((n) => n.querySelectorAll && [n, ...n.querySelectorAll("*")].some((e) => [...(e.attributes || [])].some((a) => /^on/i.test(a.name)))));
    expect(bad).toBe(false);
    expect(document.body.innerHTML).not.toMatch(/onerror|onloadstart|onclick|<script|javascript:/i);
    expect(window.__p).toBeUndefined();
  });
});

describe("sanitizePasteHtml", () => {
  it("bỏ thẻ nguy hiểm, thuộc tính on*, URL javascript:/data:text/html, giữ phần còn lại", () => {
    const out = sanitizePasteHtml('<p class="ql-align-center" style="color:red" onclick="x()">a<script>1</script><svg onload="1"><circle/></svg><a href=" JaVa\nScript:alert(1)">b</a><img src="data:text/html,<script>1</script>"><img src="https://ok.example/a.png" srcset="x" formaction="y"></p>');
    expect(out).toContain('class="ql-align-center"');
    expect(out).toContain('style="color:red"');
    expect(out).toContain('src="https://ok.example/a.png"');
    expect(out).not.toMatch(/onclick|script|svg|javascript|srcset|formaction|data:text\/html/i);
  });
  it("đầu vào rỗng / sai kiểu => chuỗi rỗng", () => {
    expect(sanitizePasteHtml("")).toBe("");
    expect(sanitizePasteHtml(null)).toBe("");
    expect(sanitizePasteHtml(123)).toBe("");
  });
});

describe("không làm đổi hành vi với nội dung hợp lệ (Delta trước/sau vá giống hệt)", () => {
  const corpus = {
    "tiêu đề + định dạng": '<h2>Tiêu đề</h2><p>Chữ <strong>đậm</strong>, <em>nghiêng</em>, <u>gạch chân</u>, <s>gạch ngang</s>.</p>',
    "liên kết": '<p>Xem <a href="https://example.com/trang?x=1" target="_blank" rel="noopener noreferrer">liên kết</a></p>',
    "danh sách": "<ul><li>một</li><li>hai</li></ul><ol><li>a</li><li>b</li></ol>",
    "trích dẫn + mã": "<blockquote>trích dẫn</blockquote><pre>const a = 1;</pre>",
    "màu + căn lề": '<p class="ql-align-center"><span style="color: rgb(230, 0, 0);">đỏ</span> <span style="background-color: rgb(255, 255, 0);">nền vàng</span></p>',
    "ảnh": '<p><img src="https://res.cloudinary.com/demo/image/upload/a.png"></p>',
    "iframe video": '<iframe class="ql-video" frameborder="0" allowfullscreen="true" src="https://www.youtube.com/embed/abc123"></iframe>',
    "video/audio file": '<video src="https://res.cloudinary.com/demo/video/upload/v.mp4" controls></video><audio src="https://res.cloudinary.com/demo/audio/a.mp3" controls></audio>',
    "tiếng Việt": "<p>Nhà ở ven đường, gió thổi qua ngõ — Đây là ví dụ có dấu: ă â ê ô ơ ư đ.</p>",
  };
  for (const [name, html] of Object.entries(corpus)) {
    it(name, () => {
      const quill = newEditor();
      const clip = quill.getModule("clipboard");
      const before = JSON.stringify(Original.prototype.convert.call(clip, html).ops);
      const after = JSON.stringify(clip.convert(html).ops);
      expect(after).toBe(before);
      expect(before.length).toBeGreaterThan(10);
    });
  }
});

// v2.5.3 [TW-19]: `style` khi dán chỉ giữ allowlist (giống backend), bỏ CSS nguy hiểm.
describe("TW-19: sanitizeStyleForPaste", () => {
  it("giữ màu/nền/căn lề/đậm/nghiêng; bỏ position/inset/z-index/url()/expression/!important", () => {
    expect(sanitizeStyleForPaste("color: red; background-color: rgb(255, 255, 0); font-weight: bold")).toBe("color:red;background-color:rgb(255, 255, 0);font-weight:bold");
    expect(sanitizeStyleForPaste("position:fixed; inset:0; z-index:99999; color:blue")).toBe("color:blue");
    expect(sanitizeStyleForPaste("background-color: url(https://evil.example/a.png)")).toBe("");
    expect(sanitizeStyleForPaste("background:url(https://evil.example/a.png)")).toBe("");
    expect(sanitizeStyleForPaste("color: expression(alert(1))")).toBe("");
    expect(sanitizeStyleForPaste("color: var(--x)")).toBe("");
    expect(sanitizeStyleForPaste("color: red !important")).toBe("");
    expect(sanitizeStyleForPaste("color:red;;;font-size:0")).toBe("color:red;font-size:0");
    expect(sanitizeStyleForPaste("")).toBe("");
    expect(sanitizeStyleForPaste(undefined)).toBe("");
  });

  it("sanitizePasteHtml: style độc bị bỏ hẳn thuộc tính; style hợp lệ còn lại; không còn url() hay position trong kết quả", () => {
    const out = sanitizePasteHtml('<p style="position:fixed;top:0;left:0;width:100vw;height:100vh;background:url(https://evil.example/x.png)">overlay</p><span style="color:#f00">đỏ</span><b style="font-weight:bold;transform:scale(9)">đậm</b>');
    expect(out).not.toMatch(/position|url\(|evil\.example|transform|100vw/);
    expect(out).toContain('style="color:#f00"');
    expect(out).toContain('style="font-weight:bold"');
    expect(out).toContain("overlay");
    expect(out).not.toMatch(/<p style/);
  });
});
