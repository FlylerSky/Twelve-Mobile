// v2.4.0 — Trang Profile: tab Trang chủ/Bài viết, ảnh bìa, ghim bài (thẻ bài + headZone). (Cài đặt ảnh bìa + hệ tab chung: tests/profile241.test.jsx)
// Chạy: npx vitest run tests/profile240.test.jsx
import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor, within, act } from "@testing-library/react";
import { MemoryRouter, Routes, Route, useLocation } from "react-router-dom";

const m = vi.hoisted(() => ({
  snack: { success: vi.fn(), error: vi.fn(), info: vi.fn(), warning: vi.fn() },
  pin: vi.fn(),
  unpin: vi.fn(),
  getPublicProfile: vi.fn(),
  getPublicProfileByTag: vi.fn(),
  listPinnedPosts: vi.fn(),
  listUserPosts: vi.fn(),
  patchProfile: vi.fn(),
  header: { current: null },
}));
let authState;

vi.mock("../src/context/AuthContext", () => ({ useAuth: () => authState }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => m.snack }));
vi.mock("../src/components/Navbar", () => ({ default: () => <nav>NAVBAR</nav> }));
vi.mock("../src/hooks/useSeo", () => ({ default: () => {} }));
vi.mock("../src/context/PageHeaderContext", () => ({
  useRegisterPageHeader: (cfg) => {
    m.header.current = cfg;
  },
}));
vi.mock("../src/api/content.api", () => ({ postsApi: { pin: (...a) => m.pin(...a), unpin: (...a) => m.unpin(...a) }, blogsApi: {} }));
vi.mock("../src/api/users.api", () => ({
  getPublicProfile: (...a) => m.getPublicProfile(...a),
  getPublicProfileByTag: (...a) => m.getPublicProfileByTag(...a),
  listPinnedPosts: (...a) => m.listPinnedPosts(...a),
  listUserPosts: (...a) => m.listUserPosts(...a),
  recordProfileVisit: () => Promise.resolve({ recorded: true }), // v2.5.2: trang tự báo lượt ghé thăm khi người đã đăng nhập xem hồ sơ người khác
}));
// Danh sách thẻ bài thật quá nặng (Firestore realtime…) — thay bằng bản tối giản; PostCard được kiểm riêng bên dưới.
vi.mock("../src/components/PostCardList", () => ({
  default: ({ posts }) => (
    <ul data-testid="cards">
      {posts.map((p) => (
        <li key={p.id}>{p.title}</li>
      ))}
    </ul>
  ),
}));
vi.mock("../src/components/FeedList", () => ({
  default: ({ feed, emptyText }) => (
    <div data-testid="feed">
      {feed.loading ? "loading" : feed.items.length === 0 ? emptyText : feed.items.map((p) => <span key={p.id}>{p.title}</span>)}
    </div>
  ),
}));
import PublicProfilePage, { PROFILE_TABS } from "../src/pages/PublicProfilePage";

const ME = { uid: "me1", displayName: "Tôi", tagName: "@toi", accountRole: "user", pinnedPostIds: [] };
const OTHER = { uid: "u2", displayName: "Lan", tagName: "@lan", accountRole: "moderator", isLegacyMember: true, badges: ["moderator", "legacy"], country: "VN", coverUrl: "https://img.example.com/c.jpg", avatarUrl: null };
const post = (id, over = {}) => ({ id, title: `Bài ${id}`, author: { uid: "u2" }, ...over });

beforeEach(() => {
  [m.pin, m.unpin, m.getPublicProfile, m.getPublicProfileByTag, m.listPinnedPosts, m.listUserPosts, m.patchProfile].forEach((f) => f.mockReset());
  Object.values(m.snack).forEach((f) => f.mockReset());
  m.header.current = null;
  authState = { profile: ME, isLoggedIn: true, isAuthReady: true, patchProfile: m.patchProfile };
  m.getPublicProfileByTag.mockResolvedValue(OTHER); // v2.4.2.1: URL hồ sơ là /u/@<tag> => tra theo Tag Name
  m.getPublicProfile.mockResolvedValue(OTHER);
  m.listPinnedPosts.mockResolvedValue([post("a"), post("b")]);
  m.listUserPosts.mockResolvedValue({ posts: [post("x"), post("y")], nextCursor: null });
});
afterEach(cleanup);

const LocationProbe = () => <div data-testid="loc">{useLocation().pathname + useLocation().search}</div>;
const renderProfile = (url = "/u/@lan") =>
  render(
    <MemoryRouter initialEntries={[url]}>
      <Routes>
        <Route path="/u/:ref" element={<><PublicProfilePage /><LocationProbe /></>} />
        <Route path="/settings/account/info" element={<LocationProbe />} />
      </Routes>
    </MemoryRouter>
  );

// ======================================================================== trang Profile
describe("PublicProfilePage — tab, đầu trang, huy hiệu", () => {
  it("cây tab là MỘT mảng (thêm tab = thêm một dòng): 'Trang chủ', 'Bài viết' và (v2.5.2) 'Blog' — tab Blog chỉ hiện ở hồ sơ SA, xem tests/profile252.test.jsx", () => {
    expect(PROFILE_TABS.map((t) => [t.key, t.label])).toEqual([["home", "Trang chủ"], ["posts", "Bài viết"], ["blog", "Blog"]]);
  });

  it("mặc định mở 'Trang chủ': hiện tên, Tag Name Search, huy hiệu CẠNH TÊN và bài đã ghim; KHÔNG tải danh sách bài", async () => {
    renderProfile();
    expect(await screen.findByText("Lan")).toBeTruthy();
    expect(screen.getByText("@lan")).toBeTruthy();
    expect(screen.getByTestId("badge-multi")).toBeTruthy(); // 2 huy hiệu → 3 chấm
    await waitFor(() => expect(screen.getByTestId("cards").textContent).toBe("Bài aBài b"));
    expect(m.listPinnedPosts).toHaveBeenCalledWith("u2");
    expect(m.listUserPosts).not.toHaveBeenCalled();
    expect(screen.getByRole("tab", { name: "Trang chủ" }).getAttribute("aria-selected")).toBe("true");
  });

  it("không còn chip chữ 'Đến từ Twelve cũ' (huy hiệu chỉ là icon, tên/mô tả hiện khi bấm)", async () => {
    renderProfile();
    await screen.findByText("Lan");
    expect(screen.queryByText("Đến từ Twelve cũ")).toBeNull();
    fireEvent.click(screen.getByTestId("user-badges"));
    expect(screen.getByText("Thành viên Twelve cũ")).toBeTruthy();
  });

  it("bấm tab 'Bài viết' → đổi ?tab=posts trên URL, tải danh sách bài (không tải lại bài ghim); về 'Trang chủ' → URL sạch", async () => {
    renderProfile();
    await screen.findByText("Lan");
    fireEvent.click(screen.getByRole("tab", { name: "Bài viết" }));
    await waitFor(() => expect(m.listUserPosts).toHaveBeenCalledWith("u2", null, 10));
    expect(screen.getByTestId("loc").textContent).toBe("/u/@lan?tab=posts");
    await waitFor(() => expect(screen.getByTestId("feed").textContent).toBe("Bài xBài y"));
    fireEvent.click(screen.getByRole("tab", { name: "Trang chủ" }));
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("/u/@lan"));
  });

  it("mở thẳng ?tab=posts → vào tab Bài viết; ?tab=lạ → về Trang chủ", async () => {
    const { unmount } = renderProfile("/u/@lan?tab=posts");
    await waitFor(() => expect(m.listUserPosts).toHaveBeenCalled());
    expect(m.listPinnedPosts).not.toHaveBeenCalled();
    unmount();
    m.listUserPosts.mockClear();
    renderProfile("/u/@lan?tab=khong-co");
    await waitFor(() => expect(m.listPinnedPosts).toHaveBeenCalled());
    expect(m.listUserPosts).not.toHaveBeenCalled();
  });

  it("chưa ghim bài nào: người khác thấy câu trung tính; chính chủ được hướng dẫn cách ghim", async () => {
    m.listPinnedPosts.mockResolvedValue([]);
    const { unmount } = renderProfile();
    expect(await screen.findByText("Người dùng này chưa ghim bài viết nào.")).toBeTruthy();
    unmount();
    m.getPublicProfileByTag.mockResolvedValue({ ...OTHER, uid: "me1", tagName: "@toi" });
    renderProfile("/u/@toi");
    expect(await screen.findByText(/Bạn chưa ghim bài viết nào/)).toBeTruthy();
  });

  it("chính chủ: headZone có 'Chỉnh sửa hồ sơ' → Cài đặt > Tài khoản > Thông tin (+ 'Sao chép URL Profile' v2.4.2.2); người khác: chỉ có 'Sao chép URL Profile'", async () => {
    renderProfile();
    await screen.findByText("Lan");
    expect(m.header.current.title).toBe("Hồ sơ");
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["copy-profile-url"]);
    cleanup();
    m.getPublicProfileByTag.mockResolvedValue({ ...OTHER, uid: "me1", tagName: "@toi" });
    renderProfile("/u/@toi");
    await screen.findByText("Lan");
    const acts = m.header.current.actions;
    expect(acts.map((a) => a.key)).toEqual(["edit-profile", "profile-visitors", "copy-profile-url"]);
    await act(async () => acts[0].onClick());
    expect(screen.getByTestId("loc").textContent).toBe("/settings/account/info");
  });

  it("chính chủ ghim/gỡ ghim ở bất cứ đâu (profile.pinnedPostIds đổi) → danh sách ghim tải lại; người khác không bị tải lại", async () => {
    m.getPublicProfileByTag.mockResolvedValue({ ...OTHER, uid: "me1", tagName: "@toi" });
    const { rerender } = renderProfile("/u/@toi");
    await screen.findByText("Lan");
    await waitFor(() => expect(m.listPinnedPosts).toHaveBeenCalledTimes(1));
    authState = { ...authState, profile: { ...ME, pinnedPostIds: ["a"] } };
    rerender(
      <MemoryRouter initialEntries={["/u/@toi"]}>
        <Routes><Route path="/u/:ref" element={<><PublicProfilePage /><LocationProbe /></>} /></Routes>
      </MemoryRouter>
    );
    await waitFor(() => expect(m.listPinnedPosts).toHaveBeenCalledTimes(2));
  });

  it("ảnh bìa: có coverUrl → hiện ảnh; ảnh lỗi → về nền gradient (không để ảnh vỡ); không có coverUrl → không có <img> bìa", async () => {
    renderProfile();
    const header = await screen.findByTestId("profile-header");
    const img = header.querySelector("img");
    expect(img.getAttribute("src")).toBe("https://img.example.com/c.jpg");
    fireEvent.error(img);
    await waitFor(() => expect(screen.getByTestId("profile-cover").querySelector("img")).toBeNull());
    cleanup();
    m.getPublicProfileByTag.mockResolvedValue({ ...OTHER, coverUrl: null });
    renderProfile();
    const h2 = await screen.findByTestId("profile-header");
    expect(h2.querySelector('[data-testid="profile-cover"] img')).toBeNull();
  });

  it("không tìm thấy người dùng → thông báo, không có tab", async () => {
    m.getPublicProfileByTag.mockRejectedValue({ message: "Không tìm thấy người dùng." });
    renderProfile();
    expect(await screen.findByText("Không tìm thấy người dùng.")).toBeTruthy();
    expect(screen.queryByRole("tab")).toBeNull();
    expect(m.snack.error).toHaveBeenCalledWith("Không tìm thấy người dùng.");
  });
});

// ======================================================================== PostCard + ghim
describe("PostCard — nút ghim trong hàng thông số", () => {
  let PostCard;
  const origRect = Element.prototype.getBoundingClientRect;
  const origClientWidth = Object.getOwnPropertyDescriptor(HTMLElement.prototype, "clientWidth");
  const setLayout = ({ container }) => {
    // jsdom không có layout: giả lập bề rộng từng chỉ số (30px) và bề rộng hộp chứa.
    Element.prototype.getBoundingClientRect = () => ({ width: 30, height: 30, top: 0, left: 0, right: 30, bottom: 30, x: 0, y: 0, toJSON() {} });
    Object.defineProperty(HTMLElement.prototype, "clientWidth", { configurable: true, get: () => container });
  };
  afterEach(() => {
    Element.prototype.getBoundingClientRect = origRect;
    if (origClientWidth) Object.defineProperty(HTMLElement.prototype, "clientWidth", origClientWidth);
    else delete HTMLElement.prototype.clientWidth;
  });

  beforeEach(async () => {
    vi.resetModules();
    vi.doMock("../src/hooks/useContentEngagement", () => ({
      default: () => ({ likeCount: 1, dislikeCount: 0, commentCount: 2, shareCount: 0, viewCount: 5, aiViewCount: 0, myReaction: null, busy: false, score: 7, react: vi.fn(), share: vi.fn() }),
    }));
    PostCard = (await import("../src/components/PostCard")).default;
  });

  const card = (p, detailPath = "/post") =>
    render(
      <MemoryRouter>
        <PostCard post={p} api={{}} detailPath={detailPath} onOpenComments={() => {}} />
      </MemoryRouter>
    );
  const mine = { id: "p1", title: "Bài của tôi", createdAt: "2026-01-01T00:00:00Z", author: { uid: "me1", displayName: "Tôi" }, hashtags: [] };

  it("tác giả thấy nút ghim (rộng rãi: nằm thẳng trong hàng thông số); bấm → gọi API ghim, vá hồ sơ ngay, báo thành công", async () => {
    setLayout({ container: 1000 });
    m.pin.mockResolvedValue({ pinnedPostIds: ["p1"] });
    card(mine);
    const btn = await screen.findByRole("button", { name: "Ghim lên trang cá nhân" });
    fireEvent.click(btn);
    await waitFor(() => expect(m.pin).toHaveBeenCalledWith("p1"));
    await waitFor(() => expect(m.patchProfile).toHaveBeenCalledWith({ pinnedPostIds: ["p1"] }));
    expect(m.snack.success).toHaveBeenCalledWith("Đã ghim bài viết lên trang cá nhân.");
  });

  it("bài đang ghim: nút đổi thành 'Gỡ ghim', có icon ghim ở đầu thẻ (không chữ); bấm → gọi API gỡ ghim", async () => {
    setLayout({ container: 1000 });
    authState = { ...authState, profile: { ...ME, pinnedPostIds: ["p1"] } };
    m.unpin.mockResolvedValue({ pinnedPostIds: [] });
    card(mine);
    expect(screen.getByTestId("pinned-mark")).toBeTruthy();
    // v2.4.1: chỉ icon — KHÔNG có chữ "Đã ghim" hiển thị (nhãn chỉ nằm trong <title> của icon cho trình đọc màn hình/tooltip).
    expect(screen.queryAllByText("Đã ghim").filter((el) => el.tagName.toLowerCase() !== "title")).toEqual([]);
    expect(screen.getByTestId("pinned-mark").querySelector("title")?.textContent).toBe("Đã ghim");
    fireEvent.click(await screen.findByRole("button", { name: "Gỡ ghim khỏi trang cá nhân" }));
    await waitFor(() => expect(m.unpin).toHaveBeenCalledWith("p1"));
    await waitFor(() => expect(m.patchProfile).toHaveBeenCalledWith({ pinnedPostIds: [] }));
  });

  it("KHÔNG thấy nút ghim: bài của người khác · khách chưa đăng nhập · Blog", async () => {
    setLayout({ container: 1000 });
    const { unmount } = card({ ...mine, author: { uid: "someone-else" } });
    expect(screen.queryByRole("button", { name: /ghim/i })).toBeNull();
    unmount();
    authState = { ...authState, isLoggedIn: false, profile: null };
    const r2 = card(mine);
    expect(screen.queryByRole("button", { name: /ghim/i })).toBeNull();
    r2.unmount();
    authState = { ...authState, isLoggedIn: true, profile: ME };
    card(mine, "/blog");
    expect(screen.queryByRole("button", { name: /ghim/i })).toBeNull();
  });

  it("thẻ của người khác hiện dấu 'Đã ghim' theo dữ liệu server (isPinned) — không có nút", async () => {
    setLayout({ container: 1000 });
    card({ ...mine, author: { uid: "u2" }, isPinned: true });
    expect(screen.getByTestId("pinned-mark")).toBeTruthy();
    expect(screen.queryByRole("button", { name: /ghim/i })).toBeNull();
  });

  it("THIẾU CHỖ: nút ghim (ưu tiên thấp nhất) tự vào menu '...' — giao diện không vỡ; bấm dòng trong menu vẫn ghim được", async () => {
    setLayout({ container: 140 }); // đủ ~4 chỉ số, không đủ cho cả 7
    m.pin.mockResolvedValue({ pinnedPostIds: ["p1"] });
    card(mine);
    await waitFor(() => expect(screen.getByRole("button", { name: "Thêm chỉ số" })).toBeTruthy());
    expect(screen.queryByRole("button", { name: "Ghim lên trang cá nhân" })).toBeNull(); // không nằm trong hàng
    fireEvent.click(screen.getByRole("button", { name: "Thêm chỉ số" }));
    const row = await screen.findByText("Ghim lên trang cá nhân");
    fireEvent.click(row);
    await waitFor(() => expect(m.pin).toHaveBeenCalledWith("p1"));
  });

  it("vượt giới hạn ghim: hiện đúng câu thông báo của backend, KHÔNG vá hồ sơ", async () => {
    setLayout({ container: 1000 });
    m.pin.mockRejectedValue({ message: "Bạn chỉ ghim được tối đa 3 bài. Hãy gỡ ghim một bài trước." });
    card(mine);
    fireEvent.click(await screen.findByRole("button", { name: "Ghim lên trang cá nhân" }));
    await waitFor(() => expect(m.snack.error).toHaveBeenCalledWith("Bạn chỉ ghim được tối đa 3 bài. Hãy gỡ ghim một bài trước."));
    expect(m.patchProfile).not.toHaveBeenCalled();
  });

  it("huy hiệu của tác giả hiện cạnh tên trên thẻ bài", async () => {
    setLayout({ container: 1000 });
    card({ ...mine, author: { uid: "u2", displayName: "Lan", accountRole: "admin", isLegacyMember: false } });
    expect(screen.getByTestId("user-badges").getAttribute("aria-label")).toBe("Huy hiệu: Quản trị viên");
  });
});

// ======================================================================== Trang POST: nút ghim ở headZone
describe("PostDetailPage — nút ghim nằm ở headZone, không ở khu thông số bài", () => {
  let PostDetailPage;
  beforeEach(async () => {
    vi.resetModules();
    vi.doMock("../src/hooks/useContentEngagement", () => ({
      default: () => ({ likeCount: 0, dislikeCount: 0, commentCount: 0, shareCount: 0, viewCount: 0, aiViewCount: 0, myReaction: null, busy: false, score: 0, react: vi.fn(), share: vi.fn() }),
    }));
    vi.doMock("../src/hooks/useCommentThread", () => ({ default: () => ({ send: vi.fn(), sending: false }) }));
    vi.doMock("../src/components/comments/CommentThread", () => ({ default: () => null }));
    vi.doMock("../src/components/comments/CommentComposer", () => ({ default: () => null }));
    vi.doMock("../src/components/PostContent", () => ({ default: () => <div>NỘI DUNG</div> }));
    vi.doMock("../src/components/MediaLightbox", () => ({ default: () => null, collectMediaSlides: () => [], findSlideIndex: () => 0 }));
    PostDetailPage = (await import("../src/pages/PostDetailPage")).default;
  });

  const open = async (postObj, path = "/post/p1") => {
    const api = { getOne: vi.fn().mockResolvedValue({ post: postObj, myReaction: null }) };
    render(
      <MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path="/post/:id" element={<PostDetailPage api={api} />} />
          <Route path="/blog/:id" element={<PostDetailPage api={api} backPath="/blog" />} />
        </Routes>
      </MemoryRouter>
    );
    await screen.findByText("NỘI DUNG");
    return api;
  };
  const base = { id: "p1", title: "Tiêu đề", contentHtml: "<p>x</p>", hashtags: [], createdAt: "2026-01-01T00:00:00Z", author: { uid: "me1", displayName: "Tôi" } };

  it("tác giả: headZone có action ghim; bấm gọi API; sau khi ghim action đổi thành 'Gỡ ghim'; KHÔNG có nút ghim trong thân trang", async () => {
    m.pin.mockResolvedValue({ pinnedPostIds: ["p1"] });
    await open(base);
    await waitFor(() => expect(m.header.current.actions.map((a) => a.key)).toEqual(["pin-post"]));
    expect(m.header.current.actions[0].label).toBe("Ghim lên trang cá nhân");
    expect(m.header.current.title).toBe("Bài viết");
    expect(screen.queryByRole("button", { name: /ghim/i })).toBeNull(); // thân trang không có nút ghim
    await act(async () => m.header.current.actions[0].onClick());
    await waitFor(() => expect(m.pin).toHaveBeenCalledWith("p1"));
    expect(m.patchProfile).toHaveBeenCalledWith({ pinnedPostIds: ["p1"] });
  });

  it("bài đã ghim: action là 'Gỡ ghim khỏi trang cá nhân' (màu primary)", async () => {
    authState = { ...authState, profile: { ...ME, pinnedPostIds: ["p1"] } };
    await open(base);
    await waitFor(() => expect(m.header.current.actions[0]?.label).toBe("Gỡ ghim khỏi trang cá nhân"));
    expect(m.header.current.actions[0].color).toBe("primary");
  });

  it("người khác xem (kể cả SA) và khách: không có action ghim", async () => {
    authState = { ...authState, profile: { ...ME, uid: "someone", accountGroup: "SA" } };
    await open(base);
    expect(m.header.current.actions).toEqual([]);
  });

  it("trang Blog: không có action ghim (Blog không có ghim)", async () => {
    await open(base, "/blog/p1");
    expect(m.header.current.actions).toEqual([]);
  });
});
