// v2.0.13: useRegisterPageHeader KHÔNG được gây vòng lặp render khi trang truyền `actions: []` (mảng mới mỗi render).
// Chạy: npx vitest run tests/pageHeaderLoop.test.jsx
import React, { useState } from "react";
import { describe, it, expect, afterEach } from "vitest";
import { render, cleanup, act, screen, fireEvent } from "@testing-library/react";
import { PageHeaderProvider, usePageHeader, useRegisterPageHeader } from "../src/context/PageHeaderContext";

afterEach(cleanup);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

describe("useRegisterPageHeader", () => {
  it("không lặp render vô hạn khi actions là mảng literal mới mỗi lần render", async () => {
    let renders = 0;
    const stableEmpty = [];
    function Page() {
      renders += 1;
      // Sau 50 lần render thì đưa mảng ổn định vào để NGẮT vòng lặp (nếu có) => test báo đỏ nhanh thay vì treo.
      useRegisterPageHeader({ title: "Twelve", isBrand: true, actions: renders > 50 ? stableEmpty : [] });
      return <div>page</div>;
    }
    render(<PageHeaderProvider><Page /></PageHeaderProvider>);
    await act(async () => { await sleep(300); });
    expect(renders).toBeLessThan(10); // bản lỗi: chạm ngưỡng 50 gần như tức thì
  });

  it("onClick của action luôn là bản mới nhất (không dính closure cũ)", async () => {
    const calls = [];
    function Header() {
      const { config } = usePageHeader();
      return <button onClick={() => config.actions[0]?.onClick()}>run</button>;
    }
    function Page() {
      const [n, setN] = useState(0);
      useRegisterPageHeader({ title: "T", actions: [{ key: "a", label: "A", onClick: () => calls.push(n) }] });
      return <><button onClick={() => setN((x) => x + 1)}>inc</button><Header /></>;
    }
    render(<PageHeaderProvider><Page /></PageHeaderProvider>);
    await act(async () => { await sleep(20); });
    fireEvent.click(screen.getByText("inc"));
    fireEvent.click(screen.getByText("inc"));
    await act(async () => { await sleep(20); });
    fireEvent.click(screen.getByText("run"));
    expect(calls).toEqual([2]);
  });
});
