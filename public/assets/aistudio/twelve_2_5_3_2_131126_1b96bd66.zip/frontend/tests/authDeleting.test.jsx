// v2.2.0: AuthContext — tài khoản đang bị xoá (status "deleting") phải đăng xuất ngay và KHÔNG bị coi là "chưa kích hoạt" (nếu không,
// PendingSessionGate sẽ đẩy người dùng về /login để xác minh email), và tên thật không lọt vào state của app.
// Chạy: npx vitest run tests/authDeleting.test.jsx
import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, act, waitFor } from "@testing-library/react";

const m = vi.hoisted(() => ({ signOut: vi.fn(), getMe: vi.fn(), authCb: null, snapCb: null }));

vi.mock("firebase/auth", () => ({
  onAuthStateChanged: (_auth, cb) => { m.authCb = cb; return () => {}; },
  signOut: (...a) => m.signOut(...a),
}));
vi.mock("firebase/firestore", () => ({
  doc: () => ({}),
  onSnapshot: (_ref, ok) => { m.snapCb = ok; return () => {}; },
}));
vi.mock("../src/firebase", () => ({ auth: { currentUser: { emailVerified: true, reload: async () => {} } }, db: {} }));
vi.mock("../src/api/users.api", () => ({ getMe: (...a) => m.getMe(...a) }));
vi.mock("../src/api/auth.api", () => ({ syncActivation: vi.fn().mockResolvedValue({}) }));

import { AuthProvider, useAuth } from "../src/context/AuthContext";

function Probe() {
  const a = useAuth();
  return (
    <div>
      <span data-testid="flags">{JSON.stringify({ isLoggedIn: a.isLoggedIn, isPending: a.isPending, isDeleting: a.isDeleting })}</span>
      <span data-testid="profile">{JSON.stringify(a.profile)}</span>
    </div>
  );
}
const snap = (data) => ({ exists: () => true, data: () => data });
const mount = async () => {
  render(<AuthProvider><Probe /></AuthProvider>);
  await act(async () => { await m.authCb({ uid: "u1", emailVerified: true }); });
};
const flags = () => JSON.parse(screen.getByTestId("flags").textContent);

beforeEach(() => {
  m.signOut.mockReset().mockResolvedValue(undefined);
  m.getMe.mockReset().mockResolvedValue({ uid: "u1", status: "active", displayName: "A" });
});
afterEach(() => cleanup());

describe("AuthContext v2.2.0", () => {
  it("tên thật (fullName) trong dữ liệu realtime bị loại khỏi state của app; các field khác vẫn cập nhật", async () => {
    await mount();
    await act(async () => { m.snapCb(snap({ uid: "u1", status: "active", fullName: "Bí Mật Legacy", accountScore: 5 })); });
    const text = screen.getByTestId("profile").textContent;
    expect(text).not.toContain("Bí Mật Legacy");
    expect(text).not.toContain("fullName");
    expect(JSON.parse(text).accountScore).toBe(5);
    expect(flags().isLoggedIn).toBe(true);
    expect(m.signOut).not.toHaveBeenCalled();
  });

  it("status chuyển sang 'deleting' (thiết bị này hoặc thiết bị khác): đăng xuất ngay, và KHÔNG tính là pending", async () => {
    await mount();
    await act(async () => { m.snapCb(snap({ uid: "u1", status: "deleting" })); });
    await waitFor(() => expect(m.signOut).toHaveBeenCalled());
    expect(flags()).toEqual({ isLoggedIn: false, isPending: false, isDeleting: true });
  });

  it("status 'pending' vẫn là pending và KHÔNG bị đăng xuất (hành vi cũ không đổi)", async () => {
    m.getMe.mockResolvedValue({ uid: "u1", status: "pending" });
    await mount();
    await act(async () => { m.snapCb(snap({ uid: "u1", status: "pending" })); });
    expect(flags()).toEqual({ isLoggedIn: false, isPending: true, isDeleting: false });
    expect(m.signOut).not.toHaveBeenCalled();
  });

  it("getMe trả 403 ACCOUNT_DELETING: đăng xuất ngay, KHÔNG thử lại 3 lần, KHÔNG hiện lỗi 'không tải được hồ sơ'", async () => {
    m.getMe.mockRejectedValue({ message: "Tài khoản đang được xoá.", response: { status: 403, data: { code: "ACCOUNT_DELETING" } } });
    await mount();
    expect(m.getMe).toHaveBeenCalledTimes(1);
    expect(m.signOut).toHaveBeenCalledTimes(1);
  });
});
