// v2.5.3 — frontend cho bản vá bảo mật: TW-09 (hộp nhập lại mật khẩu cho 3 thao tác ghi của SA) và TW-11 (debugLog chỉ chạy ở DEV, che dữ liệu; getter không lộ đối tượng User).
// Chạy: npx vitest run tests/security253.test.jsx
import React from "react";
import fs from "node:fs";
import path from "node:path";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor } from "@testing-library/react";

// ================================================================ TW-11 — debugLog
const loadDebugLog = async ({ dev }) => {
  vi.resetModules();
  vi.stubEnv("DEV", dev);
  vi.stubEnv("PROD", !dev);
  return import("../src/utils/debugLog.js");
};

describe("TW-11: debugLog", () => {
  beforeEach(() => {
    sessionStorage.clear();
    delete globalThis.__TWELVE_AUTH_CURRENT__;
    vi.useFakeTimers();
  });
  afterEach(() => {
    vi.useRealTimers();
    vi.unstubAllEnvs();
  });

  it("PRODUCTION: no-op — không giữ nhật ký, không ghi sessionStorage, không console, không bật được; khoá cũ của bản ≤2.5.2 bị xoá", async () => {
    sessionStorage.setItem("twelve_debug_v1", JSON.stringify({ enabled: true, entries: [{ id: 1, message: "email victim@example.com", data: { email: "victim@example.com" } }] }));
    const spy = vi.spyOn(console, "log").mockImplementation(() => {});
    const mod = await loadDebugLog({ dev: false });
    expect(sessionStorage.getItem("twelve_debug_v1")).toBeNull(); // dọn dấu vết cũ
    expect(mod.dlog.info("auth", "login", { email: "a@b.com", uid: "abcdef123456", token: "t" })).toBeNull();
    mod.dlog.error("api", "boom", { data: { idToken: "eyJabcdefghij.klmnopqrstuv.wxyz" } });
    mod.setDebugEnabled(true);
    expect(mod.isDebugEnabled()).toBe(false);
    expect(mod.getDebugEntries()).toEqual([]);
    expect(mod.exportDebugLogText()).toBe("");
    vi.advanceTimersByTime(5000);
    expect(sessionStorage.getItem("twelve_debug_v1")).toBeNull();
    expect(spy).not.toHaveBeenCalled();
    spy.mockRestore();
  });

  it("PRODUCTION: registerAuthSnapshotGetter không đặt gì lên globalThis; snapshotAuth chỉ trả phần `extra` (không uid/email/href)", async () => {
    const mod = await loadDebugLog({ dev: false });
    const user = { uid: "u1", email: "a@b.com", getIdToken: vi.fn() };
    mod.registerAuthSnapshotGetter(() => user);
    expect(globalThis.__TWELVE_AUTH_CURRENT__).toBeUndefined();
    expect(mod.snapshotAuth({ note: "x" })).toEqual({ note: "x" });
    expect(user.getIdToken).not.toHaveBeenCalled();
  });

  it("DEV: vẫn ghi RAM + sessionStorage nhưng GHI TRỄ/gộp (không còn stringify trên mỗi lần ghi); xoá nhật ký có hiệu lực ngay", async () => {
    const mod = await loadDebugLog({ dev: true });
    const setItem = vi.spyOn(Storage.prototype, "setItem");
    for (let i = 0; i < 50; i++) mod.dlog.info("ui", `sự kiện ${i}`);
    expect(mod.getDebugEntries().length).toBeGreaterThanOrEqual(50);
    expect(setItem).not.toHaveBeenCalled(); // chưa tới hạn trễ
    vi.advanceTimersByTime(600);
    expect(setItem).toHaveBeenCalledTimes(1); // gộp 50 lần ghi thành 1
    expect(JSON.parse(sessionStorage.getItem("twelve_debug_v1")).entries.length).toBeGreaterThan(0);
    mod.clearDebugLog();
    expect(JSON.parse(sessionStorage.getItem("twelve_debug_v1")).entries).toEqual([]);
    setItem.mockRestore();
  });

  it("DEV: che password/token/idToken/refreshToken/captchaToken/Authorization/cookie; email → a***@host; uid → 4 ký tự; Bearer/JWT trong chuỗi bị che", async () => {
    const mod = await loadDebugLog({ dev: true });
    mod.clearDebugLog();
    mod.dlog.info("api", "gọi Bearer abc.def.ghi-123 thất bại", {
      password: "p",
      Authorization: "Bearer xyz",
      authorization: "Bearer xyz",
      token: "t1",
      idToken: "t2",
      refreshToken: "t3",
      accessToken: "t4",
      captchaToken: "t5",
      cookie: "sid=1",
      apiKey: "k",
      stsTokenManager: { refreshToken: "r" },
      email: "nguyen.van@example.com",
      uid: "AbCdEf1234567890",
      authorUid: "ZzYyXx9876543210",
      note: "JWT eyJhbGciOiJI.eyJzdWIiOiIx.abcdef là mã",
      nested: { deep: { captchaToken: "zzz", ok: "giữ nguyên" } },
    });
    const text = mod.exportDebugLogText();
    for (const secret of ["Bearer xyz", "t1", "t2", "t3", "t4", "t5", "sid=1", "nguyen.van", "AbCdEf1234567890", "ZzYyXx9876543210", "eyJhbGciOiJI", "abc.def.ghi-123", "zzz"]) {
      expect(text.includes(secret), `không được lộ: ${secret}`).toBe(false);
    }
    const last = mod.getDebugEntries().slice(-1)[0];
    expect(last.data.password).toBe("[redacted]");
    expect(last.data.email).toBe("n***@example.com");
    expect(last.data.uid).toBe("AbCd…");
    expect(last.data.authorUid).toBe("ZzYy…");
    expect(last.data.stsTokenManager).toBe("[redacted]");
    expect(last.data.nested.deep.captchaToken).toBe("[redacted]");
    expect(last.data.nested.deep.ok).toBe("giữ nguyên");
    expect(last.message).toContain("Bearer [redacted]");
    // Error: message cũng được che
    mod.dlog.error("api", "lỗi", new Error("fail with Bearer secret-token-value"));
    expect(mod.exportDebugLogText()).not.toContain("secret-token-value");
  });

  it("DEV: snapshotAuth dùng getter (bản chiếu) và `href` bỏ query/hash (có thể chứa oobCode); console in bản đã che", async () => {
    const mod = await loadDebugLog({ dev: true });
    mod.registerAuthSnapshotGetter(() => ({ uid: "u123456", email: "a@b.com", emailVerified: true }));
    window.history.pushState({}, "", "/verify?mode=verifyEmail&oobCode=SECRETCODE#frag");
    const snap = mod.snapshotAuth();
    expect(snap.hasCurrentUser).toBe(true);
    expect(snap.href).toMatch(/\/verify$/);
    expect(JSON.stringify(snap)).not.toContain("SECRETCODE");
    mod.setDebugEnabled(true);
    const spy = vi.spyOn(console, "log").mockImplementation(() => {});
    mod.dlog.info("auth", "x", { email: "person@example.com", token: "abc" });
    const printed = JSON.stringify(spy.mock.calls);
    expect(printed).not.toContain("person@");
    expect(printed).not.toContain('"abc"');
    spy.mockRestore();
  });
});

describe("TW-11: mã nguồn", () => {
  const read = (p) => fs.readFileSync(path.join(__dirname, "..", p), "utf8");

  it("AuthContext chỉ đăng ký getter ở DEV và không trả nguyên đối tượng Firebase `User`", () => {
    const src = read("src/context/AuthContext.jsx");
    expect(src).not.toMatch(/registerAuthSnapshotGetter\(\s*\(\)\s*=>\s*auth\.currentUser\s*\)/);
    const i = src.indexOf("registerAuthSnapshotGetter(");
    expect(i).toBeGreaterThan(-1);
    expect(src.slice(Math.max(0, i - 120), i)).toMatch(/import\.meta\.env\.DEV/);
    const body = src.slice(i, src.indexOf("});", i));
    expect(body).toMatch(/uid:\s*u\.uid/);
    expect(body).not.toMatch(/getIdToken|accessToken|stsTokenManager/);
  });

  it("không nơi nào khác đặt __TWELVE_AUTH_CURRENT__ hoặc gọi sessionStorage với khoá debug", () => {
    const hits = [];
    const walk = (d) =>
      fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
        const p = path.join(d, e.name);
        if (e.isDirectory()) return walk(p);
        if (!/\.(jsx?|mjs)$/.test(e.name)) return;
        const src = fs.readFileSync(p, "utf8");
        const rel = path.relative(path.join(__dirname, ".."), p);
        if (/__TWELVE_AUTH_CURRENT__\s*=/.test(src) && !rel.endsWith("debugLog.js")) hits.push(`${rel}: đặt getter`);
        if (/twelve_debug_v1/.test(src) && !rel.endsWith("debugLog.js")) hits.push(`${rel}: khoá debug`);
      });
    walk(path.join(__dirname, "..", "src"));
    expect(hits).toEqual([]);
  });
});

// ================================================================ TW-09 — hộp nhập lại mật khẩu
const m = vi.hoisted(() => ({ reauth: vi.fn(), snack: { success: vi.fn(), error: vi.fn(), warning: vi.fn(), info: vi.fn() }, updateEmbed: vi.fn(), resetCsp: vi.fn(), getCsp: vi.fn(), getEmbed: vi.fn(), getRescan: vi.fn(), updateFonts: vi.fn(), getFonts: vi.fn(), refresh: vi.fn() }));
vi.mock("../src/utils/reauth", () => ({
  reauthWithPassword: (...a) => m.reauth(...a),
  describeAuthError: (e) => (e && e.message) || "lỗi",
  isReauthRequired: (err) => err?.response?.data?.code === "REAUTH_REQUIRED",
}));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => m.snack }));
vi.mock("../src/api/admin.api", () => ({
  updateEmbedDomains: (...a) => m.updateEmbed(...a),
  resetCspReports: (...a) => m.resetCsp(...a),
  getCspReports: (...a) => m.getCsp(...a),
  getEmbedDomains: (...a) => m.getEmbed(...a),
  getEmbedRescanStatus: (...a) => m.getRescan(...a),
}));
vi.mock("../src/api/fonts.api", () => ({ getAdminFonts: (...a) => m.getFonts(...a), updateAdminFonts: (...a) => m.updateFonts(...a), getPublicFonts: vi.fn() }));
vi.mock("../src/context/ThemeModeContext", () => ({ useThemeMode: () => ({ refreshServerFonts: m.refresh }) }));

import useReauthRetry from "../src/hooks/useReauthRetry";
import AdminCspReportsPanel from "../src/pages/settings/AdminCspReportsPanel";
import AdminEmbedDomainsPanel from "../src/pages/settings/AdminEmbedDomainsPanel";
import AdminFontsPanel from "../src/pages/settings/AdminFontsPanel";

const reauthErr = () => ({ message: "Cần nhập lại mật khẩu để thực hiện thao tác này.", response: { status: 403, data: { code: "REAUTH_REQUIRED" } } });
const plainErr = (msg) => ({ message: msg, response: { status: 400, data: { error: msg } } });

function Harness({ fn, onOk, onErr }) {
  const { run, reauthDialog } = useReauthRetry({ title: "Hộp thử", confirmText: "Đồng ý" });
  return (
    <div>
      <button onClick={() => run(fn).then(onOk).catch(onErr)}>chạy</button>
      {reauthDialog}
    </div>
  );
}
const typePassword = (v) => fireEvent.change(screen.getByLabelText(/Mật khẩu hiện tại/), { target: { value: v } });

describe("TW-09: useReauthRetry", () => {
  beforeEach(() => {
    Object.values(m).forEach((f) => f && f.mockReset && f.mockReset());
    Object.values(m.snack).forEach((f) => f.mockReset());
    m.reauth.mockResolvedValue(undefined);
  });
  afterEach(() => cleanup());

  it("thành công ngay (không cần mật khẩu) → không mở hộp", async () => {
    const fn = vi.fn().mockResolvedValue("ok");
    const onOk = vi.fn();
    render(<Harness fn={fn} onOk={onOk} onErr={vi.fn()} />);
    fireEvent.click(screen.getByText("chạy"));
    await waitFor(() => expect(onOk).toHaveBeenCalledWith("ok"));
    expect(screen.queryByText("Hộp thử")).toBeNull();
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it("REAUTH_REQUIRED → mở hộp; nhập mật khẩu đúng → xác thực lại, chạy LẠI đúng thao tác và trả kết quả lần chạy lại", async () => {
    const fn = vi.fn().mockRejectedValueOnce(reauthErr()).mockResolvedValueOnce({ saved: true });
    const onOk = vi.fn();
    render(<Harness fn={fn} onOk={onOk} onErr={vi.fn()} />);
    fireEvent.click(screen.getByText("chạy"));
    await screen.findByText("Hộp thử");
    expect(onOk).not.toHaveBeenCalled();
    typePassword("matkhau123");
    fireEvent.click(screen.getByText("Đồng ý"));
    await waitFor(() => expect(onOk).toHaveBeenCalledWith({ saved: true }));
    expect(m.reauth).toHaveBeenCalledWith("matkhau123");
    expect(fn).toHaveBeenCalledTimes(2);
    await waitFor(() => expect(screen.queryByText("Hộp thử")).toBeNull());
  });

  it("mật khẩu sai → báo trong hộp, KHÔNG chạy lại thao tác; thử lại đúng thì chạy", async () => {
    m.reauth.mockRejectedValueOnce(new Error("Mật khẩu không đúng.")).mockResolvedValueOnce(undefined);
    const fn = vi.fn().mockRejectedValueOnce(reauthErr()).mockResolvedValueOnce("done");
    const onOk = vi.fn();
    render(<Harness fn={fn} onOk={onOk} onErr={vi.fn()} />);
    fireEvent.click(screen.getByText("chạy"));
    await screen.findByText("Hộp thử");
    typePassword("sai");
    fireEvent.click(screen.getByText("Đồng ý"));
    await screen.findByText("Mật khẩu không đúng.");
    expect(fn).toHaveBeenCalledTimes(1);
    typePassword("dung");
    fireEvent.click(screen.getByText("Đồng ý"));
    await waitFor(() => expect(onOk).toHaveBeenCalledWith("done"));
  });

  it("Hủy hộp → promise bị từ chối với reauthCancelled (caller bỏ qua, không hiện lỗi)", async () => {
    const fn = vi.fn().mockRejectedValue(reauthErr());
    const onErr = vi.fn();
    render(<Harness fn={fn} onOk={vi.fn()} onErr={onErr} />);
    fireEvent.click(screen.getByText("chạy"));
    await screen.findByText("Hộp thử");
    fireEvent.click(screen.getByText("Hủy"));
    await waitFor(() => expect(onErr).toHaveBeenCalled());
    expect(onErr.mock.calls[0][0].reauthCancelled).toBe(true);
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it("lỗi KHÁC (400…) ném lại nguyên vẹn, không mở hộp; lỗi ở lần chạy lại hiện trong hộp", async () => {
    const onErr = vi.fn();
    render(<Harness fn={vi.fn().mockRejectedValue(plainErr("Dữ liệu sai"))} onOk={vi.fn()} onErr={onErr} />);
    fireEvent.click(screen.getByText("chạy"));
    await waitFor(() => expect(onErr).toHaveBeenCalled());
    expect(onErr.mock.calls[0][0].message).toBe("Dữ liệu sai");
    expect(screen.queryByText("Hộp thử")).toBeNull();
    cleanup();

    const fn2 = vi.fn().mockRejectedValueOnce(reauthErr()).mockRejectedValueOnce(plainErr("Domain không hợp lệ"));
    render(<Harness fn={fn2} onOk={vi.fn()} onErr={vi.fn()} />);
    fireEvent.click(screen.getByText("chạy"));
    await screen.findByText("Hộp thử");
    typePassword("x");
    fireEvent.click(screen.getByText("Đồng ý"));
    await screen.findByText("Domain không hợp lệ"); // hiện trong hộp, hộp giữ nguyên
    expect(screen.getByText("Hộp thử")).toBeTruthy();
  });
});

describe("TW-09: ba panel quản trị dùng hộp mật khẩu khi backend đòi", () => {
  beforeEach(() => {
    Object.values(m).forEach((f) => f && f.mockReset && f.mockReset());
    Object.values(m.snack).forEach((f) => f.mockReset());
    m.reauth.mockResolvedValue(undefined);
    m.getRescan.mockResolvedValue({ status: "idle" });
  });
  afterEach(() => cleanup());

  it("Báo cáo CSP: 'Bắt đầu lại' → 403 REAUTH_REQUIRED → hộp mật khẩu → chạy lại → thành công; Hủy thì không hiện snackbar lỗi", async () => {
    m.getCsp.mockResolvedValue({ startedAt: Date.now(), total: 3, uniqueViolations: 1, ignoredExtensions: 0, overflow: 0, throttled: 0, entries: [] });
    m.resetCsp.mockRejectedValueOnce(reauthErr()).mockResolvedValueOnce({ ok: true });
    render(<AdminCspReportsPanel />);
    fireEvent.click(await screen.findByText("Bắt đầu lại cửa sổ quan sát"));
    await screen.findByText("Xác nhận để đặt lại báo cáo CSP");
    typePassword("pw");
    fireEvent.click(screen.getByText("Xác nhận và đặt lại"));
    await waitFor(() => expect(m.snack.success).toHaveBeenCalledWith("Đã bắt đầu lại cửa sổ quan sát."));
    expect(m.resetCsp).toHaveBeenCalledTimes(2);

    m.resetCsp.mockReset();
    m.resetCsp.mockRejectedValue(reauthErr());
    fireEvent.click(await screen.findByText("Bắt đầu lại cửa sổ quan sát"));
    await screen.findByText("Xác nhận để đặt lại báo cáo CSP");
    fireEvent.click(screen.getByText("Hủy"));
    await new Promise((r) => setTimeout(r, 30));
    expect(m.snack.error).not.toHaveBeenCalled();
  });

  it("Domain nhúng: Lưu → REAUTH_REQUIRED → hộp mật khẩu → lưu lại thành công", async () => {
    m.getEmbed.mockResolvedValue({ enabled: true, domains: [{ domain: "youtube.com", label: "" }] });
    m.updateEmbed.mockRejectedValueOnce(reauthErr()).mockResolvedValueOnce({ enabled: true, domains: [{ domain: "youtube.com" }], rescan: { running: false, scanned: 0, modified: 0, skipped: 0, failed: 0 } });
    render(<AdminEmbedDomainsPanel />);
    const save = await screen.findByRole("button", { name: /Lưu/ });
    fireEvent.click(save);
    await screen.findByText("Xác nhận để lưu domain nhúng");
    typePassword("pw");
    fireEvent.click(screen.getByText("Xác nhận và lưu"));
    await waitFor(() => expect(m.snack.success).toHaveBeenCalledWith("Đã lưu cấu hình domain nhúng."));
    expect(m.updateEmbed).toHaveBeenCalledTimes(2);
    expect(m.updateEmbed.mock.calls[1][0]).toEqual(m.updateEmbed.mock.calls[0][0]); // chạy lại ĐÚNG dữ liệu cũ
  });

  it("Font: Lưu danh sách → REAUTH_REQUIRED → hộp mật khẩu → lưu lại thành công", async () => {
    const data = { fonts: [], availableFiles: [], visibleCount: 0, limits: { maxFonts: 20 } };
    m.getFonts.mockResolvedValue(data);
    m.updateFonts.mockRejectedValueOnce(reauthErr()).mockResolvedValueOnce(data);
    render(<AdminFontsPanel />);
    fireEvent.click(await screen.findByText("Lưu danh sách font"));
    await screen.findByText("Xác nhận để lưu font");
    typePassword("pw");
    fireEvent.click(screen.getByText("Xác nhận và lưu"));
    await waitFor(() => expect(m.snack.success).toHaveBeenCalledWith("Đã lưu danh sách font."));
    expect(m.updateFonts).toHaveBeenCalledTimes(2);
    expect(m.refresh).toHaveBeenCalled();
  });
});
