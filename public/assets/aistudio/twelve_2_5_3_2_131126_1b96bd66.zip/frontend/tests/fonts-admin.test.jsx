import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, cleanup, waitFor, act } from "@testing-library/react";

// "Server" giả: giữ danh sách font SA đã lưu, API công khai/quản trị đọc cùng một nguồn.
let saved = [];
let publicFail = false;
let adminFail = false;
const toPublic = (e) => ({ id: e.id, label: e.label, url: e.url, relative: false, format: "woff2", weight: e.weight || "100 900", note: "" });
vi.mock("../src/api/fonts.api", () => ({
  getPublicFonts: vi.fn(() => (publicFail ? Promise.reject({ message: "Mất kết nối" }) : Promise.resolve({ fonts: saved.map(toPublic) }))),
  getAdminFonts: vi.fn(() => (adminFail ? Promise.reject({ message: "Not found" }) : Promise.resolve({ fonts: saved.map((e) => ({ ...e, visible: true, hiddenReason: null })), availableFiles: [{ name: "dep.woff2", size: 2048 }], visibleCount: saved.length, limits: { maxFonts: 20 } }))),
  updateAdminFonts: vi.fn((fonts) => {
    saved = fonts.map((f, i) => ({ ...f, id: f.id || `srv-${i}${Date.now()}`, kind: f.kind }));
    return Promise.resolve({ fonts: saved.map((e) => ({ ...e, visible: true, hiddenReason: null })), availableFiles: [{ name: "dep.woff2", size: 2048 }], visibleCount: saved.length, limits: { maxFonts: 20 } });
  }),
}));
vi.mock("../src/api/client", () => ({ default: { defaults: { baseURL: "https://api.example.com/api" } } }));
// v2.5.3 [TW-09]: AdminFontsPanel giờ dùng hộp nhập lại mật khẩu (hooks/useReauthRetry → PasswordConfirmDialog → utils/reauth → ../firebase). Mock utils/reauth để test không khởi tạo Firebase thật (thiếu API key trong môi trường test).
vi.mock("../src/utils/reauth", () => ({ reauthWithPassword: vi.fn(), describeAuthError: (e) => (e && e.message) || "lỗi", isReauthRequired: (err) => err?.response?.data?.code === "REAUTH_REQUIRED" }));
const snack = { success: vi.fn(), error: vi.fn() };
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => snack }));

import { ThemeModeProvider } from "../src/context/ThemeModeContext";
import FontGroupPanel from "../src/pages/settings/FontGroupPanel";
import AdminFontsPanel from "../src/pages/settings/AdminFontsPanel";

class FakeFontFace { constructor(f, s, d) { this.family = f; } load() { return Promise.resolve(this); } }
beforeEach(() => {
  saved = []; publicFail = false; adminFail = false;
  snack.success.mockClear(); snack.error.mockClear();
  localStorage.clear();
  globalThis.FontFace = FakeFontFace;
  Object.defineProperty(document, "fonts", { configurable: true, value: { add: vi.fn() } });
  vi.spyOn(console, "error").mockImplementation(() => {});
});
afterEach(() => { cleanup(); vi.restoreAllMocks(); });

describe("font server hiển thị đúng ở Quản trị và Ứng dụng", () => {
  it("SA thêm font ở Quản trị => Ứng dụng thấy NGAY (không cần tải lại trang)", async () => {
    render(
      <ThemeModeProvider>
        <AdminFontsPanel />
        <FontGroupPanel source="server" />
      </ThemeModeProvider>
    );
    await waitFor(() => expect(screen.getByText("Chưa có font nào.")).toBeTruthy());
    await waitFor(() => expect(screen.getByText("Quản trị viên chưa cài font nào.")).toBeTruthy()); // nhóm server còn trống

    fireEvent.change(screen.getByLabelText("Link file font (https://…)"), { target: { value: "https://cdn.example.com/moi.woff2" } });
    fireEvent.change(screen.getAllByLabelText("Tên hiển thị")[0], { target: { value: "Font Mới Của SA" } });
    fireEvent.click(screen.getByText("Thêm từ link"));
    fireEvent.click(screen.getByText("Lưu danh sách font"));

    await waitFor(() => expect(snack.success).toHaveBeenCalled());
    await waitFor(() => expect(screen.queryByText("Quản trị viên chưa cài font nào.")).toBeNull());
    expect(screen.getAllByText("Font Mới Của SA").length).toBeGreaterThan(0); // hiện trong danh sách Ứng dụng
    expect(screen.getByDisplayValue("Font Mới Của SA")).toBeTruthy(); // và vẫn còn ở panel Quản trị
  });

  it("mở lại mục Ứng dụng lấy danh sách mới (font SA thêm sau khi app đã mở)", async () => {
    const { rerender } = render(<ThemeModeProvider><div /></ThemeModeProvider>);
    await act(async () => {});
    saved = [{ id: "srv-late", label: "Font Đến Muộn", kind: "url", url: "https://cdn.example.com/late.woff2" }];
    rerender(<ThemeModeProvider><FontGroupPanel source="server" /></ThemeModeProvider>);
    await waitFor(() => expect(screen.getAllByText("Font Đến Muộn").length).toBeGreaterThan(0));
  });

  it("lỗi tải danh sách font server => cảnh báo rõ ràng + nút Thử lại (không im lặng)", async () => {
    publicFail = true;
    render(<ThemeModeProvider><FontGroupPanel source="server" /></ThemeModeProvider>);
    await waitFor(() => expect(screen.getByText(/Không tải được danh sách font do quản trị viên cài/)).toBeTruthy());
    expect(screen.getByText(/Mất kết nối/)).toBeTruthy();
    publicFail = false;
    saved = [{ id: "srv-x", label: "Font X", kind: "url", url: "https://cdn.example.com/x.woff2" }];
    fireEvent.click(screen.getByText("Thử lại"));
    await waitFor(() => expect(screen.getAllByText("Font X").length).toBeGreaterThan(0));
    expect(screen.queryByText(/Không tải được danh sách font do quản trị viên cài/)).toBeNull();
  });

  it("Quản trị: lỗi tải cấu hình hiện thông báo ngay trên trang, không giả vờ 'Chưa có font'", async () => {
    adminFail = true;
    render(<ThemeModeProvider><AdminFontsPanel /></ThemeModeProvider>);
    await waitFor(() => expect(screen.getByText(/Không tải được cấu hình font: Not found/)).toBeTruthy());
    expect(screen.queryByText("Chưa có font nào.")).toBeNull();
  });

  it("Quản trị: hiện số font đang hiển thị với người dùng", async () => {
    saved = [{ id: "srv-1", label: "Một", kind: "url", url: "https://cdn.example.com/1.woff2", weight: "100 900" }];
    render(<ThemeModeProvider><AdminFontsPanel /></ThemeModeProvider>);
    await waitFor(() => expect(screen.getByText(/đang hiển thị với người dùng: 1/)).toBeTruthy());
  });
});
