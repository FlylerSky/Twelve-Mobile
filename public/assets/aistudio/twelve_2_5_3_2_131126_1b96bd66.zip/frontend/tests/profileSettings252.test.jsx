// v2.5.2 — Cài đặt > Tài khoản > Thông tin: ô Tiểu sử (Bio) và thẻ "Thông tin mở rộng" (công tắc chọn mục hiện trong hộp "Xem thêm").
// Chạy: npx vitest run tests/profileSettings252.test.jsx
import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor, act, within } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

const m = vi.hoisted(() => ({
  updateMe: vi.fn(),
  updateProfileExtras: vi.fn(),
  refreshProfile: vi.fn(),
  snack: { success: vi.fn(), error: vi.fn(), warning: vi.fn(), info: vi.fn() },
}));
let authState;

vi.mock("../src/utils/reauth", () => ({ reauthWithPassword: vi.fn(), describeAuthError: (e) => (e && e.message) || "lỗi" }));
vi.mock("../src/api/users.api", () => ({
  getRealName: vi.fn(),
  updateRealName: vi.fn(),
  updateTagName: vi.fn(),
  requestAccountDeletion: vi.fn(),
  updateMe: (...a) => m.updateMe(...a),
  uploadAvatar: vi.fn(),
  updateProfileExtras: (...a) => m.updateProfileExtras(...a),
}));
vi.mock("../src/api/auth.api", () => ({ forgotPassword: vi.fn(), checkTagName: vi.fn() }));
vi.mock("../src/api/countries.api", () => ({ listCountries: () => Promise.resolve([{ code: "VN", name: "Việt Nam" }]) }));
vi.mock("../src/context/AuthContext", () => ({ useAuth: () => authState }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => m.snack }));
vi.mock("firebase/auth", () => ({ updatePassword: vi.fn() }));
vi.mock("../src/firebase", () => ({ auth: { currentUser: { email: "me@example.com" } } }));
vi.mock("../src/components/AvatarCropper", () => ({ default: () => null }));

import AccountInfoPanel from "../src/pages/settings/AccountInfoPanel";
import ProfileExtrasCard from "../src/pages/settings/ProfileExtrasCard";
import { EXTRA_FIELDS } from "../src/utils/profileExtras";
import { BIO_MAX } from "../src/utils/bio";

const BASE_PROFILE = { uid: "u1", displayName: "Văn A", tagName: "@vana", birthday: "2000-01-01", gender: "male", country: "VN", avatarUrl: null };
const sw = (key) => screen.getByTestId(`extra-switch-${key}`);
const btn = (name) => screen.getByRole("button", { name });

beforeEach(() => {
  m.updateMe.mockReset();
  m.updateProfileExtras.mockReset();
  m.refreshProfile.mockReset().mockResolvedValue(undefined);
  Object.values(m.snack).forEach((f) => f.mockReset());
  authState = { firebaseUser: { email: "me@example.com" }, profile: { ...BASE_PROFILE }, isSA: false, signOut: vi.fn(), refreshProfile: m.refreshProfile };
});
afterEach(cleanup);

const renderCard = () => render(<ProfileExtrasCard />);
const renderPanel = () => render(<MemoryRouter><AccountInfoPanel /></MemoryRouter>);

// ======================================================================== Thông tin mở rộng
describe("ProfileExtrasCard — Thông tin mở rộng", () => {
  it("chưa từng chỉnh: công tắc ở MẶC ĐỊNH (bật thứ vốn công khai; TẮT ngày sinh/giới tính/trạng thái/UID); 4 mục riêng tư có nhãn 'Riêng tư'", () => {
    renderCard();
    expect(EXTRA_FIELDS.length).toBe(9);
    for (const k of ["displayName", "accountGroup", "accountRole", "createdAt", "achievements"]) expect(sw(k).checked, k).toBe(true);
    for (const k of ["birthday", "gender", "status", "uid"]) expect(sw(k).checked, k).toBe(false);
    expect(screen.getAllByText("Riêng tư").length).toBe(4);
    for (const k of ["birthday", "gender", "status", "uid"]) expect(within(screen.getByTestId(`extra-row-${k}`)).getByText("Riêng tư")).toBeTruthy();
    expect(within(screen.getByTestId("extra-row-displayName")).queryByText("Riêng tư")).toBeNull();
  });

  it("giá trị đã lưu trong hồ sơ ghi đè mặc định; giá trị hỏng (không phải boolean) thì dùng mặc định", () => {
    authState.profile.profileExtras = { birthday: true, achievements: false, gender: "true", rac: true };
    renderCard();
    expect(sw("birthday").checked).toBe(true);
    expect(sw("achievements").checked).toBe(false);
    expect(sw("gender").checked).toBe(false);
  });

  it("công tắc có TÊN TRUY CẬP mô tả việc nó làm (không trùng nhãn ô nhập 'Tên hiển thị')", () => {
    renderCard();
    expect(screen.getByLabelText("Hiện Tên hiển thị trong hộp Xem thêm")).toBe(sw("displayName"));
    expect(screen.getByLabelText("Hiện Ngày sinh trong hộp Xem thêm")).toBe(sw("birthday"));
  });

  it("bật một mục: ÁP DỤNG NGAY (không cần nút Lưu), gửi RIÊNG khoá đó, công tắc đổi ngay và khoá trong lúc gửi, giữ nguyên khi hồ sơ realtime chưa kịp cập nhật", async () => {
    let finish;
    m.updateProfileExtras.mockReturnValue(new Promise((r) => { finish = r; }));
    renderCard();
    expect(screen.queryByRole("button", { name: /Lưu/ })).toBeNull();
    fireEvent.click(sw("birthday"));
    expect(m.updateProfileExtras).toHaveBeenCalledTimes(1);
    expect(m.updateProfileExtras).toHaveBeenCalledWith({ birthday: true });
    expect(sw("birthday").checked).toBe(true); // lạc quan
    expect(sw("birthday").disabled).toBe(true); // không bấm chồng trong lúc gửi
    expect(sw("gender").disabled).toBe(false); // mục khác vẫn dùng được
    await act(async () => finish({ birthday: true }));
    await waitFor(() => expect(sw("birthday").disabled).toBe(false));
    expect(sw("birthday").checked).toBe(true); // hồ sơ realtime CHƯA cập nhật (authState cũ) mà công tắc không nhảy về tắt
    expect(m.snack.error).not.toHaveBeenCalled();
  });

  it("khi hồ sơ realtime theo kịp thì vẫn đúng; sau đó đổi từ thiết bị khác cũng phản ánh ở đây", async () => {
    m.updateProfileExtras.mockResolvedValue({});
    const { rerender } = renderCard();
    fireEvent.click(sw("birthday"));
    await waitFor(() => expect(sw("birthday").disabled).toBe(false));
    authState = { ...authState, profile: { ...authState.profile, profileExtras: { birthday: true } } };
    rerender(<ProfileExtrasCard />);
    expect(sw("birthday").checked).toBe(true);
    // thiết bị khác tắt lại
    authState = { ...authState, profile: { ...authState.profile, profileExtras: { birthday: false } } };
    rerender(<ProfileExtrasCard />);
    expect(sw("birthday").checked).toBe(false);
  });

  it("TẮT một mục đang bật (vd. Thành tích): gửi { achievements: false }", async () => {
    m.updateProfileExtras.mockResolvedValue({});
    renderCard();
    fireEvent.click(sw("achievements"));
    expect(m.updateProfileExtras).toHaveBeenCalledWith({ achievements: false });
    expect(sw("achievements").checked).toBe(false);
  });

  it("lỗi từ máy chủ: công tắc QUAY LẠI trạng thái cũ + báo lỗi (không để giao diện nói dối về thứ đang công khai)", async () => {
    m.updateProfileExtras.mockRejectedValue({ message: "Bạn đang chỉnh thông tin mở rộng quá nhanh." });
    renderCard();
    fireEvent.click(sw("birthday"));
    await waitFor(() => expect(m.snack.error).toHaveBeenCalledWith("Bạn đang chỉnh thông tin mở rộng quá nhanh."));
    await waitFor(() => expect(sw("birthday").checked).toBe(false));
    expect(sw("birthday").disabled).toBe(false);
  });

  it("lỗi không có thông điệp: dùng câu dự phòng", async () => {
    m.updateProfileExtras.mockRejectedValue({});
    renderCard();
    fireEvent.click(sw("uid"));
    await waitFor(() => expect(m.snack.error).toHaveBeenCalledWith("Không lưu được thay đổi."));
    expect(sw("uid").checked).toBe(false);
  });

  it("giải thích rõ ranh giới: mục riêng tư chỉ lộ khi bật; mục khác chỉ ẩn khỏi hộp 'Xem thêm'", () => {
    renderCard();
    const card = screen.getByTestId("profile-extras-card");
    expect(card.textContent).toContain("mặc định tắt và chỉ được chia sẻ khi bạn bật");
    expect(card.textContent).toContain("chỉ ẩn chúng khỏi hộp");
  });
});

// ======================================================================== Tiểu sử trong form Thông tin
describe("AccountInfoPanel — Tiểu sử (Bio)", () => {
  const bio = () => screen.getByTestId("bio-input");

  it("hiện tiểu sử hiện có; 'Lưu thay đổi' khoá khi chưa sửa; sửa → chỉ gửi ĐÚNG trường bio", async () => {
    authState.profile.bio = "Xin chào!";
    m.updateMe.mockResolvedValue({});
    renderPanel();
    expect(bio().value).toBe("Xin chào!");
    expect(btn("Lưu thay đổi").disabled).toBe(true);
    fireEvent.change(bio(), { target: { value: "Tiểu sử mới\nDòng hai" } });
    expect(btn("Lưu thay đổi").disabled).toBe(false);
    fireEvent.click(btn("Lưu thay đổi"));
    await waitFor(() => expect(m.updateMe).toHaveBeenCalledWith({ bio: "Tiểu sử mới\nDòng hai" }));
    await waitFor(() => expect(btn("Lưu thay đổi").disabled).toBe(true));
  });

  it("hồ sơ chưa có bio: ô trống; xoá hết tiểu sử → gửi chuỗi rỗng (= xoá)", async () => {
    m.updateMe.mockResolvedValue({});
    renderPanel();
    expect(bio().value).toBe("");
    fireEvent.change(bio(), { target: { value: "tạm" } });
    fireEvent.click(btn("Lưu thay đổi"));
    await waitFor(() => expect(m.updateMe).toHaveBeenCalledWith({ bio: "tạm" }));
    m.updateMe.mockClear();
    fireEvent.change(bio(), { target: { value: "" } });
    fireEvent.click(btn("Lưu thay đổi"));
    await waitFor(() => expect(m.updateMe).toHaveBeenCalledWith({ bio: "" }));
  });

  it("sửa cả tên lẫn bio: gửi cả hai và chỉ hai trường đó", async () => {
    m.updateMe.mockResolvedValue({});
    renderPanel();
    fireEvent.change(screen.getByLabelText("Tên hiển thị"), { target: { value: "Văn B" } });
    fireEvent.change(bio(), { target: { value: "Ghi chú" } });
    fireEvent.click(btn("Lưu thay đổi"));
    await waitFor(() => expect(m.updateMe).toHaveBeenCalledWith({ displayName: "Văn B", bio: "Ghi chú" }));
  });

  it("đếm ký tự trực tiếp; quá giới hạn → báo lỗi và KHOÁ nút Lưu (không gửi lên rồi mới bị từ chối)", () => {
    renderPanel();
    fireEvent.change(bio(), { target: { value: "Xin chào" } });
    expect(screen.getByText(new RegExp(`8/${BIO_MAX} ký tự`))).toBeTruthy();
    expect(bio().getAttribute("aria-invalid")).not.toBe("true");
    fireEvent.change(bio(), { target: { value: "a".repeat(BIO_MAX + 1) } });
    expect(bio().getAttribute("aria-invalid")).toBe("true");
    expect(btn("Lưu thay đổi").disabled).toBe(true);
    fireEvent.change(bio(), { target: { value: "a".repeat(BIO_MAX) } });
    expect(bio().getAttribute("aria-invalid")).not.toBe("true");
    expect(btn("Lưu thay đổi").disabled).toBe(false);
  });

  it("quá số dòng → báo rõ số dòng và khoá nút Lưu; dòng trống liên tiếp không bị tính oan", () => {
    renderPanel();
    fireEvent.change(bio(), { target: { value: Array.from({ length: 7 }, (_, i) => `d${i}`).join("\n") } });
    expect(screen.getByText(/Tối đa 6 dòng \(hiện 7 dòng\)/)).toBeTruthy();
    expect(btn("Lưu thay đổi").disabled).toBe(true);
    fireEvent.change(bio(), { target: { value: "a\n\n\n\n\n\n\n\n\nb" } }); // 10 dòng thô nhưng backend gộp còn 3
    expect(btn("Lưu thay đổi").disabled).toBe(false);
  });

  it("hồ sơ realtime cập nhật (điểm số…) KHÔNG ghi đè tiểu sử đang gõ dở", () => {
    const { rerender } = renderPanel();
    fireEvent.change(bio(), { target: { value: "Đang gõ dở" } });
    authState = { ...authState, profile: { ...authState.profile, accountScore: 99 } };
    rerender(<MemoryRouter><AccountInfoPanel /></MemoryRouter>);
    expect(bio().value).toBe("Đang gõ dở");
  });

  it("thẻ 'Thông tin mở rộng' nằm ngay trong mục Thông tin; ô 'Tên hiển thị' vẫn chỉ có MỘT điều khiển cùng tên", () => {
    renderPanel();
    expect(screen.getByTestId("profile-extras-card")).toBeTruthy();
    expect(screen.getByText("Thông tin mở rộng")).toBeTruthy();
    expect(screen.getByLabelText("Tên hiển thị").tagName).toBe("INPUT");
    expect(screen.getByLabelText("Tên hiển thị").type).toBe("text");
  });
});
