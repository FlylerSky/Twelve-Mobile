// v2.4.2.1 — URL hồ sơ dùng TAG NAME SEARCH (/u/@<tag>) thay cho UID (/u/<UID>): không lộ UID, ngắn gọn; link UID cũ vẫn chạy và được chuyển sang URL tag.
// "@" bắt buộc (phân định với /u/myProfile và route phụ sau này). Hồ sơ của người đang đăng nhập = /u/myProfile (đổi Tag Name xong bấm Back không bị "không tìm thấy").
// Chạy: npx vitest run tests/profileUrl2421.test.jsx
import React from "react";
import fs from "node:fs";
import path from "node:path";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor, act } from "@testing-library/react";
import { MemoryRouter, Routes, Route, useLocation, useNavigate, useNavigationType } from "react-router-dom";

const m = vi.hoisted(() => ({
  snack: { success: vi.fn(), error: vi.fn(), info: vi.fn(), warning: vi.fn() },
  getPublicProfile: vi.fn(),
  getPublicProfileByTag: vi.fn(),
  listPinnedPosts: vi.fn(),
  listUserPosts: vi.fn(),
  seo: [],
  header: { current: null },
}));
let authState;

vi.mock("../src/context/AuthContext", () => ({ useAuth: () => authState }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => m.snack }));
vi.mock("../src/components/Navbar", () => ({ default: () => <nav>NAVBAR</nav> }));
vi.mock("../src/hooks/useSeo", () => ({ default: (cfg) => void m.seo.push(cfg) }));
vi.mock("../src/context/PageHeaderContext", () => ({
  useRegisterPageHeader: (cfg) => {
    m.header.current = cfg;
  },
}));
vi.mock("../src/api/content.api", () => ({ postsApi: { pin: vi.fn(), unpin: vi.fn() }, blogsApi: {} }));
vi.mock("../src/api/users.api", () => ({
  getPublicProfile: (...a) => m.getPublicProfile(...a),
  getPublicProfileByTag: (...a) => m.getPublicProfileByTag(...a),
  listPinnedPosts: (...a) => m.listPinnedPosts(...a),
  listUserPosts: (...a) => m.listUserPosts(...a),
  recordProfileVisit: () => Promise.resolve({ recorded: true }), // v2.5.2: trang tự báo lượt ghé thăm khi người đã đăng nhập xem hồ sơ người khác
}));
vi.mock("../src/components/PostCardList", () => ({ default: () => <div data-testid="cards" /> }));
vi.mock("../src/components/FeedList", () => ({ default: () => <div data-testid="feed" /> }));

import PublicProfilePage from "../src/pages/PublicProfilePage";
import { UserAvatar, UserName, UserTagChip } from "../src/components/UserIdentity";
import { profilePath, classifyProfileRef, normalizeTag, isValidTag, SELF_PROFILE_PATH, SELF_PROFILE_SEGMENT } from "../src/utils/profilePath";

const LEGACY_UID = "EZRxcGpJUEcSAuFfElxj8ja8KQ22";
const MY_UID = "MyFirebaseUid0123456789AB"; // UID thật dài 28 ký tự, có chữ hoa => không bao giờ giống Tag Name
const ME = { uid: MY_UID, displayName: "Tôi", tagName: "toi_day", accountRole: "user", pinnedPostIds: [] }; // /users/me: tagName KHÔNG có "@"
const LAN = { uid: LEGACY_UID, displayName: "Lan", tagName: "@lan_vu", accountRole: "user", badges: [], country: "VN", coverUrl: null, avatarUrl: null };

beforeEach(() => {
  [m.getPublicProfile, m.getPublicProfileByTag, m.listPinnedPosts, m.listUserPosts].forEach((f) => f.mockReset());
  Object.values(m.snack).forEach((f) => f.mockReset());
  m.seo.length = 0;
  m.header.current = null;
  authState = { profile: ME, isLoggedIn: true, isAuthReady: true, patchProfile: vi.fn() };
  m.getPublicProfile.mockResolvedValue(LAN);
  m.getPublicProfileByTag.mockResolvedValue(LAN);
  m.listPinnedPosts.mockResolvedValue([]);
  m.listUserPosts.mockResolvedValue({ posts: [], nextCursor: null });
});
afterEach(cleanup);

const Probe = () => {
  const loc = useLocation();
  const type = useNavigationType();
  return (
    <>
      <div data-testid="loc">{loc.pathname + loc.search + loc.hash}</div>
      <div data-testid="navtype">{type}</div>
    </>
  );
};
const LoginProbe = () => <div data-testid="login">{(useLocation().state?.from?.pathname) || "(không có from)"}</div>;
const renderAt = (url) =>
  render(
    <MemoryRouter initialEntries={[url]}>
      <Routes>
        <Route path="/u/:ref" element={<><PublicProfilePage /><Probe /></>} />
        <Route path="*" element={<Probe />} />
      </Routes>
    </MemoryRouter>
  );
// Lịch sử nhiều mục + nút điều hướng thủ công (để dựng lại kịch bản "đổi Tag Name rồi bấm Back").
const BackButton = () => {
  const navigate = useNavigate();
  return <button onClick={() => navigate(-1)}>back</button>;
};
const GoButton = ({ to }) => {
  const navigate = useNavigate();
  return <button onClick={() => navigate(to)}>{`go ${to}`}</button>;
};

// ======================================================================== helper dựng URL (CÙNG bảng ca với backend/test/profile-2421.test.js)
describe("utils/profilePath", () => {
  it("profilePath: /u/@<tag> chữ thường (nhận cả '@abc' lẫn 'abc'); thiếu tag hợp lệ thì rơi về uid; không có gì => null", () => {
    expect(profilePath({ uid: LEGACY_UID, tagName: "@FlylerSky" })).toBe("/u/@flylersky");
    expect(profilePath({ uid: "u1", tagName: "abc_123" })).toBe("/u/@abc_123");
    expect(profilePath({ uid: "EZRx" })).toBe("/u/EZRx");
    expect(profilePath({ uid: "EZRx", tagName: "x" })).toBe("/u/EZRx");
    expect(profilePath({ uid: "EZRx", tagName: "có dấu" })).toBe("/u/EZRx");
    expect(profilePath({ tagName: "@abc" })).toBe("/u/@abc");
    expect(profilePath({})).toBeNull();
    expect(profilePath(null)).toBeNull();
    expect(profilePath({ uid: "UID_SECRET_123", tagName: "@abc" })).not.toContain("UID_SECRET_123");
  });

  it("hồ sơ của chính mình: /u/myProfile (không chứa tag nên không chết khi đổi Tag Name)", () => {
    expect(SELF_PROFILE_SEGMENT).toBe("myProfile");
    expect(SELF_PROFILE_PATH).toBe("/u/myProfile");
  });

  it("classifyProfileRef: chỉ 'tag có @' mới là tag; myProfile là route riêng; còn lại là UID cũ — không bao giờ nhập nhằng", () => {
    expect(classifyProfileRef("@abc")).toEqual({ kind: "tag", tag: "abc" });
    expect(classifyProfileRef("@Abc_9")).toEqual({ kind: "tag", tag: "abc_9" });
    expect(classifyProfileRef("@ab")).toEqual({ kind: "invalid" });
    expect(classifyProfileRef("@a-b-c")).toEqual({ kind: "invalid" });
    expect(classifyProfileRef("@")).toEqual({ kind: "invalid" });
    expect(classifyProfileRef("@" + "x".repeat(21))).toEqual({ kind: "invalid" });
    // KHÔNG có "@" thì KHÔNG bao giờ là tag — kể cả khi trông giống tag hợp lệ.
    expect(classifyProfileRef("abc").kind).toBe("uid");
    expect(classifyProfileRef("flylersky").kind).toBe("uid");
    expect(classifyProfileRef("myProfile")).toEqual({ kind: "self" });
    expect(classifyProfileRef("MYPROFILE")).toEqual({ kind: "self" });
    expect(classifyProfileRef("@myProfile")).toEqual({ kind: "tag", tag: "myprofile" }); // một người vẫn có thể đặt tag này
    expect(classifyProfileRef(LEGACY_UID).kind).toBe("uid");
    expect(classifyProfileRef(undefined).kind).toBe("uid");
  });

  it("normalizeTag / isValidTag khớp luật backend: 3-20 ký tự [a-z0-9_]", () => {
    expect(normalizeTag("  @AbC ")).toBe("abc");
    expect(normalizeTag(null)).toBe("");
    expect(isValidTag("@abc")).toBe(true);
    expect(isValidTag("ab")).toBe(false);
    expect(isValidTag("a-b-c")).toBe(false);
    expect(isValidTag("x".repeat(21))).toBe(false);
    expect(isValidTag("x".repeat(20))).toBe(true);
  });
});

// ======================================================================== trang Profile
describe("PublicProfilePage — URL theo Tag Name (/u/@tag)", () => {
  it("/u/@<tag>: tra theo Tag Name (không gọi API theo UID), URL giữ nguyên, tab nhận UID TỪ HỒ SƠ (không từ URL)", async () => {
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    expect(m.getPublicProfileByTag).toHaveBeenCalledWith("lan_vu");
    expect(m.getPublicProfile).not.toHaveBeenCalled();
    expect(screen.getByTestId("loc").textContent).toBe("/u/@lan_vu");
    await waitFor(() => expect(m.listPinnedPosts).toHaveBeenCalledWith(LEGACY_UID));
    expect(screen.getByTestId("navtype").textContent).toBe("POP"); // không điều hướng thêm
  });

  it("/u/@Lan_Vu (chữ hoa): tra theo tag chuẩn hoá, URL được THAY bằng /u/@lan_vu và chỉ tải hồ sơ MỘT lần", async () => {
    renderAt("/u/@Lan_Vu");
    await screen.findByText("Lan");
    expect(m.getPublicProfileByTag).toHaveBeenCalledTimes(1);
    expect(m.getPublicProfileByTag).toHaveBeenCalledWith("lan_vu");
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("/u/@lan_vu"));
    expect(screen.getByTestId("navtype").textContent).toBe("REPLACE");
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(m.getPublicProfileByTag).toHaveBeenCalledTimes(1);
    expect(screen.getByText("Lan")).toBeTruthy();
  });

  it("'@' là bắt buộc: /u/lan_vu (không '@') KHÔNG phải tag — coi là UID cũ, không gọi API theo tag", async () => {
    m.getPublicProfile.mockRejectedValue({ message: "Không tìm thấy người dùng." });
    renderAt("/u/lan_vu");
    expect(await screen.findByText("Không tìm thấy người dùng.")).toBeTruthy();
    expect(m.getPublicProfile).toHaveBeenCalledWith("lan_vu");
    expect(m.getPublicProfileByTag).not.toHaveBeenCalled();
    expect(screen.getByTestId("loc").textContent).toBe("/u/lan_vu");
  });

  it("'@' + tag sai định dạng (/u/@ab): 'không tìm thấy' ngay, KHÔNG gọi API nào", async () => {
    renderAt("/u/@ab");
    expect(await screen.findByText("Không tìm thấy người dùng.")).toBeTruthy();
    expect(m.getPublicProfileByTag).not.toHaveBeenCalled();
    expect(m.getPublicProfile).not.toHaveBeenCalled();
    expect(screen.queryByRole("tab")).toBeNull();
  });

  it("link CŨ /u/<UID>: tra theo UID, rồi THAY thanh địa chỉ sang /u/@<tag> (UID không còn ở URL), giữ ?tab và #hash, không tải lại lần hai", async () => {
    renderAt(`/u/${LEGACY_UID}?tab=posts#top`);
    await screen.findByText("Lan");
    expect(m.getPublicProfile).toHaveBeenCalledWith(LEGACY_UID);
    expect(m.getPublicProfileByTag).not.toHaveBeenCalled();
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("/u/@lan_vu?tab=posts#top"));
    expect(screen.getByTestId("loc").textContent).not.toContain(LEGACY_UID);
    expect(screen.getByTestId("navtype").textContent).toBe("REPLACE");
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(m.getPublicProfile).toHaveBeenCalledTimes(1);
    expect(m.getPublicProfileByTag).not.toHaveBeenCalled();
    await waitFor(() => expect(m.listUserPosts).toHaveBeenCalledWith(LEGACY_UID, null, 10)); // tab Bài viết mở đúng theo ?tab=posts
  });

  it("hồ sơ không có Tag Name hợp lệ: link UID giữ nguyên (không thay URL, không vòng lặp tải)", async () => {
    m.getPublicProfile.mockResolvedValue({ ...LAN, tagName: undefined });
    renderAt(`/u/${LEGACY_UID}`);
    await screen.findByText("Lan");
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(screen.getByTestId("loc").textContent).toBe(`/u/${LEGACY_UID}`);
    expect(m.getPublicProfile).toHaveBeenCalledTimes(1);
  });

  it("canonical gửi cho useSeo luôn là /u/@<tag> — kể cả khi vào bằng UID cũ", async () => {
    renderAt(`/u/${LEGACY_UID}`);
    await screen.findByText("Lan");
    const last = m.seo[m.seo.length - 1];
    expect(last.canonical).toBe("/u/@lan_vu");
    expect(m.seo.every((c) => !c.canonical || !c.canonical.includes(LEGACY_UID))).toBe(true);
  });

  it("đổi từ hồ sơ này sang hồ sơ khác (đổi :ref) → tải lại đúng người, không dính dữ liệu người trước", async () => {
    const other = { ...LAN, uid: "uOther", displayName: "Minh", tagName: "@minh_tran" };
    m.getPublicProfileByTag.mockImplementation((tag) => Promise.resolve(tag === "minh_tran" ? other : LAN));
    render(
      <MemoryRouter initialEntries={["/u/@lan_vu"]}>
        <Routes>
          <Route path="/u/:ref" element={<><PublicProfilePage /><GoButton to="/u/@minh_tran" /></>} />
        </Routes>
      </MemoryRouter>
    );
    await screen.findByText("Lan");
    fireEvent.click(screen.getByText("go /u/@minh_tran"));
    await screen.findByText("Minh");
    expect(m.getPublicProfileByTag).toHaveBeenLastCalledWith("minh_tran");
    await waitFor(() => expect(m.listPinnedPosts).toHaveBeenLastCalledWith("uOther"));
    expect(screen.queryByText("Lan")).toBeNull();
  });

  it("không tìm thấy (tag lạ) → thông báo, không có tab, URL giữ nguyên", async () => {
    m.getPublicProfileByTag.mockRejectedValue({ message: "Không tìm thấy người dùng." });
    renderAt("/u/@khong_co_ai");
    expect(await screen.findByText("Không tìm thấy người dùng.")).toBeTruthy();
    expect(screen.queryByRole("tab")).toBeNull();
    expect(screen.getByTestId("loc").textContent).toBe("/u/@khong_co_ai");
  });
});

// ======================================================================== /u/myProfile — hồ sơ của người đang đăng nhập
describe("PublicProfilePage — /u/myProfile (hồ sơ của chính mình, không phụ thuộc Tag Name)", () => {
  const MINE = { ...LAN, uid: MY_UID, displayName: "Tôi", tagName: "@toi_day" };
  beforeEach(() => {
    m.getPublicProfile.mockResolvedValue(MINE);
    m.getPublicProfileByTag.mockResolvedValue(MINE);
  });

  it("/u/myProfile: tra theo UID trong phiên (không theo tag), URL giữ nguyên, là chính chủ (có 'Chỉnh sửa hồ sơ'), canonical SEO vẫn là /u/@<tag>", async () => {
    renderAt("/u/myProfile");
    await screen.findByText("Tôi");
    expect(m.getPublicProfile).toHaveBeenCalledWith(MY_UID);
    expect(m.getPublicProfileByTag).not.toHaveBeenCalled();
    expect(screen.getByTestId("loc").textContent).toBe("/u/myProfile");
    expect(screen.getByTestId("navtype").textContent).toBe("POP");
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["edit-profile", "profile-visitors", "copy-profile-url"]);
    expect(m.seo[m.seo.length - 1].canonical).toBe("/u/@toi_day");
    await waitFor(() => expect(m.listPinnedPosts).toHaveBeenCalledWith(MY_UID));
  });

  it("/u/myprofile (chữ thường) cũng là hồ sơ của mình", async () => {
    renderAt("/u/myprofile");
    await screen.findByText("Tôi");
    expect(m.getPublicProfile).toHaveBeenCalledWith(MY_UID);
  });

  it("chưa đăng nhập: /u/myProfile chuyển tới /login (kèm trang đang muốn vào), KHÔNG gọi API", async () => {
    authState = { profile: null, isLoggedIn: false, isAuthReady: true, loadingProfile: false, patchProfile: vi.fn() };
    render(
      <MemoryRouter initialEntries={["/u/myProfile"]}>
        <Routes>
          <Route path="/u/:ref" element={<PublicProfilePage />} />
          <Route path="/login" element={<LoginProbe />} />
        </Routes>
      </MemoryRouter>
    );
    expect((await screen.findByTestId("login")).textContent).toBe("/u/myProfile");
    expect(m.getPublicProfile).not.toHaveBeenCalled();
    expect(m.getPublicProfileByTag).not.toHaveBeenCalled();
  });

  it("phiên đăng nhập chưa sẵn sàng: chỉ hiện vòng chờ (không chuyển /login, không gọi API); sẵn sàng rồi mới tải hồ sơ", async () => {
    authState = { profile: null, isLoggedIn: false, isAuthReady: false, loadingProfile: true, patchProfile: vi.fn() };
    // Hàm (không phải hằng) để mỗi lần rerender là một element MỚI — cùng một element thì React bỏ qua, không đọc lại trạng thái đăng nhập.
    const tree = () => (
      <MemoryRouter initialEntries={["/u/myProfile"]}>
        <Routes>
          <Route path="/u/:ref" element={<><PublicProfilePage /><Probe /></>} />
          <Route path="/login" element={<LoginProbe />} />
        </Routes>
      </MemoryRouter>
    );
    const { rerender } = render(tree());
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(screen.getByRole("progressbar")).toBeTruthy();
    expect(screen.queryByTestId("login")).toBeNull();
    expect(m.getPublicProfile).not.toHaveBeenCalled();
    authState = { profile: ME, isLoggedIn: true, isAuthReady: true, loadingProfile: false, patchProfile: vi.fn() };
    rerender(tree());
    await screen.findByText("Tôi");
    expect(m.getPublicProfile).toHaveBeenCalledTimes(1);
    expect(m.getPublicProfile).toHaveBeenCalledWith(MY_UID);
  });

  it("vào hồ sơ CỦA MÌNH bằng /u/@<tag> (vd. bấm tên mình ở bài viết): URL được THAY thành /u/myProfile, chỉ tải một lần, giữ ?tab", async () => {
    renderAt("/u/@toi_day?tab=posts");
    await screen.findByText("Tôi");
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("/u/myProfile?tab=posts"));
    expect(screen.getByTestId("navtype").textContent).toBe("REPLACE");
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(m.getPublicProfileByTag).toHaveBeenCalledTimes(1);
    expect(m.getPublicProfile).not.toHaveBeenCalled();
    expect(screen.getByText("Tôi")).toBeTruthy();
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["edit-profile", "profile-visitors", "copy-profile-url"]);
  });

  it("vào hồ sơ CỦA MÌNH bằng link UID cũ: thẳng sang /u/myProfile (không dừng ở /u/@tag), chỉ tải một lần", async () => {
    m.getPublicProfile.mockResolvedValue(MINE);
    renderAt(`/u/${MY_UID}`);
    await screen.findByText("Tôi");
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("/u/myProfile"));
    expect(screen.getByTestId("loc").textContent).not.toContain(MY_UID);
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(m.getPublicProfile).toHaveBeenCalledTimes(1);
  });

  it("phiên đăng nhập tải xong MUỘN hơn hồ sơ: hồ sơ hiện trước (công khai), rồi URL /u/@<tag> được thay thành /u/myProfile, không tải lại", async () => {
    authState = { profile: null, isLoggedIn: false, isAuthReady: true, loadingProfile: true, patchProfile: vi.fn() };
    const tree = () => (
      <MemoryRouter initialEntries={["/u/@toi_day"]}>
        <Routes>
          <Route path="/u/:ref" element={<><PublicProfilePage /><Probe /></>} />
        </Routes>
      </MemoryRouter>
    );
    const { rerender } = render(tree());
    await screen.findByText("Tôi");
    expect(screen.getByTestId("loc").textContent).toBe("/u/@toi_day");
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["copy-profile-url"]); // v2.4.2.2: hồ sơ người khác chỉ có nút sao chép URL
    authState = { profile: ME, isLoggedIn: true, isAuthReady: true, loadingProfile: false, patchProfile: vi.fn() };
    rerender(tree());
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("/u/myProfile"));
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["edit-profile", "profile-visitors", "copy-profile-url"]);
    expect(m.getPublicProfileByTag).toHaveBeenCalledTimes(1);
  });

  it("LỖI ĐÃ BÁO — đổi Tag Name rồi bấm Back về Profile: vẫn hiện hồ sơ (không 'không tìm thấy'), vì mục lịch sử là /u/myProfile", async () => {
    // Lịch sử: [/u/myProfile, /settings/account/info]; đang ở Cài đặt, người dùng đổi Tag Name toi_day -> ten_moi rồi bấm Back.
    // Tag cũ không còn ai giữ: tra theo tag cũ sẽ 404 — nếu mục lịch sử là /u/@toi_day thì đây chính là lỗi "tài khoản không tồn tại".
    m.getPublicProfileByTag.mockRejectedValue({ message: "Không tìm thấy người dùng." });
    m.getPublicProfile.mockResolvedValue({ ...MINE, tagName: "@ten_moi" });
    authState = { ...authState, profile: { ...ME, tagName: "ten_moi" } };
    render(
      <MemoryRouter initialEntries={["/u/myProfile", "/settings/account/info"]} initialIndex={1}>
        <Routes>
          <Route path="/u/:ref" element={<><PublicProfilePage /><Probe /></>} />
          <Route path="/settings/account/info" element={<BackButton />} />
        </Routes>
      </MemoryRouter>
    );
    fireEvent.click(screen.getByText("back"));
    await screen.findByText("Tôi");
    expect(screen.queryByText("Không tìm thấy người dùng.")).toBeNull();
    expect(screen.getByTestId("loc").textContent).toBe("/u/myProfile");
    expect(m.getPublicProfile).toHaveBeenCalledWith(MY_UID);
    expect(m.getPublicProfileByTag).not.toHaveBeenCalled();
    expect(m.snack.error).not.toHaveBeenCalled();
  });

  it("đối chứng: hồ sơ của NGƯỜI KHÁC theo tag cũ thì 404 như bình thường (chỉ hồ sơ của mình được bảo vệ bằng /u/myProfile)", async () => {
    m.getPublicProfileByTag.mockRejectedValue({ message: "Không tìm thấy người dùng." });
    renderAt("/u/@toi_day_cu");
    expect(await screen.findByText("Không tìm thấy người dùng.")).toBeTruthy();
  });

  it("chính chủ nhận ra theo Tag Name (me.tagName không có '@') ngay cả khi hồ sơ chưa tải xong", async () => {
    let release;
    m.getPublicProfileByTag.mockReturnValue(new Promise((r) => { release = () => r(MINE); }));
    renderAt("/u/@toi_day");
    await act(async () => { await new Promise((r) => setTimeout(r, 10)); });
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["edit-profile", "profile-visitors"]); // v2.5.2: chính chủ có thêm "Khách ghé thăm" (không cần hồ sơ đã tải)
    await act(async () => { release(); });
    await screen.findByText("Tôi");
  });

  it("hồ sơ người khác: không có action chỉnh sửa, URL giữ /u/@<tag> của họ", async () => {
    m.getPublicProfileByTag.mockResolvedValue(LAN);
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["copy-profile-url"]); // v2.4.2.2: không có "Chỉnh sửa hồ sơ", chỉ có nút sao chép URL
    expect(screen.getByTestId("loc").textContent).toBe("/u/@lan_vu");
  });
});

// ======================================================================== avatar / tên / chip tag dẫn tới /u/@<tag>
describe("UserIdentity — bấm vào người dùng đi tới /u/@<tag> (không lộ UID)", () => {
  const author = { uid: LEGACY_UID, displayName: "Lan", tagName: "@lan_vu", avatarUrl: null, badges: [] };
  const renderIdentity = (ui) =>
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route path="*" element={<>{ui}<Probe /></>} />
        </Routes>
      </MemoryRouter>
    );

  it("avatar, tên và chip tag đều dẫn tới /u/@lan_vu", () => {
    const { container } = renderIdentity(
      <>
        <UserAvatar user={author} />
        <UserName user={author} />
        <UserTagChip user={author} />
      </>
    );
    const go = () => screen.getByTestId("loc").textContent;
    fireEvent.click(screen.getByText("Lan"));
    expect(go()).toBe("/u/@lan_vu");
    cleanup();
    renderIdentity(<UserTagChip user={author} />);
    fireEvent.click(screen.getByText("@lan_vu"));
    expect(screen.getByTestId("loc").textContent).toBe("/u/@lan_vu");
    expect(screen.getByTestId("loc").textContent).not.toContain(LEGACY_UID);
    expect(container).toBeTruthy();
  });

  it("onProfileClick nhận ĐỐI TƯỢNG người dùng (không phải uid) — để hộp bình luận tự dựng URL tag", () => {
    const spy = vi.fn();
    renderIdentity(<UserName user={author} onProfileClick={spy} />);
    fireEvent.click(screen.getByText("Lan"));
    expect(spy).toHaveBeenCalledTimes(1);
    expect(spy.mock.calls[0][0]).toMatchObject({ uid: LEGACY_UID, tagName: "@lan_vu" });
    expect(screen.getByTestId("loc").textContent).toBe("/"); // đã ghi đè: không tự điều hướng
  });

  it("tác giả chưa có tag hợp lệ: vẫn bấm được (rơi về /u/<uid>, trang Profile sẽ chuyển tiếp); không có cả uid lẫn tag: không bấm được", () => {
    renderIdentity(<UserName user={{ uid: "EZRx", displayName: "Không tag" }} />);
    fireEvent.click(screen.getByText("Không tag"));
    expect(screen.getByTestId("loc").textContent).toBe("/u/EZRx");
    cleanup();
    renderIdentity(<UserName user={{ displayName: "Ẩn danh" }} />);
    fireEvent.click(screen.getByText("Ẩn danh"));
    expect(screen.getByTestId("loc").textContent).toBe("/");
  });
});

// ======================================================================== chốt chặn hồi quy: không ai tự ghép /u/${uid}
describe("không còn chỗ nào tự ghép /u/<uid>", () => {
  const walk = (dir) =>
    fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
      const full = path.join(dir, e.name);
      return e.isDirectory() ? walk(full) : /\.(jsx?|mjs)$/.test(e.name) ? [full] : [];
    });
  it("mọi liên kết hồ sơ trong src/ đi qua profilePath()/SELF_PROFILE_PATH: không tự ghép `/u/${…}`, '/u/' + biến, hay gõ cứng /u/myProfile", () => {
    const offenders = [];
    for (const file of walk(path.resolve(__dirname, "../src"))) {
      if (file.endsWith(path.join("utils", "profilePath.js"))) continue;
      const code = fs.readFileSync(file, "utf8").split("\n");
      code.forEach((line, i) => {
        const t = line.trim();
        if (t.startsWith("*") || t.startsWith("//") || t.startsWith("/*")) return; // chú thích
        // Không tự ghép `/u/${…}`, '/u/' + biến, `/u/@${…}`, và không gõ cứng "/u/myProfile" (dùng profilePath(user) / SELF_PROFILE_PATH).
        if (/`\/u\/(@)?\$\{/.test(line) || /["']\/u\/(@)?["']\s*\+/.test(line) || /["'`]\/u\/myProfile/i.test(line)) offenders.push(`${path.relative(process.cwd(), file)}:${i + 1}`);
      });
    }
    expect(offenders).toEqual([]);
  });
});
