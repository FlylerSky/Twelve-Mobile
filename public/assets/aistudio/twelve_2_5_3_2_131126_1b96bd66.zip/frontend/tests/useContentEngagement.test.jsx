import { describe, it, expect, vi, beforeEach } from "vitest";
import { renderHook, act } from "@testing-library/react";

let rtCb = null;
vi.mock("../src/hooks/useRealtimeDoc", () => ({ default: (_c, _id, cb) => { rtCb = cb; } }));
vi.mock("../src/context/AuthContext", () => ({ useAuth: () => ({ refreshProfile: vi.fn() }) }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => ({ error: vi.fn(), success: vi.fn() }) }));
vi.mock("../src/hooks/useAuthGate", () => ({ default: () => ({ requireLogin: () => true }) }));
vi.mock("../src/utils/postScore", () => ({ computePostScore: () => 0 }));

import useContentEngagement from "../src/hooks/useContentEngagement";

const base = { id: "p1", myReaction: null, likeCount: 0, dislikeCount: 0, commentCount: 0, shareCount: 0, viewCount: 0, aiViewCount: 0 };
const mkApi = (type) => ({ react: vi.fn(async () => ({ myReaction: type })) });

describe("useContentEngagement", () => {
  beforeEach(() => { rtCb = null; });

  it("bình luận (initial.commentCount đổi) KHÔNG làm mất like vừa bấm — đúng kịch bản người dùng báo", async () => {
    const api = { react: vi.fn() };
    api.react.mockResolvedValueOnce({ myReaction: "like" }).mockResolvedValueOnce({ myReaction: null });
    const { result, rerender } = renderHook(({ initial }) => useContentEngagement({ api, collectionName: "posts", id: "p1", initial }), { initialProps: { initial: base } });
    act(() => rtCb({ likeCount: 0, commentCount: 0 }));

    await act(async () => { await result.current.react("like"); });
    act(() => rtCb({ likeCount: 1, commentCount: 0 }));
    expect(result.current.myReaction).toBe("like");
    expect(result.current.likeCount).toBe(1);

    // Hộp bình luận gửi comment => danh sách đổi commentCount (initial CŨ: myReaction null, likeCount 0)
    rerender({ initial: { ...base, commentCount: 1 } });
    act(() => rtCb({ likeCount: 1, commentCount: 1 }));
    expect(result.current.myReaction).toBe("like");   // trước vá: null
    expect(result.current.likeCount).toBe(1);          // trước vá: 0
    expect(result.current.commentCount).toBe(1);

    // Bấm like lần nữa => bỏ like (trước vá: hiện 2 rồi nhảy về 0, tô màu sai)
    await act(async () => { await result.current.react("like"); });
    expect(result.current.myReaction).toBe(null);
    expect(result.current.likeCount).toBe(0);
    expect(api.react).toHaveBeenCalledTimes(2);
  });

  it("realtime là nguồn đúng: initial cũ không ghi đè số đếm sau khi realtime đã về", () => {
    const api = mkApi(null);
    const { result, rerender } = renderHook(({ initial }) => useContentEngagement({ api, collectionName: "posts", id: "p1", initial }), { initialProps: { initial: base } });
    act(() => rtCb({ likeCount: 5, commentCount: 3 }));
    rerender({ initial: { ...base, commentCount: 1 } }); // số cũ + optimistic của danh sách
    expect(result.current.commentCount).toBe(3);
    expect(result.current.likeCount).toBe(5);
  });

  it("trước khi realtime về (hoặc listener lỗi) vẫn đồng bộ từng trường từ initial", () => {
    const api = mkApi(null);
    const { result, rerender } = renderHook(({ initial }) => useContentEngagement({ api, collectionName: "posts", id: "p1", initial }), { initialProps: { initial: base } });
    rerender({ initial: { ...base, likeCount: 4 } });
    expect(result.current.likeCount).toBe(4);
  });

  it("tải lại danh sách (initial.myReaction đổi, vd. sau đăng nhập) được áp dụng", () => {
    const api = mkApi(null);
    const { result, rerender } = renderHook(({ initial }) => useContentEngagement({ api, collectionName: "posts", id: "p1", initial }), { initialProps: { initial: base } });
    rerender({ initial: { ...base, myReaction: "dislike" } });
    expect(result.current.myReaction).toBe("dislike");
  });

  it("server trả trạng thái khác UI => tự sửa theo server", async () => {
    const api = mkApi("dislike");
    const { result } = renderHook(() => useContentEngagement({ api, collectionName: "posts", id: "p1", initial: base }));
    await act(async () => { await result.current.react("like"); });
    expect(result.current.myReaction).toBe("dislike");
  });

  it("đổi id => reset toàn bộ", () => {
    const api = mkApi(null);
    const { result, rerender } = renderHook(({ id, initial }) => useContentEngagement({ api, collectionName: "posts", id, initial }), { initialProps: { id: "p1", initial: { ...base, myReaction: "like", likeCount: 2 } } });
    act(() => rtCb({ likeCount: 2 }));
    rerender({ id: "p2", initial: { ...base, id: "p2", likeCount: 9 } });
    expect(result.current.myReaction).toBe(null);
    expect(result.current.likeCount).toBe(9);
  });
});
