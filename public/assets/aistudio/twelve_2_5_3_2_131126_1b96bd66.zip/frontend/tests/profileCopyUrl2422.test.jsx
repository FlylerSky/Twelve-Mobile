// v2.4.2.2 — nút "Sao chép URL Profile" ở headZone trang Profile (hồ sơ của mình và của mọi người), mở hộp chọn 2 loại URL:
//   [URL Ngắn (Tag Name Search) = /u/@tag, URL cố định (UID) = /u/<uid>].
// QUAN TRỌNG: URL hồ sơ CHÍNH vẫn là /u/@tag. URL UID chỉ là lựa chọn sao chép thêm, tận dụng việc link UID cũ vẫn được hỗ trợ (mở ra thì tự chuyển sang URL Tag Name).
// Các test "chốt chặn" bên dưới đảm bảo không ai lỡ đổi lại hệ thống URL (profilePath vẫn ưu tiên tag; mở link UID vẫn chuyển sang tag).
// Chạy: npx vitest run tests/profileCopyUrl2422.test.jsx
import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor, act, within } from "@testing-library/react";
import { MemoryRouter, Routes, Route, useLocation, useNavigate } from "react-router-dom";

const m = vi.hoisted(() => ({
  snack: { success: vi.fn(), error: vi.fn(), info: vi.fn(), warning: vi.fn() },
  getPublicProfile: vi.fn(),
  getPublicProfileByTag: vi.fn(),
  listPinnedPosts: vi.fn(),
  listUserPosts: vi.fn(),
  header: { current: null },
}));
let authState;

vi.mock("../src/context/AuthContext", () => ({ useAuth: () => authState }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => m.snack }));
vi.mock("../src/components/Navbar", () => ({ default: () => <nav>NAVBAR</nav> }));
vi.mock("../src/hooks/useSeo", () => ({ default: () => {} }));
vi.mock("../src/context/PageHeaderContext", () => ({
  useRegisterPageHeader: (cfg) => {
    m.header.current = cfg;
  },
}));
vi.mock("../src/api/content.api", () => ({ postsApi: { pin: vi.fn(), unpin: vi.fn() }, blogsApi: {} }));
vi.mock("../src/api/users.api", () => ({
  getPublicProfile: (...a) => m.getPublicProfile(...a),
  getPublicProfileByTag: (...a) => m.getPublicProfileByTag(...a),
  listPinnedPosts: (...a) => m.listPinnedPosts(...a),
  listUserPosts: (...a) => m.listUserPosts(...a),
  recordProfileVisit: () => Promise.resolve({ recorded: true }), // v2.5.2: trang tự báo lượt ghé thăm khi người đã đăng nhập xem hồ sơ người khác
}));
vi.mock("../src/components/PostCardList", () => ({ default: () => <div data-testid="cards" /> }));
vi.mock("../src/components/FeedList", () => ({ default: () => <div data-testid="feed" /> }));

import PublicProfilePage from "../src/pages/PublicProfilePage";
import CopyProfileUrlDialog from "../src/components/profile/CopyProfileUrlDialog";
import { profilePath, profileTagPath, profileUidPath, profileShareUrls } from "../src/utils/profilePath";
import { copyText } from "../src/utils/clipboard";
import { copyText as copyTextFromDebugReport } from "../src/pages/settings/debugReport";

const LAN_UID = "EZRxcGpJUEcSAuFfElxj8ja8KQ22";
const MY_UID = "MyFirebaseUid0123456789AB";
const LAN = { uid: LAN_UID, displayName: "Lan", tagName: "@lan_vu", accountRole: "user", badges: [], country: "VN", coverUrl: null, avatarUrl: null };
const MINE = { ...LAN, uid: MY_UID, displayName: "Tôi", tagName: "@toi_day" };
const ME = { uid: MY_UID, displayName: "Tôi", tagName: "toi_day", accountRole: "user", pinnedPostIds: [] };
const ORIGIN = window.location.origin;

let writeText;
beforeEach(() => {
  [m.getPublicProfile, m.getPublicProfileByTag, m.listPinnedPosts, m.listUserPosts].forEach((f) => f.mockReset());
  Object.values(m.snack).forEach((f) => f.mockReset());
  m.header.current = null;
  authState = { profile: ME, isLoggedIn: true, isAuthReady: true, patchProfile: vi.fn() };
  m.getPublicProfile.mockResolvedValue(LAN);
  m.getPublicProfileByTag.mockResolvedValue(LAN);
  m.listPinnedPosts.mockResolvedValue([]);
  m.listUserPosts.mockResolvedValue({ posts: [], nextCursor: null });
  writeText = vi.fn().mockResolvedValue(undefined);
  Object.defineProperty(navigator, "clipboard", { value: { writeText }, configurable: true });
});
afterEach(() => {
  cleanup();
  delete navigator.clipboard;
});

const Loc = () => {
  const l = useLocation();
  return <div data-testid="loc">{l.pathname + l.search + l.hash}</div>;
};
const renderAt = (url) =>
  render(
    <MemoryRouter initialEntries={[url]}>
      <Routes>
        <Route path="/u/:ref" element={<><PublicProfilePage /><Loc /></>} />
      </Routes>
    </MemoryRouter>
  );
const openDialog = async () => {
  await act(async () => m.header.current.actions.find((a) => a.key === "copy-profile-url").onClick());
  return await screen.findByRole("dialog");
};

// ======================================================================== helper URL
describe("utils/profilePath — link để sao chép (v2.4.2.2)", () => {
  it("profileTagPath: /u/@<tag> chữ thường; thiếu tag hợp lệ => null (KHÔNG rơi về UID như profilePath)", () => {
    expect(profileTagPath({ uid: "u1", tagName: "@FlylerSky" })).toBe("/u/@flylersky");
    expect(profileTagPath({ uid: "u1", tagName: "abc_123" })).toBe("/u/@abc_123");
    expect(profileTagPath({ uid: "u1" })).toBeNull();
    expect(profileTagPath({ uid: "u1", tagName: "ab" })).toBeNull();
    expect(profileTagPath({ uid: "u1", tagName: "có dấu" })).toBeNull();
    expect(profileTagPath(null)).toBeNull();
  });
  it("profileUidPath: /u/<uid> (mã hoá URL); không có uid => null", () => {
    expect(profileUidPath({ uid: LAN_UID })).toBe(`/u/${LAN_UID}`);
    expect(profileUidPath({ uid: "a/b c" })).toBe("/u/a%2Fb%20c");
    expect(profileUidPath({ tagName: "@abc" })).toBeNull();
    expect(profileUidPath(null)).toBeNull();
  });
  it("profileShareUrls: link tuyệt đối theo origin; mỗi link null nếu thiếu dữ liệu; mặc định origin của trang", () => {
    expect(profileShareUrls({ uid: LAN_UID, tagName: "@lan_vu" }, "https://twelve.example")).toEqual({
      tag: "https://twelve.example/u/@lan_vu",
      uid: `https://twelve.example/u/${LAN_UID}`,
    });
    expect(profileShareUrls({ uid: LAN_UID }, "https://x.y")).toEqual({ tag: null, uid: `https://x.y/u/${LAN_UID}` });
    expect(profileShareUrls({ tagName: "@lan_vu" }, "https://x.y")).toEqual({ tag: "https://x.y/u/@lan_vu", uid: null });
    expect(profileShareUrls({ uid: LAN_UID, tagName: "@lan_vu" }).tag).toBe(`${ORIGIN}/u/@lan_vu`);
  });
  it("CHỐT CHẶN: URL hồ sơ CHÍNH vẫn là /u/@tag — profilePath() không đổi (UID chỉ là đường lùi khi không có tag hợp lệ)", () => {
    expect(profilePath({ uid: LAN_UID, tagName: "@lan_vu" })).toBe("/u/@lan_vu");
    expect(profilePath({ uid: LAN_UID, tagName: "x" })).toBe(`/u/${LAN_UID}`);
    expect(profilePath({ uid: LAN_UID })).toBe(`/u/${LAN_UID}`);
    expect(profilePath({ tagName: "@abc" })).toBe("/u/@abc");
    expect(profilePath(null)).toBeNull();
  });
});

describe("utils/clipboard — copyText dùng chung", () => {
  it("copyText ghi vào clipboard; debugReport vẫn export cùng hàm (nơi import cũ không vỡ)", async () => {
    expect(copyTextFromDebugReport).toBe(copyText);
    expect(await copyText("abc")).toBe(true);
    expect(writeText).toHaveBeenCalledWith("abc");
  });
});

// ======================================================================== hộp chọn
describe("CopyProfileUrlDialog", () => {
  const onClose = vi.fn();
  beforeEach(() => onClose.mockReset());
  const show = (user = LAN) => render(<CopyProfileUrlDialog open onClose={onClose} user={user} />);

  it("hiện đúng 2 lựa chọn: 'URL Ngắn (Tag Name Search)' và 'URL cố định (UID)', kèm link đầy đủ", () => {
    show();
    expect(screen.getByText("Sao chép URL Profile")).toBeTruthy();
    expect(screen.getByText("URL Ngắn (Tag Name Search)")).toBeTruthy();
    expect(screen.getByText("URL cố định (UID)")).toBeTruthy();
    expect(screen.getByTestId("copy-url-tag-value").textContent).toBe(`${ORIGIN}/u/@lan_vu`);
    expect(screen.getByTestId("copy-url-uid-value").textContent).toBe(`${ORIGIN}/u/${LAN_UID}`);
  });

  it("chọn URL Ngắn → sao chép /u/@tag, báo thành công, đóng hộp", async () => {
    show();
    await act(async () => fireEvent.click(screen.getByTestId("copy-url-tag")));
    expect(writeText).toHaveBeenCalledTimes(1);
    expect(writeText).toHaveBeenCalledWith(`${ORIGIN}/u/@lan_vu`);
    expect(m.snack.success).toHaveBeenCalledWith("Đã sao chép URL Ngắn (Tag Name Search).");
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it("chọn URL cố định → sao chép /u/<uid>, báo thành công, đóng hộp", async () => {
    show();
    await act(async () => fireEvent.click(screen.getByTestId("copy-url-uid")));
    expect(writeText).toHaveBeenCalledWith(`${ORIGIN}/u/${LAN_UID}`);
    expect(m.snack.success).toHaveBeenCalledWith("Đã sao chép URL cố định (UID).");
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it("hồ sơ chưa có Tag Name hợp lệ: URL Ngắn bị khoá (có giải thích), URL cố định vẫn sao chép được", async () => {
    show({ uid: LAN_UID, displayName: "Cũ", tagName: "tag-cu-khong-hop-le-qua-dai-dong-dai-hon-20" });
    expect(screen.getByTestId("copy-url-tag").getAttribute("aria-disabled")).toBe("true");
    expect(screen.getByTestId("copy-url-tag-value").textContent).toMatch(/chưa có Tag Name hợp lệ/);
    await act(async () => fireEvent.click(screen.getByTestId("copy-url-tag")));
    expect(writeText).not.toHaveBeenCalled();
    await act(async () => fireEvent.click(screen.getByTestId("copy-url-uid")));
    expect(writeText).toHaveBeenCalledWith(`${ORIGIN}/u/${LAN_UID}`);
  });

  it("sao chép thất bại (clipboard bị chặn, không có đường dự phòng): báo lỗi và GIỮ hộp mở để tự chọn link", async () => {
    writeText.mockRejectedValue(new Error("denied"));
    show();
    await act(async () => fireEvent.click(screen.getByTestId("copy-url-tag")));
    expect(m.snack.error).toHaveBeenCalled();
    expect(m.snack.success).not.toHaveBeenCalled();
    expect(onClose).not.toHaveBeenCalled();
    expect(screen.getByTestId("copy-url-tag-value").textContent).toBe(`${ORIGIN}/u/@lan_vu`); // link vẫn hiển thị dạng văn bản
  });

  it("nút Đóng gọi onClose, không sao chép gì", () => {
    show();
    fireEvent.click(screen.getByRole("button", { name: "Đóng" }));
    expect(onClose).toHaveBeenCalledTimes(1);
    expect(writeText).not.toHaveBeenCalled();
  });
});

// ======================================================================== trang Profile
describe("PublicProfilePage — nút 'Sao chép URL Profile' ở headZone", () => {
  it("hồ sơ NGƯỜI KHÁC: có nút (đúng nhãn), bấm mở hộp; chọn URL UID → sao chép link UID của họ, thanh địa chỉ KHÔNG đổi", async () => {
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    const acts = m.header.current.actions;
    expect(acts.map((a) => a.key)).toEqual(["copy-profile-url"]);
    expect(acts[0].label).toBe("Sao chép URL Profile");
    expect(screen.queryByRole("dialog")).toBeNull();

    const dlg = await openDialog();
    expect(within(dlg).getByText("URL Ngắn (Tag Name Search)")).toBeTruthy();
    expect(within(dlg).getByText("URL cố định (UID)")).toBeTruthy();
    await act(async () => fireEvent.click(within(dlg).getByTestId("copy-url-uid")));
    expect(writeText).toHaveBeenCalledWith(`${ORIGIN}/u/${LAN_UID}`);
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    expect(screen.getByTestId("loc").textContent).toBe("/u/@lan_vu"); // copy không điều hướng
  });

  it("hồ sơ CỦA MÌNH (đang ở /u/myProfile): nút đứng sau 'Chỉnh sửa hồ sơ'; link ngắn là /u/@tag của mình — KHÔNG phải /u/myProfile", async () => {
    m.getPublicProfile.mockResolvedValue(MINE);
    renderAt("/u/myProfile");
    await screen.findByText("Tôi");
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["edit-profile", "profile-visitors", "copy-profile-url"]);
    const dlg = await openDialog();
    await act(async () => fireEvent.click(within(dlg).getByTestId("copy-url-tag")));
    expect(writeText).toHaveBeenCalledWith(`${ORIGIN}/u/@toi_day`);
    expect(writeText.mock.calls[0][0]).not.toMatch(/myprofile/i);
    expect(screen.getByTestId("loc").textContent).toBe("/u/myProfile");
  });

  it("hồ sơ của mình: link UID là UID của mình (không phải của ai khác)", async () => {
    m.getPublicProfile.mockResolvedValue(MINE);
    renderAt("/u/myProfile");
    await screen.findByText("Tôi");
    const dlg = await openDialog();
    expect(within(dlg).getByTestId("copy-url-uid-value").textContent).toBe(`${ORIGIN}/u/${MY_UID}`);
  });

  it("khách (chưa đăng nhập) xem hồ sơ công khai: vẫn có nút sao chép", async () => {
    authState = { profile: null, isLoggedIn: false, isAuthReady: true, loadingProfile: false, patchProfile: vi.fn() };
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["copy-profile-url"]);
  });

  it("chưa tải xong / không tìm thấy: KHÔNG có nút sao chép (chưa có tagName/uid để dựng link)", async () => {
    let release;
    m.getPublicProfileByTag.mockReturnValue(new Promise((r) => { release = () => r(LAN); }));
    renderAt("/u/@lan_vu");
    await act(async () => { await new Promise((r) => setTimeout(r, 10)); });
    expect(m.header.current.actions).toEqual([]);
    await act(async () => { release(); });
    await screen.findByText("Lan");
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["copy-profile-url"]);
    cleanup();

    m.getPublicProfileByTag.mockRejectedValue({ message: "Không tìm thấy người dùng." });
    renderAt("/u/@khong_co_ai");
    expect(await screen.findByText("Không tìm thấy người dùng.")).toBeTruthy();
    expect(m.header.current.actions).toEqual([]);
  });

  it("đang mở hộp mà chuyển sang hồ sơ người khác: hộp tự đóng, không dính link người trước", async () => {
    const other = { ...LAN, uid: "uOther", displayName: "Minh", tagName: "@minh_tran" };
    m.getPublicProfileByTag.mockImplementation((tag) => Promise.resolve(tag === "minh_tran" ? other : LAN));
    const GoButton = () => {
      const navigate = useNavigate();
      return <button onClick={() => navigate("/u/@minh_tran")}>sang Minh</button>;
    };
    render(
      <MemoryRouter initialEntries={["/u/@lan_vu"]}>
        <Routes>
          <Route path="/u/:ref" element={<><PublicProfilePage /><GoButton /></>} />
        </Routes>
      </MemoryRouter>
    );
    await screen.findByText("Lan");
    await openDialog();
    fireEvent.click(screen.getByText("sang Minh"));
    await screen.findByText("Minh");
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    const dlg2 = await openDialog();
    expect(within(dlg2).getByTestId("copy-url-tag-value").textContent).toBe(`${ORIGIN}/u/@minh_tran`);
  });
});

// ======================================================================== chốt chặn: link UID được sao chép vẫn mở ra và TỰ CHUYỂN sang URL Tag Name
describe("CHỐT CHẶN — URL UID chỉ là link phụ: mở ra thì tự chuyển sang URL Tag Name (hệ thống URL không bị đổi)", () => {
  it("mở đúng đường dẫn mà nút 'URL cố định (UID)' sao chép (người khác) → thanh địa chỉ về /u/@tag", async () => {
    const uidPath = profileUidPath(LAN);
    renderAt(uidPath);
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("/u/@lan_vu"));
    expect(m.getPublicProfile).toHaveBeenCalledWith(LAN_UID);
  });
  it("mở link UID của CHÍNH MÌNH → về /u/myProfile (như PATCH-19)", async () => {
    m.getPublicProfile.mockResolvedValue(MINE);
    renderAt(profileUidPath(MINE));
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("/u/myProfile"));
  });
});
