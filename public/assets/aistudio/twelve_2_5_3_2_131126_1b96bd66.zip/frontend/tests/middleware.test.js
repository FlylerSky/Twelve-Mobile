import { describe, it, expect, vi, beforeEach } from "vitest";

// Mô phỏng @vercel/functions: rewrite()/next() trả về đối tượng mô tả để kiểm tra định tuyến.
vi.mock("@vercel/functions", () => ({
  rewrite: (dest, init) => ({ kind: "rewrite", dest: String(dest), init }),
  next: (init) => ({ kind: "next", init }),
}));

let middleware;
beforeEach(async () => {
  vi.resetModules();
  process.env.BACKEND_ORIGIN = "https://be.example";
  process.env.SSR_PROXY_SECRET = "s3cr3t";
  middleware = (await import("../middleware.js")).default;
});

const req = (url, headers = {}, method = "GET") => new Request(url, { method, headers });
const CHROME = "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 Chrome/120 Safari/537.36";
const IPHONE = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17 Mobile/15E148 Safari/604.1";

describe("định tuyến SEO", () => {
  it("bot -> SSR; trình duyệt thật (kể cả iPhone Safari thiếu Sec-Fetch-User) -> SPA", () => {
    expect(middleware(req("https://s/post/1", { "user-agent": "Googlebot/2.1" })).kind).toBe("rewrite");
    expect(middleware(req("https://s/post/1", { "user-agent": IPHONE, "sec-fetch-mode": "navigate" })).kind).toBe("next");
    expect(middleware(req("https://s/post/1", { "user-agent": CHROME, "sec-fetch-mode": "navigate", "sec-fetch-user": "?1" })).kind).toBe("next");
    expect(middleware(req("https://s/post/1", { "user-agent": CHROME })).kind).toBe("rewrite"); // fetch phía server
  });
  it("?spa=1 luôn là SPA (không vòng lặp)", () => {
    expect(middleware(req("https://s/post/1?spa=1", { "user-agent": "Googlebot/2.1" })).kind).toBe("next");
  });
});

describe("G1: /csp-report", () => {
  it("chuyển POST tới backend /api/csp-report, kèm secret + IP thật, xoá header x-twelve-* của client", () => {
    const r = middleware(
      req("https://s/csp-report", { "content-type": "application/csp-report", "x-real-ip": "1.2.3.4", "x-twelve-client-ip": "6.6.6.6", "x-twelve-ssr-secret": "evil" }, "POST")
    );
    expect(r.kind).toBe("rewrite");
    expect(r.dest).toBe("https://be.example/api/csp-report");
    const h = r.init.request.headers;
    expect(h.get("x-twelve-ssr-secret")).toBe("s3cr3t");
    expect(h.get("x-twelve-client-ip")).toBe("1.2.3.4");
  });
  it("không phụ thuộc User-Agent (trình duyệt thật cũng gửi báo cáo)", () => {
    const r = middleware(req("https://s/csp-report", { "user-agent": CHROME, "sec-fetch-mode": "no-cors" }, "POST"));
    expect(r.dest).toBe("https://be.example/api/csp-report");
  });
});

describe("robots/sitemap", () => {
  it("luôn do backend sinh", () => {
    expect(middleware(req("https://s/sitemap-2.xml", { "user-agent": CHROME })).dest).toBe("https://be.example/sitemap-2.xml");
    expect(middleware(req("https://s/robots.txt", { "user-agent": CHROME })).dest).toBe("https://be.example/robots.txt");
  });
});
