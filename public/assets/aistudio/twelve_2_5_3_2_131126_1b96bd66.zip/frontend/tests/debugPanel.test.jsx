// v2.3.0: Cài đặt > Quản trị > Gỡ lỗi — danh sách module, chạy thử (một / tất cả), kết quả trực quan & văn bản, sao chép, nhập lại mật khẩu, lỗi.
// Chạy: npx vitest run tests/debugPanel.test.jsx
import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor, within } from "@testing-library/react";

const m = vi.hoisted(() => ({
  list: vi.fn(),
  run: vi.fn(),
  reauth: vi.fn(),
  snack: { success: vi.fn(), error: vi.fn(), warning: vi.fn(), info: vi.fn() },
}));
vi.mock("../src/api/admin.api", () => ({ listDebugModules: (...a) => m.list(...a), runDebugModule: (...a) => m.run(...a) }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => m.snack }));
vi.mock("../src/utils/reauth", () => ({ reauthWithPassword: (...a) => m.reauth(...a), describeAuthError: (e) => (e && e.message) || "lỗi" }));

import AdminDebugPanel from "../src/pages/settings/AdminDebugPanel";
import { formatResultText, formatSummaryMarkdown, countStatuses, isReauthError, copyText } from "../src/pages/settings/debugReport";

const mod = (over = {}) => ({
  id: "a01-uid-crash", ref: "A-01", title: "Sập tiến trình bằng id lạ", severity: "high", recordedIn: "2.2.0", fixedIn: "2.2.1", knownOpen: false,
  description: "Mô tả lỗi A-01 đủ dài.", mode: "isolated", lastRun: null, ...over,
});
const listOf = (modules, extra = {}) => ({ appVersion: "2.3.0.171026", enabled: true, busy: null, loadErrors: 0, modules, ...extra });
const result = (over = {}) => ({
  id: "a01-uid-crash", ref: "A-01", title: "Sập tiến trình bằng id lạ", severity: "high", recordedIn: "2.2.0", fixedIn: "2.2.1", mode: "isolated",
  status: "pass", summary: "2/2 kiểm tra đạt", startedAt: 1760000000000, finishedAt: 1760000000900, durationMs: 900, appVersion: "2.3.0.171026",
  checks: [{ name: "Hồ sơ id %2F trả 404", ok: true, level: "ok", detail: "HTTP 404" }, { name: "Server còn sống", ok: true, level: "ok", detail: "" }],
  metrics: [{ name: "Số ca", value: 20, unit: "ca" }], logs: [{ t: 3, level: "ok", msg: "✔ Hồ sơ id %2F trả 404 — HTTP 404" }], truncated: false, ...over,
});

beforeEach(() => {
  Object.values(m).forEach((f) => f && f.mockReset && f.mockReset());
  Object.values(m.snack).forEach((f) => f.mockReset());
  m.reauth.mockResolvedValue(undefined);
});
afterEach(() => cleanup());

const open = async (data) => {
  m.list.mockResolvedValue(data);
  render(<AdminDebugPanel />);
  await screen.findByText("Phiên bản máy chủ: v2.3.0.171026");
};
const runBtn = (title) => screen.getByRole("button", { name: `Chạy thử ${title}` });

describe("danh sách module", () => {
  it("hiện tên lỗi, mã, mức độ, phiên bản ghi nhận/đã vá, chế độ, mô tả và lần chạy gần nhất", async () => {
    await open(listOf([
      mod({ lastRun: { status: "pass", summary: "20/20 kiểm tra đạt", appVersion: "2.2.2.171026", startedAt: 1760000000000 } }),
      mod({ id: "cfg-runtime", ref: "CFG", title: "Cấu hình chạy thật", severity: "medium", recordedIn: "2.2.0", fixedIn: null, mode: "static", description: "Đọc cấu hình của tiến trình." }),
    ]));
    expect(screen.getByText("Sập tiến trình bằng id lạ")).toBeTruthy();
    expect(screen.getByText("A-01")).toBeTruthy();
    expect(screen.getByText("Mức Cao")).toBeTruthy();
    expect(screen.getByText(/Ghi nhận ở v2\.2\.0 · đã vá ở v2\.2\.1 · Cô lập \(tiến trình con\)/)).toBeTruthy();
    expect(screen.getByText(/Lần cuối:.*v2\.2\.2\.171026.*Đạt — 20\/20 kiểm tra đạt/)).toBeTruthy();
    expect(screen.getByText(/không gắn với một bản vá/)).toBeTruthy();
    expect(screen.getByText("Chưa chạy lần nào")).toBeTruthy();
    expect(screen.getByText("Mô tả lỗi A-01 đủ dài.")).toBeTruthy();
  });

  it("chưa chạy gì: bộ đếm báo 'Chưa chạy N'", async () => {
    await open(listOf([mod(), mod({ id: "b", title: "Lỗi B" })]));
    expect(screen.getByTestId("debug-counts").textContent).toContain("Chưa chạy 2");
  });

  it("tải danh sách lỗi → hiện lỗi và nút Thử lại gọi lại API", async () => {
    m.list.mockRejectedValueOnce({ message: "Mất kết nối" });
    render(<AdminDebugPanel />);
    expect(await screen.findByText("Mất kết nối")).toBeTruthy();
    m.list.mockResolvedValue(listOf([mod()]));
    fireEvent.click(screen.getByRole("button", { name: "Thử lại" }));
    expect(await screen.findByText("Sập tiến trình bằng id lạ")).toBeTruthy();
  });

  it("máy chủ tắt chạy module (enabled:false) → cảnh báo và mọi nút chạy bị khoá", async () => {
    await open(listOf([mod()], { enabled: false }));
    expect(screen.getByText(/DEBUG_PANEL_ENABLED=off/)).toBeTruthy();
    expect(runBtn("Sập tiến trình bằng id lạ").disabled).toBe(true);
    expect(screen.getByRole("button", { name: /Chạy tất cả/ }).disabled).toBe(true);
  });

  it("có module bị lỗi khai báo → báo cho quản trị viên", async () => {
    await open(listOf([mod()], { loadErrors: 2 }));
    expect(screen.getByText(/2 module bị lỗi khai báo/)).toBeTruthy();
  });
});

describe("chạy một module", () => {
  it("bấm Chạy thử → gọi API đúng id, hiện kết quả trực quan (✔, chi tiết, số đo) và cập nhật bộ đếm", async () => {
    m.run.mockResolvedValue(result());
    await open(listOf([mod()]));
    fireEvent.click(runBtn("Sập tiến trình bằng id lạ"));
    const visual = await screen.findByTestId("debug-visual");
    expect(m.run).toHaveBeenCalledWith("a01-uid-crash");
    expect(within(visual).getByText("Hồ sơ id %2F trả 404")).toBeTruthy();
    expect(within(visual).getByText("HTTP 404")).toBeTruthy();
    expect(within(visual).getByText("20 ca")).toBeTruthy();
    expect(screen.getByTestId("debug-counts").textContent).toContain("Đạt 1");
    expect(screen.getByText(/Vừa chạy · 900 ms · 2\/2 kiểm tra đạt/)).toBeTruthy();
  });

  it("module không đạt → trạng thái 'Không đạt', bộ đếm đỏ, hiện kiểm tra hỏng với chi tiết", async () => {
    m.run.mockResolvedValue(result({ status: "fail", summary: "1 kiểm tra KHÔNG đạt / 2", checks: [{ name: "Server còn sống", ok: false, level: "fail", detail: "TIẾN TRÌNH CON ĐÃ SẬP (mã 1)" }] }));
    await open(listOf([mod()]));
    fireEvent.click(runBtn("Sập tiến trình bằng id lạ"));
    expect(await screen.findByText("TIẾN TRÌNH CON ĐÃ SẬP (mã 1)")).toBeTruthy();
    expect(screen.getAllByText("Không đạt").length).toBeGreaterThan(0);
    expect(screen.getByTestId("debug-counts").textContent).toContain("Không đạt 1");
  });

  it("tab 'Văn bản' hiện đúng văn bản định dạng; nút Sao chép đưa nó vào clipboard", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "clipboard", { value: { writeText }, configurable: true });
    m.run.mockResolvedValue(result());
    await open(listOf([mod()]));
    fireEvent.click(runBtn("Sập tiến trình bằng id lạ"));
    await screen.findByTestId("debug-visual");
    fireEvent.click(screen.getByRole("button", { name: "Văn bản" }));
    const pre = await screen.findByTestId("debug-text");
    expect(pre.textContent).toBe(formatResultText(result()));
    expect(pre.textContent).toContain("✔ Hồ sơ id %2F trả 404 — HTTP 404");
    fireEvent.click(screen.getByRole("button", { name: /Sao chép kết quả/ }));
    await waitFor(() => expect(writeText).toHaveBeenCalledWith(formatResultText(result())));
    await waitFor(() => expect(m.snack.success).toHaveBeenCalledWith("Đã sao chép kết quả."));
  });

  it("module 'cần kiểm tay' hiện danh sách bước; module bị bỏ qua hiện lý do", async () => {
    m.run.mockImplementation(async (id) => id === "manual-external"
      ? result({ id, status: "manual", summary: "Cần kiểm tay", checks: [], metrics: [], logs: [], steps: [{ title: "Bật Email enumeration protection", how: "Firebase Console → Authentication." }] })
      : result({ id, status: "skip", summary: "Không có mạng", reason: "Không gọi được Firestore REST", checks: [], metrics: [], logs: [] }));
    await open(listOf([mod({ id: "manual-external", title: "Việc cần kiểm tay", mode: "manual" }), mod({ id: "rules-private-collections", title: "Rules" })]));
    fireEvent.click(runBtn("Việc cần kiểm tay"));
    expect(await screen.findByText("Bật Email enumeration protection")).toBeTruthy();
    expect(screen.getByText("Firebase Console → Authentication.")).toBeTruthy();
    fireEvent.click(runBtn("Rules"));
    expect(await screen.findByText(/Bỏ qua: Không gọi được Firestore REST/)).toBeTruthy();
  });

  it("lỗi từ máy chủ (vd. 409 đang bận) → thông báo lỗi, KHÔNG hiện kết quả giả", async () => {
    m.run.mockRejectedValue({ message: "Đang chạy module khác.", response: { data: { code: "DEBUG_BUSY" } } });
    await open(listOf([mod()]));
    fireEvent.click(runBtn("Sập tiến trình bằng id lạ"));
    await waitFor(() => expect(m.snack.error).toHaveBeenCalledWith("Đang chạy module khác."));
    expect(screen.queryByTestId("debug-visual")).toBeNull();
    expect(runBtn("Sập tiến trình bằng id lạ").disabled).toBe(false); // thoát trạng thái bận để thử lại
  });
});

describe("Chạy tất cả", () => {
  it("chạy TUẦN TỰ theo thứ tự danh sách (không bao giờ hai module cùng lúc), hiện tiến độ, rồi trả nút về trạng thái ban đầu", async () => {
    let inflight = 0; let maxInflight = 0; const order = [];
    m.run.mockImplementation(async (id) => {
      inflight++; maxInflight = Math.max(maxInflight, inflight); order.push(id);
      await new Promise((r) => setTimeout(r, 20));
      inflight--;
      return result({ id, title: id });
    });
    await open(listOf([mod({ id: "m1", title: "Một" }), mod({ id: "m2", title: "Hai" }), mod({ id: "m3", title: "Ba" })]));
    fireEvent.click(screen.getByRole("button", { name: "Chạy tất cả" }));
    expect(await screen.findByRole("button", { name: /Đang chạy \d\/3…/ })).toBeTruthy();
    await waitFor(() => expect(screen.getByRole("button", { name: "Chạy tất cả" })).toBeTruthy(), { timeout: 3000 });
    expect(order).toEqual(["m1", "m2", "m3"]);
    expect(maxInflight).toBe(1);
    expect(screen.getByTestId("debug-counts").textContent).toContain("Đạt 3");
  });

  it("một module lỗi giữa chừng → dừng, báo lỗi, các module sau KHÔNG bị chạy", async () => {
    m.run.mockImplementation(async (id) => { if (id === "m2") throw { message: "Máy chủ quá tải" }; return result({ id }); });
    await open(listOf([mod({ id: "m1", title: "Một" }), mod({ id: "m2", title: "Hai" }), mod({ id: "m3", title: "Ba" })]));
    fireEvent.click(screen.getByRole("button", { name: "Chạy tất cả" }));
    await waitFor(() => expect(m.snack.error).toHaveBeenCalledWith("Máy chủ quá tải"));
    expect(m.run.mock.calls.map((c) => c[0])).toEqual(["m1", "m2"]);
  });
});

describe("nhập lại mật khẩu (REAUTH_REQUIRED)", () => {
  const reauthErr = () => ({ message: "Cần nhập lại mật khẩu", response: { data: { code: "REAUTH_REQUIRED" } } });

  it("hết hạn → mở hộp mật khẩu (không báo lỗi); nhập đúng → chạy lại module đó và TIẾP TỤC các module còn lại", async () => {
    let first = true;
    m.run.mockImplementation(async (id) => { if (id === "m1" && first) { first = false; throw reauthErr(); } return result({ id }); });
    await open(listOf([mod({ id: "m1", title: "Một" }), mod({ id: "m2", title: "Hai" })]));
    fireEvent.click(screen.getByRole("button", { name: "Chạy tất cả" }));
    expect(await screen.findByText("Xác nhận để chạy kiểm tra")).toBeTruthy();
    expect(m.snack.error).not.toHaveBeenCalled();
    fireEvent.change(screen.getByLabelText(/Mật khẩu hiện tại/), { target: { value: "matkhau123" } });
    fireEvent.click(screen.getByRole("button", { name: "Xác nhận và chạy" }));
    await waitFor(() => expect(m.reauth).toHaveBeenCalledWith("matkhau123"));
    await waitFor(() => expect(m.run.mock.calls.map((c) => c[0])).toEqual(["m1", "m1", "m2"]));
    await waitFor(() => expect(screen.getByTestId("debug-counts").textContent).toContain("Đạt 2"));
  });

  it("nhập sai mật khẩu → lỗi hiện trong hộp, KHÔNG chạy module", async () => {
    m.run.mockRejectedValueOnce(reauthErr());
    await open(listOf([mod()]));
    fireEvent.click(runBtn("Sập tiến trình bằng id lạ"));
    await screen.findByText("Xác nhận để chạy kiểm tra");
    m.reauth.mockRejectedValue({ message: "Mật khẩu không đúng" });
    fireEvent.change(screen.getByLabelText(/Mật khẩu hiện tại/), { target: { value: "sai" } });
    fireEvent.click(screen.getByRole("button", { name: "Xác nhận và chạy" }));
    expect(await screen.findByText("Mật khẩu không đúng")).toBeTruthy();
    expect(m.run).toHaveBeenCalledTimes(1);
  });
});

describe("hàm thuần debugReport", () => {
  it("isReauthError chỉ nhận đúng mã REAUTH_REQUIRED", () => {
    expect(isReauthError({ response: { data: { code: "REAUTH_REQUIRED" } } })).toBe(true);
    for (const e of [null, {}, { response: {} }, { response: { data: { code: "DEBUG_BUSY" } } }, new Error("x")]) expect(isReauthError(e)).toBe(false);
  });

  it("countStatuses ưu tiên kết quả vừa chạy hơn lần chạy gần nhất; module chưa chạy tính là 'never'", () => {
    const mods = [mod({ id: "a", lastRun: { status: "fail" } }), mod({ id: "b", lastRun: { status: "pass" } }), mod({ id: "c" })];
    expect(countStatuses(mods, { a: { status: "pass" } })).toMatchObject({ pass: 2, fail: 0, never: 1 });
  });

  it("formatSummaryMarkdown liệt kê mọi module và nêu rõ các module không đạt", () => {
    const md = formatSummaryMarkdown({ appVersion: "2.3.0.171026", modules: [mod({ id: "a", ref: "A-01" }), mod({ id: "b", ref: "A-02", title: "Lỗi | có gạch" })], results: { a: result({ status: "fail", summary: "x | y" }) }, at: 1760000000000 });
    expect(md).toContain("# Báo cáo Gỡ lỗi — Twelve v2.3.0.171026");
    expect(md).toContain("| A-01 |");
    expect(md).toContain("Lỗi \\| có gạch");
    expect(md).toContain("x \\| y");
    expect(md).toContain("**Cần xem lại (1):** A-01");
  });

  it("copyText có đường dự phòng khi không có navigator.clipboard", async () => {
    Object.defineProperty(navigator, "clipboard", { value: undefined, configurable: true });
    document.execCommand = vi.fn(() => true);
    expect(await copyText("abc")).toBe(true);
    expect(document.execCommand).toHaveBeenCalledWith("copy");
    document.execCommand = vi.fn(() => false);
    expect(await copyText("abc")).toBe(false);
  });
});
