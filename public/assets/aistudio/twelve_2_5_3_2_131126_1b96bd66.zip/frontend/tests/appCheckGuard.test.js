// v2.5.3.121126 — App Check không được làm treo ứng dụng (xem src/utils/appCheckGuard.js và PATCH-25-NOTES.md).
// Chạy: npx vitest run tests/appCheckGuard.test.js
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { waitForRecaptcha, withTokenTimeout, RECAPTCHA_SCRIPT_URL } from "../src/utils/appCheckGuard";

// DOM giả tối thiểu: createElement("script") + head.appendChild — để tự bắn onload/onerror.
const fakeDoc = () => {
  const scripts = [];
  return {
    scripts,
    createElement: () => ({}),
    head: { appendChild: (el) => scripts.push(el) },
  };
};

describe("waitForRecaptcha", () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it("script bị chặn (onerror — vd. CSP) ⇒ REJECT ngay, không treo", async () => {
    const doc = fakeDoc();
    const p = waitForRecaptcha({ doc, win: {} });
    expect(doc.scripts).toHaveLength(1);
    expect(doc.scripts[0].src).toBe(RECAPTCHA_SCRIPT_URL.v3);
    doc.scripts[0].onerror();
    await expect(p).rejects.toThrow(/không tải được script reCAPTCHA/);
  });

  it("script không bao giờ báo gì (mạng treo) ⇒ REJECT khi hết timeout", async () => {
    const doc = fakeDoc();
    const p = waitForRecaptcha({ doc, win: {}, timeoutMs: 8000 });
    const assertion = expect(p).rejects.toThrow(/chưa sẵn sàng sau 8000ms/);
    await vi.advanceTimersByTimeAsync(8000);
    await assertion;
  });

  it("script tải xong nhưng không có grecaptcha.ready ⇒ REJECT", async () => {
    const doc = fakeDoc();
    const p = waitForRecaptcha({ doc, win: {} });
    doc.scripts[0].onload();
    await expect(p).rejects.toThrow(/không dùng được/);
  });

  it("script tải xong và grecaptcha.ready chạy ⇒ RESOLVE bằng grecaptcha (SDK sẽ thấy sẵn nên không nạp lại)", async () => {
    const doc = fakeDoc();
    const win = {};
    const p = waitForRecaptcha({ doc, win });
    win.grecaptcha = { ready: (cb) => cb() };
    doc.scripts[0].onload();
    await expect(p).resolves.toBe(win.grecaptcha);
  });

  it("grecaptcha đã có sẵn ⇒ không thêm script thứ hai", async () => {
    const doc = fakeDoc();
    const win = { grecaptcha: { ready: (cb) => cb() } };
    await expect(waitForRecaptcha({ doc, win })).resolves.toBe(win.grecaptcha);
    expect(doc.scripts).toHaveLength(0);
  });

  it("bản Enterprise: đúng URL và dùng grecaptcha.enterprise", async () => {
    const doc = fakeDoc();
    const win = {};
    const p = waitForRecaptcha({ doc, win, enterprise: true });
    expect(doc.scripts[0].src).toBe(RECAPTCHA_SCRIPT_URL.enterprise);
    win.grecaptcha = { enterprise: { ready: (cb) => cb() } };
    doc.scripts[0].onload();
    await expect(p).resolves.toBe(win.grecaptcha.enterprise);
  });

  it("ready bắn SAU khi đã quá hạn thì không đổi kết quả (không resolve muộn)", async () => {
    const doc = fakeDoc();
    const win = {};
    let late;
    const p = waitForRecaptcha({ doc, win, timeoutMs: 1000 });
    win.grecaptcha = { ready: (cb) => (late = cb) };
    doc.scripts[0].onload();
    const assertion = expect(p).rejects.toThrow(/chưa sẵn sàng/);
    await vi.advanceTimersByTimeAsync(1000);
    await assertion;
    expect(() => late()).not.toThrow();
  });
});

describe("withTokenTimeout", () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  const never = () => new Promise(() => {});

  it("provider trả token đúng hạn ⇒ chuyển tiếp nguyên giá trị", async () => {
    const inner = { initialize: vi.fn(), isEqual: vi.fn(), getToken: vi.fn().mockResolvedValue({ token: "t", expireTimeMillis: 1 }) };
    const p = withTokenTimeout(inner);
    await expect(p.getToken()).resolves.toEqual({ token: "t", expireTimeMillis: 1 });
  });

  it("provider báo lỗi ⇒ chuyển tiếp đúng lỗi đó (SDK tự xử lý: token giả + lỗi)", async () => {
    const err = new Error("recaptcha-error");
    const p = withTokenTimeout({ getToken: () => Promise.reject(err) });
    await expect(p.getToken()).rejects.toBe(err);
  });

  it("provider ném lỗi đồng bộ ⇒ REJECT, không ném ra ngoài", async () => {
    const p = withTokenTimeout({ getToken: () => { throw new Error("sync"); } });
    await expect(p.getToken()).rejects.toThrow("sync");
  });

  it("provider TREO ⇒ REJECT sau timeout (không treo vô hạn như 2.5.3), rồi bỏ qua trong thời gian nguội", async () => {
    const inner = { getToken: vi.fn(never) };
    const p = withTokenTimeout(inner, { timeoutMs: 5000, cooldownMs: 60000 });
    const first = expect(p.getToken()).rejects.toThrow(/quá 5000ms/);
    await vi.advanceTimersByTimeAsync(5000);
    await first;
    expect(inner.getToken).toHaveBeenCalledTimes(1);

    // Trong 60 giây: từ chối NGAY (các yêu cầu Auth/Firestore kế tiếp không phải chờ thêm 5 giây nữa), không gọi lại provider.
    await expect(p.getToken()).rejects.toThrow(/tạm bỏ qua/);
    expect(inner.getToken).toHaveBeenCalledTimes(1);

    // Hết thời gian nguội: thử lại provider.
    await vi.advanceTimersByTimeAsync(60000);
    const again = expect(p.getToken()).rejects.toThrow(/quá 5000ms/);
    await vi.advanceTimersByTimeAsync(5000);
    await again;
    expect(inner.getToken).toHaveBeenCalledTimes(2);
  });

  it("chuyển tiếp initialize(app) và isEqual cho SDK (cả hai do @firebase/app-check gọi trên provider)", () => {
    const inner = { initialize: vi.fn(), isEqual: vi.fn().mockReturnValue(true), getToken: vi.fn() };
    const a = withTokenTimeout(inner);
    const b = withTokenTimeout(inner);
    a.initialize("APP");
    expect(inner.initialize).toHaveBeenCalledWith("APP");
    expect(a.isEqual(b)).toBe(true);
    expect(a.isEqual({})).toBe(false);
    expect(a.isEqual(null)).toBe(false);
  });
});
