import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, act, renderHook, cleanup, waitFor } from "@testing-library/react";

let serverResponse = { fonts: [] };
let serverFail = false;
vi.mock("../src/api/fonts.api", () => ({
  getPublicFonts: vi.fn(() => (serverFail ? Promise.reject(new Error("net")) : Promise.resolve(serverResponse))),
}));
vi.mock("../src/api/client", () => ({ default: { defaults: { baseURL: "https://api.example.com/api" } } }));

import {
  validateCustomFontInput, fontFromServerEntry, readCustomFonts, readServerFontsCache,
  DEFAULT_FONT_ID, MAX_CUSTOM_FONTS, formatFromUrl,
} from "../src/theme/fonts";
import { ThemeModeProvider, useThemeMode } from "../src/context/ThemeModeContext";
import FontGroupPanel from "../src/pages/settings/FontGroupPanel";

let created = [];
let failLoad = false;
class FakeFontFace {
  constructor(family, source, desc) { this.family = family; this.source = source; this.desc = desc; created.push(this); }
  load() { return failLoad ? Promise.reject(new Error("blocked")) : Promise.resolve(this); }
}
beforeEach(() => {
  created = []; failLoad = false; serverFail = false; serverResponse = { fonts: [] };
  localStorage.clear();
  globalThis.FontFace = FakeFontFace;
  Object.defineProperty(document, "fonts", { configurable: true, value: { add: vi.fn() } });
  vi.spyOn(console, "error").mockImplementation(() => {});
});
afterEach(() => { cleanup(); vi.restoreAllMocks(); });

describe("#2 validateCustomFontInput", () => {
  it("chấp nhận link hợp lệ, tự đặt tên từ tên file", () => {
    const r = validateCustomFontInput({ url: "https://cdn.example.com/fonts/Dep-Font_Viet.woff2" });
    expect(r.error).toBeUndefined();
    expect(r.label).toBe("Dep Font Viet");
    expect(validateCustomFontInput({ url: "https://cdn.example.com/a.otf", label: "  Tên   riêng " }).label).toBe("Tên riêng");
  });
  it.each([
    [""], ["not a url"], ["http://cdn.example.com/a.woff2"], ["javascript:alert(1)"], ["data:font/woff2;base64,AA"],
    ["https://user:pw@cdn.example.com/a.woff2"], ["https://localhost/a.woff2"], ["https://192.168.1.1/a.woff2"],
    ["https://[::1]/a.woff2"], ["https://fonts.googleapis.com/css2?family=Roboto"], ["https://cdn.example.com/s.css"],
    ["https://cdn.example.com/a.exe"], ["https://cdn.example.com/" + "a".repeat(600) + ".woff2"],
  ])("từ chối %s", (url) => {
    expect(validateCustomFontInput({ url }).error).toBeTruthy();
  });
  it("chặn trùng link và vượt giới hạn", () => {
    const a = fontFromServerEntry({ id: "srv-1", label: "x", url: "https://cdn.example.com/a.woff2" });
    expect(validateCustomFontInput({ url: "https://cdn.example.com/a.woff2" }, [a]).error).toMatch(/đã thêm/);
    const many = Array.from({ length: MAX_CUSTOM_FONTS }, (_, i) => fontFromServerEntry({ id: `srv-${i}`, label: "x", url: `https://cdn.example.com/${i}.woff2` }));
    expect(validateCustomFontInput({ url: "https://cdn.example.com/new.woff2" }, many).error).toMatch(/Tối đa/);
  });
});

describe("#1.1 fontFromServerEntry / định dạng", () => {
  it("ghép URL file tương đối với API base; bỏ qua dữ liệu xấu", () => {
    const f = fontFromServerEntry({ id: "srv-ab", label: "A", url: "/fonts/files/a.woff2", relative: true, format: "woff2", weight: "400" }, "https://api.example.com/api/");
    expect(f.faces[0]).toMatchObject({ url: "https://api.example.com/api/fonts/files/a.woff2", weight: "400", format: "woff2" });
    expect(f.source).toBe("server");
    expect(f.stack).toContain('"Twelve srv-ab"');
    expect(fontFromServerEntry({ id: "x", url: "javascript:alert(1)" })).toBeNull();
    expect(fontFromServerEntry({ id: "x", url: "/fonts/files/a.woff2", relative: true }, "")).toBeNull();
    expect(fontFromServerEntry(null)).toBeNull();
  });
  it("formatFromUrl", () => {
    expect(formatFromUrl("https://x.com/a.ttf?v=1")).toBe("truetype");
    expect(formatFromUrl("https://x.com/a")).toBeNull();
  });
  it("link không đuôi: không ép format woff2 sai", async () => {
    const f = fontFromServerEntry({ id: "srv-n", label: "N", url: "https://cdn.example.com/noext" });
    const { ensureFont } = await import("../src/theme/fonts");
    await ensureFont(f);
    expect(created[0].source).toBe('url("https://cdn.example.com/noext")');
  });
});

const wrapper = ThemeModeProvider;

describe("font server trong ThemeModeProvider", () => {
  it("tải từ API, gộp vào danh sách, lưu cache", async () => {
    serverResponse = { fonts: [{ id: "srv-aa", label: "Server A", url: "/fonts/files/a.woff2", relative: true, format: "woff2", weight: "100 900", note: "" }] };
    const { result } = renderHook(() => useThemeMode(), { wrapper });
    await waitFor(() => expect(result.current.fonts.some((f) => f.id === "srv-aa")).toBe(true));
    expect(JSON.parse(localStorage.getItem("twelve_server_fonts"))).toHaveLength(1);
    act(() => result.current.setFontId("srv-aa"));
    expect(result.current.fontId).toBe("srv-aa");
  });
  it("font server đã chọn dùng được NGAY từ cache (khung hình đầu), không chờ mạng", () => {
    localStorage.setItem("twelve_server_fonts", JSON.stringify([{ id: "srv-aa", label: "A", url: "https://cdn.example.com/a.woff2", relative: false }]));
    localStorage.setItem("twelve_font_id", "srv-aa");
    serverFail = true;
    const { result } = renderHook(() => useThemeMode(), { wrapper });
    expect(result.current.fontId).toBe("srv-aa");
  });
  it("lỗi mạng KHÔNG làm mất font đang chọn; API trả thành công mà thiếu font => về mặc định", async () => {
    localStorage.setItem("twelve_server_fonts", JSON.stringify([{ id: "srv-aa", label: "A", url: "https://cdn.example.com/a.woff2", relative: false }]));
    localStorage.setItem("twelve_font_id", "srv-aa");
    serverFail = true;
    const r1 = renderHook(() => useThemeMode(), { wrapper });
    await act(async () => {});
    expect(r1.result.current.fontId).toBe("srv-aa");
    r1.unmount();

    serverFail = false; serverResponse = { fonts: [] }; // SA đã gỡ font
    const r2 = renderHook(() => useThemeMode(), { wrapper });
    await waitFor(() => expect(r2.result.current.fontId).toBe(DEFAULT_FONT_ID));
  });
});

describe("#2 font tuỳ chỉnh trong ThemeModeProvider", () => {
  it("thêm: kiểm tra link, thử tải thật, lưu localStorage; xoá font đang dùng => về mặc định", async () => {
    const { result } = renderHook(() => useThemeMode(), { wrapper });
    let created1;
    await act(async () => { created1 = await result.current.addCustomFont({ url: "https://cdn.example.com/dep.woff2", label: "Đẹp" }); });
    expect(created1.id).toMatch(/^custom-/);
    expect(result.current.fonts.some((f) => f.id === created1.id)).toBe(true);
    expect(readCustomFonts()).toHaveLength(1);
    act(() => result.current.setFontId(created1.id));
    expect(result.current.fontId).toBe(created1.id);
    act(() => result.current.removeCustomFont(created1.id));
    expect(result.current.fontId).toBe(DEFAULT_FONT_ID);
    expect(readCustomFonts()).toHaveLength(0);
  });
  it("link không tải được => báo lỗi tiếng Việt và KHÔNG lưu", async () => {
    failLoad = true;
    const { result } = renderHook(() => useThemeMode(), { wrapper });
    await expect(act(async () => { await result.current.addCustomFont({ url: "https://cdn.example.com/hong.woff2" }); })).rejects.toThrow(/CORS/);
    expect(readCustomFonts()).toHaveLength(0);
    expect(result.current.fonts.filter((f) => f.source === "custom")).toHaveLength(0);
  });
  it("dữ liệu localStorage bị sửa (http, id lạ) bị bỏ qua", () => {
    localStorage.setItem("twelve_custom_fonts", JSON.stringify([
      { id: "custom-1", label: "ok", url: "https://cdn.example.com/a.woff2" },
      { id: "custom-2", label: "xấu", url: "http://insecure.example.com/a.woff2" },
      { id: "khac-3", label: "sai id", url: "https://cdn.example.com/b.woff2" },
    ]));
    expect(readCustomFonts().map((f) => f.id)).toEqual(["custom-1"]);
  });
  it("cache font server hỏng không làm app lỗi", () => {
    localStorage.setItem("twelve_server_fonts", "{không phải json");
    expect(readServerFontsCache("https://api.example.com/api")).toEqual([]);
  });
});

// v2.1.0: mỗi nhóm font là một mục lá riêng trong cây Cài đặt; test dựng cả 3 nhóm cạnh nhau để kiểm hành vi như trước.
describe("giao diện Cài đặt", () => {
  it("hiện nhóm client + server + tuỳ chỉnh; thêm font từ URL qua form rồi dùng ngay", async () => {
    serverResponse = { fonts: [{ id: "srv-aa", label: "Font Server A", url: "https://cdn.example.com/a.woff2", relative: false, format: "woff2", weight: "100 900", note: "" }] };
    render(
      <ThemeModeProvider>
        <FontGroupPanel source="client" />
        <FontGroupPanel source="server" />
        <FontGroupPanel source="custom" />
      </ThemeModeProvider>
    );
    await waitFor(() => expect(screen.getAllByText("Font Server A").length).toBeGreaterThan(0));
    expect(screen.getByText("Mặc định (Google Sans)")).toBeTruthy(); // nhóm client

    fireEvent.change(screen.getByLabelText("Link file font"), { target: { value: "http://xau.example.com/a.woff2" } });
    fireEvent.click(screen.getByText("Thêm và dùng"));
    await waitFor(() => expect(screen.getByText("Link phải bắt đầu bằng https://.")).toBeTruthy());

    fireEvent.change(screen.getByLabelText("Link file font"), { target: { value: "https://cdn.example.com/toi.woff2" } });
    fireEvent.change(screen.getByLabelText("Tên hiển thị (tuỳ chọn)"), { target: { value: "Font Của Tôi" } });
    fireEvent.click(screen.getByText("Thêm và dùng"));
    await waitFor(() => expect(screen.getAllByText("Font Của Tôi").length).toBeGreaterThan(0));
    expect(screen.getByText("Đang dùng")).toBeTruthy();
    expect(JSON.parse(localStorage.getItem("twelve_custom_fonts"))).toHaveLength(1);

    fireEvent.click(screen.getByLabelText("Xoá font Font Của Tôi"));
    await waitFor(() => expect(screen.queryAllByText("Font Của Tôi")).toHaveLength(0));
  });
});
