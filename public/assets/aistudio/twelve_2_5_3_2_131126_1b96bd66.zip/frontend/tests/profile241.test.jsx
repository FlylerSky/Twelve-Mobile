// v2.4.1 — ảnh bìa (bo góc nhỏ, kéo/thu phóng như avatar, dùng được cho URL ngoài) + hệ thống tab dùng chung (StickyTabs / useTabTree) + huy hiệu ở mọi nơi.
// Chạy: npx vitest run tests/profile241.test.jsx
import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor, within, act } from "@testing-library/react";
import { MemoryRouter, Routes, Route, useLocation } from "react-router-dom";
import { ThemeProvider } from "@mui/material/styles";
import { createAppTheme } from "../src/theme/theme";
import fs from "node:fs";
import path from "node:path";

const m = vi.hoisted(() => ({
  snack: { success: vi.fn(), error: vi.fn(), info: vi.fn(), warning: vi.fn() },
  uploadCover: vi.fn(),
  setCoverUrl: vi.fn(),
  setCoverCrop: vi.fn(),
  removeCover: vi.fn(),
  patchProfile: vi.fn(),
  prepareCoverImage: vi.fn(),
  cropperProps: [],
}));
let authState;

vi.mock("../src/context/AuthContext", () => ({ useAuth: () => authState }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => m.snack }));
vi.mock("../src/api/users.api", () => ({
  uploadCover: (...a) => m.uploadCover(...a),
  setCoverUrl: (...a) => m.setCoverUrl(...a),
  setCoverCrop: (...a) => m.setCoverCrop(...a),
  removeCover: (...a) => m.removeCover(...a),
}));
vi.mock("../src/utils/imageDownscale", async (orig) => ({ ...(await orig()), prepareCoverImage: (...a) => m.prepareCoverImage(...a) }));
// react-easy-crop cần layout thật (đo ảnh/khung) — jsdom không có. Thay bằng bản giả ghi lại props và tự báo khung khi "ảnh tải xong".
vi.mock("react-easy-crop", () => ({
  default: (props) => {
    m.cropperProps.push(props);
    return (
      <div data-testid="easy-crop">
        <button onClick={() => props.onCropComplete({ x: 12.5, y: 30, width: 50, height: 16.67 }, {})}>REPORT-AREA</button>
        <button onClick={() => props.mediaProps?.onError?.()}>IMAGE-ERROR</button>
      </div>
    );
  },
}));

import ProfileCover, { COVER_RADIUS, frameImageSx, isValidCrop } from "../src/components/profile/ProfileCover";
import CoverAdjustDialog from "../src/components/profile/CoverAdjustDialog";
import CoverImageRow from "../src/pages/settings/CoverImageRow";
import StickyTabs from "../src/components/tabs/StickyTabs";
import TabTreeBars from "../src/components/tabs/TabTreeBars";
import useTabTree from "../src/components/tabs/useTabTree";
import { fitWithin } from "../src/utils/imageDownscale";

const ME = { uid: "me1", displayName: "Tôi", coverUrl: null, coverCrop: null };
beforeEach(() => {
  [m.uploadCover, m.setCoverUrl, m.setCoverCrop, m.removeCover, m.patchProfile, m.prepareCoverImage].forEach((f) => f.mockReset());
  Object.values(m.snack).forEach((f) => f.mockReset());
  m.cropperProps.length = 0;
  authState = { profile: ME, patchProfile: m.patchProfile };
  globalThis.URL.createObjectURL = vi.fn(() => "blob:test-cover");
  globalThis.URL.revokeObjectURL = vi.fn();
});
afterEach(cleanup);

const CROP = { x: 12.5, y: 30, width: 50, height: 16.67 };

// ======================================================================== Ảnh bìa: hiển thị
describe("ProfileCover — bo góc nhỏ, khung kéo/thu phóng, nền dự phòng", () => {
  it("bo góc NHỎ (8px) — không phải 32px như 2.4.0 (borderRadius: 2 × 16px của theme)", () => {
    // PHẢI dùng theme thật của Twelve (shape.borderRadius = 16): theme mặc định của MUI là 4 nên bản lỗi 2.4.0 sẽ lọt qua.
    render(
      <ThemeProvider theme={createAppTheme("light")}>
        <ProfileCover url="https://img.example.com/c.jpg" />
      </ThemeProvider>
    );
    const radius = getComputedStyle(screen.getByTestId("profile-cover")).borderRadius;
    expect(radius).toBe(COVER_RADIUS);
    expect(COVER_RADIUS).toBe("8px");
    expect(radius).not.toBe("32px");
  });

  it("không có khung: ảnh canh giữa (object-fit cover); có khung: phóng + dời đúng công thức, không méo", () => {
    expect(frameImageSx(null)).toEqual({ width: "100%", height: "100%", objectFit: "cover" });
    // khung rộng 50% ảnh, bắt đầu ở x=10%, y=20%, cao 16.667% → ảnh rộng 200% khung, dời -20% (trái), -120% (trên)
    const sx = frameImageSx({ x: 10, y: 20, width: 50, height: 50 / 3 });
    expect(sx.position).toBe("absolute");
    expect(sx.width).toBe("200.000%");
    expect(sx.height).toBe("600.000%");
    expect(sx.left).toBe("-20.000%");
    expect(sx.top).toBe("-120.000%");
    expect(sx.objectFit).toBe("fill");
    // khung toàn ảnh = không phóng
    expect(frameImageSx({ x: 0, y: 0, width: 100, height: 100 }).width).toBe("100.000%");
  });

  it("khung hỏng/lạ KHÔNG lọt vào CSS — rơi về canh giữa", () => {
    const bad = [
      { x: "10", y: 0, width: 50, height: 50 },
      { x: 0, y: 0, width: NaN, height: 50 },
      { x: 0, y: 0, width: 5, height: 50 }, // phóng > 10 lần
      { x: -3, y: 0, width: 50, height: 50 },
      { x: 80, y: 0, width: 50, height: 50 },
      { x: 0, y: 0, width: "50%; background:url(x)", height: 50 },
      "chuỗi", 42, [],
    ];
    for (const b of bad) {
      expect(isValidCrop(b), JSON.stringify(b)).toBe(false);
      expect(frameImageSx(b).objectFit).toBe("cover");
    }
    expect(isValidCrop(CROP)).toBe(true);
  });

  it("áp khung lên <img>; ảnh lỗi → nền gradient, không còn <img>, báo onLoadError; đổi URL thì thử lại", () => {
    const onErr = vi.fn();
    const { rerender } = render(<ProfileCover url="https://img.example.com/a.jpg" crop={CROP} onLoadError={onErr} />);
    const img = screen.getByTestId("profile-cover").querySelector("img");
    expect(img.style.width || getComputedStyle(img).width).toBeTruthy();
    expect(getComputedStyle(img).position).toBe("absolute");
    fireEvent.error(img);
    expect(onErr).toHaveBeenCalledTimes(1);
    expect(screen.getByTestId("profile-cover").querySelector("img")).toBeNull();
    rerender(<ProfileCover url="https://img.example.com/b.jpg" crop={null} onLoadError={onErr} />);
    expect(screen.getByTestId("profile-cover").querySelector("img")).toBeTruthy();
  });

  it("chưa có ảnh bìa: không có <img>", () => {
    render(<ProfileCover url={null} />);
    expect(screen.getByTestId("profile-cover").querySelector("img")).toBeNull();
  });
});

// ======================================================================== Hộp kéo/thu phóng
describe("CoverAdjustDialog — kéo & thu phóng như avatar, KHÔNG cắt ảnh", () => {
  const open = (props = {}) => {
    const onSave = vi.fn().mockResolvedValue(undefined);
    const onClose = vi.fn();
    render(<CoverAdjustDialog open imageSrc="https://img.example.com/a.jpg" onSave={onSave} onClose={onClose} {...props} />);
    return { onSave, onClose };
  };
  const lastCropper = () => m.cropperProps.at(-1);

  it("khung cắt chữ nhật tỉ lệ 3:1, có thanh thu phóng 1–3 và nút Đặt lại", () => {
    open();
    expect(lastCropper()).toMatchObject({ aspect: 3, cropShape: "rect", minZoom: 1, maxZoom: 3, image: "https://img.example.com/a.jpg" });
    expect(screen.getByLabelText("Thu phóng ảnh bìa")).toBeTruthy();
    expect(screen.getByRole("button", { name: "Đặt lại" })).toBeTruthy();
  });

  it("Lưu bị khoá tới khi có khung; bấm Lưu → onSave(khung %) rồi đóng hộp", async () => {
    const { onSave, onClose } = open();
    const save = screen.getByRole("button", { name: "Lưu ảnh bìa" });
    expect(save.disabled).toBe(true);
    fireEvent.click(screen.getByText("REPORT-AREA"));
    expect(save.disabled).toBe(false);
    fireEvent.click(save);
    await waitFor(() => expect(onSave).toHaveBeenCalledWith(CROP));
    await waitFor(() => expect(onClose).toHaveBeenCalled());
  });

  it("mở lại ảnh đã có khung → đưa khung đang lưu vào lại đúng chỗ (initialCroppedAreaPercentages); khung hỏng thì bỏ", () => {
    open({ initialCrop: CROP });
    expect(lastCropper().initialCroppedAreaPercentages).toEqual(CROP);
    cleanup();
    m.cropperProps.length = 0;
    open({ initialCrop: { x: "a", y: 0, width: 50, height: 50 } });
    expect(lastCropper().initialCroppedAreaPercentages).toBeUndefined();
  });

  it("lưu thất bại: hiện lỗi NGAY TRONG hộp, hộp KHÔNG đóng, bấm lại được", async () => {
    const onSave = vi.fn().mockRejectedValue({ message: "Khung ảnh bìa không hợp lệ." });
    const { onClose } = open({ onSave });
    fireEvent.click(screen.getByText("REPORT-AREA"));
    fireEvent.click(screen.getByRole("button", { name: "Lưu ảnh bìa" }));
    expect(await screen.findByText("Khung ảnh bìa không hợp lệ.")).toBeTruthy();
    expect(onClose).not.toHaveBeenCalled();
    expect(screen.getByRole("button", { name: "Lưu ảnh bìa" }).disabled).toBe(false);
  });

  it("ảnh không tải được (URL hỏng): báo lỗi rõ ràng, khoá Lưu", () => {
    open();
    fireEvent.click(screen.getByText("REPORT-AREA"));
    fireEvent.click(screen.getByText("IMAGE-ERROR"));
    expect(screen.getByText(/Không tải được ảnh này để chỉnh/)).toBeTruthy();
    expect(screen.getByRole("button", { name: "Lưu ảnh bìa" }).disabled).toBe(true);
  });
});

// ======================================================================== Cài đặt > Ảnh bìa
describe("CoverImageRow — tải lên / dùng đường dẫn / điều chỉnh / gỡ", () => {
  const btn = (name) => screen.getByRole("button", { name });
  const pickFile = async (file = new File(["x"], "a.jpg", { type: "image/jpeg" })) => {
    await act(async () => fireEvent.change(screen.getByTestId("cover-file-input"), { target: { files: [file] } }));
  };

  it("chưa có ảnh bìa: có 'Tải ảnh lên' và 'Dùng đường dẫn'; KHÔNG có 'Điều chỉnh' và 'Gỡ ảnh bìa'", () => {
    render(<CoverImageRow />);
    expect(btn("Tải ảnh lên")).toBeTruthy();
    expect(btn("Dùng đường dẫn")).toBeTruthy();
    expect(screen.queryByRole("button", { name: "Điều chỉnh" })).toBeNull();
    expect(screen.queryByRole("button", { name: "Gỡ ảnh bìa" })).toBeNull();
  });

  it("tải ảnh lên: chọn file → thu nhỏ → mở hộp kéo/thu phóng với ảnh đó → Lưu gửi (ảnh, khung %) → vá hồ sơ cả ảnh lẫn khung", async () => {
    const blob = new Blob(["jpeg"], { type: "image/jpeg" });
    m.prepareCoverImage.mockResolvedValue(blob);
    m.uploadCover.mockResolvedValue({ coverUrl: "https://res.cloudinary.com/x/c.jpg", coverCrop: CROP });
    render(<CoverImageRow />);
    await pickFile();
    await waitFor(() => expect(m.cropperProps.at(-1)?.image).toBe("blob:test-cover"));
    expect(m.cropperProps.at(-1).aspect).toBe(3);
    fireEvent.click(screen.getByText("REPORT-AREA"));
    fireEvent.click(screen.getByRole("button", { name: "Lưu ảnh bìa" }));
    await waitFor(() => expect(m.uploadCover).toHaveBeenCalledWith(blob, CROP));
    await waitFor(() => expect(m.patchProfile).toHaveBeenCalledWith({ coverUrl: "https://res.cloudinary.com/x/c.jpg", coverCrop: CROP }));
    expect(m.setCoverCrop).not.toHaveBeenCalled();
    await waitFor(() => expect(URL.revokeObjectURL).toHaveBeenCalledWith("blob:test-cover")); // không rò URL tạm
  });

  it("file không dùng được (sai định dạng/quá lớn): báo lỗi, KHÔNG mở hộp, không gọi API", async () => {
    m.prepareCoverImage.mockRejectedValue(new Error("Chỉ nhận ảnh JPEG, PNG hoặc WebP."));
    render(<CoverImageRow />);
    await pickFile(new File(["x"], "a.gif", { type: "image/gif" }));
    await waitFor(() => expect(m.snack.error).toHaveBeenCalledWith("Chỉ nhận ảnh JPEG, PNG hoặc WebP."));
    expect(screen.queryByTestId("easy-crop")).toBeNull();
    expect(m.uploadCover).not.toHaveBeenCalled();
  });

  it("tải lên thất bại: lỗi hiện trong hộp, hộp giữ mở, KHÔNG vá hồ sơ", async () => {
    m.prepareCoverImage.mockResolvedValue(new Blob(["j"]));
    m.uploadCover.mockRejectedValue({ message: "Ảnh quá lớn (tối đa 3MB)." });
    render(<CoverImageRow />);
    await pickFile();
    await waitFor(() => expect(screen.getByTestId("easy-crop")).toBeTruthy());
    fireEvent.click(screen.getByText("REPORT-AREA"));
    fireEvent.click(screen.getByRole("button", { name: "Lưu ảnh bìa" }));
    expect(await screen.findByText("Ảnh quá lớn (tối đa 3MB).")).toBeTruthy();
    expect(m.patchProfile).not.toHaveBeenCalled();
  });

  it("dùng đường dẫn: lưu URL (đã cắt khoảng trắng) → vá hồ sơ → MỞ LUÔN hộp kéo/thu phóng cho ảnh đó → Lưu chỉ gửi khung (không tải lại ảnh)", async () => {
    m.setCoverUrl.mockResolvedValue({ coverUrl: "https://img.example.com/a.png", coverCrop: null });
    m.setCoverCrop.mockResolvedValue({ coverCrop: CROP });
    render(<CoverImageRow />);
    fireEvent.click(btn("Dùng đường dẫn"));
    const input = await screen.findByLabelText("Đường dẫn ảnh bìa");
    expect(btn("Lưu ảnh bìa").disabled).toBe(true);
    fireEvent.change(input, { target: { value: "  https://img.example.com/a.png  " } });
    fireEvent.click(btn("Lưu ảnh bìa"));
    await waitFor(() => expect(m.setCoverUrl).toHaveBeenCalledWith("https://img.example.com/a.png"));
    await waitFor(() => expect(m.patchProfile).toHaveBeenCalledWith({ coverUrl: "https://img.example.com/a.png", coverCrop: null }));
    await waitFor(() => expect(m.cropperProps.at(-1)?.image).toBe("https://img.example.com/a.png")); // URL ngoài cũng kéo/thu phóng được
    fireEvent.click(screen.getByText("REPORT-AREA"));
    fireEvent.click(screen.getByRole("button", { name: "Lưu vị trí" }));
    await waitFor(() => expect(m.setCoverCrop).toHaveBeenCalledWith(CROP));
    expect(m.uploadCover).not.toHaveBeenCalled();
    await waitFor(() => expect(m.patchProfile).toHaveBeenCalledWith({ coverCrop: CROP }));
  });

  it("dùng đường dẫn bị backend từ chối (domain chưa được phép): lý do hiện trong hộp URL, hộp KHÔNG đóng, không mở hộp kéo/thu phóng", async () => {
    m.setCoverUrl.mockRejectedValue({ message: "Ảnh bìa phải đến từ một domain được phép nhúng (xem mục Quản trị > Domain nhúng)." });
    render(<CoverImageRow />);
    fireEvent.click(btn("Dùng đường dẫn"));
    fireEvent.change(await screen.findByLabelText("Đường dẫn ảnh bìa"), { target: { value: "https://la.example.org/a.png" } });
    fireEvent.click(btn("Lưu ảnh bìa"));
    expect(await screen.findByText(/domain được phép nhúng/)).toBeTruthy();
    expect(screen.getByLabelText("Đường dẫn ảnh bìa")).toBeTruthy();
    expect(screen.queryByTestId("easy-crop")).toBeNull();
    expect(m.patchProfile).not.toHaveBeenCalled();
  });

  it("đã có ảnh bìa: 'Điều chỉnh' mở lại hộp với ảnh + khung đang lưu → Lưu gửi chỉ khung (ảnh tải lên hay URL ngoài đều vậy)", async () => {
    authState = { ...authState, profile: { ...ME, coverUrl: "https://img.example.com/c.png", coverCrop: CROP } };
    m.setCoverCrop.mockResolvedValue({ coverCrop: { ...CROP, x: 20 } });
    render(<CoverImageRow />);
    fireEvent.click(btn("Điều chỉnh"));
    expect(m.cropperProps.at(-1)).toMatchObject({ image: "https://img.example.com/c.png", initialCroppedAreaPercentages: CROP });
    fireEvent.click(screen.getByText("REPORT-AREA"));
    fireEvent.click(screen.getByRole("button", { name: "Lưu vị trí" }));
    await waitFor(() => expect(m.setCoverCrop).toHaveBeenCalledWith(CROP));
    expect(m.uploadCover).not.toHaveBeenCalled();
    expect(m.setCoverUrl).not.toHaveBeenCalled();
  });

  it("đã có ảnh bìa: xem trước dùng đúng khung đã lưu; 'Gỡ ảnh bìa' gọi API và vá hồ sơ về null cả ảnh lẫn khung", async () => {
    authState = { ...authState, profile: { ...ME, coverUrl: "https://img.example.com/c.png", coverCrop: CROP } };
    m.removeCover.mockResolvedValue({ coverUrl: null, coverCrop: null });
    render(<CoverImageRow />);
    const img = screen.getByAltText("Ảnh bìa hiện tại");
    expect(img.getAttribute("src")).toBe("https://img.example.com/c.png");
    expect(getComputedStyle(img).position).toBe("absolute"); // khung được áp
    fireEvent.click(btn("Gỡ ảnh bìa"));
    await waitFor(() => expect(m.removeCover).toHaveBeenCalled());
    await waitFor(() => expect(m.patchProfile).toHaveBeenCalledWith({ coverUrl: null, coverCrop: null }));
  });

  it("ảnh bìa hiện tại không tải được → cảnh báo rõ ràng và ẩn 'Điều chỉnh' (không có gì để chỉnh)", async () => {
    authState = { ...authState, profile: { ...ME, coverUrl: "https://img.example.com/hong.png" } };
    render(<CoverImageRow />);
    expect(screen.getByRole("button", { name: "Điều chỉnh" })).toBeTruthy();
    fireEvent.error(screen.getByAltText("Ảnh bìa hiện tại"));
    expect(await screen.findByText(/Không tải được ảnh bìa/)).toBeTruthy();
    expect(screen.queryByRole("button", { name: "Điều chỉnh" })).toBeNull();
  });
});

describe("thu nhỏ ảnh trước khi tải lên (ảnh bìa lưu nguyên ảnh nên phải vừa giới hạn 3 MB của backend)", () => {
  it("fitWithin: chỉ thu khi cạnh dài vượt giới hạn, giữ tỉ lệ, không bao giờ phóng to", () => {
    expect(fitWithin(4000, 3000, 2400)).toEqual({ width: 2400, height: 1800, scaled: true });
    expect(fitWithin(3000, 4000, 2400)).toEqual({ width: 1800, height: 2400, scaled: true });
    expect(fitWithin(1500, 500, 2400)).toEqual({ width: 1500, height: 500, scaled: false });
    expect(fitWithin(2400, 2400, 2400).scaled).toBe(false);
    expect(fitWithin(0, 0, 2400).scaled).toBe(false);
  });
});

// ======================================================================== Hệ thống tab dùng chung
describe("StickyTabs — một hàng tab sticky dùng chung", () => {
  const tabs = [{ key: "a", label: "Alpha" }, { key: "b", label: "Beta" }, { key: "c", label: "Gamma", disabled: true }];

  it("chọn tab khác → onChange(key); bấm lại tab đang mở → KHÔNG onChange nhưng onTabClick vẫn chạy (Cài đặt cần để 'về gốc tab')", () => {
    const onChange = vi.fn();
    const onTabClick = vi.fn();
    render(<StickyTabs tabs={tabs} value="a" onChange={onChange} onTabClick={onTabClick} />);
    fireEvent.click(screen.getByRole("tab", { name: "Alpha" }));
    expect(onChange).not.toHaveBeenCalled();
    expect(onTabClick).toHaveBeenCalledWith(expect.objectContaining({ key: "a" }));
    fireEvent.click(screen.getByRole("tab", { name: "Beta" }));
    expect(onChange).toHaveBeenCalledWith("b", expect.objectContaining({ key: "b" }));
    expect(screen.getByRole("tab", { name: "Gamma" }).disabled).toBe(true);
  });

  it("value không khớp tab nào → không tab nào được chọn (không lỗi)", () => {
    render(<StickyTabs tabs={tabs} value="khong-co" />);
    expect(screen.getAllByRole("tab").every((t) => t.getAttribute("aria-selected") === "false")).toBe(true);
  });

  it("nhiều cấp: hàng sâu hơn có z-index cao hơn (đè hàng cha khi cuộn) và cùng `top` — quy ước Xu hướng", () => {
    render(
      <>
        <StickyTabs level={0} tabs={tabs} value="a" />
        <StickyTabs level={1} tabs={tabs} value="a" />
        <StickyTabs level={2} tabs={tabs} value="a" />
      </>
    );
    const z = [0, 1, 2].map((l) => Number(getComputedStyle(screen.getByTestId(`sticky-tabs-${l}`)).zIndex));
    expect(z).toEqual([11, 12, 13]);
    const tops = [0, 1, 2].map((l) => getComputedStyle(screen.getByTestId(`sticky-tabs-${l}`)).top);
    expect(new Set(tops).size).toBe(1);
    expect(getComputedStyle(screen.getByTestId("sticky-tabs-0")).position).toBe("sticky");
  });
});

describe("useTabTree + TabTreeBars — tab, sub-tab và tab có điều kiện, đồng bộ URL", () => {
  const Dummy = () => null;
  const TREE = [
    { key: "home", label: "Trang chủ", Component: Dummy },
    {
      key: "posts",
      label: "Bài viết",
      children: [
        { key: "all", label: "Tất cả", Component: Dummy },
        { key: "media", label: "Ảnh", Component: Dummy, children: [{ key: "recent", label: "Gần đây", Component: Dummy }, { key: "old", label: "Cũ", Component: Dummy }] },
      ],
    },
    { key: "saved", label: "Đã lưu", Component: Dummy, visible: (ctx) => ctx.isOwn },
  ];
  const Harness = ({ isOwn = false }) => {
    const tree = useTabTree(TREE, { ctx: { isOwn } });
    const loc = useLocation();
    return (
      <>
        <TabTreeBars tabTree={tree} maxWidth="sm" />
        <div data-testid="url">{loc.search}</div>
        <div data-testid="path">{tree.path.map((n) => n.key).join("/")}</div>
      </>
    );
  };
  const mount = (url = "/", props) =>
    render(
      <MemoryRouter initialEntries={[url]}>
        <Routes><Route path="*" element={<Harness {...props} />} /></Routes>
      </MemoryRouter>
    );
  const names = (level) => within(screen.getByTestId(`sticky-tabs-${level}`)).getAllByRole("tab").map((t) => t.textContent);

  it("mặc định: tab đầu, URL sạch; chỉ 1 hàng (tab 'Trang chủ' không có sub-tab)", () => {
    mount();
    expect(screen.getByTestId("path").textContent).toBe("home");
    expect(screen.queryByTestId("sticky-tabs-1")).toBeNull();
    expect(names(0)).toEqual(["Trang chủ", "Bài viết"]); // 'Đã lưu' chỉ cho chủ hồ sơ
  });

  it("chọn tab có sub-tab → hàng thứ 2 xuất hiện, node con đầu tiên mở sẵn; URL chỉ có ?tab=posts (mặc định của cấp con không ghi)", () => {
    mount();
    fireEvent.click(screen.getByRole("tab", { name: "Bài viết" }));
    expect(screen.getByTestId("path").textContent).toBe("posts/all");
    expect(screen.getByTestId("url").textContent).toBe("?tab=posts");
    expect(names(1)).toEqual(["Tất cả", "Ảnh"]);
  });

  it("ba cấp: ?tab=posts&sub=media → có hàng thứ 3; chọn sub không mặc định ghi vào URL; đổi cấp trên thì cấp dưới về mặc định", () => {
    mount("/?tab=posts&sub=media");
    expect(names(2)).toEqual(["Gần đây", "Cũ"]);
    fireEvent.click(screen.getByRole("tab", { name: "Cũ" }));
    expect(screen.getByTestId("url").textContent).toBe("?tab=posts&sub=media&sub2=old");
    fireEvent.click(screen.getByRole("tab", { name: "Tất cả" }));
    expect(screen.getByTestId("url").textContent).toBe("?tab=posts"); // sub về mặc định → xoá cả sub2
    fireEvent.click(screen.getByRole("tab", { name: "Trang chủ" }));
    expect(screen.getByTestId("url").textContent).toBe("");
  });

  it("khoá lạ trên URL → về mặc định (không lỗi); tab 'visible' bị ẩn dù URL trỏ tới; chủ hồ sơ thì thấy", () => {
    mount("/?tab=khong-co&sub=la");
    expect(screen.getByTestId("path").textContent).toBe("home");
    cleanup();
    mount("/?tab=saved", { isOwn: false });
    expect(screen.getByTestId("path").textContent).toBe("home");
    cleanup();
    mount("/?tab=saved", { isOwn: true });
    expect(screen.getByTestId("path").textContent).toBe("saved");
    expect(names(0)).toEqual(["Trang chủ", "Bài viết", "Đã lưu"]);
  });

  it("giữ các tham số URL khác khi đổi tab", () => {
    mount("/?q=abc");
    fireEvent.click(screen.getByRole("tab", { name: "Bài viết" }));
    expect(screen.getByTestId("url").textContent).toBe("?q=abc&tab=posts");
  });
});

describe("mọi trang dùng ĐÚNG hệ tab chung (không tự dựng <Tabs> riêng) — chống lệch lại như 2.4.0", () => {
  const src = path.resolve(__dirname, "../src");
  const walk = (dir) =>
    fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]));
  const files = walk(src).filter((f) => f.endsWith(".jsx"));

  it("<Tabs> của MUI chỉ xuất hiện trong components/tabs/StickyTabs.jsx", () => {
    const offenders = files.filter((f) => /<Tabs[\s>]/.test(fs.readFileSync(f, "utf8"))).map((f) => path.relative(src, f));
    expect(offenders).toEqual([path.join("components", "tabs", "StickyTabs.jsx")]);
  });

  it("Cài đặt, Xu hướng và Profile đều dựng tab bằng StickyTabs/TabTreeBars", () => {
    const read = (rel) => fs.readFileSync(path.join(src, rel), "utf8");
    expect(read("pages/SettingsPage.jsx")).toMatch(/<StickyTabs/);
    expect(read("pages/TrendingPage.jsx")).toMatch(/<StickyTabs/);
    expect(read("pages/PublicProfilePage.jsx")).toMatch(/<TabTreeBars/);
  });
});

// ======================================================================== Huy hiệu có ở MỌI nơi hiện tên
describe("huy hiệu: không nơi nào hiện tên người dùng mà quên huy hiệu", () => {
  const src = path.resolve(__dirname, "../src");
  const walk = (dir) =>
    fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]));

  // File được phép hiện displayName mà KHÔNG có huy hiệu, kèm lý do. Thêm chỗ mới ở đây phải có lý do chính đáng.
  const EXEMPT = {
    "components/ProfileFields.jsx": "ô nhập form",
    "components/WelcomeSetupDialog.jsx": "form thiết lập lần đầu (ô nhập + chữ cái avatar)",
    "pages/RegisterPage.jsx": "form đăng ký",
    "pages/settings/AccountInfoPanel.jsx": "form sửa thông tin của chính mình (chữ cái avatar + ô nhập)",
    "pages/settings/AdminAssetsPanel.jsx": "bảng thống kê dung lượng của SA — không phải nơi hiển thị danh tính",
  };
  // Hiện tên thành CHỮ trong JSX: {x.displayName}, {x?.displayName || "..."} … (không tính chữ cái avatar `displayName?.[0]` và gán state/thuộc tính).
  const SHOWS_NAME = /\{[^{}]*\bdisplayName\b(?!\?*\.?\[)[^{}]*\}/;

  it("mọi file .jsx hiện displayName đều dùng UserName/UserBadges (hoặc nằm trong danh sách miễn trừ có lý do)", () => {
    const offenders = [];
    for (const f of walk(src).filter((x) => x.endsWith(".jsx"))) {
      const rel = path.relative(src, f).split(path.sep).join("/");
      const text = fs.readFileSync(f, "utf8");
      const body = text.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, ""); // bỏ chú thích
      const jsxText = body
        .split("\n")
        .filter((line) => SHOWS_NAME.test(line) && !/(useState|label=|value=|setForm|const \{|form\.|useSeo|title:|description:|`)/.test(line))
        .join("\n");
      if (!jsxText.trim()) continue;
      if (/\bUserName\b|\bUserBadges\b/.test(body)) continue;
      if (EXEMPT[rel]) continue;
      offenders.push(`${rel}: ${jsxText.trim().split("\n")[0].trim()}`);
    }
    expect(offenders).toEqual([]);
  });

  it("các nơi chính (thẻ bài, bình luận, trang POST, Menu, đầu trang Profile, bảng xếp hạng) đều vẽ huy hiệu", () => {
    const read = (rel) => fs.readFileSync(path.join(src, rel), "utf8");
    expect(read("components/PostCard.jsx")).toMatch(/UserName/);
    expect(read("components/comments/CommentItem.jsx")).toMatch(/UserName/);
    expect(read("pages/PostDetailPage.jsx")).toMatch(/UserName/);
    expect(read("components/Navbar.jsx")).toMatch(/<UserBadges/);
    expect(read("components/profile/ProfileHeader.jsx")).toMatch(/<UserBadges/);
    expect(read("components/RankingList.jsx")).toMatch(/<UserBadges/);
  });
});
