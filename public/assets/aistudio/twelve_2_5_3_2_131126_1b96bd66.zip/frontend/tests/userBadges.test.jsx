// v2.4.0 — Huy hiệu cạnh tên: chỉ icon; 1 huy hiệu → icon; nhiều → "3 chấm"; bấm → danh sách; bấm không kích hoạt phần tử cha; có mặt ở mọi nơi hiện tên.
// Chạy: npx vitest run tests/userBadges.test.jsx
import React from "react";
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, within } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import UserBadges from "../src/components/UserBadges";
import { UserName } from "../src/components/UserIdentity";

afterEach(cleanup);

describe("UserBadges", () => {
  it("không có huy hiệu → không vẽ gì", () => {
    const { container } = render(<UserBadges user={{ accountRole: "user" }} />);
    expect(container.querySelector('[data-testid="user-badges"]')).toBeNull();
  });

  it("1 huy hiệu → đúng MỘT nút icon (không có chữ mô tả dài), không phải 3 chấm", () => {
    render(<UserBadges user={{ accountRole: "admin" }} />);
    const btn = screen.getByTestId("user-badges");
    expect(btn.getAttribute("aria-label")).toBe("Huy hiệu: Quản trị viên");
    expect(screen.queryByTestId("badge-multi")).toBeNull();
    expect(btn.textContent).toBe(""); // chỉ icon, tiết kiệm chỗ
  });

  it("từ 2 huy hiệu → gộp thành MỘT huy hiệu 3 chấm; bấm vào mở danh sách đủ icon + tên + mô tả", () => {
    render(<UserBadges user={{ accountRole: "admin", isLegacyMember: true }} />);
    expect(screen.getAllByTestId("user-badges")).toHaveLength(1);
    expect(screen.getByTestId("badge-multi")).toBeTruthy();
    expect(screen.getByTestId("user-badges").getAttribute("aria-label")).toBe("Xem 2 huy hiệu");
    expect(screen.queryByTestId("badge-row-admin")).toBeNull(); // chưa bấm: danh sách chưa mở
    fireEvent.click(screen.getByTestId("user-badges"));
    const admin = screen.getByTestId("badge-row-admin");
    const legacy = screen.getByTestId("badge-row-legacy");
    expect(within(admin).getByText("Quản trị viên")).toBeTruthy();
    expect(within(legacy).getByText("Thành viên Twelve cũ")).toBeTruthy();
    expect(within(legacy).getByText(/phiên bản đầu tiên/)).toBeTruthy();
  });

  it("SA đặt tay (accountGroup=SA, accountRole vẫn là 'user') CÓ huy hiệu — ca khiến 2.4.0 không hiện huy hiệu", () => {
    render(<UserBadges user={{ accountGroup: "SA", accountRole: "user" }} />);
    expect(screen.getByTestId("user-badges").getAttribute("aria-label")).toBe("Huy hiệu: Tài khoản cấp cao");
  });

  it("bấm huy hiệu đơn cũng mở danh sách (1 mục)", () => {
    render(<UserBadges user={{ accountRole: "pro_user" }} />);
    fireEvent.click(screen.getByTestId("user-badges"));
    expect(screen.getByTestId("badge-row-pro")).toBeTruthy();
  });

  it("bấm huy hiệu KHÔNG kích hoạt onClick của phần tử cha (thẻ bài / hàng xếp hạng)", () => {
    const parent = vi.fn();
    render(
      <div onClick={parent}>
        <UserBadges user={{ accountRole: "dev", isLegacyMember: true }} />
      </div>
    );
    fireEvent.click(screen.getByTestId("user-badges"));
    expect(parent).not.toHaveBeenCalled();
  });

  it("dòng bảng xếp hạng (chỉ có `badges`) hiện đúng huy hiệu; `ids` truyền thẳng cũng được", () => {
    const { unmount } = render(<UserBadges user={{ displayName: "A", badges: ["moderator"] }} />);
    expect(screen.getByTestId("user-badges").getAttribute("aria-label")).toBe("Huy hiệu: Điều hành viên");
    unmount();
    render(<UserBadges ids={["tester", "legacy"]} />);
    expect(screen.getByTestId("badge-multi")).toBeTruthy();
  });
});

describe("UserName — huy hiệu có mặt ở MỌI nơi hiện tên (bài viết, bình luận…)", () => {
  const wrap = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  it("tên + huy hiệu ngay cạnh nhau", () => {
    wrap(<UserName user={{ uid: "u1", displayName: "Lan", accountRole: "moderator", isLegacyMember: false }} />);
    expect(screen.getByText("Lan")).toBeTruthy();
    expect(screen.getByTestId("user-badges")).toBeTruthy();
  });

  it("người thường không có huy hiệu nào; tên dự phòng vẫn hiện", () => {
    wrap(<UserName user={null} />);
    expect(screen.getByText("Người dùng Twelve")).toBeTruthy();
    expect(screen.queryByTestId("user-badges")).toBeNull();
  });

  it("showBadges={false} tắt huy hiệu", () => {
    wrap(<UserName user={{ uid: "u1", displayName: "Lan", accountRole: "admin" }} showBadges={false} />);
    expect(screen.queryByTestId("user-badges")).toBeNull();
  });
});
