// v2.2.0: Cài đặt > Tài khoản — hộp nhập lại mật khẩu, tên thật (ẩn/hiện/đổi), đổi mật khẩu, xoá tài khoản, quên mật khẩu, thông tin hồ sơ, đổi tag.
// Chạy: npx vitest run tests/account220.test.jsx
import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor, act } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

const m = vi.hoisted(() => ({
  reauth: vi.fn(),
  getRealName: vi.fn(),
  updateRealName: vi.fn(),
  updateTagName: vi.fn(),
  requestAccountDeletion: vi.fn(),
  updateMe: vi.fn(),
  forgotPassword: vi.fn(),
  checkTagName: vi.fn(),
  updatePassword: vi.fn(),
  signOut: vi.fn(),
  refreshProfile: vi.fn(),
  navigate: vi.fn(),
  snack: { success: vi.fn(), error: vi.fn(), warning: vi.fn(), info: vi.fn() },
  currentUser: { email: "me@example.com" },
}));
let authState;

vi.mock("../src/utils/reauth", () => ({
  reauthWithPassword: (...a) => m.reauth(...a),
  describeAuthError: (e) => (e && e.code === "auth/weak-password" ? "Mật khẩu mới quá yếu." : (e && e.message) || "lỗi"),
}));
vi.mock("../src/api/users.api", () => ({
  getRealName: (...a) => m.getRealName(...a),
  updateRealName: (...a) => m.updateRealName(...a),
  updateTagName: (...a) => m.updateTagName(...a),
  requestAccountDeletion: (...a) => m.requestAccountDeletion(...a),
  updateMe: (...a) => m.updateMe(...a),
  uploadAvatar: vi.fn(),
}));
vi.mock("../src/api/auth.api", () => ({ forgotPassword: (...a) => m.forgotPassword(...a), checkTagName: (...a) => m.checkTagName(...a) }));
vi.mock("../src/api/countries.api", () => ({ listCountries: () => Promise.resolve([{ code: "VN", name: "Việt Nam" }]) }));
vi.mock("../src/context/AuthContext", () => ({ useAuth: () => authState }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => m.snack }));
vi.mock("firebase/auth", () => ({ updatePassword: (...a) => m.updatePassword(...a) }));
vi.mock("../src/firebase", () => ({ auth: { get currentUser() { return m.currentUser; } } }));
vi.mock("../src/components/AvatarCropper", () => ({ default: () => null }));
vi.mock("react-router-dom", async () => ({ ...(await vi.importActual("react-router-dom")), useNavigate: () => m.navigate }));

import PasswordConfirmDialog from "../src/components/PasswordConfirmDialog";
import ForgotPasswordDialog from "../src/components/ForgotPasswordDialog";
import RealNameRow, { REVEAL_MS } from "../src/pages/settings/RealNameRow";
import ChangePasswordPanel, { validateNewPassword } from "../src/pages/settings/ChangePasswordPanel";
import DeleteAccountPanel from "../src/pages/settings/DeleteAccountPanel";
import AccountInfoPanel from "../src/pages/settings/AccountInfoPanel";

const pwField = () => screen.getByLabelText(/Mật khẩu hiện tại/);
const typePw = (v = "matkhau123") => fireEvent.change(pwField(), { target: { value: v } });
const btn = (name) => screen.getByRole("button", { name });

beforeEach(() => {
  Object.values(m).forEach((f) => f && f.mockReset && f.mockReset());
  Object.values(m.snack).forEach((f) => f.mockReset());
  m.reauth.mockResolvedValue(undefined);
  m.signOut.mockResolvedValue(undefined);
  m.refreshProfile.mockResolvedValue(undefined);
  m.updatePassword.mockResolvedValue(undefined);
  m.currentUser = { email: "me@example.com" };
  authState = {
    firebaseUser: { email: "me@example.com" },
    profile: { uid: "u1", displayName: "Văn A", tagName: "@vana", birthday: "2000-01-01", gender: "male", country: "VN", avatarUrl: null },
    isSA: false,
    signOut: m.signOut,
    refreshProfile: m.refreshProfile,
  };
});
afterEach(() => {
  cleanup();
  vi.useRealTimers();
});

describe("PasswordConfirmDialog", () => {
  const open = (props = {}) => {
    const onConfirm = props.onConfirm || vi.fn().mockResolvedValue(undefined);
    const onClose = props.onClose || vi.fn();
    render(<PasswordConfirmDialog open title="Xác nhận" confirmText="Đồng ý" {...props} onConfirm={onConfirm} onClose={onClose} />);
    return { onConfirm, onClose };
  };

  it("nút xác nhận khoá cho tới khi gõ mật khẩu; đúng mật khẩu ⇒ reauth rồi MỚI chạy onConfirm rồi đóng", async () => {
    const order = [];
    m.reauth.mockImplementation(async () => order.push("reauth"));
    const { onConfirm, onClose } = open({ onConfirm: vi.fn(async () => order.push("confirm")) });
    expect(btn("Đồng ý").disabled).toBe(true);
    typePw("abc12345");
    expect(btn("Đồng ý").disabled).toBe(false);
    fireEvent.click(btn("Đồng ý"));
    await waitFor(() => expect(onClose).toHaveBeenCalled());
    expect(m.reauth).toHaveBeenCalledWith("abc12345");
    expect(order).toEqual(["reauth", "confirm"]);
    expect(onConfirm).toHaveBeenCalledTimes(1);
  });

  it("sai mật khẩu: hiện lỗi trong hộp, KHÔNG chạy onConfirm, KHÔNG đóng", async () => {
    m.reauth.mockRejectedValue(new Error("Mật khẩu không đúng."));
    const { onConfirm, onClose } = open();
    typePw("sai");
    fireEvent.click(btn("Đồng ý"));
    await screen.findByText("Mật khẩu không đúng.");
    expect(onConfirm).not.toHaveBeenCalled();
    expect(onClose).not.toHaveBeenCalled();
  });

  it("onConfirm (request backend) lỗi: hiện lỗi, giữ hộp mở để thử lại", async () => {
    const { onClose } = open({ onConfirm: vi.fn().mockRejectedValue(new Error("Backend từ chối")) });
    typePw();
    fireEvent.click(btn("Đồng ý"));
    await screen.findByText("Backend từ chối");
    expect(onClose).not.toHaveBeenCalled();
  });

  it("confirmDisabled (vd. chưa tick cam kết) giữ nút khoá dù đã nhập mật khẩu", () => {
    open({ confirmDisabled: true });
    typePw();
    expect(btn("Đồng ý").disabled).toBe(true);
  });
});

describe("RealNameRow — tên thật", () => {
  it("mặc định ẩn và không gọi API nào", () => {
    render(<RealNameRow />);
    expect(screen.getByText("••••••••••")).toBeTruthy();
    expect(m.getRealName).not.toHaveBeenCalled();
  });

  it("Hiện: chỉ gọi API SAU khi nhập đúng mật khẩu; hiện tên rồi TỰ ẨN lại sau 1 phút", async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    m.getRealName.mockResolvedValue("Nguyễn Văn A");
    render(<RealNameRow />);
    fireEvent.click(btn("Hiện"));
    expect(m.getRealName).not.toHaveBeenCalled(); // mới mở hộp mật khẩu
    typePw();
    fireEvent.click(btn("Hiện tên thật"));
    await screen.findByText("Nguyễn Văn A");
    expect(m.reauth).toHaveBeenCalledWith("matkhau123");
    expect(m.reauth.mock.invocationCallOrder[0]).toBeLessThan(m.getRealName.mock.invocationCallOrder[0]);
    await act(async () => { vi.advanceTimersByTime(REVEAL_MS + 100); });
    expect(screen.queryByText("Nguyễn Văn A")).toBeNull();
    expect(screen.getByText("••••••••••")).toBeTruthy();
  });

  it("sai mật khẩu: không bao giờ lấy tên thật, vẫn ẩn", async () => {
    m.reauth.mockRejectedValue(new Error("Mật khẩu không đúng."));
    render(<RealNameRow />);
    fireEvent.click(btn("Hiện"));
    typePw("sai");
    fireEvent.click(btn("Hiện tên thật"));
    await screen.findByText("Mật khẩu không đúng.");
    expect(m.getRealName).not.toHaveBeenCalled();
    expect(screen.getByText("••••••••••")).toBeTruthy();
  });

  it("Đổi: cần nhập tên mới + mật khẩu; gửi tên đã cắt khoảng trắng; xong thì ẩn lại", async () => {
    m.updateRealName.mockResolvedValue({});
    render(<RealNameRow />);
    fireEvent.click(btn("Đổi"));
    typePw();
    expect(btn("Lưu tên thật").disabled).toBe(true); // chưa có tên mới
    fireEvent.change(screen.getByLabelText("Tên thật mới"), { target: { value: "  Trần Thị B  " } });
    fireEvent.click(btn("Lưu tên thật"));
    await waitFor(() => expect(m.updateRealName).toHaveBeenCalledWith("Trần Thị B"));
    expect(m.reauth.mock.invocationCallOrder[0]).toBeLessThan(m.updateRealName.mock.invocationCallOrder[0]);
    expect(m.snack.success).toHaveBeenCalled();
  });
});

describe("ChangePasswordPanel — đổi mật khẩu", () => {
  it("validateNewPassword: thiếu mật khẩu cũ / quá ngắn / trùng mật khẩu cũ / không khớp / hợp lệ", () => {
    expect(validateNewPassword({ current: "", next: "12345678", confirm: "12345678" })).toMatch(/hiện tại/);
    expect(validateNewPassword({ current: "a", next: "1234567", confirm: "1234567" })).toMatch(/ít nhất 8/);
    expect(validateNewPassword({ current: "12345678", next: "12345678", confirm: "12345678" })).toMatch(/khác/);
    expect(validateNewPassword({ current: "cu123456", next: "moi12345", confirm: "moi123456" })).toMatch(/không khớp/);
    expect(validateNewPassword({ current: "cu123456", next: "moi12345", confirm: "moi12345" })).toBe("");
  });

  const fill = (cur, next, confirm) => {
    fireEvent.change(screen.getByLabelText("Mật khẩu hiện tại"), { target: { value: cur } });
    fireEvent.change(screen.getByLabelText("Mật khẩu mới"), { target: { value: next } });
    fireEvent.change(screen.getByLabelText("Nhập lại mật khẩu mới"), { target: { value: confirm } });
  };

  it("đúng mật khẩu cũ: reauth rồi updatePassword; xong thì xoá các ô", async () => {
    render(<ChangePasswordPanel />);
    fill("cu123456", "moi12345", "moi12345");
    fireEvent.click(btn("Đổi mật khẩu"));
    await waitFor(() => expect(m.updatePassword).toHaveBeenCalledWith(m.currentUser, "moi12345"));
    expect(m.reauth).toHaveBeenCalledWith("cu123456");
    expect(m.reauth.mock.invocationCallOrder[0]).toBeLessThan(m.updatePassword.mock.invocationCallOrder[0]);
    await waitFor(() => expect(screen.getByLabelText("Mật khẩu mới").value).toBe(""));
    expect(m.snack.success).toHaveBeenCalled();
  });

  it("sai mật khẩu cũ: báo lỗi và KHÔNG đổi mật khẩu", async () => {
    m.reauth.mockRejectedValue(Object.assign(new Error("Mật khẩu không đúng."), { code: "auth/invalid-credential" }));
    render(<ChangePasswordPanel />);
    fill("sai", "moi12345", "moi12345");
    fireEvent.click(btn("Đổi mật khẩu"));
    await screen.findByText("Mật khẩu không đúng.");
    expect(m.updatePassword).not.toHaveBeenCalled();
  });

  it("mật khẩu mới không hợp lệ bị chặn ngay ở giao diện, không gọi Firebase", async () => {
    render(<ChangePasswordPanel />);
    fill("cu123456", "ngan", "ngan");
    fireEvent.click(btn("Đổi mật khẩu"));
    await screen.findByText(/ít nhất 8/);
    expect(m.reauth).not.toHaveBeenCalled();
  });

  it("'Quên mật khẩu?' mở hộp quên mật khẩu với email của tài khoản đang đăng nhập, khoá không cho sửa", async () => {
    render(<ChangePasswordPanel />);
    fireEvent.click(btn("Quên mật khẩu?"));
    const email = await screen.findByLabelText(/^Email/);
    expect(email.value).toBe("me@example.com");
    expect(email.disabled).toBe(true);
  });
});

describe("ForgotPasswordDialog — quên mật khẩu", () => {
  it("gửi email đã nhập; hiện đúng thông báo chung của backend", async () => {
    m.forgotPassword.mockResolvedValue({ message: "Nếu email này thuộc một tài khoản Twelve, chúng tôi đã gửi hướng dẫn." });
    render(<ForgotPasswordDialog open onClose={() => {}} initialEmail="" />);
    fireEvent.change(screen.getByLabelText(/^Email/), { target: { value: " me@example.com " } });
    fireEvent.click(btn("Gửi email"));
    await screen.findByText(/Nếu email này thuộc một tài khoản Twelve/);
    expect(m.forgotPassword).toHaveBeenCalledWith({ email: "me@example.com", captchaToken: null });
    expect(screen.queryByRole("button", { name: "Gửi email" })).toBeNull(); // đã xong: không cho gửi lại liên tục
  });

  it("lỗi từ backend (vd. quá nhiều lần) hiện trong hộp và cho thử lại", async () => {
    m.forgotPassword.mockRejectedValue(new Error("Bạn đã yêu cầu quá nhiều lần."));
    render(<ForgotPasswordDialog open onClose={() => {}} initialEmail="a@b.com" />);
    fireEvent.click(btn("Gửi email"));
    await screen.findByText("Bạn đã yêu cầu quá nhiều lần.");
    expect(btn("Gửi email").disabled).toBe(false);
  });
});

describe("DeleteAccountPanel — xoá tài khoản", () => {
  const openDialog = () => {
    render(
      <MemoryRouter>
        <DeleteAccountPanel />
      </MemoryRouter>
    );
    fireEvent.click(btn("Xoá tài khoản"));
  };
  const confirm = () => {
    fireEvent.click(screen.getByRole("checkbox"));
    typePw();
    fireEvent.click(btn("Xoá vĩnh viễn"));
  };

  it("phải tick 'tôi hiểu không thể hoàn tác' mới bấm được; xác nhận ⇒ reauth → gọi backend → đăng xuất → về trang chủ", async () => {
    m.requestAccountDeletion.mockResolvedValue({ status: "accepted" });
    openDialog();
    typePw();
    expect(btn("Xoá vĩnh viễn").disabled).toBe(true);
    fireEvent.click(screen.getByRole("checkbox"));
    expect(btn("Xoá vĩnh viễn").disabled).toBe(false);
    fireEvent.click(btn("Xoá vĩnh viễn"));
    await waitFor(() => expect(m.navigate).toHaveBeenCalledWith("/", { replace: true }));
    expect(m.reauth.mock.invocationCallOrder[0]).toBeLessThan(m.requestAccountDeletion.mock.invocationCallOrder[0]);
    expect(m.requestAccountDeletion.mock.invocationCallOrder[0]).toBeLessThan(m.signOut.mock.invocationCallOrder[0]);
  });

  it("sai mật khẩu: KHÔNG gửi yêu cầu xoá, KHÔNG đăng xuất", async () => {
    m.reauth.mockRejectedValue(new Error("Mật khẩu không đúng."));
    openDialog();
    confirm();
    await screen.findByText("Mật khẩu không đúng.");
    expect(m.requestAccountDeletion).not.toHaveBeenCalled();
    expect(m.signOut).not.toHaveBeenCalled();
  });

  it("backend báo tài khoản ĐÃ đang được xoá (gửi lại sau khi mất mạng): coi là thành công", async () => {
    m.requestAccountDeletion.mockRejectedValue({ message: "Tài khoản đang được xoá.", response: { status: 403, data: { code: "ACCOUNT_DELETING" } } });
    openDialog();
    confirm();
    await waitFor(() => expect(m.signOut).toHaveBeenCalled());
    expect(m.navigate).toHaveBeenCalledWith("/", { replace: true });
  });

  it("mất mạng, không có phản hồi: giải thích rõ, KHÔNG tự đăng xuất", async () => {
    m.requestAccountDeletion.mockRejectedValue({ message: "Đã có lỗi xảy ra, vui lòng thử lại." });
    openDialog();
    confirm();
    await screen.findByText(/Không nhận được phản hồi từ máy chủ/);
    expect(m.signOut).not.toHaveBeenCalled();
  });

  it("lỗi từ backend (vd. 403/500) hiện nguyên văn và không đăng xuất", async () => {
    m.requestAccountDeletion.mockRejectedValue({ message: "Máy chủ đang bận.", response: { status: 500, data: { error: "Máy chủ đang bận." } } });
    openDialog();
    confirm();
    await screen.findByText("Máy chủ đang bận.");
    expect(m.signOut).not.toHaveBeenCalled();
  });

  it("tài khoản SA: nút xoá bị khoá và có giải thích (backend cũng chặn)", () => {
    authState = { ...authState, isSA: true };
    render(
      <MemoryRouter>
        <DeleteAccountPanel />
      </MemoryRouter>
    );
    expect(btn("Xoá tài khoản").disabled).toBe(true);
    expect(screen.getByText(/không thể tự xoá/)).toBeTruthy();
  });
});

describe("AccountInfoPanel — thông tin tài khoản", () => {
  it("hiện thông tin hiện có; 'Lưu thay đổi' khoá khi chưa sửa; chỉ gửi ĐÚNG trường đã sửa", async () => {
    m.updateMe.mockResolvedValue({});
    render(<AccountInfoPanel />);
    expect(screen.getByText("@vana")).toBeTruthy();
    expect(screen.getByLabelText("Tên hiển thị").value).toBe("Văn A");
    expect(btn("Lưu thay đổi").disabled).toBe(true);
    fireEvent.change(screen.getByLabelText("Tên hiển thị"), { target: { value: "Văn B" } });
    expect(btn("Lưu thay đổi").disabled).toBe(false);
    fireEvent.click(btn("Lưu thay đổi"));
    await waitFor(() => expect(m.updateMe).toHaveBeenCalledWith({ displayName: "Văn B" }));
    await waitFor(() => expect(btn("Lưu thay đổi").disabled).toBe(true));
  });

  it("KHÔNG có ô tên thật dạng chữ rõ: chỉ có dấu che; tên thật không xuất hiện trong dữ liệu hồ sơ", () => {
    authState.profile.fullName = undefined;
    render(<AccountInfoPanel />);
    expect(screen.getByText("••••••••••")).toBeTruthy();
  });

  it("hồ sơ cập nhật realtime (điểm số...) KHÔNG ghi đè thứ người dùng đang gõ", () => {
    const { rerender } = render(<AccountInfoPanel />);
    fireEvent.change(screen.getByLabelText("Tên hiển thị"), { target: { value: "Đang gõ dở" } });
    authState = { ...authState, profile: { ...authState.profile, accountScore: 99 } };
    rerender(<AccountInfoPanel />);
    expect(screen.getByLabelText("Tên hiển thị").value).toBe("Đang gõ dở");
  });

  it("đổi Tag Name Search: chỉ cho bấm khi tag hợp lệ VÀ còn trống; gửi tag không kèm @", async () => {
    m.checkTagName.mockResolvedValue({ available: true });
    m.updateTagName.mockResolvedValue({ tagName: "@moitag" });
    render(<AccountInfoPanel />);
    fireEvent.click(screen.getAllByRole("button", { name: "Đổi" }).slice(-1)[0]); // hàng Tag Name Search (sau hàng Tên thật)
    const input = await screen.findByLabelText("Tag Name Search");
    fireEvent.change(input, { target: { value: "@moitag" } });
    expect(btn("Đổi tag").disabled).toBe(true); // còn đang kiểm tra
    await waitFor(() => expect(btn("Đổi tag").disabled).toBe(false), { timeout: 3000 });
    expect(m.checkTagName).toHaveBeenCalledWith("moitag");
    fireEvent.click(btn("Đổi tag"));
    // v2.4.2.1: "Đổi tag" chỉ mở bước CẢNH BÁO — chưa đổi gì cho tới khi bấm "Vẫn đổi tag".
    await screen.findByText("Link hồ sơ bạn đã chia sẻ sẽ không còn dùng được");
    expect(m.updateTagName).not.toHaveBeenCalled();
    fireEvent.click(btn("Vẫn đổi tag"));
    await waitFor(() => expect(m.updateTagName).toHaveBeenCalledWith("moitag"));
    expect(m.refreshProfile).toHaveBeenCalled();
  });

  // ---- v2.4.2.1: hộp cảnh báo về link hồ sơ đã chia sẻ ----
  const openTagWarning = async (typed = "@moitag") => {
    m.checkTagName.mockResolvedValue({ available: true });
    render(<AccountInfoPanel />);
    fireEvent.click(screen.getAllByRole("button", { name: "Đổi" }).slice(-1)[0]);
    const input = await screen.findByLabelText("Tag Name Search");
    fireEvent.change(input, { target: { value: typed } });
    await waitFor(() => expect(btn("Đổi tag").disabled).toBe(false), { timeout: 3000 });
    fireEvent.click(btn("Đổi tag"));
    await screen.findByText("Link hồ sơ bạn đã chia sẻ sẽ không còn dùng được");
  };

  it("cảnh báo đổi tag: nêu rõ link cũ ngừng hoạt động, tag cũ có thể bị người khác nhận, và cho thấy link cũ → link mới", async () => {
    await openTagWarning();
    expect(screen.getByTestId("tag-old-link").textContent).toBe(`${window.location.origin}/u/@vana`);
    expect(screen.getByTestId("tag-new-link").textContent).toBe(`${window.location.origin}/u/@moitag`);
    expect(screen.getByText(/Không tìm thấy người dùng/)).toBeTruthy();
    expect(screen.getByText(/người khác có thể đăng ký đúng tag đó/)).toBeTruthy();
    expect(m.updateTagName).not.toHaveBeenCalled();
  });

  it("cảnh báo đổi tag: 'Quay lại' về bước nhập (giữ tag đã gõ), không gọi API; đổi ý hoàn toàn bằng cách đóng hộp", async () => {
    await openTagWarning();
    fireEvent.click(btn("Quay lại"));
    const input = await screen.findByLabelText("Tag Name Search");
    expect(input.value.replace(/^@/, "")).toBe("moitag");
    expect(screen.queryByText("Link hồ sơ bạn đã chia sẻ sẽ không còn dùng được")).toBeNull();
    expect(m.updateTagName).not.toHaveBeenCalled();
    fireEvent.click(btn("Hủy"));
    await waitFor(() => expect(screen.queryByLabelText("Tag Name Search")).toBeNull());
    expect(m.updateTagName).not.toHaveBeenCalled();
    expect(m.refreshProfile).not.toHaveBeenCalled();
  });

  it("cảnh báo đổi tag: lỗi từ máy chủ (vd. tag vừa bị người khác lấy) đưa về bước nhập kèm thông báo, không báo thành công", async () => {
    m.updateTagName.mockRejectedValue({ message: "Tag Name Search này đã được sử dụng." });
    await openTagWarning();
    fireEvent.click(btn("Vẫn đổi tag"));
    expect(await screen.findByText("Tag Name Search này đã được sử dụng.")).toBeTruthy();
    expect(screen.getByLabelText("Tag Name Search")).toBeTruthy(); // đã về bước nhập
    expect(m.refreshProfile).not.toHaveBeenCalled();
    expect(m.snack.success).not.toHaveBeenCalled();
  });

  it("tag đã có người dùng: nút khoá và báo rõ; tag không hợp lệ: báo ngay, không gọi API", async () => {
    m.checkTagName.mockResolvedValue({ available: false });
    render(<AccountInfoPanel />);
    fireEvent.click(screen.getAllByRole("button", { name: "Đổi" }).slice(-1)[0]);
    const input = await screen.findByLabelText("Tag Name Search");
    fireEvent.change(input, { target: { value: "ab" } });
    await screen.findByText(/3-20 ký tự/);
    expect(m.checkTagName).not.toHaveBeenCalled();
    fireEvent.change(input, { target: { value: "dacoai" } });
    await screen.findByText("Tag Name Search này đã có người dùng.", {}, { timeout: 3000 });
    expect(btn("Đổi tag").disabled).toBe(true);
  });
});
