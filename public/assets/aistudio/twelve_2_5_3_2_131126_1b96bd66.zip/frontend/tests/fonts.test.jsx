import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, act, renderHook, cleanup } from "@testing-library/react";
import { useTheme } from "@mui/material";

import { CLIENT_FONTS, DEFAULT_FONT_ID, FALLBACK_STACK, findFont, resolveFont, ensureFont } from "../src/theme/fonts";
import { ThemeModeProvider, useThemeMode } from "../src/context/ThemeModeContext";
import FontGroupPanel from "../src/pages/settings/FontGroupPanel";

// v2.0.8: ThemeModeProvider nay gọi API font server — mock để test không cần Firebase/mạng.
vi.mock("../src/api/fonts.api", () => ({ getPublicFonts: () => Promise.resolve({ fonts: [] }) }));
vi.mock("../src/api/client", () => ({ default: { defaults: { baseURL: "https://api.example.com/api" } } }));

// ---- FontFace giả để theo dõi việc nạp font
let created = [];
class FakeFontFace {
  constructor(family, source, desc) { this.family = family; this.source = source; this.desc = desc; created.push(this); }
  load() { return Promise.resolve(this); }
}
afterEach(() => cleanup());
beforeEach(() => {
  created = [];
  localStorage.clear();
  globalThis.FontFace = FakeFontFace;
  Object.defineProperty(document, "fonts", { configurable: true, value: { add: vi.fn() } });
});

describe("kho font", () => {
  it("có font mặc định và SVN-Headliner No. 45 (client), id duy nhất", () => {
    expect(findFont(DEFAULT_FONT_ID)).toBeTruthy();
    const f = findFont("svn-headliner-no45");
    expect(f.source).toBe("client");
    expect(f.family).toBe("SVN-Headliner No. 45");
    expect(f.stack.endsWith(FALLBACK_STACK)).toBe(true); // ký tự thiếu glyph rơi về font mặc định
    expect(new Set(CLIENT_FONTS.map((x) => x.id)).size).toBe(CLIENT_FONTS.length);
  });
  it("id lạ => về font mặc định, không ném lỗi", () => {
    expect(resolveFont("khong-ton-tai").id).toBe(DEFAULT_FONT_ID);
    expect(resolveFont(null).id).toBe(DEFAULT_FONT_ID);
  });
  it("khai báo khoảng độ đậm 100–900 (tránh faux bold) và đường dẫn woff2 có thật", async () => {
    const f = findFont("svn-headliner-no45");
    expect(f.faces[0].weight).toBe("100 900");
    const { existsSync } = await import("node:fs");
    expect(existsSync("public" + f.faces[0].url)).toBe(true);
  });
  it("ensureFont: font mặc định không tải gì; font tuỳ chọn chỉ tải 1 lần", async () => {
    expect(await ensureFont(findFont(DEFAULT_FONT_ID))).toBe(true);
    expect(created.length).toBe(0);
    const f = findFont("svn-headliner-no45");
    await ensureFont(f); await ensureFont(f);
    expect(created.length).toBe(1);
    expect(created[0].desc).toMatchObject({ weight: "100 900", display: "swap" });
    expect(document.fonts.add).toHaveBeenCalledTimes(1);
  });
  it("ensureFont: lỗi tải => false và cho phép thử lại", async () => {
    const f = { id: "font-thu-nghiem", label: "Thử nghiệm", family: "Thu Nghiem", faces: [{ url: "/fonts/x.woff2", weight: "400", style: "normal" }] };
    FakeFontFace.prototype.load = () => Promise.reject(new Error("404"));
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(await ensureFont(f)).toBe(false);
    FakeFontFace.prototype.load = function () { return Promise.resolve(this); };
    expect(await ensureFont(f)).toBe(true);
    spy.mockRestore();
  });
});

function Probe() {
  const theme = useTheme();
  const { fontId } = useThemeMode();
  return <div data-testid="probe" data-font={fontId}>{theme.typography.fontFamily}</div>;
}

describe("ThemeModeProvider + font", () => {
  it("mặc định dùng font mặc định", () => {
    render(<ThemeModeProvider><Probe /></ThemeModeProvider>);
    expect(screen.getByTestId("probe").textContent).toBe(FALLBACK_STACK);
  });
  it("khôi phục font đã lưu ngay ở lần render đầu; id lạ trong localStorage bị bỏ qua", () => {
    localStorage.setItem("twelve_font_id", "svn-headliner-no45");
    const { unmount } = render(<ThemeModeProvider><Probe /></ThemeModeProvider>);
    expect(screen.getByTestId("probe").textContent).toContain("SVN-Headliner No. 45");
    unmount();
    localStorage.setItem("twelve_font_id", "font-da-bi-go");
    render(<ThemeModeProvider><Probe /></ThemeModeProvider>);
    expect(screen.getByTestId("probe").dataset.font).toBe(DEFAULT_FONT_ID);
  });
  it("chọn font trong Cài đặt: đổi theme, lưu localStorage, tải file font", async () => {
    render(
      <ThemeModeProvider>
        <Probe />
        <FontGroupPanel source="client" />
      </ThemeModeProvider>
    );
    await act(async () => {});
    fireEvent.click(screen.getAllByText("SVN-Headliner No. 45")[0]);
    await act(async () => {});
    expect(screen.getByTestId("probe").textContent).toContain("SVN-Headliner No. 45");
    expect(localStorage.getItem("twelve_font_id")).toBe("svn-headliner-no45");
    // (việc tải file font chỉ 1 lần/phiên đã được kiểm ở nhóm "kho font"; ở đây module đã cache từ ca trước)
    expect(screen.getByText("Đang dùng")).toBeTruthy();
    // quay lại mặc định
    fireEvent.click(screen.getByText("Mặc định (Google Sans)"));
    await act(async () => {});
    expect(screen.getByTestId("probe").textContent).toBe(FALLBACK_STACK);
    expect(localStorage.getItem("twelve_font_id")).toBe(DEFAULT_FONT_ID);
  });
  it("setFontId bỏ qua id không tồn tại", () => {
    const { result } = renderHook(() => useThemeMode(), { wrapper: ThemeModeProvider });
    act(() => result.current.setFontId("khong-co"));
    expect(result.current.fontId).toBe(DEFAULT_FONT_ID);
    expect(localStorage.getItem("twelve_font_id")).toBe(null);
  });
});
