// v2.4.2 — Nút Back DUY NHẤT ở headZone đi lên đúng, không quay vòng; không còn nút "quay lại" riêng trong nội dung trang.
// Tái hiện lỗi người dùng báo: Cài đặt › Ứng dụng › Chế độ giao diện → "quay lại" trong trang → Back ở headZone → lại rơi vào Chế độ giao diện.
// Chạy: npx vitest run tests/backNav.test.jsx
import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor, act, within } from "@testing-library/react";
import { MemoryRouter, Routes, Route, useLocation, useNavigate } from "react-router-dom";
import fs from "node:fs";
import path from "node:path";

const m = vi.hoisted(() => ({
  snack: { success: vi.fn(), error: vi.fn(), info: vi.fn(), warning: vi.fn() },
  getOne: vi.fn(),
  remove: vi.fn(),
}));
let authState;
vi.mock("../src/context/AuthContext", () => ({ useAuth: () => authState }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => m.snack }));
vi.mock("../src/components/Navbar", () => ({ default: () => <nav>NAVBAR</nav> }));
vi.mock("../src/hooks/useSeo", () => ({ default: () => {} }));

// ---- mock các nội dung nặng của từng trang (khai báo ở cấp file: KHÔNG dùng vi.resetModules — nó tạo bản context thứ hai làm hook mất Provider) ----
vi.mock("../src/pages/settings/ThemeModePanel", () => ({ default: () => <div>THEME-PANEL</div> }));
vi.mock("../src/pages/settings/FontGroupPanel", () => ({ default: ({ source }) => <div>{`FONT-PANEL:${source}`}</div> }));
vi.mock("../src/api/trending.api", () => ({
  getWeeklyRanking: vi.fn().mockResolvedValue({ ranking: [] }),
  getAllTimeRanking: vi.fn().mockResolvedValue({ ranking: [] }),
  getHashtagWeeklyRanking: vi.fn().mockResolvedValue({ ranking: [], weekCode: "2026-W43" }),
  getHashtagAllTimeRanking: vi.fn().mockResolvedValue({ ranking: [] }),
  getHashtagPosts: vi.fn().mockResolvedValue({ tag: "#abc", posts: [] }),
  searchTrending: vi.fn().mockResolvedValue({ results: [] }),
}));
// Danh sách hashtag giả: một nút để "chọn hashtag" như người dùng bấm trong danh sách.
vi.mock("../src/components/HashtagRankingList", () => ({ default: ({ onSelectHashtag }) => <button onClick={() => onSelectHashtag("#abc")}>PICK-TAG</button> }));
vi.mock("../src/components/HashtagPostList", () => ({ default: () => <div>TAG-POSTS</div> }));
vi.mock("../src/components/RankingList", () => ({ default: () => <div>RANKING</div> }));
vi.mock("../src/api/content.api", () => ({ postsApi: { pin: vi.fn(), unpin: vi.fn() }, blogsApi: {} }));
vi.mock("../src/hooks/useContentEngagement", () => ({
  default: () => ({ likeCount: 0, dislikeCount: 0, commentCount: 0, shareCount: 0, viewCount: 0, aiViewCount: 0, myReaction: null, busy: false, score: 0, react: vi.fn(), share: vi.fn() }),
}));
vi.mock("../src/hooks/useCommentThread", () => ({ default: () => ({ send: vi.fn(), sending: false }) }));
vi.mock("../src/components/comments/CommentThread", () => ({ default: () => null }));
vi.mock("../src/components/comments/CommentComposer", () => ({ default: () => null }));
vi.mock("../src/components/PostContent", () => ({ default: () => <div>NỘI DUNG</div> }));
vi.mock("../src/components/MediaLightbox", () => ({ default: () => null, collectMediaSlides: () => [], findSlideIndex: () => 0 }));

import { PageHeaderProvider, usePageHeader } from "../src/context/PageHeaderContext";
import { useHeaderBack, useGoUp } from "../src/hooks/useBack";
import NavStackTracker from "../src/components/NavStackTracker";
import { resetNavStack, planUp, __debugNavStack } from "../src/utils/navStack";
import SettingsPage from "../src/pages/SettingsPage";
import TrendingPage from "../src/pages/TrendingPage";
import PostDetailPage from "../src/pages/PostDetailPage";
import { FONT_SOURCE_LABELS } from "../src/theme/fonts";

const Loc = () => <div data-testid="loc">{useLocation().pathname + useLocation().search}</div>;
const loc = () => screen.getByTestId("loc").textContent;
// Dựng lại đúng cách Navbar dùng nút Back: useHeaderBack(config của trang).
function HeadZoneBack() {
  const { config } = usePageHeader();
  const back = useHeaderBack(config);
  return <button onClick={back}>HEADZONE-BACK</button>;
}
const headBack = () => fireEvent.click(screen.getByText("HEADZONE-BACK"));
// Công cụ điều hướng cho test: đi tới (push) / đi lên / xem bản ghi
let nav;
let up;
function Tools() {
  nav = useNavigate();
  up = useGoUp();
  return null;
}
const push = (to) => act(() => nav(to));
const goUp = (to) => act(() => up(to));
const shell = (children, entries = ["/"]) =>
  render(
    <PageHeaderProvider>
      <MemoryRouter initialEntries={entries} initialIndex={entries.length - 1}>
        <NavStackTracker />
        <Tools />
        <HeadZoneBack />
        {children}
        <Loc />
      </MemoryRouter>
    </PageHeaderProvider>
  );

// Dựng ở entries[0] rồi ĐI TỚI (push) từng mục còn lại — đúng như người dùng điều hướng thật, nên bản ghi lịch sử đầy đủ
// (khởi tạo MemoryRouter với nhiều mục thì mục trước không đi qua điều hướng nên không được ghi, làm test dễ "đúng nhờ may").
const boot = async (children, entries) => {
  shell(children, [entries[0]]);
  for (const e of entries.slice(1)) await push(e);
};

beforeEach(() => {
  resetNavStack();
  authState = { isSA: false, isLoggedIn: true, isAuthReady: true, loadingProfile: false, firebaseUser: { uid: "u1" }, profile: { uid: "u1" }, profileError: null };
  Object.values(m.snack).forEach((f) => f.mockReset());
  m.getOne.mockReset();
  m.remove.mockReset();
  window.scrollTo = vi.fn();
});
afterEach(cleanup);

// ======================================================================== lõi: đi lên không sinh mục lịch sử mới
describe("planUp / goUp — đi lên mà không để lại lối quay vòng", () => {
  it("trang cha đã nằm ngay trước trong lịch sử → LÙI thẳng tới đó; Back kế tiếp đi tới nơi trước đó, KHÔNG chui lại mục con", async () => {
    shell(null);
    await push("/settings/app");
    await push("/settings/app/theme");
    expect(planUp("/settings/app")).toEqual({ type: "pop", delta: -1 });
    await goUp("/settings/app");
    await waitFor(() => expect(loc()).toBe("/settings/app"));
    headBack(); // không khai báo backTo → lùi lịch sử
    await waitFor(() => expect(loc()).toBe("/")); // KHÔNG phải /settings/app/theme
  });

  it("lên NHIỀU cấp một lần: các mục giữa đều là con cháu của trang cha → lùi xuyên qua hết", async () => {
    shell(null);
    await push("/settings/app");
    await push("/settings/app/font");
    await push("/settings/app/font/server");
    expect(planUp("/settings/app")).toEqual({ type: "pop", delta: -2 });
    await goUp("/settings/app");
    await waitFor(() => expect(loc()).toBe("/settings/app"));
    headBack();
    await waitFor(() => expect(loc()).toBe("/"));
  });

  it("vào thẳng URL sâu (lịch sử chỉ có mục đó) → THAY mục hiện tại bằng trang cha; không phình lịch sử", async () => {
    shell(null, ["/settings/app/theme"]);
    await waitFor(() => expect(__debugNavStack().paths).toEqual(["/settings/app/theme"]));
    expect(planUp("/settings/app")).toEqual({ type: "replace" });
    await goUp("/settings/app");
    await waitFor(() => expect(loc()).toBe("/settings/app"));
    expect(__debugNavStack().paths).toEqual(["/settings/app"]);
  });

  it("giữa chừng có TRANG LẠ → không lùi xuyên qua (không văng người dùng ra khỏi chỗ họ đã đi); thay thế mục hiện tại", async () => {
    shell(null);
    await push("/settings/app");
    await push("/post/1");
    await push("/settings/app/theme");
    expect(planUp("/settings/app")).toEqual({ type: "replace" });
    await goUp("/settings/app");
    await waitFor(() => expect(loc()).toBe("/settings/app"));
    headBack(); // lùi lịch sử → /post/1 (đúng thứ tự họ đã đi), không phải mục sâu
    await waitFor(() => expect(loc()).toBe("/post/1"));
  });

  it("cha là Trang chủ '/': mọi trang khác đều là con cháu (nên lùi được xuyên qua)", async () => {
    shell(null);
    await push("/post/9");
    expect(planUp("/")).toEqual({ type: "pop", delta: -1 });
  });

  it("lịch sử rẽ nhánh: sau khi lùi rồi đi chỗ khác, bản ghi cắt đúng như trình duyệt (không còn mục 'tiến tới' cũ)", async () => {
    shell(null);
    await push("/a");
    await push("/a/b");
    await goUp("/a"); // pop
    await waitFor(() => expect(loc()).toBe("/a"));
    await push("/c");
    expect(__debugNavStack().paths).toEqual(["/", "/a", "/c"]);
  });
});

// ======================================================================== Cài đặt: tái hiện đúng kịch bản người dùng báo
describe("Cài đặt — kịch bản quay vòng người dùng báo", () => {
  const settings = (entries) =>
    boot(
      <Routes>
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/settings/:tab/*" element={<SettingsPage />} />
        <Route path="*" element={<div>OTHER</div>} />
      </Routes>,
      entries
    );

  it("Trang chủ › Cài đặt › Ứng dụng › Chế độ giao diện: Back ở headZone → Ứng dụng; Back lần nữa → Trang chủ (KHÔNG chui lại Chế độ giao diện)", async () => {
    await settings(["/", "/settings/app"]);
    fireEvent.click(screen.getByText("Chế độ giao diện"));
    expect(await screen.findByText("THEME-PANEL")).toBeTruthy();
    expect(loc()).toBe("/settings/app/theme");
    expect(screen.queryByLabelText("Quay lại")).toBeNull(); // không còn nút back riêng chiếm chỗ trong trang

    headBack();
    await waitFor(() => expect(loc()).toBe("/settings/app"));
    headBack();
    await waitFor(() => expect(loc()).toBe("/"));
    expect(screen.queryByText("THEME-PANEL")).toBeNull();
  });

  it("đường dẫn (breadcrumb) lên cấp cha rồi Back ở headZone: cũng không quay vòng (không chui lại mục sâu vừa rời)", async () => {
    await settings(["/", "/settings/app"]);
    fireEvent.click(screen.getByText("Font chữ"));
    await waitFor(() => expect(loc()).toBe("/settings/app/font"));
    fireEvent.click(screen.getByText(FONT_SOURCE_LABELS.server));
    expect(await screen.findByText("FONT-PANEL:server")).toBeTruthy();
    // bấm "Font chữ" trong đường dẫn = đi lên một cấp
    fireEvent.click(within(screen.getByLabelText("Đường dẫn mục cài đặt")).getByText("Font chữ"));
    await waitFor(() => expect(loc()).toBe("/settings/app/font"));
    headBack(); // Back ở headZone: từ thư mục Font chữ lên gốc tab — KHÔNG phải quay lại mục "server"
    await waitFor(() => expect(loc()).toBe("/settings/app"));
    expect(screen.queryByText("FONT-PANEL:server")).toBeNull();
    headBack();
    await waitFor(() => expect(loc()).toBe("/"));
  });

  it("bấm lại tab 'Ứng dụng' khi đang ở sâu → về gốc tab; Back ở headZone KHÔNG quay lại chỗ sâu vừa rời", async () => {
    await settings(["/", "/settings/app", "/settings/app/font", "/settings/app/font/server"]);
    expect(await screen.findByText("FONT-PANEL:server")).toBeTruthy();
    fireEvent.click(screen.getByRole("tab", { name: "Ứng dụng" }));
    await waitFor(() => expect(loc()).toBe("/settings/app"));
    headBack();
    await waitFor(() => expect(loc()).toBe("/"));
  });

  it("vào thẳng URL sâu rồi Back ở headZone lên đúng một cấp, lần nữa về gốc tab, lần nữa về Trang chủ", async () => {
    await settings(["/settings/app/font/server"]);
    expect(await screen.findByText("FONT-PANEL:server")).toBeTruthy();
    headBack();
    await waitFor(() => expect(loc()).toBe("/settings/app/font"));
    headBack();
    await waitFor(() => expect(loc()).toBe("/settings/app"));
    headBack(); // gốc tab, lịch sử không còn gì để lùi → Trang chủ
    await waitFor(() => expect(loc()).toBe("/"));
  });

  it("trang khai báo backTo đúng theo cấp: gốc tab = không có; mục con = mục cha", async () => {
    let cfg;
    const Spy = () => {
      cfg = usePageHeader().config;
      return null;
    };
    render(
      <PageHeaderProvider>
        <MemoryRouter initialEntries={["/settings/app"]}>
          <Spy />
          <Routes><Route path="/settings/:tab/*" element={<SettingsPage />} /></Routes>
          <Tools />
        </MemoryRouter>
      </PageHeaderProvider>
    );
    await waitFor(() => expect(cfg.title).toBe("Cài đặt"));
    expect(cfg.backTo).toBeNull();
    await act(async () => nav("/settings/app/font/custom"));
    await waitFor(() => expect(cfg.backTo).toBe("/settings/app/font"));
    await act(async () => nav("/settings/app/font"));
    await waitFor(() => expect(cfg.backTo).toBe("/settings/app"));
  });
});

// ======================================================================== Xu hướng: chi tiết hashtag
describe("Xu hướng — không còn nút back riêng ở chi tiết hashtag", () => {
  const trending = (entries) => boot(<Routes><Route path="/trending" element={<TrendingPage />} /><Route path="*" element={<div>OTHER</div>} /></Routes>, entries);

  it("chọn hashtag trong danh sách → Back ở headZone về DANH SÁCH hashtag (vẫn ở Xu hướng); Back lần nữa → trang trước đó; không có nút ← trong trang", async () => {
    await trending(["/", "/trending?tab=hashtag"]);
    fireEvent.click(await screen.findByText("PICK-TAG"));
    expect(await screen.findByText("TAG-POSTS")).toBeTruthy();
    expect(screen.queryByLabelText("Quay lại")).toBeNull();
    headBack();
    await waitFor(() => expect(screen.queryByText("TAG-POSTS")).toBeNull());
    expect(screen.getByText("PICK-TAG")).toBeTruthy();
    expect(loc()).toContain("/trending");
    headBack();
    await waitFor(() => expect(loc()).toBe("/"));
  });

  it("vào chi tiết hashtag từ LIÊN KẾT NGOÀI (Chip hashtag ở thẻ bài) → Back ở headZone trở về đúng trang đã bấm, không giữ lại ở Xu hướng", async () => {
    await trending(["/post/1", "/trending?tab=hashtag&hashtag=%23abc"]);
    expect(await screen.findByText("TAG-POSTS")).toBeTruthy();
    headBack();
    await waitFor(() => expect(loc()).toBe("/post/1"));
  });
});

// ======================================================================== Trang bài viết: không bẫy quay vòng khi lỗi/xoá
describe("Trang bài viết — chuyển đi sau lỗi/xoá không để lại bẫy cho nút Back", () => {
  const open = (entries) =>
    boot(
      <Routes>
        <Route path="/post/:id" element={<PostDetailPage api={{ getOne: m.getOne, remove: m.remove }} backPath="/" />} />
        <Route path="/" element={<div>HOME</div>} />
      </Routes>,
      entries
    );

  it("bài không tồn tại: chuyển về Trang chủ bằng cách ĐI LÊN — Back sau đó KHÔNG quay lại URL lỗi (bẫy: URL lỗi → tự chuyển đi → Back lại vào URL lỗi…)", async () => {
    m.getOne.mockRejectedValue({ message: "Không tìm thấy bài viết." });
    await open(["/", "/post/khong-co"]);
    await waitFor(() => expect(loc()).toBe("/"));
    expect(m.snack.error).toHaveBeenCalled();
    headBack(); // lịch sử đã rút gọn: không còn /post/khong-co phía sau
    await waitFor(() => expect(loc()).toBe("/"));
    expect(screen.queryByText("NỘI DUNG")).toBeNull();
  });

  it("vào thẳng URL bài không tồn tại (lịch sử chỉ có nó): được THAY bằng Trang chủ, Back không bị kẹt", async () => {
    m.getOne.mockRejectedValue({ message: "Không tìm thấy bài viết." });
    await open(["/post/khong-co"]);
    await waitFor(() => expect(loc()).toBe("/"));
    expect(__debugNavStack().paths).toEqual(["/"]);
  });
});

// ======================================================================== PageHeader + quy ước
describe("PageHeader — backTo/onBack", () => {
  it("onBack trả true = trang đã tự xử lý (không điều hướng); trả false/không có = đi tiếp (backTo rồi lịch sử)", async () => {
    const { useRegisterPageHeader } = await import("../src/context/PageHeaderContext");
    let handled = false;
    const onBack = vi.fn(() => handled);
    const Page = () => {
      useRegisterPageHeader({ title: "T", isBrand: false, backTo: "/up", onBack });
      return null;
    };
    shell(<Routes><Route path="/x" element={<Page />} /><Route path="*" element={<div />} /></Routes>, ["/", "/up", "/x"]);
    handled = true;
    headBack();
    expect(onBack).toHaveBeenCalledTimes(1);
    expect(loc()).toBe("/x"); // đã xử lý: không đi đâu
    handled = false;
    headBack();
    await waitFor(() => expect(loc()).toBe("/up")); // không xử lý → backTo → lùi thẳng tới /up
  });

  it("mặc định (không backTo/onBack): lùi lịch sử; không còn gì để lùi → Trang chủ", async () => {
    shell(<Routes><Route path="*" element={<div />} /></Routes>, ["/only"]);
    headBack();
    await waitFor(() => expect(loc()).toBe("/"));
  });
});

describe("quy ước: không trang nào tự vẽ nút 'quay lại' trong nội dung", () => {
  const src = path.resolve(__dirname, "../src");
  const walk = (dir) =>
    fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]));
  const files = walk(src).filter((f) => f.endsWith(".jsx"));
  const rel = (f) => path.relative(src, f).split(path.sep).join("/");

  it("ArrowBackIcon chỉ được dùng ở Navbar (nút Back của headZone)", () => {
    const offenders = files.filter((f) => /ArrowBack(Icon)?\b/.test(fs.readFileSync(f, "utf8").replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, ""))).map(rel);
    expect(offenders).toEqual(["components/Navbar.jsx"]);
  });

  it("không nút nào có nhãn 'Quay lại' ngoài headZone", () => {
    const offenders = files
      .filter((f) => /aria-label="Quay lại"|label="Quay lại"/.test(fs.readFileSync(f, "utf8")))
      .map(rel)
      .filter((f) => f !== "components/Navbar.jsx");
    expect(offenders).toEqual([]);
  });

  it("không trang nào tự điều hướng LÙI bằng navigate(-1) hay navigate(backPath) đẩy mục mới — dùng headZone/useGoUp", () => {
    const offenders = files
      .filter((f) => rel(f) !== "hooks/useBack.js")
      .filter((f) => /navigate\(-1\)|navigate\(backPath\)/.test(fs.readFileSync(f, "utf8").replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "")))
      .map(rel);
    expect(offenders).toEqual([]);
  });
});
