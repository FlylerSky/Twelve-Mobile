// v2.2.0: trang Đăng nhập có "Quên mật khẩu?" — mở đúng hộp dùng chung (components/ForgotPasswordDialog), điền sẵn email đang gõ.
// Chạy: npx vitest run tests/loginForgot.test.jsx
import React from "react";
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

const dialogProps = vi.hoisted(() => ({ last: null }));
vi.mock("../src/components/Navbar", () => ({ default: () => null }));
vi.mock("../src/hooks/useSeo", () => ({ default: () => {} }));
vi.mock("../src/context/PageHeaderContext", () => ({ useRegisterPageHeader: () => {} }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => ({ success: vi.fn(), error: vi.fn(), warning: vi.fn(), info: vi.fn() }) }));
vi.mock("../src/context/AuthContext", () => ({
  useAuth: () => ({ isAuthReady: true, hasSession: false, emailVerified: false, isPending: false, refreshProfile: vi.fn(), reloadEmailVerified: vi.fn() }),
}));
vi.mock("../src/firebase", () => ({ auth: { currentUser: null } }));
vi.mock("firebase/auth", () => ({ sendEmailVerification: vi.fn(), signOut: vi.fn() }));
vi.mock("../src/utils/email", () => ({ signInWithEmailCompat: vi.fn() }));
vi.mock("../src/api/auth.api", () => ({ syncActivation: vi.fn() }));
vi.mock("../src/components/ForgotPasswordDialog", () => ({
  default: (p) => {
    dialogProps.last = p;
    return p.open ? <div>FORGOT-DIALOG {p.initialEmail}</div> : null;
  },
}));

import LoginPage from "../src/pages/LoginPage";

afterEach(() => cleanup());

describe("LoginPage — quên mật khẩu", () => {
  it("nút 'Quên mật khẩu?' mở hộp quên mật khẩu, điền sẵn email người dùng đã gõ ở form đăng nhập", () => {
    render(<MemoryRouter><LoginPage /></MemoryRouter>);
    expect(screen.queryByText(/FORGOT-DIALOG/)).toBeNull();
    fireEvent.change(screen.getByLabelText(/^Email/), { target: { value: "ban@example.com" } });
    fireEvent.click(screen.getByRole("button", { name: "Quên mật khẩu?" }));
    expect(screen.getByText("FORGOT-DIALOG ban@example.com")).toBeTruthy();
    expect(dialogProps.last.emailLocked).toBeFalsy(); // ở trang đăng nhập người dùng được sửa email
  });
});
