// v2.5.2 — Hoàn thiện trang Profile: tab Blog (SA), Tiểu sử, hộp "Xem thêm", "Khách ghé thăm", tự báo lượt ghé thăm, hộp "Sao chép URL Profile" có thẻ/viền.
// Chạy: npx vitest run tests/profile252.test.jsx
import React from "react";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent, waitFor, act, within } from "@testing-library/react";
import { MemoryRouter, Routes, Route, useLocation } from "react-router-dom";

const m = vi.hoisted(() => ({
  snack: { success: vi.fn(), error: vi.fn(), info: vi.fn(), warning: vi.fn() },
  getPublicProfile: vi.fn(),
  getPublicProfileByTag: vi.fn(),
  listPinnedPosts: vi.fn(),
  listUserPosts: vi.fn(),
  listUserBlogs: vi.fn(),
  getProfileExtraInfo: vi.fn(),
  listMyVisitors: vi.fn(),
  recordProfileVisit: vi.fn(),
  header: { current: null },
  blogsApi: { marker: "blogsApi" },
  feedCfgs: [],
  feedProps: { current: null },
}));
let authState;

vi.mock("../src/context/AuthContext", () => ({ useAuth: () => authState }));
vi.mock("../src/context/SnackbarContext", () => ({ useSnackbar: () => m.snack }));
vi.mock("../src/components/Navbar", () => ({ default: () => <nav>NAVBAR</nav> }));
vi.mock("../src/hooks/useSeo", () => ({ default: () => {} }));
vi.mock("../src/context/PageHeaderContext", () => ({
  useRegisterPageHeader: (cfg) => {
    m.header.current = cfg;
  },
}));
vi.mock("../src/api/content.api", () => ({ postsApi: { pin: vi.fn(), unpin: vi.fn() }, blogsApi: m.blogsApi }));
vi.mock("../src/api/users.api", () => ({
  getPublicProfile: (...a) => m.getPublicProfile(...a),
  getPublicProfileByTag: (...a) => m.getPublicProfileByTag(...a),
  listPinnedPosts: (...a) => m.listPinnedPosts(...a),
  listUserPosts: (...a) => m.listUserPosts(...a),
  listUserBlogs: (...a) => m.listUserBlogs(...a),
  getProfileExtraInfo: (...a) => m.getProfileExtraInfo(...a),
  listMyVisitors: (...a) => m.listMyVisitors(...a),
  recordProfileVisit: (...a) => m.recordProfileVisit(...a),
}));
vi.mock("../src/components/PostCardList", () => ({ default: () => <div data-testid="cards" /> }));
// FeedList + usePaginatedFeed giả: ghi lại cấu hình để kiểm tab Blog nối đúng API/đường dẫn/bộ sưu tập.
vi.mock("../src/components/FeedList", () => ({
  default: (props) => {
    m.feedProps.current = props;
    return <div data-testid="feed" />;
  },
}));
vi.mock("../src/hooks/usePaginatedFeed", () => ({
  default: (cfg) => {
    m.feedCfgs.push(cfg);
    return { items: [] };
  },
}));

import PublicProfilePage from "../src/pages/PublicProfilePage";
import { PROFILE_TABS } from "../src/components/profile/profileTabs";
import CopyProfileUrlDialog from "../src/components/profile/CopyProfileUrlDialog";
import { EXTRA_FIELDS, EXTRA_DEFAULTS, GROUP_LABELS, ROLE_LABELS, resolveExtras, formatBirthday, formatJoinDate, formatExtraValue, buildExtraRows, formatWeekLabel } from "../src/utils/profileExtras";
import { BIO_MAX, BIO_MAX_LINES, normalizeBio, bioStats } from "../src/utils/bio";

const LAN_UID = "EZRxcGpJUEcSAuFfElxj8ja8KQ22";
const MY_UID = "MyFirebaseUid0123456789AB";
const LAN = { uid: LAN_UID, displayName: "Lan", tagName: "@lan_vu", accountGroup: "RA", accountRole: "user", badges: [], country: "VN", coverUrl: null, avatarUrl: null, bio: "" };
const SA_LAN = { ...LAN, accountGroup: "SA", accountRole: "admin", badges: ["admin"] };
const MINE = { ...LAN, uid: MY_UID, displayName: "Tôi", tagName: "@toi_day" };
const ME = { uid: MY_UID, displayName: "Tôi", tagName: "toi_day", accountRole: "user", pinnedPostIds: [] };

beforeEach(() => {
  [m.getPublicProfile, m.getPublicProfileByTag, m.listPinnedPosts, m.listUserPosts, m.listUserBlogs, m.getProfileExtraInfo, m.listMyVisitors, m.recordProfileVisit].forEach((f) => f.mockReset());
  Object.values(m.snack).forEach((f) => f.mockReset());
  m.header.current = null;
  m.feedCfgs.length = 0;
  m.feedProps.current = null;
  authState = { profile: ME, isLoggedIn: true, isAuthReady: true, patchProfile: vi.fn() };
  m.getPublicProfile.mockResolvedValue(LAN);
  m.getPublicProfileByTag.mockResolvedValue(LAN);
  m.listPinnedPosts.mockResolvedValue([]);
  m.listUserPosts.mockResolvedValue({ posts: [], nextCursor: null });
  m.listUserBlogs.mockResolvedValue({ blogs: [], nextCursor: null });
  m.recordProfileVisit.mockResolvedValue({ recorded: true });
  m.getProfileExtraInfo.mockResolvedValue({ fields: {}, achievements: null });
  m.listMyVisitors.mockResolvedValue({ visitors: [], max: 50 });
});
afterEach(cleanup);

const Loc = () => {
  const l = useLocation();
  return <div data-testid="loc">{l.pathname + l.search + l.hash}</div>;
};
const renderAt = (url) =>
  render(
    <MemoryRouter initialEntries={[url]}>
      <Routes>
        <Route path="/u/:ref" element={<><PublicProfilePage /><Loc /></>} />
        <Route path="/settings/account/info" element={<><div data-testid="settings-page" /><Loc /></>} />
      </Routes>
    </MemoryRouter>
  );
const action = (key) => m.header.current.actions.find((a) => a.key === key);

// ======================================================================== tiện ích (không DOM)
describe("utils/profileExtras — bảng Thông tin mở rộng KHỚP backend", () => {
  const backendFile = path.resolve(__dirname, "../../backend/src/utils/profileExtras.js");
  const hasBackend = fs.existsSync(backendFile); // repo tách riêng frontend/backend thì bỏ qua phần đối chiếu
  const backend = hasBackend ? createRequire(import.meta.url)(backendFile) : null;

  it("cùng danh sách khoá, cùng THỨ TỰ hiển thị gốc và cùng giá trị mặc định (frontend không được lệch backend)", () => {
    if (!backend) return;
    expect(EXTRA_FIELDS.map((f) => f.key).sort()).toEqual([...backend.EXTRA_KEYS].sort());
    expect({ ...EXTRA_DEFAULTS }).toEqual({ ...backend.EXTRA_DEFAULTS });
    // resolveExtras hai phía cho cùng kết quả với mọi đầu vào lạ
    for (const stored of [undefined, null, [], "x", {}, { birthday: true }, { birthday: "true", gender: 1 }, { rac: true, status: true }]) {
      expect(resolveExtras(stored)).toEqual(backend.resolveExtras(stored));
    }
  });

  it("nhãn nhóm/vai trò khớp bảng nhãn SSR của backend", () => {
    if (!backend) return;
    expect({ ...GROUP_LABELS }).toEqual({ ...backend.GROUP_LABELS });
    expect({ ...ROLE_LABELS }).toEqual({ ...backend.ROLE_LABELS });
  });

  it("giới hạn Tiểu sử khớp backend (PROFILE.BIO_MAX / BIO_MAX_LINES)", () => {
    if (!hasBackend) return;
    const { PROFILE } = createRequire(import.meta.url)(path.resolve(__dirname, "../../backend/src/utils/constants.js"));
    expect(BIO_MAX).toBe(PROFILE.BIO_MAX);
    expect(BIO_MAX_LINES).toBe(PROFILE.BIO_MAX_LINES);
  });

  it("mặc định: ngày sinh/giới tính/trạng thái/UID TẮT và đánh dấu riêng tư; phần còn lại bật", () => {
    for (const k of ["birthday", "gender", "status", "uid"]) {
      const f = EXTRA_FIELDS.find((x) => x.key === k);
      expect(f.defaultOn, k).toBe(false);
      expect(f.private, k).toBe(true);
    }
    for (const k of ["displayName", "accountGroup", "accountRole", "createdAt", "achievements"]) expect(EXTRA_FIELDS.find((x) => x.key === k).defaultOn, k).toBe(true);
    expect(EXTRA_FIELDS.every((f) => f.label && f.hint)).toBe(true);
  });

  it("định dạng: ngày sinh cắt chuỗi (KHÔNG lệch múi giờ), mã lạ hiện nguyên, hàng 'Xem thêm' đúng thứ tự và bỏ giá trị rỗng", () => {
    expect(formatBirthday("2000-01-31")).toBe("31/01/2000");
    expect(formatBirthday("rac")).toBe("rac");
    expect(formatJoinDate("2026-01-05T10:00:00.000Z")).toMatch(/^\d{1,2}\/\d{1,2}\/2026$/);
    expect(formatJoinDate("hỏng")).toBe("");
    expect(formatExtraValue("accountRole", "moderator")).toBe("Điều hành viên");
    expect(formatExtraValue("accountRole", "vai_tro_moi")).toBe("vai_tro_moi");
    expect(formatExtraValue("gender", "other")).toBe("Khác");
    expect(formatExtraValue("status", "suspended")).toBe("Bị tạm khóa");
    expect(formatWeekLabel("3.2.10.2026")).toBe("Tuần 3.2.10.2026");
    const rows = buildExtraRows({ uid: "u1", birthday: "2000-01-31", displayName: "Lan", status: "", gender: null, createdAt: "hỏng", rac: "x" });
    expect(rows.map((r) => r.key)).toEqual(["displayName", "birthday", "uid"]); // theo thứ tự EXTRA_FIELDS; bỏ rỗng/null/giá trị hiển thị không được/khoá lạ
    expect(buildExtraRows(undefined)).toEqual([]);
  });
});

describe("utils/bio — kiểm tra Tiểu sử phía giao diện", () => {
  it("normalizeBio: CRLF, khoảng trắng thừa, dòng trống liên tiếp", () => {
    expect(normalizeBio("  a  b \r\n\r\n\r\n\r\n c ")).toBe("a b\n\nc");
    expect(normalizeBio(null)).toBe("");
  });
  it("bioStats: đếm theo code point; quá ký tự / quá dòng", () => {
    expect(bioStats("😀".repeat(BIO_MAX)).valid).toBe(true);
    expect(bioStats("a".repeat(BIO_MAX + 1))).toMatchObject({ tooLong: true, valid: false });
    const many = Array.from({ length: BIO_MAX_LINES + 1 }, (_, i) => `d${i}`).join("\n");
    expect(bioStats(many)).toMatchObject({ tooManyLines: true, valid: false, lines: BIO_MAX_LINES + 1 });
    expect(bioStats("")).toMatchObject({ chars: 0, lines: 0, valid: true });
    expect(bioStats("a\n\n\n\n\nb").lines).toBe(3); // dòng trống liên tiếp gộp lại như backend
  });
});

// ======================================================================== tab Blog
describe("PublicProfilePage — tab Blog (chỉ hồ sơ SA)", () => {
  it("cây tab: 'Blog' có điều kiện theo bậc CHỦ HỒ SƠ (isSA) — không phụ thuộc người xem/isOwn", () => {
    const blog = PROFILE_TABS.find((t) => t.key === "blog");
    expect(blog.label).toBe("Blog");
    expect(blog.visible({ isSA: true })).toBe(true);
    for (const ctx of [{}, { isSA: false }, { isOwn: true }, { isOwn: true, isSA: false }, { isSA: "true" }]) expect(blog.visible(ctx), JSON.stringify(ctx)).toBe(false);
  });

  it("hồ sơ KHÔNG phải SA: không có tab Blog; ?tab=blog rơi về 'Trang chủ' và không tải blog", async () => {
    renderAt("/u/@lan_vu?tab=blog");
    await screen.findByText("Lan");
    expect(screen.queryByRole("tab", { name: "Blog" })).toBeNull();
    expect(screen.getByRole("tab", { name: "Trang chủ" }).getAttribute("aria-selected")).toBe("true");
    expect(m.listUserBlogs).not.toHaveBeenCalled();
    expect(m.feedCfgs.find((c) => c.listKey === "blogs")).toBeUndefined();
  });

  it("hồ sơ SA: có tab Blog sau 'Bài viết'; bấm → URL ?tab=blog, nối ĐÚNG API blog của người này (uid từ hồ sơ), thẻ blog mở /blog/:id", async () => {
    m.getPublicProfileByTag.mockResolvedValue(SA_LAN);
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    expect(screen.getAllByRole("tab").map((t) => t.textContent)).toEqual(["Trang chủ", "Bài viết", "Blog"]);
    fireEvent.click(screen.getByRole("tab", { name: "Blog" }));
    await waitFor(() => expect(screen.getByTestId("feed")).toBeTruthy());
    expect(screen.getByTestId("loc").textContent).toBe("/u/@lan_vu?tab=blog");
    const cfg = m.feedCfgs.find((c) => c.listKey === "blogs");
    expect(cfg).toBeTruthy();
    await cfg.api.list("cursor1", 10);
    expect(m.listUserBlogs).toHaveBeenCalledWith(LAN_UID, "cursor1", 10);
    expect(m.feedProps.current.api).toBe(m.blogsApi);
    expect(m.feedProps.current.detailPath).toBe("/blog");
    expect(m.feedProps.current.collectionName).toBe("blogs");
    expect(m.feedProps.current.emptyText).toBe("Người dùng này chưa đăng bài Blog nào.");
  });

  it("hồ sơ SA của CHÍNH MÌNH: có tab Blog, câu trống nói 'Bạn chưa đăng…'; deep link ?tab=blog mở thẳng tab", async () => {
    authState = { ...authState, profile: { ...ME, accountGroup: "SA" } };
    m.getPublicProfile.mockResolvedValue({ ...MINE, accountGroup: "SA", accountRole: "admin", badges: ["admin"] });
    renderAt("/u/myProfile?tab=blog");
    await screen.findByTestId("feed");
    expect(screen.getByRole("tab", { name: "Blog" }).getAttribute("aria-selected")).toBe("true");
    expect(m.feedProps.current.emptyText).toBe("Bạn chưa đăng bài Blog nào.");
  });

  it("người XEM là SA nhưng chủ hồ sơ không phải SA: KHÔNG có tab Blog (theo bậc chủ hồ sơ)", async () => {
    authState = { ...authState, profile: { ...ME, accountGroup: "SA" }, isSA: true };
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    expect(screen.queryByRole("tab", { name: "Blog" })).toBeNull();
  });
});

// ======================================================================== Tiểu sử
describe("ProfileHeader — Tiểu sử", () => {
  it("hiện tiểu sử như VĂN BẢN (không diễn giải HTML), giữ xuống dòng", async () => {
    const bio = 'Xin chào!\n<img src=x onerror="alert(1)"> & <b>đậm</b>';
    m.getPublicProfileByTag.mockResolvedValue({ ...LAN, bio });
    renderAt("/u/@lan_vu");
    const el = await screen.findByTestId("profile-bio");
    expect(el.textContent).toBe(bio);
    expect(el.querySelector("img, b, script")).toBeNull();
    expect(getComputedStyle(el).whiteSpace).toBe("pre-wrap");
  });

  it("không có tiểu sử (rỗng/thiếu) => không vẽ khối trống", async () => {
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    expect(screen.queryByTestId("profile-bio")).toBeNull();
    cleanup();
    m.getPublicProfileByTag.mockResolvedValue({ ...LAN, bio: undefined });
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    expect(screen.queryByTestId("profile-bio")).toBeNull();
  });
});

// ======================================================================== Xem thêm
describe("Hộp 'Xem thêm'", () => {
  const FULL = {
    fields: { displayName: "Lan", accountGroup: "SA", accountRole: "admin", birthday: "2000-01-31", createdAt: "2026-01-05T10:00:00.000Z", gender: "female", status: "active", uid: LAN_UID },
    achievements: {
      accountScore: 1234,
      weekly: {
        weeksRecorded: 12, top10Count: 4, top3Count: 2, firstPlaceCount: 1,
        best: { weekCode: "3.3.01.2026", rank: 1, weeklyGrowth: 50 },
        recent: [{ weekCode: "9.1.03.2026", rank: 5, weeklyGrowth: 8 }, { weekCode: "3.3.01.2026", rank: 1, weeklyGrowth: 50 }],
      },
    },
  };
  const open = async () => {
    fireEvent.click(await screen.findByTestId("profile-more-button"));
    return await screen.findByRole("dialog");
  };

  it("nút 'Xem thêm' có ở hồ sơ người khác; KHÔNG tải gì cho tới khi bấm", async () => {
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    expect(screen.getByTestId("profile-more-button").textContent).toContain("Xem thêm");
    expect(m.getProfileExtraInfo).not.toHaveBeenCalled();
  });

  it("bấm → gọi API theo uid của HỒ SƠ (không từ URL); hiện từng trường theo thứ tự, ngày sinh dạng DD/MM/YYYY, nhãn nhóm/vai trò tiếng Việt", async () => {
    m.getProfileExtraInfo.mockResolvedValue(FULL);
    renderAt("/u/@lan_vu");
    const dlg = await open();
    await within(dlg).findByTestId("more-fields");
    expect(m.getProfileExtraInfo).toHaveBeenCalledTimes(1);
    expect(m.getProfileExtraInfo).toHaveBeenCalledWith(LAN_UID);
    const keys = [...dlg.querySelectorAll('[data-testid^="more-row-"]')].map((e) => e.getAttribute("data-testid").replace("more-row-", ""));
    expect(keys).toEqual(["displayName", "accountGroup", "accountRole", "birthday", "createdAt", "gender", "status", "uid"]);
    const row = (k) => within(dlg).getByTestId(`more-row-${k}`).textContent;
    expect(row("accountGroup")).toContain("Tài khoản cấp cao (SA)");
    expect(row("accountRole")).toContain("Quản trị viên");
    expect(row("birthday")).toContain("31/01/2000");
    expect(row("gender")).toContain("Nữ");
    expect(row("status")).toContain("Đang hoạt động");
    expect(row("uid")).toContain(LAN_UID);
    expect(row("createdAt")).toMatch(/\d{1,2}\/\d{1,2}\/2026/);
  });

  it("thành tích: điểm tài khoản, số lần top 10/top 3/hạng 1, tuần tốt nhất, các tuần gần đây", async () => {
    m.getProfileExtraInfo.mockResolvedValue(FULL);
    renderAt("/u/@lan_vu");
    const dlg = await open();
    const ach = await within(dlg).findByTestId("more-achievements");
    expect(within(ach).getByTestId("stat-score").textContent).toContain((1234).toLocaleString("vi-VN"));
    expect(within(ach).getByTestId("stat-top10").textContent).toMatch(/4.*\/ 12 tuần/);
    expect(within(ach).getByTestId("stat-top3").textContent).toContain("2");
    expect(within(ach).getByTestId("stat-first").textContent).toContain("1");
    expect(within(ach).getByTestId("best-week").textContent).toContain("hạng 1");
    expect(within(ach).getByTestId("best-week").textContent).toContain("Tuần 3.3.01.2026");
    const weeks = within(ach).getByTestId("recent-weeks").querySelectorAll("li");
    expect([...weeks].map((li) => li.textContent)).toEqual([expect.stringContaining("Tuần 9.1.03.2026"), expect.stringContaining("Tuần 3.3.01.2026")]);
    expect(weeks[0].textContent).toContain("Hạng 5");
    expect(weeks[0].textContent).toContain("+8 điểm");
  });

  it("chỉ vẽ ĐÚNG những gì backend trả: không có ngày sinh/giới tính/thành tích thì KHÔNG có dòng/khối đó", async () => {
    m.getProfileExtraInfo.mockResolvedValue({ fields: { displayName: "Lan", accountRole: "user" }, achievements: null });
    renderAt("/u/@lan_vu");
    const dlg = await open();
    await within(dlg).findByTestId("more-fields");
    expect(within(dlg).getAllByTestId(/^more-row-/).length).toBe(2);
    for (const label of ["Ngày sinh", "Giới tính", "UID", "Trạng thái tài khoản"]) expect(within(dlg).queryByText(label)).toBeNull();
    expect(within(dlg).queryByTestId("more-achievements")).toBeNull();
  });

  it("chưa lọt top 10 tuần nào: vẫn hiện điểm + câu trung tính, không có danh sách tuần", async () => {
    m.getProfileExtraInfo.mockResolvedValue({ fields: {}, achievements: { accountScore: 5, weekly: { weeksRecorded: 3, top10Count: 0, top3Count: 0, firstPlaceCount: 0, best: null, recent: [] } } });
    renderAt("/u/@lan_vu");
    const dlg = await open();
    await within(dlg).findByTestId("more-achievements");
    expect(within(dlg).getByTestId("no-weekly")).toBeTruthy();
    expect(within(dlg).queryByTestId("recent-weeks")).toBeNull();
    expect(within(dlg).queryByTestId("stat-top3")).toBeNull();
  });

  it("không chia sẻ gì: câu trung tính cho người khác; cho chính chủ thì nói rõ + lối tắt 'Tùy chỉnh' → Cài đặt > Tài khoản > Thông tin", async () => {
    m.getProfileExtraInfo.mockResolvedValue({ fields: {}, achievements: null });
    renderAt("/u/@lan_vu");
    let dlg = await open();
    expect((await within(dlg).findByTestId("more-empty")).textContent).toBe("Người dùng này chưa chia sẻ thông tin mở rộng nào.");
    expect(within(dlg).queryByTestId("more-customize")).toBeNull();
    cleanup();

    m.getPublicProfile.mockResolvedValue(MINE);
    renderAt("/u/myProfile");
    dlg = await open();
    expect((await within(dlg).findByTestId("more-empty")).textContent).toBe("Bạn chưa bật mục thông tin nào để hiển thị.");
    fireEvent.click(within(dlg).getByTestId("more-customize"));
    await screen.findByTestId("settings-page");
    expect(screen.getByTestId("loc").textContent).toBe("/settings/account/info");
  });

  it("lỗi tải: báo lỗi trong hộp (không treo vòng quay), mở lại thì thử lại", async () => {
    m.getProfileExtraInfo.mockRejectedValueOnce({ message: "Máy chủ bận." });
    renderAt("/u/@lan_vu");
    const dlg = await open();
    expect((await within(dlg).findByRole("alert")).textContent).toContain("Máy chủ bận.");
    expect(within(dlg).queryByRole("progressbar")).toBeNull();
    fireEvent.click(within(dlg).getByRole("button", { name: "Đóng" }));
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    m.getProfileExtraInfo.mockResolvedValueOnce({ fields: { displayName: "Lan" }, achievements: null });
    fireEvent.click(screen.getByTestId("profile-more-button"));
    await screen.findByTestId("more-row-displayName");
    expect(m.getProfileExtraInfo).toHaveBeenCalledTimes(2);
  });
});

// ======================================================================== tự báo lượt ghé thăm
describe("Ghi nhận lượt ghé thăm (POST /users/:uid/visit)", () => {
  it("đã đăng nhập xem hồ sơ NGƯỜI KHÁC → báo đúng một lần với uid của hồ sơ", async () => {
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    await waitFor(() => expect(m.recordProfileVisit).toHaveBeenCalledTimes(1));
    expect(m.recordProfileVisit).toHaveBeenCalledWith(LAN_UID);
  });

  it("vào bằng link UID cũ (trang tự thay URL sang /u/@tag): vẫn CHỈ MỘT lần báo, không báo lại khi URL đổi", async () => {
    renderAt(`/u/${LAN_UID}`);
    await screen.findByText("Lan");
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("/u/@lan_vu"));
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(m.recordProfileVisit).toHaveBeenCalledTimes(1);
  });

  it("KHÔNG báo khi xem hồ sơ của chính mình (cả /u/myProfile lẫn /u/@tag của mình)", async () => {
    m.getPublicProfile.mockResolvedValue(MINE);
    m.getPublicProfileByTag.mockResolvedValue(MINE);
    renderAt("/u/myProfile");
    await screen.findByText("Tôi");
    cleanup();
    renderAt("/u/@toi_day");
    await screen.findByText("Tôi");
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(m.recordProfileVisit).not.toHaveBeenCalled();
  });

  it("KHÔNG báo khi chưa đăng nhập (khách ẩn danh không để lại dấu)", async () => {
    authState = { profile: null, isLoggedIn: false, isAuthReady: true, patchProfile: vi.fn() };
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(m.recordProfileVisit).not.toHaveBeenCalled();
  });

  it("báo lỗi/bị giới hạn tần suất thì im lặng: không snackbar, trang vẫn dùng bình thường", async () => {
    m.recordProfileVisit.mockRejectedValue({ message: "Bạn đang ghé thăm hồ sơ quá nhanh." });
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    await waitFor(() => expect(m.recordProfileVisit).toHaveBeenCalled());
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(m.snack.error).not.toHaveBeenCalled();
    expect(screen.getByText("Lan")).toBeTruthy();
  });

  it("đổi sang hồ sơ người khác thì báo cho người mới (mỗi hồ sơ một lần)", async () => {
    const BAO = { ...LAN, uid: "uBao", displayName: "Bảo", tagName: "@bao_le" };
    m.getPublicProfileByTag.mockImplementation((tag) => Promise.resolve(tag === "bao_le" ? BAO : LAN));
    const Hop = () => {
      const nav = require("react-router-dom").useNavigate();
      return <button onClick={() => nav("/u/@bao_le")}>sang Bảo</button>;
    };
    render(
      <MemoryRouter initialEntries={["/u/@lan_vu"]}>
        <Routes>
          <Route path="/u/:ref" element={<><PublicProfilePage /><Hop /></>} />
        </Routes>
      </MemoryRouter>
    );
    await screen.findByText("Lan");
    await waitFor(() => expect(m.recordProfileVisit).toHaveBeenCalledWith(LAN_UID));
    fireEvent.click(screen.getByText("sang Bảo"));
    await screen.findByText("Bảo");
    await waitFor(() => expect(m.recordProfileVisit).toHaveBeenCalledWith("uBao"));
    expect(m.recordProfileVisit).toHaveBeenCalledTimes(2);
  });
});

// ======================================================================== Khách ghé thăm
describe("Hộp 'Khách ghé thăm' (headZone của chủ hồ sơ)", () => {
  const V = (uid, name, tag, extra = {}) => ({ uid, displayName: name, tagName: `@${tag}`, avatarUrl: null, accountGroup: "RA", accountRole: "user", badges: [], visitedAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(), ...extra });
  const openVisitors = async () => {
    await act(async () => action("profile-visitors").onClick());
    return await screen.findByRole("dialog");
  };
  const renderMine = () => {
    m.getPublicProfile.mockResolvedValue(MINE);
    return renderAt("/u/myProfile");
  };

  it("nút 'Khách ghé thăm' CHỈ có ở hồ sơ của mình, đứng giữa 'Chỉnh sửa hồ sơ' và 'Sao chép URL Profile'", async () => {
    renderMine();
    await screen.findByText("Tôi");
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["edit-profile", "profile-visitors", "copy-profile-url"]);
    expect(action("profile-visitors").label).toBe("Khách ghé thăm");
    cleanup();
    renderAt("/u/@lan_vu");
    await screen.findByText("Lan");
    expect(m.header.current.actions.map((a) => a.key)).toEqual(["copy-profile-url"]);
  });

  it("KHÔNG tải danh sách cho tới khi bấm; bấm → hiện đúng thứ tự API (mới nhất trên cùng) với tên, Tag Name Search, huy hiệu, thời gian", async () => {
    m.listMyVisitors.mockResolvedValue({
      max: 50,
      visitors: [V("v1", "An", "an_01", { badges: ["admin"], accountGroup: "SA", accountRole: "admin" }), V("v2", "Bình", "binh_02"), V("v3", "Chi", "chi_03", { visitedAt: "2020-01-02T03:04:05.000Z" })],
    });
    renderMine();
    await screen.findByText("Tôi");
    expect(m.listMyVisitors).not.toHaveBeenCalled();
    const dlg = await openVisitors();
    const list = await within(dlg).findByTestId("visitors-list");
    expect(m.listMyVisitors).toHaveBeenCalledTimes(1);
    const rows = [...list.querySelectorAll("li")];
    expect(rows.map((r) => r.getAttribute("data-testid"))).toEqual(["visitor-v1", "visitor-v2", "visitor-v3"]);
    expect(within(rows[0]).getByText("An")).toBeTruthy();
    expect(within(rows[0]).getByText("@an_01")).toBeTruthy();
    expect(within(rows[0]).getByTestId("user-badges")).toBeTruthy(); // huy hiệu tài khoản (cùng module UserIdentity/UserBadges với thẻ bài)
    expect(within(rows[1]).queryByTestId("user-badges")).toBeNull();
    expect(within(rows[0]).getByTestId("visitor-time-v1").textContent.trim()).not.toBe("");
    expect(within(rows[2]).getByTestId("visitor-time-v3").textContent).toMatch(/2020/); // quá cũ => hiện ngày giờ cụ thể
    expect(within(dlg).getByText(/Chỉ hiển thị 50 người ghé thăm gần nhất/)).toBeTruthy();
  });

  it("danh sách trống / lỗi tải có thông báo riêng; mở lại tải lại", async () => {
    m.listMyVisitors.mockResolvedValueOnce({ visitors: [], max: 50 });
    renderMine();
    await screen.findByText("Tôi");
    let dlg = await openVisitors();
    expect((await within(dlg).findByTestId("visitors-empty")).textContent).toBe("Chưa có ai ghé thăm hồ sơ của bạn.");
    fireEvent.click(within(dlg).getByRole("button", { name: "Đóng" }));
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());

    m.listMyVisitors.mockRejectedValueOnce({ message: "Lỗi mạng." });
    dlg = await openVisitors();
    expect((await within(dlg).findByRole("alert")).textContent).toContain("Lỗi mạng.");
    expect(m.listMyVisitors).toHaveBeenCalledTimes(2);
  });

  it("bấm tên khách → ĐÓNG hộp rồi sang hồ sơ họ (/u/@tag); chỉ một lần điều hướng", async () => {
    m.listMyVisitors.mockResolvedValue({ visitors: [V("v1", "An", "an_01")], max: 50 });
    m.getPublicProfileByTag.mockResolvedValue({ ...LAN, uid: "v1", displayName: "An", tagName: "@an_01" });
    renderMine();
    await screen.findByText("Tôi");
    const dlg = await openVisitors();
    const row = await within(dlg).findByTestId("visitor-v1");
    fireEvent.click(within(row).getByText("An"));
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("/u/@an_01"));
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    expect(m.getPublicProfileByTag).toHaveBeenCalledWith("an_01");
  });

  it("mỗi dòng là THẺ có viền + nền (không phải chữ trần)", async () => {
    m.listMyVisitors.mockResolvedValue({ visitors: [V("v1", "An", "an_01")], max: 50 });
    renderMine();
    await screen.findByText("Tôi");
    const dlg = await openVisitors();
    const cs = getComputedStyle(await within(dlg).findByTestId("visitor-v1"));
    expect(cs.borderTopStyle).toBe("solid");
    expect(cs.borderTopWidth).toBe("1px");
  });
});

// ======================================================================== Sao chép URL Profile — thẻ có viền
describe("Hộp 'Sao chép URL Profile' — hai lựa chọn nhìn ra là bấm được (v2.5.2)", () => {
  const renderDlg = () => render(<CopyProfileUrlDialog open onClose={() => {}} user={{ uid: LAN_UID, tagName: "@lan_vu" }} />);

  it("mỗi lựa chọn có VIỀN liền 1px + nền, và hai thẻ cách nhau (không dính liền)", async () => {
    renderDlg();
    const tag = await screen.findByTestId("copy-url-tag");
    const uid = screen.getByTestId("copy-url-uid");
    for (const el of [tag, uid]) {
      const cs = getComputedStyle(el);
      expect(cs.borderTopStyle).toBe("solid");
      expect(cs.borderTopWidth).toBe("1px");
      expect(cs.borderTopColor).not.toBe("");
      expect(cs.backgroundColor).not.toMatch(/^(rgba\(0, 0, 0, 0\)|transparent|)$/);
    }
    expect(tag.parentElement).toBe(uid.parentElement); // cùng một danh sách
    expect(getComputedStyle(tag.parentElement).display).toBe("flex");
    expect(getComputedStyle(tag.parentElement).flexDirection).toBe("column");
    // jsdom không phân giải thuộc tính `gap` (getComputedStyle trả "normal"), nên kiểm thẳng trong CSS emotion đã sinh cho đúng lớp của danh sách.
    const css = [...document.querySelectorAll("style")].map((el) => el.textContent).join("\n");
    const listRule = [...tag.parentElement.classList].map((c) => new RegExp(`\\.${c}\\{[^}]*gap:\\s*(\\d+(?:\\.\\d+)?)px`).exec(css)).find(Boolean);
    expect(listRule, "danh sách phải có khoảng cách giữa hai thẻ").toBeTruthy();
    expect(Number(listRule[1])).toBeGreaterThan(0);
  });

  it("vẫn dùng được như trước: hiện đủ 2 link, bấm là sao chép đúng loại", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "clipboard", { value: { writeText }, configurable: true });
    const onClose = vi.fn();
    render(<CopyProfileUrlDialog open onClose={onClose} user={{ uid: LAN_UID, tagName: "@lan_vu" }} />);
    expect((await screen.findByTestId("copy-url-tag-value")).textContent).toMatch(/\/u\/@lan_vu$/);
    expect(screen.getByTestId("copy-url-uid-value").textContent).toMatch(new RegExp(`/u/${LAN_UID}$`));
    fireEvent.click(screen.getByTestId("copy-url-uid"));
    await waitFor(() => expect(writeText).toHaveBeenCalledWith(expect.stringMatching(new RegExp(`/u/${LAN_UID}$`))));
    expect(onClose).toHaveBeenCalled();
    delete navigator.clipboard;
  });

  it("thẻ thiếu dữ liệu (không có Tag hợp lệ) vẫn có viền nhưng bị vô hiệu", async () => {
    render(<CopyProfileUrlDialog open onClose={() => {}} user={{ uid: LAN_UID }} />);
    const tag = await screen.findByTestId("copy-url-tag");
    expect(tag.getAttribute("aria-disabled")).toBe("true");
    expect(getComputedStyle(tag).borderTopStyle).toBe("solid");
  });
});
