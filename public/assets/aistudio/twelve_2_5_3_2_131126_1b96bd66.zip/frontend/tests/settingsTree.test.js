// v2.1.0: cây Cài đặt — quy tắc thư mục/lá, quyền, giải nghĩa URL, và kiểm tra CHÍNH registry thật.
// Chạy: npx vitest run tests/settingsTree.test.js
import { describe, it, expect } from "vitest";
import { buildAccess, buildHref, isFolder, resolvePath, validateTree, visibleChildren } from "../src/pages/settings/settingsTree";
import { SETTINGS_TABS } from "../src/pages/settings/registry";

const Comp = () => null;
const leaf = (key, extra = {}) => ({ key, title: `T-${key}`, component: Comp, ...extra });
const folder = (key, children, extra = {}) => ({ key, title: `T-${key}`, children, ...extra });

const USER = buildAccess({ isSA: false }); // khách (chưa đăng nhập)
const SA = buildAccess({ isSA: true });
const MEMBER = buildAccess({ isLoggedIn: true }); // v2.2.0: người đã đăng nhập (không SA)
const SA_MEMBER = buildAccess({ isSA: true, isLoggedIn: true });

describe("v2.2.0 — tab Tài khoản", () => {
  it("cấu trúc đã chốt: Tài khoản = Thông tin (lá) + Bảo mật (thư mục: Đổi mật khẩu, Xóa tài khoản); chỉ cho người đã đăng nhập", () => {
    const account = SETTINGS_TABS.find((t) => t.key === "account");
    expect(account.requires).toBe("user");
    const [info, security] = account.children;
    expect([info.key, security.key]).toEqual(["info", "security"]);
    expect(isFolder(info)).toBe(false);
    expect(isFolder(security)).toBe(true);
    expect(security.children.map((c) => c.key)).toEqual(["password", "delete"]);
    [info, ...security.children].forEach((c) => expect(typeof c.component).toBe("object")); // tải lười
  });

  it("khách không thấy tab Tài khoản; người đã đăng nhập thấy; SA đã đăng nhập thấy cả ba; thứ tự Ứng dụng → Tài khoản → Quản trị", () => {
    const keys = (access) => resolvePath(SETTINGS_TABS, access, undefined, []).tabs.map((t) => t.key);
    expect(keys(USER)).toEqual(["app"]);
    expect(keys(MEMBER)).toEqual(["app", "account"]);
    expect(keys(SA_MEMBER)).toEqual(["app", "account", "admin"]);
    // /settings (không chỉ định tab) vẫn mở tab Ứng dụng như cũ
    expect(resolvePath(SETTINGS_TABS, MEMBER, undefined, []).tab.key).toBe("app");
  });

  it("đường dẫn lồng: /settings/account/security/delete mở đúng mục lá khi đã đăng nhập; khách bị từ chối (không lộ tồn tại)", () => {
    const ok = resolvePath(SETTINGS_TABS, MEMBER, "account", ["security", "delete"]);
    expect(ok.ok).toBe(true);
    expect(ok.node.key).toBe("delete");
    expect(buildHref("account", ["security", "delete"])).toBe("/settings/account/security/delete");
    expect(resolvePath(SETTINGS_TABS, USER, "account", ["security", "delete"]).ok).toBe(false);
    expect(resolvePath(SETTINGS_TABS, USER, "account", []).ok).toBe(false);
  });

  it("buildAccess: chỉ true khi đúng true (chuỗi/số không được tính)", () => {
    expect(buildAccess({ isLoggedIn: "yes" }).user).toBe(false);
    expect(buildAccess({ isLoggedIn: true }).user).toBe(true);
    expect(buildAccess().user).toBe(false);
  });
});

describe("registry thật của Twelve", () => {
  it("hợp lệ: không trùng key, không thiếu component, quyền hợp lệ", () => {
    expect(validateTree(SETTINGS_TABS)).toEqual([]);
  });

  it("giữ đúng cấu trúc đã chốt: Ứng dụng = Chế độ giao diện (lá) + Font chữ (thư mục 3 nhóm)", () => {
    const app = SETTINGS_TABS.find((t) => t.key === "app");
    const [theme, font] = app.children;
    expect(isFolder(theme)).toBe(false);
    expect(isFolder(font)).toBe(true);
    expect(font.children.map((c) => c.key)).toEqual(["client", "server", "custom"]);
    // 3 nhóm font dùng CHUNG một component, khác nhau ở props
    expect(new Set(font.children.map((c) => c.component)).size).toBe(1);
    expect(font.children.map((c) => c.props.source)).toEqual(["client", "server", "custom"]);
  });

  it("tab Quản trị chỉ dành cho SA, và mọi mục lá bên trong đều tải lười", () => {
    const admin = SETTINGS_TABS.find((t) => t.key === "admin");
    expect(admin.requires).toBe("sa");
    expect(admin.children.map((c) => c.key)).toEqual(["embed-domains", "fonts", "csp-reports", "assets", "ip-topology", "debug"]);
    // React.lazy => đối tượng có $$typeof lazy, không phải hàm thường
    admin.children.forEach((c) => expect(typeof c.component).toBe("object"));
  });

  it("người thường không thấy tab Quản trị; SA thấy cả hai", () => {
    expect(resolvePath(SETTINGS_TABS, USER, undefined, []).tabs.map((t) => t.key)).toEqual(["app"]);
    expect(resolvePath(SETTINGS_TABS, SA, undefined, []).tabs.map((t) => t.key)).toEqual(["app", "admin"]);
  });
});

describe("validateTree bắt khai báo sai", () => {
  it("key trùng / key sai định dạng / thiếu title", () => {
    const errs = validateTree([folder("a", [leaf("x"), leaf("x"), leaf("Bad_Key"), { key: "no-title", component: Comp }])]);
    expect(errs.join("\n")).toMatch(/trùng key/);
    expect(errs.join("\n")).toMatch(/key phải là chữ thường/);
    expect(errs.join("\n")).toMatch(/thiếu title/);
  });
  it("vừa có children vừa có component; không có cả hai; thư mục rỗng", () => {
    const errs = validateTree([
      { key: "both", title: "t", component: Comp, children: [leaf("x")] },
      { key: "none", title: "t" },
      folder("empty", []),
    ]);
    expect(errs.join("\n")).toMatch(/vừa có children vừa có component/);
    expect(errs.join("\n")).toMatch(/phải có children \(thư mục\) hoặc component/);
    expect(errs.join("\n")).toMatch(/thư mục rỗng/);
  });
  it("requires lạ bị báo (tránh gõ sai quyền rồi vô tình mở cho mọi người)", () => {
    expect(validateTree([folder("a", [leaf("x")], { requires: "admin" })]).join()).toMatch(/chưa được hỗ trợ/);
  });
});

describe("resolvePath", () => {
  const tabs = [
    folder("app", [leaf("theme"), folder("font", [leaf("one"), leaf("two")])]),
    folder("admin", [leaf("panel-a"), leaf("panel-b")], { requires: "sa" }),
  ];

  it("không chỉ định tab ⇒ tab đầu tiên, ở gốc, kiểu thư mục", () => {
    const r = resolvePath(tabs, USER, undefined, []);
    expect(r.ok && r.kind).toBe("folder");
    expect(r.tab.key).toBe("app");
    expect(r.trail).toEqual([]);
    expect(r.items.map((i) => i.key)).toEqual(["theme", "font"]);
  });

  it("mục lá ⇒ kind=leaf; thư mục ⇒ kind=folder với danh sách mục con", () => {
    expect(resolvePath(tabs, USER, "app", ["theme"]).kind).toBe("leaf");
    const f = resolvePath(tabs, USER, "app", ["font"]);
    expect(f.kind).toBe("folder");
    expect(f.items.map((i) => i.key)).toEqual(["one", "two"]);
    expect(f.trail.map((n) => n.key)).toEqual(["font"]);
  });

  it("đường dẫn sai ⇒ ok=false (không đoán, không rơi về tab khác)", () => {
    expect(resolvePath(tabs, USER, "app", ["khong-co"]).ok).toBe(false);
    expect(resolvePath(tabs, USER, "app", ["theme", "con"]).ok).toBe(false); // đi tiếp qua một mục lá
    expect(resolvePath(tabs, USER, "khong-co", []).ok).toBe(false);
  });

  it("quyền: người thường không vào được Quản trị bằng URL; SA vào được", () => {
    expect(resolvePath(tabs, USER, "admin", []).ok).toBe(false);
    expect(resolvePath(tabs, USER, "admin", ["panel-a"]).ok).toBe(false);
    expect(resolvePath(tabs, SA, "admin", ["panel-a"]).ok).toBe(true);
  });

  it("requires đặt ở thư mục áp dụng cho mọi thứ bên dưới", () => {
    const t = [folder("app", [folder("sec", [leaf("x"), leaf("y")], { requires: "sa" }), leaf("z")])];
    expect(visibleChildren(t[0], USER).map((c) => c.key)).toEqual(["z"]);
    expect(resolvePath(t, USER, "app", ["sec", "x"]).ok).toBe(false);
    expect(resolvePath(t, SA, "app", ["sec", "x"]).ok).toBe(true);
  });

  it("quy tắc 3: thư mục không còn mục con hiển thị được thì biến mất", () => {
    const t = [folder("app", [leaf("z"), folder("sec", [leaf("x", { requires: "sa" })])])];
    expect(visibleChildren(t[0], USER).map((c) => c.key)).toEqual(["z"]);
    expect(resolvePath(t, USER, "app", ["sec"]).ok).toBe(false);
  });

  it("quy tắc 4: thư mục chỉ còn MỘT mục con hiển thị được ⇒ mở ra là thấy luôn nội dung, giữ tên thư mục", () => {
    const t = [folder("app", [folder("sec", [leaf("only"), leaf("hidden", { requires: "sa" })], { icon: "ICON" })])];
    const user = resolvePath(t, USER, "app", ["sec"]);
    expect(user.kind).toBe("leaf");
    expect(user.node.component).toBe(Comp);
    expect(user.node.title).toBe("T-sec"); // tên của thư mục, không phải của con
    // SA thấy 2 mục con ⇒ lại là thư mục thật
    expect(resolvePath(t, SA, "app", ["sec"]).kind).toBe("folder");
  });

  it("quy tắc 4 áp dụng dây chuyền qua nhiều tầng một-con", () => {
    const t = [folder("app", [folder("a", [folder("b", [leaf("deep")])])])];
    const r = resolvePath(t, USER, "app", ["a"]);
    expect(r.kind).toBe("leaf");
    expect(r.node.title).toBe("T-a");
  });

  it("gốc tab KHÔNG bị gộp dù chỉ có một mục", () => {
    const t = [folder("app", [leaf("only")])];
    const r = resolvePath(t, USER, "app", []);
    expect(r.kind).toBe("folder");
    expect(r.items).toHaveLength(1);
  });
});

describe("buildHref", () => {
  it("ghép đường dẫn", () => {
    expect(buildHref("app")).toBe("/settings/app");
    expect(buildHref("app", ["font", "custom"])).toBe("/settings/app/font/custom");
  });
});
