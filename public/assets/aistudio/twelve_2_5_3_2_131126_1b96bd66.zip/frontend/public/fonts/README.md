# Font chữ client (#1.2)

File trong thư mục này được phục vụ nguyên trạng tại `/fonts/<tên>` và được khai báo trong `src/theme/fonts.js`.

- `svn-headliner-no45.woff2` — SVN-Headliner No. 45 (chuyển từ `.otf` sang WOFF2, giữ nguyên 372 glyph, gồm đủ tiếng Việt).
  Bản quyền trong file font: "Copyright (c) 2012 by Kevin Christopher. Licensed. Copyright KC Fonts all rights reserved."
  Hãy chắc chắn giấy phép bạn có cho phép nhúng font lên web trước khi phát hành công khai.

Vercel cache các file ở đây 1 năm (`immutable`, xem `vercel.json`) => khi THAY NỘI DUNG font, hãy ĐỔI TÊN file
(vd. `svn-headliner-no45-v2.woff2`) và cập nhật `url` trong `fonts.js`.
