# PATCH 25 — v2.5.3.121126: Hotfix — App Check (TW-04) làm treo frontend

Chỉ **frontend** (backend không đổi mã). Test: backend **316** (312 + 4 ở `security-2531.test.js`), frontend **397** (385 + 12 ở `appCheckGuard.test.js`), `vite build` sạch.
Không cần đổi `vercel.json`, Firestore rules hay biến môi trường nào. Sau khi deploy có thể đặt lại `VITE_FIREBASE_APPCHECK_SITE_KEY` **nếu và chỉ khi** đã làm đủ mục 4.

## 1. Triệu chứng (do vận hành báo)
Sau khi lên 2.5.3, frontend tải rất lâu (> 2 phút): đăng nhập, đăng ký, bảng xếp hạng… trong khi `curl` tới backend vẫn nhanh. Frontend 2.5.2 + backend 2.5.3 nhanh; frontend 2.5.3 **xoá biến App Check** cũng nhanh.
⇒ Backend 2.5.3 không có lỗi hiệu năng (chạy backend thật + Chromium: mọi API < 30 ms, preflight CORS bình thường, 312 test chạy 16 giây). Lỗi nằm ở `frontend/src/firebase.js` (TW-04) khi có `VITE_FIREBASE_APPCHECK_SITE_KEY`.

## 2. Nguyên nhân gốc (đã đọc mã Firebase SDK 10.14.1 và tái hiện bằng trình duyệt thật)
1. 2.5.3 làm CSP **chặn thật** `script-src 'self' https://challenges.cloudflare.com`. Khi đặt site key mà CSP chưa mở reCAPTCHA (hoặc reCAPTCHA bị chặn/lỗi mạng/trình chặn quảng cáo) thì script `https://www.google.com/recaptcha/api.js` không tải được.
2. `loadReCAPTCHAV3Script()` trong `@firebase/app-check` **không có `onerror`** ⇒ Promise `initialized` không bao giờ resolve ⇒ `ReCaptchaV3Provider.getToken()` treo vô hạn (không có timeout), và `state.exchangeTokenPromise` giữ Promise treo đó cho mọi lần gọi sau.
3. Firebase Auth (`_getAppCheckToken`) và Firestore **`await` token này trước mỗi yêu cầu mạng** ⇒ yêu cầu `signInWithPassword` thậm chí không được gửi đi; token hết hạn không làm mới được; listener Firestore không kết nối. Chỉ các lệnh gọi axios tới Express (không qua Firebase) còn chạy — nên `curl` và các trang không cần phiên vẫn nhanh.
4. Lỗi "bình thường" của App Check (sai khoá, bị throttle…) **không** treo: SDK đổi thành token giả + lỗi rồi cho yêu cầu đi tiếp. Chỉ trường hợp "script không bao giờ báo gì" mới treo — đúng cái CSP chặn gây ra.

Cách tái hiện (Chromium, đúng header `vercel.json` 2.5.3, Firebase giả lập): bản 2.5.3 + site key + CSP như đã giao ⇒ bấm Đăng nhập, **0 yêu cầu được gửi, chờ 30 giây vẫn treo**; cùng bản build không có site key ⇒ phản hồi sau 89 ms.

## 3. Thay đổi
- **`src/utils/appCheckGuard.js` (mới)**: `waitForRecaptcha()` tự nạp đúng URL reCAPTCHA mà SDK sẽ nạp (nên SDK thấy `grecaptcha` có sẵn và không nạp lại) với `onerror` + timeout 8 giây rồi chờ `grecaptcha.ready`; `withTokenTimeout()` bọc provider để `getToken()` quá 5 giây thì báo lỗi (SDK cho yêu cầu đi tiếp không kèm token hợp lệ) và tạm bỏ qua App Check 60 giây.
- **`src/firebase.js`**: `initializeAppCheck` chỉ chạy sau `waitForRecaptcha()` thành công, provider luôn là `withTokenTimeout(...)`; thất bại ⇒ `console.warn("App Check bị bỏ qua …")` và ứng dụng chạy như khi chưa bật. Token gỡ lỗi (DEV) không đi qua reCAPTCHA nên không phải chờ.
- **`src/firebase.js` (Auth)**: dùng `initializeAuth(app, { persistence: [...] })` **không** gắn `browserPopupRedirectResolver`. `getAuth()` luôn gắn nó và trên điện thoại/Safari/iOS Firebase nạp `https://apis.google.com/js/api.js` ngay khi mở trang — từ 2.5.3 CSP chặn script này (đã thấy báo vi phạm ở mỗi lần mở trang khi giả lập iPhone). Twelve chỉ đăng nhập bằng email/mật khẩu (không có popup/redirect/OAuth trong mã — có test canh), nên bỏ resolver là đủ, không phải mở `apis.google.com` trong CSP. Nếu sau này thêm đăng nhập Google/popup: khôi phục `getAuth()` và mở CSP.
- Số phiên bản 2.5.3.081126 → 2.5.3.121126 ở mọi nơi quy ước (test TW-23 canh).

Kết quả sau sửa (cùng bộ kịch bản): key đặt + reCAPTCHA bị CSP chặn → đăng nhập phản hồi sau 89 ms, có cảnh báo; key đặt + CSP đã mở + reCAPTCHA chạy → yêu cầu đăng nhập mang `X-Firebase-AppCheck`, có 1 lần đổi token; key đặt + `execute()` không bao giờ trả lời → đăng nhập qua sau ≤ 5 giây (token giả, không treo); không đặt key → như cũ; iPhone → hết vi phạm `apis.google.com`.

## 4. Cách bật App Check ĐÚNG (làm theo thứ tự)
1. Sửa `frontend/vercel.json` — **cả hai header**. Header **chặn thật** (`Content-Security-Policy`) mới là header làm treo; Report-Only chỉ để báo:
   - `Content-Security-Policy` (chặn thật): `script-src 'self' https://challenges.cloudflare.com https://www.google.com/recaptcha/ https://www.gstatic.com/recaptcha/; script-src-attr 'none'`
   - `Content-Security-Policy-Report-Only`: thêm cùng hai nguồn vào `script-src`; `frame-src` thêm `https://www.google.com/recaptcha/ https://recaptcha.google.com/recaptcha/`; `connect-src` thêm `https://firebaseappcheck.googleapis.com`.
   - Bản `v3` cần khoá reCAPTCHA **v3** đã thêm tên miền Vercel của bạn trong Firebase Console › App Check › Apps.
2. Deploy, rồi đặt `VITE_FIREBASE_APPCHECK_SITE_KEY` trên Vercel và deploy lại.
3. Kiểm trên trình duyệt: Console **không** có `Refused to load the script '…recaptcha/api.js'` và **không** có `App Check bị bỏ qua`; Network có `exchangeRecaptchaV3Token` trả 200; yêu cầu tới `identitytoolkit`/Firestore có header `X-Firebase-AppCheck`.
4. Firebase Console › App Check › Cloud Firestore ở **Monitor** vài ngày; chỉ sang **Enforce** khi tỉ lệ yêu cầu có token ≈ 100%. Lưu ý: ở Enforce, người dùng mà reCAPTCHA bị chặn (trình chặn quảng cáo…) sẽ bị Firestore từ chối **nhanh** (không còn treo) — chấp nhận đánh đổi này hay không là quyết định của bạn.

## 5. Ghi nhận / chưa kiểm chứng
- Mình **không có** Firebase/reCAPTCHA/Vercel thật trong môi trường làm việc: đường "reCAPTCHA chạy bình thường" được kiểm bằng bản giả lập `grecaptcha` + điểm cuối đổi token giả, không phải reCAPTCHA thật. Hãy làm bước 3 ở mục 4 trên bản xem trước Vercel.
- PATCH-24 nói "khi để trống, bundler loại bỏ hẳn mã App Check". Chính xác hơn: provider reCAPTCHA và mã khởi tạo bị loại, nhưng phần lõi SDK App Check (đăng ký component, chế độ khởi tạo `EXPLICIT`) vẫn nằm trong bundle và **không chạy** khi không gọi `initializeAppCheck` — đã kiểm: không đặt key thì đăng nhập phản hồi bình thường.
- Chưa kiểm hành vi của Safari/WebKit khi script bị CSP chặn (có phát `error` hay không) — việc bỏ resolver Auth giúp tránh hẳn câu hỏi này.
