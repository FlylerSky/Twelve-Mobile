# PATCH 26 — v2.5.3.131126 ("2.5.3.2"): đo + sửa nhận diện IP (TW-01), tinh chỉnh CSP, đính chính báo cáo phụ lục (13/11/2026)

Backend + frontend. Không có index/rules mới, không đổi dữ liệu. **Mặc định hành vi KHÔNG đổi so với 2.5.3.121126** — mọi thứ mới là công cụ đo hoặc công tắc tuỳ chọn (tắt).
Test: backend **330** (316 + 14 ở `test/security-2532.test.js`), frontend **403** (397 + 6 ở `tests/ipTopologyPanel.test.jsx`), `vite build` sạch.

## 1. Vì sao có bản này
Báo cáo phụ lục re-audit 2.5.3 (`TWELVE-SECURITY-AUDIT-v2.5.3-ADDENDUM.md`) kết luận ở §9 rằng V-01 (né limiter) là **false positive**. Đối chiếu với mã nguồn, kết luận đó **chưa đủ căn cứ**:

1. **Header `x-ratelimit-*` không bị "nhiều limiter ghi đè nhau".** Chỉ `globalLimiter` (`server.js`) và `authLimiter` (`/api/auth`) phát header kiểu cũ; 23 limiter còn lại (ở 2.5.3) đều đặt `legacyHeaders: false`. Trên `/api/posts` chỉ có MỘT bộ đếm viết `x-ratelimit-remaining`. Chuỗi `277 297 296 295 276 275 299 294 298 297 296` (số lặp, nhảy lên xuống trong cùng cửa sổ 15 phút) không thể do một khoá duy nhất ⇒ khoá IP đã đổi giữa các request. (Test canh: `security-2532.test.js` "header x-ratelimit-* …".)
2. **V-02 (`viewCount` 1→3 trong 10 lần GET cùng IP) không thể là "dedupe trong RAM của từng instance".** `registerView` (`helpers.js`) chống trùng bằng giao dịch Firestore (`views/<viewerKey>`), khoá là hash của `getClientKey(req)`. Số view chỉ tăng nhiều lần khi `viewerKey` đổi ⇒ cùng nguyên nhân với (1), độc lập với limiter.
3. **Số liệu "chứng minh chính xác" ở §9 không khớp.** Cửa sổ 2 nhận 167 request thì `x-ratelimit-remaining` phải ≈ 132, đo được 79; `x-ratelimit-reset` chỉ nhảy +7 giây trong khi một cửa sổ 15 phút roll-over phải nhảy ≈ +900 giây. Hai con số này khớp với việc có hai bucket (hai khoá khác nhau) bắt đầu cách nhau 7 giây.
4. **Burst từ một IP không chứng minh khoá là IP thật.** Limiter đếm đúng theo khoá không có nghĩa khoá đó là IP người dùng — mà đó chính là điều TW-01 cần kiểm.

Giả thuyết "Render nhiều instance" đúng là sai (free tier 1 instance) — nhưng điều đó **không** loại được nguyên nhân còn lại: khoá IP không ổn định / không đúng. Chỉ đo mới chốt được (xem §3).

Phát hiện thêm khi viết test trên Express thật (`security-2532.test.js`, ca "rủi ro đã biết"): nếu Render thêm **một hop nội bộ** sau Cloudflare (`X-Forwarded-For = "client, edge, 10.x"`), cấu hình mặc định (`TRUST_PROXY_HOPS=1`) cho `req.ip = 10.x` — **mọi người dùng chung MỘT khoá**. Không biết đây có phải topology thật không; công cụ dưới đây phát hiện được đúng trường hợp này.

## 2. Thay đổi
### Backend
- **`utils/clientIp.js`**:
  - `describeIpTopology(req)` — mô tả request hiện tại (peer, chuỗi `X-Forwarded-For`, `CF-Connecting-IP`) và khoá sẽ ra gì ở từng cấu hình ứng viên (`TRUST_PROXY_HOPS=0…4`, `TRUST_PROXY_MODE=cloudflare`), kèm kết luận `OK` / `MISMATCH_FIXABLE` / `MISMATCH_UNKNOWN` / `NO_CF_HEADER`. Mô hình đã đối chiếu với `req.ip` của Express thật cho 5 chuỗi × 5 cấu hình (test). Chỉ gợi ý chế độ `cloudflare` (nếu dùng được) và số hop **nhỏ nhất** đúng — không bao giờ khuyên số hop thừa (số hop thừa chọn trúng mục do client tự đặt, N-01 của báo cáo).
  - `TRUST_PROXY_MODE=cloudflare` (**tuỳ chọn, mặc định `hops`**): Express tin mọi địa chỉ thuộc dải Cloudflare + nội bộ (loopback/link-local/private) + `TRUST_PROXY_EXTRA` rồi lấy địa chỉ không tin cậy đầu tiên tính từ bên phải `X-Forwarded-For` làm IP client — không phụ thuộc số hop. Test chống giả: mục giả bên trái (kể cả trông như IP Cloudflare) và `CF-Connecting-IP` giả không bao giờ được chọn.
  - `trustProxySetting()` (dùng ở `server.js`), `parseRangeList()` (mục env hỏng bị bỏ), `isTrustedProxyAddress()`.
- **`GET /api/admin/ip-topology`** (`controllers/ipTopology.controller.js`, route trong `admin.routes.js`): chỉ SA (dưới `router.use(requireSA)`), chỉ đọc, `Cache-Control: no-store`, limiter riêng `ipTopologyLimiter` (60/15 phút/tài khoản). Chỉ trả IP hợp lệ + chuỗi header đã lọc ký tự; **không** trả `Authorization`, `x-twelve-ssr-secret`, cookie hay header khác (test).
- `ipTopologyProbe` (log `[IP-TOPO]`) giữ nguyên, thêm `trustMode`.

### Frontend
- **Cài đặt › Quản trị › "Nhận diện IP"** (`pages/settings/AdminIpTopologyPanel.jsx`, tải lười, `requires:"sa"` kế thừa từ tab Quản trị): nút **Đo ngay** gọi backend 5 lần, hiện kết luận, khoá IP có ổn định qua các lần đo không, chuỗi proxy và bảng "đặt cấu hình nào thì khoá ra gì". Không tự gọi khi mở; không có đường ghi.
- **`vercel.json`**: bỏ `usb=()` khỏi `Permissions-Policy` (trình duyệt báo "Unrecognized feature", vô hại); thêm `https://ik.imagekit.io` vào `img-src` **Report-Only** (ảnh thật của nền tảng, 88 vi phạm đã thấy ở bảng báo cáo CSP). **Không enforce** `img-src`/`frame-src`; `script-src` enforce **không đổi** (xem §5).

## 3. Cách dùng (làm theo thứ tự)
1. Deploy backend + frontend (không cần `firestore:rules`). Đặt `BACKEND_VERSION=2.5.3.131126` trên Render.
2. Đăng nhập tài khoản SA → Cài đặt → Quản trị → **Nhận diện IP** → **Đo ngay**. Đọc kết luận:

| Kết luận | Nghĩa | Làm gì |
|---|---|---|
| **Đúng** (`OK`) | Khoá = IP Cloudflare thấy | TW-01 ổn trên topology này. Nếu vẫn thấy `x-ratelimit-remaining` nhảy / `viewCount` tăng nhiều, nguyên nhân là chỗ khác — báo lại kèm số liệu |
| **KHÁC IP thật + có gợi ý** (`MISMATCH_FIXABLE`) | Khoá đang là IP edge hoặc IP nội bộ | Đặt biến được gợi ý trên Render (**ưu tiên `TRUST_PROXY_MODE=cloudflare`** nếu có trong gợi ý, vì không phụ thuộc số hop; không thì `TRUST_PROXY_HOPS=<số>`), **khởi động lại**, đo lại. Nếu bảng ứng viên ghi "chưa dùng được (peer không thuộc dải tin cậy)" thì đừng dùng chế độ `cloudflare` — dùng số hop, hoặc thêm dải proxy vào `TRUST_PROXY_EXTRA` |
| **KHÁC + không gợi ý** (`MISMATCH_UNKNOWN`) | Không cấu hình nào cho ra IP thật | Thử `CLOUDFLARE_EXTRA_RANGES` (nếu địa chỉ ở gần app là Cloudflare mà chưa nằm trong danh sách) hoặc `TRUST_PROXY_EXTRA` (proxy nội bộ), đo lại; không được thì gửi nguyên bảng kết quả |
| **Chưa có gì để đối chiếu** (`NO_CF_HEADER`) | Request không có `CF-Connecting-IP` | Mở trang bằng địa chỉ chính thức rồi đo lại |

3. Sau khi đổi biến, **kiểm bằng số đếm thật** (không chỉ nhìn panel): từ MỘT máy chạy
   `for i in $(seq 30); do curl -s -o /dev/null -D - "https://twelveta.onrender.com/api/posts?limit=1" | tr -d '\r' | grep -i '^x-ratelimit-remaining'; done`
   — số phải **giảm đều từng đơn vị**, không có số lặp hay nhảy lên. Rồi mở một bài mới 10 lần từ cùng IP: `viewCount` chỉ tăng 1.
4. Lưu ý khi đổi khoá: định dạng khoá chống đếm trùng không đổi nhưng GIÁ TRỊ đổi (từ IP edge sang IP thật) ⇒ mỗi khách ẩn danh được đếm thêm tối đa 1 lượt xem một lần (không ảnh hưởng điểm — như ghi chú ở 2.5.3).
5. `DEBUG_IP_TOPOLOGY=on` (log `[IP-TOPO]`) vẫn dùng được nếu bạn thích đọc log; panel làm cùng việc mà không cần Render.

## 4. Điều KHÔNG đổi (có chủ ý)
- Mặc định `TRUST_PROXY_HOPS=1`, `CLIENT_IP_MODE=auto`, `TRUST_PROXY_MODE=hops` — không đổi hành vi nếu bạn không đặt biến nào. (Panel vẫn chạy được ở mặc định.)
- **Không thêm Redis**: nếu chỉ có một instance thì không cần; chỉ cần khi scale nhiều instance.
- `img-src`/`frame-src` **chưa enforce** — xem §5.

## 5. Quyết định của bạn (chưa làm vì chưa có dữ liệu để chốt)
1. **App Check** (biến `VITE_FIREBASE_APPCHECK_SITE_KEY` đang đặt trên Vercel; log cho thấy script bị `script-src` enforce chặn nên App Check đang tắt — không treo nhờ hotfix 2.5.3.1). Hoặc **(a)** gỡ biến cho gọn (log hết cảnh báo; Firestore không có App Check), hoặc **(b)** bật thật theo thứ tự ở `PATCH-25-NOTES.md` §4. Lưu ý từ log: script được nạp là `…/recaptcha/enterprise.js` ⇒ biến `VITE_FIREBASE_APPCHECK_PROVIDER=enterprise` đang đặt (mã hỗ trợ cả `v3` lẫn `enterprise`; báo cáo phụ lục nói "PATCH-25 giả định v3" là chưa đúng). Với enterprise, ngoài `script-src` cần thêm `frame-src https://www.google.com/recaptcha/` và `connect-src https://firebaseappcheck.googleapis.com` vào bản Report-Only và quan sát trước. Mình KHÔNG mở sẵn vì đây là thay đổi hành vi (bật App Check thật) mà bạn chưa quyết.
2. **Suno** (`cdn2.suno.ai`, 8 vi phạm ở `/u/:id`): ảnh hiện được nghĩa là `suno.ai` có trong allowlist domain nhúng (Cài đặt › Quản trị › Domain nhúng) **hoặc** có đường render ảnh không qua `isAllowedEmbedSrc` (ví dụ ảnh bìa hồ sơ). Hãy xem allowlist trước: nếu không có `suno.ai` thì đó là lỗ hổng cần điều tra, không phải "thêm vào CSP". Nếu có, thêm `https://suno.ai https://*.suno.ai`… vào `img-src` (dùng `npm run csp:sources` để sinh từ allowlist thật).
3. **Enforce `img-src`/`frame-src`**: sau ≥ 7 ngày bảng báo cáo CSP không còn vi phạm hợp lệ. Danh sách nguồn lấy từ `npm run csp:sources` (đọc allowlist thật), không thêm tay theo số lần vi phạm. `ik.imagekit.io` hiện ở mức *domain* (CSP không áp path tin cậy giữa trình duyệt) nên cho cả tài khoản ImageKit khác — chấp nhận được vì phía backend vẫn lọc theo path trong allowlist.

## 6. Đính chính báo cáo phụ lục (để chuyển lại cho người kiểm thử)
| Chỗ | Nội dung báo cáo | Đối chiếu mã |
|---|---|---|
| §9 V-01 "false positive" | Do nhiều limiter ghi đè header; burst chứng minh limiter đúng | Chỉ `globalLimiter` phát `x-ratelimit-*`; remaining/reset không khớp mô hình một cửa sổ; burst không chứng minh khoá đúng ⇒ **mở lại V-01 ở mức "chưa kết luận — đo bằng panel Nhận diện IP"** |
| §2.2/§9 V-02 | Dedupe "in-memory mỗi process" | Dedupe ở Firestore (`views/<viewerKey>`) ⇒ `viewCount` tăng nhiều chỉ khi khoá đổi; cùng nguyên nhân V-01 |
| §2.3 | Ảnh bài viết là "https bất kỳ" | `isAllowedEmbedSrc` lọc `img/video/audio/source/iframe` theo allowlist SA; SSR `img-src https:` là cho CSP backend, không phải chính sách ảnh |
| §8.2 | "PATCH-25 giả định v3; enterprise.js mới đúng" | Mã hỗ trợ cả hai (`VITE_FIREBASE_APPCHECK_PROVIDER`); `enterprise.js` bị nạp chứng tỏ biến đang là `enterprise` |
| §8.2 ImageKit | "Bắt buộc thêm vào img-src" | Đã thêm vào **Report-Only** (chưa enforce); nguồn nên sinh bằng `csp:sources` |
| §6/§1 | "13/21 đã vá" | Bảng chỉ có 11 mục ✅ + V-16 một phần |

## 7. Chưa kiểm chứng
- Mình không có Render/Cloudflare thật: mô hình đo được đối chiếu với **Express thật** (peer là 127.0.0.1, chuỗi proxy mô phỏng bằng `X-Forwarded-For`) chứ không phải với topology Render thật — việc đo trên Render là bước 2 ở §3. Giả định của chế độ `cloudflare` (proxy sát app của Render nằm trong dải nội bộ) cũng chỉ kiểm được bằng panel: nếu `peerTrusted=false` thì đừng bật.
- Panel gọi 5 lần qua cùng một kết nối của trình duyệt, nên "khoá ổn định qua 5 lần đo" không chứng minh được ổn định qua mọi đường đi; kết luận chính là phần đối chiếu với `CF-Connecting-IP` và phép thử đếm ở §3 bước 3.
