# v2.0.11 — Vá theo Báo cáo bảo mật Phiên 2 (Frontend)

Xây trên **v2.0.10** (đã gồm bản vá Phiên 1), theo quyết định của bạn. Nhãn `2.0.11.081026` là tạm.
Backend: chỉ thêm endpoint thu báo cáo CSP. Frontend: CSP, Quill, giới hạn nội dung, tách mã.

## Đối chiếu từng mục
| Mục | Kết luận của mình | Trạng thái |
|---|---|---|
| G1 CSP chưa enforce, không có report | Đúng. **Bắt đầu bước 1 (thu báo cáo)** + bật ngay phần CSP an toàn nhất; script-src vẫn Report-Only | **Đã làm** (chờ quan sát rồi mới enforce) |
| G2 Quill 1.3.7 / CVE-2021-3163 | Báo cáo kết luận "không tái hiện" vì jsdom không bắn `onerror`. **Cơ chế vẫn thật**: mình dựng lại ở mức DOM — `convert()` gắn `<img onerror>` vào container nằm TRONG tài liệu (MutationObserver bắt được). Trình duyệt thật sẽ bắt đầu tải ảnh ⇒ có thể chạy `onerror` | **Đã giảm thiểu** (không nâng Quill) |
| G3 `npm audit` frontend | Nâng version không cần thiết: mình đo được mã bị cảnh báo **không có trong bundle** | **Không đổi** (có bằng chứng, xem dưới) |
| G4 Bundle 1,46 MB | Đúng | **Đã làm** → 1,02 MB (-30%) |
| G5 Giới hạn nội dung phía client | Đúng (cần sau F1 của Phiên 1) | **Đã làm** + test khớp hằng số với backend |

## G1 — CSP
- **Backend:** `POST /api/csp-report` (công khai, luôn 204, body ≤16 KB, ≤20 báo cáo/request, 60 request/phút/IP, nhận cả `application/csp-report` lẫn `application/reports+json`). Gom nhóm trong RAM (≤300 loại, không ghi Firestore), **chỉ giữ origin+path**: bỏ query/hash, `blocked-uri` chỉ còn origin, không lưu IP; tiện ích trình duyệt (`chrome-extension://…`) đếm riêng. SA xem ở **Cài đặt > Quản trị > Báo cáo vi phạm CSP** (`GET/DELETE /api/admin/csp-reports`).
- **Frontend:** `vercel.json` thêm `report-uri /csp-report` (cùng origin; `middleware.js` chuyển POST sang backend nên KHÔNG hardcode host). Thêm header **enforcing** `Content-Security-Policy: object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'` — hai header CSP cùng tồn tại, trình duyệt áp dụng cả hai; 4 directive này gần như không thể làm hỏng chức năng (đã kiểm: app không dùng `<object>/<embed>/<base>`, không có form gửi ra ngoài, `frame-ancestors 'self'` trùng `X-Frame-Options` đang có).
- **Lộ trình enforce (bạn quyết định thời điểm):** (1) deploy, để chạy ≥7 ngày có lưu lượng thật; (2) xem panel: chấp nhận được khi chỉ còn dòng từ tiện ích (đã tự bỏ qua) hoặc không còn dòng nào ở `script-src*`/`frame-src`/`connect-src`; (3) đổi tên header `Content-Security-Policy-Report-Only` → `Content-Security-Policy` trong `vercel.json`; (4) rollback = đổi lại tên. Mình không tự bật vì không có trình duyệt thật để thử; bundle chỉ tham chiếu `apis.google.com`/`www.google.com` (luồng đăng nhập popup/reCAPTCHA của Firebase mà Twelve không dùng).
- Lưu ý: số liệu nằm trong RAM ⇒ mất khi Render khởi động lại; hãy xem log Render (`[CSP] …`, tối đa 30 dòng/phút) nếu cần lịch sử.

## G2 — Quill
`utils/quillSafeClipboard.js` ghi đè `clipboard.convert()`: HTML dạng chuỗi (đường `dangerouslyPasteHTML` mà react-quill và nút chèn media dùng) đi qua `DOMParser` (tài liệu trơ) để bỏ thẻ nguy hiểm (script/style/svg/math/form/object/embed…), mọi thuộc tính ngoài allowlist (gồm toàn bộ `on*`) và URL `javascript:`/`data:text/html`, rồi mới đến Quill. Test với **Quill 1.3.7 thật**: mã gốc gắn phần tử có `on*` vào DOM; sau vá thì không; hoàn nguyên bản vá → test fail; 9 mẫu nội dung thật (tiêu đề, link, danh sách, màu/căn lề, ảnh, iframe video, `video/audio` file, tiếng Việt) cho **Delta giống hệt** trước/sau.
**Không giải quyết được:** Ctrl+V gốc của trình duyệt (trình duyệt tự chèn vào container trước khi Quill đọc; trình duyệt hiện đại tự lọc script/`on*` khi dán). Hiện Twelve không có màn hình sửa bài và nội dung nạp lại đã được backend sanitize nên rủi ro thực tế thấp (self-XSS). Kế hoạch trung hạn vẫn là chuyển sang Quill 2.

## G3 — vì sao không đổi dependency
Đã thử trong bản sao riêng: nâng `firebase` 10→12 và `react-router-dom` 6→7 thì test (46/46) và build vẫn qua, nhưng bundle tăng 17% (1.711 KB), **`npm audit` vẫn còn 6 cảnh báo** (`@grpc/grpc-js` vẫn bị `@firebase/firestore` giữ phiên bản cũ), và mình không thể thử runtime (đăng nhập, Firestore realtime) mà không có Firebase/trình duyệt thật. Bằng chứng mức ảnh hưởng: tìm trong bundle production các mã bị cảnh báo (`undici`, `@grpc/grpc-js`, `ServerCredentials`, `node:http`) → **0 kết quả** (chúng chỉ chạy ở Node). `react-router` open-redirect: Twelve không truyền dữ liệu người dùng vào `navigate()`/`<Link to>` (theo báo cáo). Đề xuất: nâng `firebase`+`react-router-dom` cùng lúc với `firebase-admin` ở Phiên 3, kèm hồi quy thủ công trên trình duyệt.

## G4 — tách mã
`React.lazy` cho Trending, PostDetail, PublicProfile, Settings (+các panel quản trị), modal soạn bài (**Quill 252 KB**, chỉ tải khi mở lần đầu, cả ở Trang chủ lẫn Blog), `WelcomeSetupDialog` (kéo theo react-easy-crop). Đồ thị chunk đã kiểm: mọi chunk lười chỉ phụ thuộc `index` (hình sao, **không có vòng lặp**). `main.jsx` thêm phục hồi `vite:preloadError`: tải chunk thất bại (vd. vừa deploy bản mới) ⇒ tải lại trang đúng 1 lần (có cờ chống vòng lặp). Mình **cố ý không dùng `manualChunks`** cho vendor: dễ sinh lỗi thứ tự khởi tạo giữa các chunk mà mình không có trình duyệt để kiểm chứng.
| | Trước | Sau |
|---|---|---|
| JS chính (gzip) | 1.459 KB (410 KB) | 1.018 KB (290 KB) |

## G5 — giới hạn nội dung
`utils/contentLimits.js` (khớp `CONTENT_LIMITS` của backend, có test đọc thẳng file backend để không lệch): bộ đếm ký tự, cảnh báo từ 80%, chặn nút **Đăng bài** + thông báo khi vượt (ký tự/phần tử/media). Đã xác nhận lỗi 422 của backend hiện **nguyên văn tiếng Việt** (test CreatePostModal).

## Kiểm thử
Frontend **82/82** (36 ca mới: middleware, CSP-report, giới hạn nội dung, Quill an toàn, tải lười, phục hồi chunk) · Backend **57/57** (+2) · `vite build` OK · chạy `server.js` thật: POST `/api/csp-report` → 204, SA đọc được thống kê, người thường 403, 65 báo cáo liên tiếp vẫn 204. Đột biến: hoàn nguyên G1/G2/G5 thì test tương ứng FAIL.
**Chưa kiểm:** trình duyệt thật (tải lười, Quill, CSP), Vercel proxy POST qua middleware, trình duyệt có thật sự gửi báo cáo. Sau deploy:
```bash
curl -i -X POST https://<frontend>/csp-report -H 'content-type: application/csp-report' \
  -d '{"csp-report":{"document-uri":"https://x/","effective-directive":"img-src","blocked-uri":"https://t.example/a.png"}}'   # phải 204
# rồi mở Cài đặt > Quản trị > Báo cáo vi phạm CSP => thấy 1 dòng (img-src / https://t.example)
```
Kiểm thủ công nên làm: mở Trending/Cài đặt/bài viết/hồ sơ, soạn bài ở Trang chủ và Blog (SA), dán nội dung có định dạng vào editor, thử trên iPhone Safari.
