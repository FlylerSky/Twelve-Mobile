# PATCH 15 — v2.3.0.171026: mục **Gỡ lỗi** (hồi quy các lỗi bảo mật đã từng gặp)

Nền: v2.2.2. Có hai phần: (1) **tính năng mới** — Cài đặt → Quản trị → **Gỡ lỗi**; (2) **hai bản vá nhỏ** còn sót từ báo cáo kiểm tra lại 2.2.2 (R-03, R-01) để các module hồi quy đều xanh ngay từ đầu.

## 1. Mục "Gỡ lỗi" là gì
Mỗi lỗi bảo mật đã từng gặp là **một module độc lập**: tên lỗi, phiên bản ghi nhận, phiên bản đã vá, mô tả, nút **Chạy thử**, kết quả hiển thị **trực quan** (✔/✖/⚠ + thanh số đo) hoặc **văn bản** có nút **Sao chép**. "Chạy tất cả" chạy tuần tự mọi module và cho bộ đếm Đạt/Không đạt/Cảnh báo; "Sao chép báo cáo tổng" xuất bảng markdown. Sau mỗi lần nâng phiên bản, quản trị viên mở mục này để biết lỗi cũ có **tái xuất** không.

**Thêm lỗi mới = thêm một tệp** `backend/src/debug/modules/<id>.js` (panel và API tự nhận, không sửa chỗ nào khác). Quy ước **chỉ thêm, không xoá** được giữ bằng test (`REQUIRED_IDS`). Hướng dẫn + mẫu: `backend/src/debug/README.md`.

### 9 module đầu tiên
| id | Lỗi | Mức | Ghi nhận → vá | Chế độ |
|---|---|---|---|---|
| `a01-uid-crash` | Sập tiến trình bằng id lạ (`/api/users/a%2Fb`) | Cao | 2.2.0 → 2.2.1 | cô lập: **server.js thật** trong tiến trình con, 18 tình huống id lạ trên nhiều route |
| `a02-delete-race` | Dữ liệu dựng lại sau khi xoá tài khoản (tên thật, bài mồ côi, hồ sơ ma) | Trung bình | 2.2.0 → 2.2.1 | cô lập |
| `a03-forgot-timing` | Quên mật khẩu lộ email nào có tài khoản (thời gian/mã lỗi) | Thấp | 2.2.0 → 2.2.1 | cô lập (đo median 10 cặp xen kẽ) |
| `a04-reserved-tags` | Mạo danh tag admin/twelve/support… | Thấp | 2.2.0 → **2.3.0** | hàm thuần (26 tên phải chặn + 34 tag thường phải dùng được) |
| `a05-csp-monitor` | Đầu độc bảng báo cáo CSP | Thấp | 2.2.0 → 2.2.2 | cô lập (bảng CSP là trạng thái toàn cục trong RAM) |
| `a06-style-hidden-text` | Chữ vô hình / phá bố cục qua `style` | Thấp | 2.2.0 → **2.3.0** | hàm thuần (31 payload phải loại + 15 định dạng phải giữ + 5 vector XSS) |
| `cfg-runtime` | Cấu hình chạy thật (NODE_ENV, secret, lưới an toàn của A-01, F3) | Trung bình | — | đọc cấu hình; **chỉ báo có/không**, không in giá trị bí mật |
| `rules-private-collections` | `firestore.rules` đã deploy chặn đọc `userPrivate`, `accountDeletions`, `assets`, `debugRuns`, `users` | Cao | — | gọi REST Firestore (GET, không token); có **đối chứng** để không báo "đạt" giả |
| `manual-external` | Việc phải kiểm tay (Firebase Console, Render, Vercel, lockfile…) | Thông tin | — | liệt kê bước, trạng thái "Cần kiểm tay" |

### Kiến trúc và rào an toàn (do **bộ chạy** ép, module không phải tự lo)
- **API:** `GET /api/admin/debug/modules` (danh sách + lần chạy gần nhất); `POST /api/admin/debug/modules/:id/run`. Nằm dưới `admin.routes` (`requireAuth → requireActive → requireSA`); route chạy còn đòi **nhập lại mật khẩu gần đây** (`requireRecentAuth`) + `debugRunLimiter` (60 lượt/15 phút/tài khoản). Client chỉ gửi `id` — **không có đường nào đưa mã/lệnh/tham số vào module**; id lạ (`a%2Fb`, `..`, quá dài…) → 404.
- **Một module chạy một lúc** (409 `DEBUG_BUSY`); **timeout cứng** 30 s (tối đa 60 s) và kill mọi tiến trình con.
- **Cô lập:** mã có thể làm sập tiến trình hoặc đổi trạng thái toàn cục chạy ở **tiến trình con** với Firestore/Auth **giả** (`src/debug/support/fakeFirebase.js`, chuyển từ `test/helpers/` — tệp cũ giờ chỉ re-export). Tiến trình con **không thừa kế biến môi trường** của server (không có khoá Firebase/Cloudinary/secret) và chỉ chạy được tệp trong `src/debug/children/`.
- **Che bí mật:** giá trị biến môi trường kiểu SECRET/TOKEN/PASSWORD/KEY/PRIVATE/SERVICE_ACCOUNT, khoá PEM và JWT bị thay bằng `[đã ẩn]` ở mọi chuỗi trong kết quả. Giới hạn dung lượng: 300 dòng log, 500 ký tự/dòng, 60.000 ký tự, 200 kiểm tra, 100 số đo (vượt thì cắt và đánh dấu).
- **Lưu trữ:** chỉ **bản tóm tắt** lần chạy gần nhất (trạng thái, phiên bản, thời gian, ai chạy) vào collection `debugRuns`, **không lưu log**. Collection này bị catch-all deny của `firestore.rules` chặn hoàn toàn (**cố ý không dùng `config`** vì `config` đọc công khai) — **không cần sửa/deploy rules**.
- **Công tắc:** `DEBUG_PANEL_ENABLED=off` tắt việc *chạy* (danh sách vẫn xem được, API trả 403 `DEBUG_DISABLED`). Mặc định bật.

## 2. Hai bản vá nhỏ kèm theo (để module `a04`/`a06` xanh)
- **R-03 — `support_team`, `admin_news` lọt:** gập chữ lặp trên cả chuỗi làm mất một chữ ở chỗ nối hai từ. Giờ `isReservedTagName` so khớp **hai lượt** (có và không gập chữ lặp), khớp một trong hai là chặn. Đã kiểm 34 tag bình thường: **không chặn nhầm**.
- **R-01 — ngưỡng alpha và màu hệ thống:** ngưỡng alpha của **chữ** nâng 0.1 → **0.5**; từ khoá màu theo **danh sách trắng 148 tên màu CSS** + `currentcolor/inherit/initial/unset` (trước đây mọi từ chỉ gồm chữ cái được nhận, kể cả `canvas`, `field`, `window`, `buttonface` luôn trùng nền trình duyệt). `background-color` không đổi. ⚠️ **Đổi hành vi:** chữ có màu mờ hơn 50% hoặc dùng từ khoá lạ sẽ bị bỏ thuộc tính `color` khi lưu bài **mới**. Muốn áp cho bài cũ: `node src/seed/resanitizeContent.js` (**sao lưu trước, không có dry-run**).
- Test cũ `security-222.test.js` mã hoá ngưỡng 0.1 nên đã cập nhật theo ngưỡng mới (các dòng có chú thích `v2.3.0`).

## 3. Kiểm chứng
- **Backend 145/145** (126 cũ + 19 mới ở `test/debug-230.test.js`): sổ đăng ký, trạng thái pass/fail/warn/error/skip/manual, timeout + dọn dẹp, khoá một-lúc, che bí mật, giới hạn dung lượng, danh sách host cho phép, cách ly môi trường tiến trình con, module thật (a01…a06 **phải đạt**), a05 không đụng bảng CSP thật, rules (4 tình huống), API (401/403/REAUTH/404/409/tắt), R-01, R-03.
- **Frontend 171/171** (153 cũ + 18 mới ở `tests/debugPanel.test.jsx`) và `vite build` qua; panel là chunk tải lười (chỉ tải khi mở mục Gỡ lỗi). Hai test cây Cài đặt đã cập nhật cho mục thứ 5.
- **Kiểm chứng "module có thật sự bắt được lỗi không" (đột biến):** tái tạo từng lỗi cũ trên bản sao rồi chạy module — mọi module đều chuyển **đỏ**:

| Tái tạo lỗi | Module | Kết quả |
|---|---|---|
| Bỏ **toàn bộ** lớp chống A-01 (route param, kiểm id, try/catch, chuyển lỗi async) | `a01-uid-crash` | không đạt (request treo/500) |
| `writeRealName` bỏ kiểm tra trạng thái | `a02-delete-race` | không đạt (HTTP 500 thay vì 403) |
| `createPost` bỏ kiểm tra tác giả còn hoạt động | `a02-delete-race` | không đạt (201 + bài mồ côi) |
| Trả lời quên mật khẩu **sau** khi gửi thư | `a03-forgot-timing` | không đạt (chênh 300,7 ms) |
| `isReservedTagName` luôn `false` / bỏ lượt so khớp thứ hai | `a04-reserved-tags` | không đạt (liệt kê tên lọt) |
| Ngưỡng alpha 0.1 | `a06-style-hidden-text` | không đạt (liệt kê payload lọt) |
| Mỗi nguồn CSP được 10.000 khoá | `a05-csp-monitor` | không đạt |

  Lưu ý khi tự kiểm: A-01 có **nhiều lớp phòng thủ chồng nhau**, nên gỡ riêng một lớp (ví dụ chỉ `router.param`) **đúng** là vẫn "đạt" — module chỉ đỏ khi lỗi thật sự tái xuất.

## 4. Tài nguyên
Mỗi lần chỉ một tiến trình con. Đỉnh bộ nhớ đo được (VmHWM): `race-probe` 134 MB, `server.js` con (a01) 125 MB, `forgot-timing-probe` 94 MB, `csp-probe` 53 MB — **cộng thêm** vào bộ nhớ của server đang chạy. Trên instance Render miễn phí 512 MB, nên chạy lúc ít người dùng; nếu lo thì đặt `DEBUG_PANEL_ENABLED=off` và chỉ bật khi cần kiểm.

## 5. Triển khai
1. Backend → frontend như thường lệ. **Không** có thay đổi `firestore.rules` hay index.
2. (Tuỳ chọn) `DEBUG_PANEL_ENABLED` — mặc định bật.
3. Đặt `BACKEND_VERSION=2.3.0.171026` và chạy `npm run seed:version` để nhãn phiên bản trên giao diện khớp.
4. Mở **Cài đặt → Quản trị → Gỡ lỗi → Chạy tất cả** và đọc kết quả. Trên máy chủ thật dự kiến: `a01…a06` **Đạt**; `cfg-runtime` có thể **Cảnh báo** (F3 còn tắt, thiếu biến khuyến nghị) — đó là thông tin, không phải lỗi; `rules-private-collections` **Đạt** hoặc **Bỏ qua** (nếu máy chủ không gọi được Firestore REST hoặc không xác định được project id); `manual-external` **Cần kiểm tay**.
5. (Sau khi áp bộ lọc style mới cho bài cũ nếu muốn) `node src/seed/resanitizeContent.js` — sao lưu trước.

## 6. Giới hạn đã biết
- Module `a03` đo thời gian nên **nhạy tải CPU**: nếu chỉ đỏ ở mục thời gian, chạy lại lúc máy rảnh.
- Module `a01`/`a02` chạy trên **Firestore giả** (mô phỏng cả lỗi của SDK với id chứa `/`): chúng kiểm *logic ứng dụng*, không kiểm Firestore thật.
- `rules-private-collections` chỉ chứng minh được khi phép thử đối chứng phân biệt được "cho đọc" và "chặn"; nếu không, nó **báo Bỏ qua** thay vì "đạt" giả.
- Panel không thể kiểm những thứ ngoài máy chủ (Email enumeration protection của Firebase, IPv6 phía Render, hành vi `auth_time`) — xem `manual-external`.
- Kết quả đầy đủ (log) chỉ nằm trong phiên làm việc của trình duyệt; sau khi tải lại trang chỉ còn bản tóm tắt lần chạy gần nhất.

## 7. Tệp thay đổi
Mới: `backend/src/debug/{registry,runner,child}.js`, `debug/modules/*` (9), `debug/children/*` (4), `debug/support/{fakeFirebase,childResult}.js`, `debug/README.md`, `controllers/debug.controller.js`, `test/debug-230.test.js`, `frontend/src/pages/settings/{AdminDebugPanel.jsx,debugReport.js}`, `frontend/tests/debugPanel.test.jsx`, `PATCH-15-NOTES.md`.
Sửa: `routes/admin.routes.js`, `middleware/rateLimiters.js`, `utils/constants.js` (`COLLECTIONS.DEBUG_RUNS`), `utils/helpers.js` (R-03), `services/sanitize.service.js` (R-01), `test/helpers/fakeFirebase.js` (re-export), `test/security-222.test.js`, `package.json` (script test + version), `.env.example`, `frontend/src/api/admin.api.js`, `pages/settings/registry.jsx`, `frontend/tests/{settingsTree.test.js,settingsPage.test.jsx}`, `frontend/package.json` + `public/version.json` (version), `SECURITY-STATUS.md`.
