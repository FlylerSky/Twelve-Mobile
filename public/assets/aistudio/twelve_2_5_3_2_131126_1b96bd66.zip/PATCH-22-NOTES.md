# PATCH 22 — v2.5.1.1.241026: Đưa thẻ xác thực Google Search Console vào source

Backend + frontend, thay đổi nhỏ. Test: backend **206/206** (205 → +1), frontend **317/317** (315 → +2), `vite build` sạch. Không đổi biến môi trường, `middleware.js`, `vercel.json`, API.

## 1. Vì sao
Thẻ `<meta name="google-site-verification" …>` trước đây phải gắn tay sau mỗi lần deploy; mất thẻ là Google có thể thu hồi quyền sở hữu thuộc tính trong Search Console. Nay thẻ nằm sẵn trong source.

## 2. Đặt ở đâu (và vì sao ở HAI nơi)
| Nơi | Ai nhận bản này ở `/` |
|---|---|
| `frontend/index.html` (`<head>`, ngay dưới `<meta name="description">`) | Trình xác minh `Google-Site-Verification/1.0` — `middleware.js` **không** coi UA này là bot nên trả SPA |
| `backend/src/views/partials/top.ejs` (`<head>` chung của mọi trang SSR) | Googlebot / Google-InspectionTool — `middleware.js` định tuyến sang SSR |

Chỉ đặt một nơi thì lần kiểm tra lại định kỳ bằng UA còn lại có thể không thấy thẻ. Thẻ ở **mọi** trang SSR (không chỉ trang chủ) cho đơn giản — Google chỉ đòi trang chủ, thẻ thừa ở trang khác vô hại.

## 3. Test chốt chặn
- Backend (`seo-250.test.js`): 6 loại trang SSR (trang chủ, blog, bài viết, blog chi tiết, hồ sơ, hashtag) đều có **đúng 1** thẻ, nằm trước `</head>`; nếu có `../../frontend/index.html` thì cũng đúng 1 thẻ **cùng mã**.
- Frontend (`seo250.test.jsx`): `index.html` có đúng 1 thẻ trong `<head>`; `top.ejs` chứa thẻ cùng mã.
Muốn đổi mã (đổi thuộc tính Search Console) phải sửa cả hai file — test sẽ báo đỏ nếu lệch.

## 4. Điều bạn nên biết
1. Sau khi deploy, kiểm tra cả hai đường:
   `curl -s -A "Mozilla/5.0 (compatible; Google-Site-Verification/1.0)" https://<tên-miền>/ | grep google-site-verification`
   `curl -s -A "Googlebot/2.1" https://<tên-miền>/ | grep google-site-verification`
   rồi bấm **Xác minh** trong Search Console. Bản SSR có thể được CDN giữ tối đa 5 phút (`s-maxage=300`) nên lệnh thứ hai có thể cần chờ.
2. **Đừng xoá thẻ** sau khi xác minh xong — Google kiểm tra lại định kỳ.
3. Xác minh bằng bản ghi **DNS TXT** (thuộc tính "Tên miền") không phụ thuộc mã nguồn; có thể dùng song song để dự phòng.

## 5. File
`frontend/index.html`, `backend/src/views/partials/top.ejs`, `backend/test/seo-250.test.js`, `frontend/tests/seo250.test.jsx`; phiên bản `2.5.1.1.241026`: `package.json` ×2, `package-lock.json` ×2, `frontend/public/version.json`; tài liệu: `backend/README.md` (mục -30), `SECURITY-STATUS.md` (dòng đầu).
