# PATCH 18 — v2.4.2.211026: nút Back duy nhất ở headZone, hết quay vòng

Chỉ frontend (backend không đổi ngoài số phiên bản). Test: frontend **260/260** (240 → +20 mới, 3 test Cài đặt cũ chuyển sang dùng Back ở headZone), backend 181/181, `vite build` sạch.

## 1. Nguyên nhân quay vòng
Hai loại "quay lại" khác bản chất nhưng cùng tồn tại:
- **Back ở headZone** (`Navbar`): `navigate(-1)` — **lùi** theo lịch sử;
- **Nút ← trong trang** (thanh đường dẫn Cài đặt; chi tiết hashtag ở Xu hướng): liên kết `to=<mục cha>` — **tiến thêm một mục** vào lịch sử.

Kịch bản bạn tả: Cài đặt › Ứng dụng › Chế độ giao diện (lịch sử: …, Ứng dụng, theme) → ← trong trang (đẩy thêm *Ứng dụng*: …, theme, **Ứng dụng**) → Back ở headZone (lùi một mục) → rơi lại vào *Chế độ giao diện*. Đã dựng lại đúng kịch bản này thành test, và thử đưa hành vi cũ trở lại để chắc test báo đỏ.

Cùng một họ lỗi còn ở **Trang bài viết**: bài không tồn tại → `navigate(backPath)` (đẩy mục mới) → Back ở headZone quay lại đúng URL lỗi → lại bị đẩy đi: bẫy. Và bấm lại tab Cài đặt đang mở khi ở sâu (đẩy mục mới ⇒ Back quay lại chỗ sâu vừa rời).

## 2. Cách sửa
**Nút Back ở headZone là nút quay lại DUY NHẤT của ứng dụng; trang khai báo "lên đâu" thay vì tự vẽ nút.**
- `useRegisterPageHeader` nhận thêm **`backTo`** (đường dẫn trang cha) và **`onBack`** (trang tự xử lý trạng thái nội bộ; trả `true` = đã xử lý). Thứ tự khi bấm ←: `onBack` → `backTo` → lùi lịch sử (vào thẳng, không còn gì lùi → Trang chủ).
- **Mọi động tác "lên cấp" đi qua `useGoUp()` và không bao giờ đẩy mục lịch sử mới** (`hooks/useBack.js`, `utils/navStack.js`): nếu trang cha đã nằm trong lịch sử phía sau — và mọi mục giữa chúng là con cháu của nó — thì **lùi thẳng** tới đó (lịch sử rút gọn, không còn gì để "chui lại"); nếu không (vào thẳng URL sâu, hoặc giữa chừng có trang lạ) thì **thay thế** mục hiện tại. Trình duyệt không cho đọc nội dung lịch sử nên `NavStackTracker` (đặt một lần trong `App.jsx`) ghi lại từng mục khi điều hướng; tải lại trang thì bản ghi trống và luôn rơi về "thay thế" (vẫn đúng).

## 3. Đã đổi gì ở từng nơi
| Nơi | Trước | Nay |
|---|---|---|
| **Cài đặt** — thanh đường dẫn | nút ← (liên kết đẩy mục mới) + đường dẫn | **chỉ còn đường dẫn** (bỏ ←, đỡ một hàng nút chiếm chỗ); trang khai báo `backTo` = mục cha, gốc tab = không có |
| Cài đặt — bấm cấp cha trên đường dẫn | liên kết đẩy mục mới | `goUp` (bấm giữa/Ctrl/⌘ vẫn mở tab mới như liên kết thật) |
| Cài đặt — bấm lại tab đang mở khi ở sâu | đẩy mục mới (Back quay lại chỗ sâu) | `goUp` về gốc tab |
| **Xu hướng** — chi tiết hashtag | nút ← riêng trong nội dung | **bỏ**; `onBack` đóng chi tiết hashtag **khi mở từ danh sách** trong trang; mở từ Chip hashtag ở thẻ bài/URL ngoài thì Back lùi về đúng nơi đã bấm |
| **Trang bài viết** — không tìm thấy / sau khi xoá | `navigate(backPath)` | `goUp(backPath)` |
| Navbar (headZone) | `navigate(-1)` hoặc `/` | `useHeaderBack` (thứ tự ở mục 2) |

Quy ước được bảo vệ bằng test quét mã nguồn: `ArrowBackIcon` chỉ được dùng trong `Navbar`; không nhãn "Quay lại" nào ngoài headZone; không `navigate(-1)` / `navigate(backPath)` trong trang.

## 4. Điều bạn nên biết
- **Hành vi đã đổi có chủ ý:** trước đây bấm lại tab Cài đặt đang mở là một bước *có thể hoàn tác* bằng Back (comment cũ ghi rõ). Nay nó là "đi lên", Back sẽ không đưa bạn trở lại chỗ sâu vừa rời — đúng với yêu cầu hết quay vòng, nhưng là một thay đổi so với thiết kế v2.1.0.
- Lùi xuyên nhiều cấp chỉ khi các mục ở giữa là **con cháu** của trang đích; nếu bạn đã đi sang trang khác giữa chừng (vd. Cài đặt › bài viết › Cài đặt sâu hơn), Back **không** nhảy xuyên qua bài viết đó mà thay thế mục hiện tại.
- Không đụng các nút "Về Cài đặt" (trạng thái lỗi của Cài đặt) và "Về trang chủ" (trang 404): đó là nút *đi tới*, không phải nút quay lại, và không tạo vòng.
- Chưa kiểm trên trình duyệt thật: test dùng `MemoryRouter`. Nên thử tay trên điện thoại: vào Cài đặt › Ứng dụng › Chế độ giao diện, bấm Back ở headZone hai lần (phải ra Ứng dụng rồi ra nơi trước đó); thử thêm bấm cấp cha trên đường dẫn rồi Back; và Xu hướng › Hashtag › chọn một hashtag › Back.

## 5. File chính
Mới: `utils/navStack.js`, `components/NavStackTracker.jsx`, `hooks/useBack.js`; test `backNav.test.jsx` (+20). Đổi: `PageHeaderContext.jsx` (`backTo`/`onBack`), `Navbar.jsx`, `App.jsx`, `SettingsPage.jsx`, `settings/SettingsNav.jsx`, `TrendingPage.jsx`, `PostDetailPage.jsx`; test `settingsPage.test.jsx` (dùng Back ở headZone). Tài liệu: `headZone.md` (mục "Nút ← (Back)", quy ước 8, bảng ví dụ, lịch sử) — bản cập nhật ở thư mục kết quả.
