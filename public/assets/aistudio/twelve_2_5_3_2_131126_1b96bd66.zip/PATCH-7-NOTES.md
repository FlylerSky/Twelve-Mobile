# v2.0.10 — Vá theo Báo cáo bảo mật Phiên 1 (Backend)

Xây trên v2.0.9. Nhãn phiên bản `2.0.10.071026` là tạm (đổi theo quy ước của bạn). Chỉ đổi backend (+ `version.json`).

## Kết quả đối chiếu từng mục
Mình KHÔNG tin báo cáo mà tái hiện từng mục trên mã thật trước khi vá.

| Mục | Mức | Tái hiện được? | Trạng thái |
|---|---|---|---|
| F1 DoS sanitize | Cao | Có (2.000 thẻ `<b>` ≈ 1,4 s; 4.000 ≈ 4,9 s). **Rộng hơn báo cáo:** `<table>` 2.000 hàng ≈ 3,6 s, `<div>` lồng 2.000 tầng ≈ 1,1 s, 5.000 `<img>` ≈ 3,4 s | **Đã vá** |
| F2 multipart avatar | Trung bình | Có (62 MB toàn field text → HTTP 200, đỉnh RSS +110 MB) | **Đã vá** (sau vá: 400, +38 MB) |
| F3 điểm xem lặp | Trung bình | (không tái hiện — cần quyết định sản phẩm) | **Chưa vá — cần bạn quyết định, xem dưới** |
| F4 pending nhận điểm share | Trung bình | Có. **Rộng hơn báo cáo:** cùng lỗ hổng ở điểm xem (viewer pending/suspended cũng được +1 và cộng điểm cho tác giả) | **Đã vá** ở gốc |
| F5 phụ thuộc | Thấp | Có (`npm audit`) | **Một phần** (xem dưới) |
| F6 token thu hồi | Thấp | Có (đọc mã) | **Đã vá** (có cache) |
| F7 Unicode trong tên | Thấp | Có | **Đã vá** |
| F8 sai kiểu → 500 | Thấp | Có (`limit=-5`, cursor mảng, `content` số…) | **Đã vá** + fuzz 2.324 request: 0 lỗi 5xx |
| F9 birthday | Thấp | Có | **Đã vá** |
| F10 rescan | Thấp | Có | **Đã vá** (đi kèm F1) |
| F11 (mới, phát sinh khi điều tra F5) | Trung bình | Có: `file-type@19.6.0` lặp vô hạn với file ASF dị dạng, chạy trên buffer người dùng tải lên ở `/users/me/avatar` → treo cả tiến trình | **Đã vá** |

## Chi tiết sửa
**F1/F10** — `services/contentPipeline.js` + `services/sanitize.worker.js`
- Lớp 1 `assessHtml` (quét O(n), không dùng DOM): tối đa 250.000 ký tự, 5.000 phần tử, độ sâu 100, 300 thẻ không hỗ trợ, 200 media. Các ngưỡng này được chọn từ số đo; bài viết thật 118 KB (≈3.600 phần tử) vẫn qua, trường hợp xấu nhất NẰM TRONG ngưỡng ≈ 1,4 giây.
- Lớp 2: sanitize chạy ở `worker_threads` với **timeout cứng 3 giây** (quá hạn → `terminate()` worker, trả 422, tự dựng lại). Luồng chính không bao giờ bị chặn — lớp 1 chỉ là heuristic (có thể bị lách bằng thuộc tính chứa `>`), lớp 2 là chốt chặn. Test đo: trong lúc worker bận, event loop chính vẫn chạy.
- `createPost/updatePost/createBlog/updateBlog` và rescan embed đều dùng đường này (excerpt cũng tính trong worker). Lỗi trả `422 {error, code}` (hoặc 400 nếu sai kiểu, 503 nếu hàng đợi đầy).
- Rescan: mỗi tài liệu nằm trong try/catch; tài liệu cũ vượt giới hạn chỉ được tính `failed`, không huỷ cả đợt.
- Chi phí: thêm 1 worker (~50–60 MB RAM). Kiểm tra gói Render của bạn còn đủ bộ nhớ. `SANITIZE_WORKER=off` để chạy tại luồng chính nếu cần.

**F2** — multer: `fields:5, fieldSize:1KB, parts:10, headerPairs:50`. Frontend chỉ gửi đúng 1 trường `avatar` nên không ảnh hưởng.

**F4** — `optionalAuth` chỉ gán `req.authUid` khi tài khoản **active**; pending/suspended bị coi như khách (không điểm, không khoá dedup riêng theo uid). Test: 5 tài khoản pending cùng IP chỉ tạo 1 lượt share.

**F6** — tự kiểm `tokensValidAfterTime` và `disabled`, cache 60 giây theo uid ⇒ tối đa 1 lượt gọi Firebase Auth/người dùng/phút; cửa sổ token cũ còn dùng được giảm từ ~1 giờ xuống ≤ 60 giây. Lỗi tra cứu → bỏ qua kiểm thu hồi (có log); `status` vẫn đọc tươi từ Firestore mỗi request.

**F7** — tên hiển thị/họ tên: NFC, bỏ `\p{Cc}\p{Cf}\p{Zl}\p{Zp}\p{Co}` + ký tự "trống" giả (Braille blank, Hangul filler…). Tiêu đề và bình luận: bỏ bidi/rộng-0 nhưng **giữ ZWJ** cho emoji ghép. *Đánh đổi:* tên hiển thị mất ZWJ nên emoji ghép tách thành emoji đơn.
**F8** — `isString()` trước sanitize ở mọi trường hồ sơ/đăng ký; `parseLimit/parseCursor`; `content` bình luận phải là chuỗi.
**F9** — `YYYY-MM-DD` nghiêm ngặt, đúng lịch, từ 1900-01-01 đến hôm nay (UTC).
**F11** — `sniffImageMime` (chữ ký JPEG/PNG/WebP) chạy TRƯỚC; `file-type` chỉ nhận 4 KB đầu của buffer đã qua chữ ký; nâng `file-type` lên `^21.3.4` (đã kiểm: PoC kết thúc 8 ms; nâng cùng dòng API nên không phải sửa mã gọi). `engines.node` → `>=20`.

## F5 — vì sao chỉ làm một phần
`npm audit` còn `node-forge` và `uuid` qua `firebase-admin@12`; bản sửa là **firebase-admin 14 (nâng 2 major)**. Mình không nâng mù vì bộ test dùng Firebase giả, không phát hiện được thay đổi API. Đánh giá khả năng bị khai thác thực tế (mình đọc mã phụ thuộc):
- `node-forge`: lỗ hổng ở xác minh chữ ký RSA PKCS#1 v1.5; `firebase-admin` chỉ gọi `forge.pki.privateKeyFromPem` để kiểm tra khoá service account lúc khởi động ⇒ không chạm tới đường lỗi.
- `uuid`: lỗi kiểm biên buffer ở v3/v5/v6 khi truyền `buf`; phụ thuộc dùng `v4()` ⇒ không chạm tới.
Đề xuất: nâng `firebase-admin` ở phiên riêng, chạy thử với Firebase thật/emulator (đăng nhập, `verifyIdToken`, Firestore, Auth Admin).

## F3 — cần bạn quyết định (không tự vá)
Lỗ hổng là logic sản phẩm: mỗi (người xem, bài) cứ 31 phút lại được cộng điểm. Phương án mình đề xuất, **ít xáo trộn nhất**: giữ nguyên `viewCount` (hiển thị) nhưng **điểm** (`externalPostScore` của tác giả + `positiveScore` của người xem) chỉ cộng **một lần cho mỗi cặp (người xem, bài)**, giống cách bạn đã làm cho bình luận (v2.0.5) và reaction. Phương án khác: trần điểm xem theo ngày/tài khoản. Bạn chọn hướng nào?

## Kiểm thử
Backend **55/55** (13 ca mới trong `test/security-session1.test.js`). Mỗi bản vá đều được kiểm bằng "đột biến": hoàn nguyên bản vá thì test tương ứng FAIL (đã thử F1, F2, F4, F6, F8, F9). Thêm fuzz 2.324 request sai kiểu trên `server.js` thật (middleware auth/SA/CORS/helmet, Firestore giả): trước vá có lỗi 5xx, sau vá 0.
**Chưa kiểm:** Firebase/Cloudinary/Render thật. Hai điểm cần xem sau deploy: (1) log Render có dòng `sanitize worker lỗi` hay không và bộ nhớ sau khi nạp worker; (2) `auth.getUser` trả `tokensValidAfterTime` đúng như tài liệu.

## Việc frontend nên làm (Phiên 2/3)
Backend giờ từ chối nội dung >250.000 ký tự / quá phức tạp bằng 422 kèm thông báo tiếng Việt; trình soạn thảo nên có bộ đếm/giới hạn phía client để người dùng biết trước. F7: tên "tick xanh" bằng ký tự ✔/✅ chưa bị chặn (phụ thuộc bạn có huy hiệu xác minh hay không).
