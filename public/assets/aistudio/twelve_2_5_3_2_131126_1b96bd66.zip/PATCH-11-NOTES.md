# Bản 11 — v2.1.0.081026 (xây trên v2.0.13.100726): Cài đặt theo "hệ thống thư mục"

Nhãn `2.1.0.081026` là tạm — đổi tuỳ ý ở `frontend/package.json`, `frontend/public/version.json`, `backend/package.json`.

## Vấn đề
Trang Cài đặt xếp mọi tuỳ chọn của một tab thành MỘT cột dài: tab Ứng dụng không có đường phân chia, tab Quản trị có `<Divider>` —
không đồng nhất, và kể cả có đường phân chia vẫn không biết "tới đây hết mục này chưa" (mục "Font chữ" còn có 3 nhóm lồng bên trong).

## Cách làm (đúng ý tưởng "thư mục", có điều chỉnh — xem mục "Đánh giá")
- **Gốc tab / thư mục** chỉ hiện danh sách TÊN mục + mũi tên. Bấm vào để mở.
- **Mục lá** (một tuỳ chọn duy nhất, vd. "Chế độ giao diện") mở ra là thấy luôn nội dung.
- **Thư mục** (nhiều tuỳ chọn, vd. "Font chữ") mở ra thành danh sách mục con ("Font chữ có sẵn trong ứng dụng", "Font chữ do quản trị
  viên cài đặt", "Font chữ tuỳ chỉnh"); bấm một mục con mới thấy nội dung.
- Mỗi màn hình = đúng MỘT mục → luôn rõ bắt đầu/kết thúc ở đâu. Mọi cấp sâu hơn gốc tab có thanh **quay lại + đường dẫn**
  (`Font chữ › Font chữ tuỳ chỉnh`; các cấp cha bấm được).
- **URL phản ánh vị trí**: `/settings/app/font/custom`. Nút Back của trình duyệt/điện thoại đi lên đúng một cấp; chia sẻ link được.
  `/settings`, `/settings/app`, `/settings/admin` vẫn dùng như cũ. Bấm lại tab đang mở khi đang ở sâu → về gốc tab.
- Tab Quản trị: 4 mục lá (Domain nhúng media · Font chữ trên server · Báo cáo vi phạm CSP · Tài nguyên người dùng upload).

## Tự động / tái sử dụng — thêm tuỳ chọn mới chỉ cần MỘT khai báo
Toàn bộ trang là một cây khai báo ở `frontend/src/pages/settings/registry.jsx`; `SettingsPage` không còn biết có tuỳ chọn nào.
```jsx
{ key: "language", title: "Ngôn ngữ", icon: <LanguageIcon />, component: lazy(() => import("./LanguagePanel")) }   // lá
{ key: "notify", title: "Thông báo", icon: <…/>, children: [ …lá hoặc thư mục con… ] }                           // thư mục
{ …, requires: "sa" }                                                                                              // chỉ SA (đặt ở tab/thư mục = cả nhánh)
{ …, component: SharedPanel, props: { source: "x" } }                                                              // dùng lại một component
```
Quy tắc tự động (`settingsTree.js`): có `children` ⇒ thư mục, có `component` ⇒ lá · không đủ quyền ⇒ ẩn khỏi danh sách VÀ không vào được bằng URL ·
thư mục không còn mục con hiển thị được ⇒ tự biến mất · thư mục chỉ còn MỘT mục con hiển thị được ⇒ mở ra là thấy luôn nội dung ·
quyền lạ/gõ sai ⇒ ẩn (từ chối mặc định). `tests/settingsTree.test.js` kiểm chính registry thật (key trùng, thiếu component, quyền lạ…).
Tiêu đề do khung vẽ từ `title`; panel **không** tự vẽ tiêu đề.

## Thay đổi mã
| File | Thay đổi |
|---|---|
| `pages/settings/registry.jsx` (mới) | Cây khai báo duy nhất |
| `pages/settings/settingsTree.js` (mới) | Logic thuần: quyền, giải nghĩa URL, gộp thư mục một con, `validateTree` |
| `pages/settings/SettingsNav.jsx` (mới) | `SettingsRows` (danh sách tên) + `SettingsHeaderBar` (quay lại + đường dẫn) — dùng chung mọi cấp |
| `pages/settings/ThemeModePanel.jsx` (mới) | Tách từ `AppTab` cũ |
| `pages/settings/FontGroupPanel.jsx` | Thay `FontSettingsSection.jsx` (đã xoá): một component, `props.source` = `client`/`server`/`custom`; chỉ tải font xem trước của nhóm đang mở, chỉ hỏi server khi mở nhóm "server" |
| `pages/SettingsPage.jsx` | Viết lại: đọc registry, tab sticky giữ nguyên |
| `pages/settings/Admin*Panel.jsx` ×4 | Bỏ tiêu đề riêng (khung vẽ) và `mt: 4` xếp chồng; còn lại không đổi |
| `App.jsx` | Route `/settings/:tab` → `/settings/:tab/*` |

## Hiệu ứng phụ có lợi
- Người dùng thường **không còn tải mã panel quản trị** (~31 KB, 11 KB gzip — nay là chunk riêng, chỉ tải khi SA mở đúng mục).
- Trước đây mở tab Quản trị là **cả 4 panel gọi API cùng lúc**; nay chỉ panel đang mở gọi.
- Danh sách font xem trước không còn tải hết cả 3 nhóm khi mở "Font chữ".

## Hành vi thay đổi (cần biết)
- Nhóm "Font chữ do quản trị viên cài đặt" trước đây **ẩn khi rỗng**; nay luôn hiện (đúng 3 mục như yêu cầu) và hiện "Quản trị viên chưa cài font nào." khi rỗng.
- Gõ URL tab/mục không tồn tại hoặc không đủ quyền: trước đây âm thầm rơi về tab Ứng dụng; nay báo rõ + nút "Về Cài đặt"
  (chờ hồ sơ tải xong rồi mới kết luận để SA tải lại trang ở `/settings/admin/…` không bị báo nhầm).
- Backend, Firestore rules, biến môi trường: **không đổi** (chỉ đổi nhãn phiên bản). Chỉ cần deploy lại frontend.

## Kiểm thử
Frontend **115/115** (84 cũ + 31 mới: `settingsTree.test.js` 17, `settingsPage.test.jsx` 13, +1 dòng route sâu ở `lazyRoutes`). Ba file test font cũ được sửa
để dựng `FontGroupPanel` thay `FontSettingsSection` (cùng các khẳng định hành vi). Đột biến: bỏ `key={pathKey}` ở khung ⇒ test "chuyển thẳng giữa 2 mục lá dùng chung component" FAIL.
`vite build` OK, chunk panel quản trị tách riêng.
**Chưa kiểm:** giao diện trên trình duyệt/điện thoại thật (chỉ jsdom + build) — hãy xem thử bố cục thanh đường dẫn trên màn hình hẹp và bấm Back của điện thoại.
