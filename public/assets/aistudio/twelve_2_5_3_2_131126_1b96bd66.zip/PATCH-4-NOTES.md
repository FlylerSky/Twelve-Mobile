# v2.0.7 — Tuỳ chọn Font chữ (Settings > Ứng dụng)

Xây trên bản vá 3. Version đã đổi thành `2.0.7.041026` ở `frontend/public/version.json`, `frontend/package.json`, `backend/package.json`.

## Khung tổng thể (đã sẵn để mở rộng)
| Loại | Trạng thái |
|---|---|
| #1.1 Font server (SA cài) | Chưa có — thêm vào `getAllFonts()` ở bản sau |
| **#1.2 Font client (hard-code / link ngoài)** | **Bản này: Mặc định (Google Sans) + SVN-Headliner No. 45** |
| #2 Font tuỳ chỉnh qua URL | Chưa có |

## Đã làm
- `frontend/public/fonts/svn-headliner-no45.woff2` — chuyển từ OTF (505 KB → 265 KB), giữ đủ 372 glyph; đã kiểm tra có đủ toàn bộ chữ cái tiếng Việt có dấu.
- `src/theme/fonts.js` — kho font + `ensureFont()` (nạp bằng **FontFace API**, không chèn thẻ `<style>`, nên chỉ cần `font-src` trong CSP). File font chỉ tải khi người dùng chọn hoặc mở mục xem trước, và chỉ tải 1 lần/phiên.
- `ThemeModeContext` — thêm `fontId`, `setFontId`, `fontLoading`; lưu `localStorage["twelve_font_id"]` (theo thiết bị, giống chế độ Sáng/Tối). Id lạ/đã gỡ → tự về font mặc định.
- `theme.js` — `createAppTheme(mode, fontFamily)`; font chọn luôn có `FALLBACK_STACK` phía sau nên ký tự thiếu glyph vẫn hiển thị bằng font mặc định.
- `pages/settings/FontSettingsSection.jsx` — mục "Font chữ" dưới "Chế độ giao diện": nhóm theo nguồn, mỗi font hiển thị bằng chính nó, dấu "Đang dùng", vòng xoay khi đang tải.
- `vercel.json` — cache `/fonts/*` 1 năm (immutable). **Đổi nội dung font ⇒ đổi tên file.**
- Font chỉ có 1 độ đậm (Regular): khai báo `font-weight: 100 900` để trình duyệt không tự "làm đậm giả" ở các chỗ giao diện dùng độ đậm 500–700.

## Kiểm thử
`frontend/tests/fonts.test.jsx` (9 ca): kho font, id lạ, đường dẫn woff2 có thật, tải 1 lần, lỗi tải/thử lại, khôi phục từ localStorage, chọn font trong Cài đặt đổi theme và lưu, bỏ qua id không tồn tại. Cùng ca cũ của hotfix: 15/15 pass; `vite build` thành công. **Chưa thử trên trình duyệt thật** — hãy mở Cài đặt > Ứng dụng, chọn font, tải lại trang (font phải được giữ), và thử trên điện thoại.

## Lưu ý
- **Giấy phép:** font ghi "Licensed. Copyright KC Fonts all rights reserved." Hãy chắc bạn có quyền nhúng web/phân phối công khai.
- SVN-Headliner là font trang trí: đẹp ở tiêu đề nhưng khó đọc ở đoạn dài; đã ghi chú trong giao diện. Nếu muốn, bản sau có thể thêm tuỳ chọn "áp dụng cho: tiêu đề / toàn bộ".
- Font chỉ áp dụng cho giao diện SPA, không đổi trang SSR dành cho bot (cố ý).
- Lựa chọn lưu theo thiết bị. Đồng bộ qua tài khoản cần thêm field hồ sơ — chưa làm.
- Cho 1.1 và #2 sau này: URL font tuỳ chỉnh phải được kiểm tra (https, giới hạn domain/định dạng) và mở `font-src` tương ứng trong CSP.
