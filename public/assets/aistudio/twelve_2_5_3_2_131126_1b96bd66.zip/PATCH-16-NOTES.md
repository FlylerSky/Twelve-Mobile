# PATCH 16 — v2.4.0.181026: trang **Profile** (ảnh bìa · huy hiệu · bài ghim · tab Bài viết)

Nền: v2.3.0. Không có thay đổi `firestore.rules`, `firestore.indexes.json` hay biến môi trường mới. Test: backend **175/175** (145 cũ + 30 mới), frontend **213/213** (171 cũ + 42 mới), `vite build` sạch.

## 1. Những gì bạn sẽ thấy

**Trang Profile (`/u/:uid`)** có đầu trang + 2 tab (`?tab=posts` cho tab Bài viết; tab Trang chủ là mặc định, URL sạch):
- **Đầu trang:** ảnh bìa khổ 3:1 (chưa có / ảnh lỗi → nền gradient theo màu theme), avatar đè mép dưới ảnh bìa, Tên hiển thị + **huy hiệu ngay cạnh tên**, Tag Name Search, quốc gia.
- **Tab "Trang chủ":** các bài người dùng **ghim** (tối đa 3, bài ghim sau đứng trước). Chính chủ ghim/gỡ ghim ở *bất cứ trang nào* thì danh sách này đổi theo.
- **Tab "Bài viết":** mọi bài của người đó, mới nhất trước, phân trang như feed Trang chủ (cùng `PostCard`, cùng hộp bình luận). Bài đang ghim vẫn nằm trong danh sách, kèm dấu "Đã ghim".
- **headZone:** chủ hồ sơ có nút **Chỉnh sửa hồ sơ** → Cài đặt › Tài khoản › Thông tin. (Tab thêm sau này = thêm *một dòng* vào `PROFILE_TABS` ở `PublicProfilePage.jsx`; chỉ tab đang mở mới được dựng và gọi API.)

**Ghim bài**
- Thẻ bài: nút ghim là **một chỉ số nữa** trong hàng thông số (chỉ tác giả thấy, chỉ bài viết — không phải Blog), **ưu tiên thấp nhất, không có số đếm**. Thiếu chỗ thì tự chuyển vào menu "···" nhờ cơ chế đo sẵn có — giao diện không vỡ (có test mô phỏng hộp hẹp).
- Trang POST: nút ghim **không** nằm ở khu thông số mà ở **headZone** (`Ghim / Gỡ ghim khỏi trang cá nhân`).
- Vượt 3 bài: báo đúng câu của backend ("Bạn chỉ ghim được tối đa 3 bài…"). Đổi giới hạn ở **một chỗ**: `PROFILE.PINNED_POSTS_MAX` trong `backend/src/utils/constants.js`.

**Ảnh bìa — Cài đặt › Tài khoản › Thông tin** (hàng mới ở đầu): ảnh xem trước + 3 nút **Tải ảnh lên** (chọn ảnh, cắt khung ngang 3:1, lưu 1500×500), **Dùng đường dẫn** (dán URL https), **Gỡ ảnh bìa**.

## 2. Hệ huy hiệu — định nghĩa lại
Hiện trạng ≤ 2.3.0 (đúng như bạn nhớ): có 2 thứ — nhãn nhóm tài khoản `SA/RA/LLA` (chỉ ở thẻ hồ sơ trong Menu của *chính chủ*, dạng chữ) và "Đến từ Twelve cũ" (chỉ ở trang hồ sơ công khai, chip chữ dài). Bài viết/bình luận/xếp hạng không hiện gì.

Từ 2.4.0: huy hiệu là **dữ liệu suy ra**, không lưu thêm trường nào, nên không thể lệch với vai trò thật.

| id | Icon | Khi nào có | Tên (hiện khi bấm) |
|---|---|---|---|
| `admin` | AdminPanelSettings | `accountRole = admin` | Quản trị viên |
| `dev` | Code | `dev` | Lập trình viên |
| `moderator` | Gavel | `moderator` | Điều hành viên |
| `pro` | Diamond | `pro_user` | Người dùng Pro |
| `tester` | Science | `test` (tài khoản LLA) | Tài khoản thử nghiệm |
| `legacy` | History | `isLegacyMember = true` | Thành viên Twelve cũ |

- Vai trò `user` (người thường) **cố ý không có huy hiệu**. Thứ tự: cấp bậc trước, `legacy` sau.
- **Chỉ vẽ icon.** 1 huy hiệu → icon đó; **≥ 2 → gộp thành một huy hiệu "3 chấm"**; bấm vào (huy hiệu nào cũng được) mở danh sách icon + tên + mô tả. Bấm không kích hoạt thẻ bài/hàng xếp hạng chứa nó.
- **Có ở mọi nơi hiện tên:** `toPublicUser` (tác giả ở mọi thẻ bài/bình luận) trả `badges: [...]`; `UserName` (một component) vẽ chúng nên bài viết, trang POST, bình luận đều có; thêm: Menu, trang Profile, bảng xếp hạng người dùng (`renderNameExtra` mới ở `RankingBoard`).
- Nguồn sự thật: `backend/src/utils/badges.js` (ai có huy hiệu nào) + `frontend/src/utils/badges.js` (hình/tên/mô tả). Hai bên có **một bảng ca test giống hệt nhau**; id lạ (backend mới hơn frontend) hiện bằng huy hiệu chung, không vỡ.

## 3. API mới (tất cả có test)
| Method + đường dẫn | Quyền | Ghi chú |
|---|---|---|
| `GET /api/users/:uid/posts?cursor&limit` | công khai (`optionalAuth` để có `myReaction`) | `limit` mặc định 10, tối đa 30; cursor của bài người khác bị bỏ qua; dùng chỉ mục **đã có** (`authorUid`+`createdAt`) |
| `GET /api/users/:uid/pinned` | công khai | Tự loại bài đã mất/không còn của người này và gỡ id sót khỏi hồ sơ |
| `PUT` / `DELETE /api/posts/:id/pin` | **chủ bài**, `requireActive` | Idempotent; SA cũng không ghim hộ (403); `409 PIN_LIMIT_REACHED` |
| `POST /api/users/me/cover` | đăng nhập | multipart field `cover`, ≤ 3 MB, JPEG/PNG/WebP, magic-bytes như avatar |
| `PUT /api/users/me/cover` `{url}` | đăng nhập | https + domain trong danh sách nhúng |
| `DELETE /api/users/me/cover` | đăng nhập | Idempotent |

`GET /users/:uid` thêm `coverUrl`, `badges`. `GET /users/me` thêm `badges`. Ảnh bìa **chỉ** có ở hồ sơ đầy đủ (`toPublicProfile`), không gắn vào `author` của từng thẻ.

## 4. Dữ liệu
- `users/{uid}.pinnedPostIds: string[]` (theo thứ tự hiển thị) và `users/{uid}.coverUrl: string|null`. Chủ tài khoản đã nghe realtime document này (AuthContext), nên mọi thẻ bài của mình biết ngay bài nào đang ghim mà không gọi API thêm.
- Bài bị xoá (chủ bài hoặc SA) → gỡ id khỏi ghim ngay sau khi xoá (nền) *và* lần đọc ghim sau tự dọn; không bao giờ dựng lại hồ sơ đã xoá.
- Ảnh bìa tải lên: Cloudinary `twelve/covers/<uid>/cover` (mỗi người đúng 1 file, đổi = ghi đè), có dòng trong sổ `assets` kind `cover` (Quản trị › Tài nguyên hiện loại mới). Chuyển sang URL ngoài hoặc gỡ → file Twelve giữ được xoá (trừ khi URL mới *chính là* file đó). Xoá tài khoản dọn luôn thư mục covers. Script dọn ảnh mồ côi chỉ quét `twelve/avatars/` nên **không bao giờ đụng ảnh bìa**.
- SSR `/u/:uid`: `og:image` ưu tiên ảnh bìa → avatar → ảnh mặc định.

## 5. ⚠ Cần bạn quyết định / kiểm tra
1. **Dán URL ảnh bìa bị giới hạn bởi danh sách "Domain nhúng"** (cùng luật với ảnh bìa bài viết; mặc định danh sách *không* có host ảnh phổ biến). Muốn người dùng dán từ imgur/i.ibb.co… thì SA phải thêm domain ở Quản trị › Domain nhúng; nếu không họ nhận lỗi rõ ràng và dùng "Tải ảnh lên". Nếu bạn muốn nới riêng cho ảnh bìa hồ sơ (cho mọi https), đó là sửa một hàm: `validateProfileCoverUrl` ở `backend/src/utils/helpers.js` — nhưng nó cũng thành `og:image` cho bot, nên mình giữ chặt làm mặc định.
2. **Giả định mình tự chọn** (đổi ở một chỗ): tối đa **3** bài ghim; người thường **không** có huy hiệu; tài khoản `test` có huy hiệu "Tài khoản thử nghiệm"; Blog không ghim được.
3. **Chưa kiểm chứng trên môi trường thật** (chỉ có Firestore/Cloudinary giả + jsdom): upload ảnh bìa lên Cloudinary thật, hiển thị thực tế trên điện thoại (độ lớn icon huy hiệu, avatar đè ảnh bìa, hộp cắt 3:1), và việc nút ghim vào "···" ở độ rộng thật. Nên thử tay 3 điểm này sau khi deploy.
4. Hồ sơ cũ trong bảng xếp hạng *tuần đã lưu* không có `badges` (chỉ ảnh hưởng dòng lịch sử, không lỗi).
5. SSR cho bot (`/u/:uid`) **chưa** liệt kê bài ghim trước — vẫn là danh sách bài gần đây như trước.

## 6. Bề mặt tấn công mới (đã rà, có test)
- **Quyền sở hữu:** ghim chỉ cho chủ bài (kể cả SA bị 403), kiểm trong transaction; ảnh bìa/ghim luôn theo `req.authUid`, không nhận uid từ client.
- **Đầu vào:** id route lạ (`a%2Fb`…) → 404, không tái xuất A-01; `pinnedPostIds` hỏng (không phải mảng/phần tử lạ/trùng) bị lọc, không làm 500; URL ảnh bìa: chỉ https, không khoảng trắng/điều khiển, không `user:pass@`, ≤ 2000 ký tự, domain theo danh sách; upload: giới hạn field/part của multer, MIME khai báo + magic-bytes + `file-type`.
- **Lạm dụng:** `coverUploadLimiter` 6/giờ, `pinLimiter` 60/15 phút, `userPostsLimiter` 200/15 phút; limiter đặt **trước** multer.
- **Rò rỉ:** `pinnedPostIds`, `email`, ngày sinh… không có trong hồ sơ công khai (có test); URL ảnh bìa không đi kèm mọi `author`.
- **Hồ sơ không xem được** (pending, đang xoá, "ma"): `/posts` và `/pinned` cũng 404.

## 7. File chính đã đổi
Backend: `utils/badges.js`·`services/pins.js`·`utils/profilePosts.js` (mới); `controllers/users|posts|trending`, `routes/users|posts|ssr`, `services/assets`, `middleware/upload|rateLimiters`, `utils/constants|helpers|cloudinaryUrl|seoMeta`; test `test/profile-240.test.js`.
Frontend: `utils/badges.js`, `components/UserBadges.jsx`, `components/profile/*`, `hooks/usePinPost.js`, `pages/settings/CoverImageRow.jsx` (mới); `PublicProfilePage`, `PostCard`, `PostDetailPage`, `UserIdentity`, `Navbar`, `RankingBoard/List`, `AvatarCropper` (tổng quát hoá, mặc định giữ nguyên hành vi avatar), `AccountInfoPanel`, `AuthContext` (`patchProfile`), `api/*`; test `badges`, `userBadges`, `profile240`.
Tài liệu: `headZone.md` (bản cập nhật ở thư mục kết quả; ví dụ Post detail/Profile + lịch sử), `SECURITY-STATUS.md`.
