# Bản vá 2 — theo báo cáo 2 (xây trên bản vá 1; nhãn "v2.0.5" chỉ là nhãn tạm)

## Triển khai (theo thứ tự)
1. `firebase deploy --only firestore:indexes` (thêm index `hashtagsLower`), chờ *Enabled*.
2. Deploy backend, rồi frontend.
3. Backfill hashtag cho bài cũ: `npm run hashtags:backfill` (dry-run) → `npm run hashtags:backfill:apply`.
   Chưa backfill thì SSR tự lùi về khớp đúng chữ hoa/thường như cũ (không lỗi).
4. Dọn comment mồ côi của bài đã xoá từ trước: `npm run orphans:purge` (dry-run) → `npm run orphans:purge:apply`.
5. Firestore rules không đổi so với bản vá 1.

## Đã vá
| # | Nội dung | Cách làm |
|---|---|---|
| 1 | Farm điểm bằng bình luận | Chỉ bình luận ĐẦU TIÊN của mỗi (user, bài) được +3 (tác giả) / +1 (người bình luận). Mọi bình luận vẫn đăng được; các bình luận sau `scored:false`. Xoá chỉ hoàn điểm cho bình luận đã có điểm (bình luận cũ không có field `scored` coi là đã có điểm). |
| 2 | Email Gmail có dấu chấm | `normalizeEmail()` → chỉ trim + chữ thường. Frontend thêm `signInWithEmailCompat`: tài khoản CŨ (email đã bị bỏ chấm) đăng nhập bằng email gốc sẽ được thử lại bằng dạng chuẩn hoá kiểu cũ. |
| 3 | Xếp hạng tuần/toàn thời gian quét users | Cache 60 giây + single-flight (nhiều request đồng thời chỉ quét 1 lần); batch tự sửa snapshot chia lô 400 (trước đó >500 user sẽ lỗi). |
| 4 | Xoá bài/blog để lại comment mồ côi | `recursiveDelete` chạy nền sau khi xoá; script `purge-orphan-subcollections` dọn phần đã mồ côi. |
| 5 | Tạo/sửa bài không limiter riêng | Tạo: 20 bài/giờ/tài khoản; sửa: 60/15 phút/tài khoản; (thêm) tải bình luận: 200/15 phút. |
| 6 | Rescan embed đồng bộ | PUT trả ngay `rescan:{running:true}`; quét nền theo trang 100 doc, nhường event loop, cập nhật cả `excerpt`; trạng thái ở `GET /api/admin/embed-domains/rescan` (UI tự hỏi 3 giây/lần). Cấu hình embed đồng bộ giữa nhiều instance mỗi 60 giây. |
| 7 | Tìm theo tên tác giả | Đối chiếu displayName/@tagName trên toàn bộ nội dung (trước đây lọc nội dung trước nên gần như không bao giờ ra). |
| 8 | Hashtag hoa/thường, trang rỗng | Thêm `hashtagsLower`; SSR dùng 1 URL canonical chữ thường; hashtag không có bài → HTTP 404 + noindex. |
| 9 | Link người dùng thiếu rel | Sanitizer ép `rel="ugc nofollow noopener"` (link ngoài) / `noopener` (nội bộ). **Bài cũ chỉ được áp dụng sau khi chạy lại `node src/seed/resanitizeContent.js`** hoặc khi sửa bài. |
| — | `coverImageUrl` bỏ qua allowlist | Ảnh bìa phải thuộc domain SA cho phép; ảnh bìa đang lưu không đổi thì không bị kiểm tra lại. |
| — | Đăng ký tạo user trước rồi mới kiểm tra tagName | Kiểm tra tagName trước khi tạo user Firebase (giao dịch vẫn là chốt cuối). |

## Quyết định cần bạn xác nhận
- **Điểm đã bị farm trước đây KHÔNG được tự sửa.** Muốn chuẩn hoá lại cần script đếm lại bình luận đầu tiên mỗi cặp (user, bài) rồi `reconcilePostsScoreSum` — mình chưa viết vì thay đổi điểm hiện có là quyết định của bạn.
- Bình luận bị xoá là bình luận đầu: các bình luận còn lại của người đó vẫn không có điểm (không "thăng hạng").
- `postScore` (điểm hiển thị, chế độ *classic*) vẫn tính MỌI bình luận (+3 mỗi cái) vì đó là điểm tương tác tổng; chỉ `externalPostScore` (điểm xếp hạng *advanced* và điểm tài khoản) được chống farm.
- Tài khoản cũ có email bị bỏ chấm vẫn lưu email cũ trong Firebase; không thể tự khôi phục email gốc.
- `register` vẫn trả 409 "Email này đã được đăng ký" (UX); đổi sang thông báo chung sẽ chặn dò email nhưng làm đăng ký khó hiểu hơn.

## Chưa làm
- `vercel.json`: CSP vẫn Report-Only, `frame-src https:` vẫn mở (danh sách iframe do SA đổi lúc chạy nên không thể tĩnh hoá trong file này; sanitizer phía server mới là chốt chặn), host onrender vẫn hardcode. Cần bước build sinh file hoặc chuyển CSP về middleware.
- DOMPurify phía client cho `PostContent` (thêm phụ thuộc mới; nội dung đã sanitize ở server).
- Tái cấu trúc frontend (`TrendingPage` 599 dòng, `PostCard`, `Navbar`, gộp `RankingBoard/RankingList/HashtagRankingList`, gộp 2 hook bình luận): không sửa khi chưa có test giao diện; mình nghiêng về làm riêng từng cái.
- Chưa đọc `assets.service`, `assetAudit`, `AuthContext`.
- Test dùng Firestore giả: chưa chạy trên Firestore thật/emulator (đặc biệt giao dịch có truy vấn trong `addComment` và `recursiveDelete`).
