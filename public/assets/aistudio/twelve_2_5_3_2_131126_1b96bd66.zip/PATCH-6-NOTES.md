# v2.0.9 — Hotfix hiển thị font server (Quản trị / Ứng dụng)

Xây trên v2.0.8. Version: `2.0.9.061026`. Không đổi schema, không cần index mới, không đổi rules.

## Sửa
1. **Cài đặt > Ứng dụng không cập nhật sau khi SA lưu font.** Trước đây danh sách font server chỉ được lấy MỘT lần lúc mở app,
   nên font mới chỉ hiện sau khi tải lại trang. Nay lấy lại mỗi lần mở mục Font chữ và ngay sau khi SA bấm "Lưu danh sách font".
2. **Lỗi tải danh sách bị che.** Trước đây lỗi mạng/404 chỉ làm danh sách trống (Ứng dụng) hoặc hiện "Chưa có font nào" (Quản trị)
   kèm snackbar thoáng qua. Nay hiện cảnh báo ngay trên trang với nguyên nhân và nút "Thử lại"
   (Quản trị còn gợi ý khả năng backend chưa deploy bản có tính năng).
3. **Trình duyệt giữ danh sách cũ tới 60 giây** (`Cache-Control: max-age=60` của `GET /api/fonts`). Đổi thành `no-cache`
   (có ETag nên rất rẻ; server vẫn cache RAM 60 giây và vô hiệu ngay khi SA lưu).
4. **Font bị ẩn im lặng.** `GET /api/admin/fonts` trả thêm `visible`, `hiddenReason`, `visibleCount`; panel Quản trị hiển thị
   "đang hiển thị với người dùng: N" và cảnh báo từng font bị ẩn (vd. file không còn trong `backend/fonts`).

## Kiểm thử
Backend 42/42, frontend 46/46 (5 ca mới ở `frontend/tests/fonts-admin.test.jsx`: lưu ở Quản trị → Ứng dụng thấy ngay, font đến muộn,
lỗi tải + Thử lại, lỗi Quản trị hiện trên trang, đếm font hiển thị). 3/5 ca mới FAIL trên mã v2.0.8 và PASS trên v2.0.9.
Ngoài ra đã chạy thử `server.js` thật (middleware auth/SA/CORS/helmet, Firestore giả): GET công khai → GET/PUT quản trị → GET công khai đều đúng.
`vite build` OK. Chưa thử trên Firestore thật/trình duyệt thật.

## Lưu ý thao tác
Ở Quản trị, "Thêm từ link/từ file" chỉ thêm dòng vào danh sách tạm trên màn hình; font chỉ có hiệu lực sau khi bấm **"Lưu danh sách font"**.
