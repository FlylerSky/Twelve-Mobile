# TWELVE-MAP — bản đồ mã nguồn Twelve (cập nhật ở v2.5.3.131126)

**Đọc file này TRƯỚC khi đọc mã.** Mục đích: người (hoặc Claude) mới mở dự án nắm được kiến trúc, khái niệm lõi, quy ước và cạm bẫy trong vài phút, rồi chỉ đọc đúng file cần sửa. Mọi điều dưới đây đã đối chiếu với mã ở phiên bản trên; khi mã đổi theo hướng làm sai file này (kiến trúc, khái niệm lõi, dữ liệu, quy ước, cách chạy test), sửa file này **cùng lúc** — quy tắc ở mục 5, điều 2.

Nhật ký thay đổi: `PATCH-1…26-NOTES.md` (mới nhất = `PATCH-26-NOTES.md` — 2.5.3.131126: đo + sửa nhận diện IP client, tinh chỉnh CSP; trước đó `PATCH-25-NOTES.md` — hotfix 2.5.3.121126: App Check làm treo frontend; trước đó `PATCH-24-NOTES.md` — bản vá bảo mật 2.5.3), `backend/README.md` (mục `-N` mới nhất ở đầu file), `SECURITY-STATUS.md` (tình trạng bảo mật + việc cần quyết). Mỗi file nguồn có chú thích đầu file nêu phiên bản và lý do — **đọc chú thích trước khi sửa**, nhiều quyết định có chủ đích ghi ở đó.

---

## 1. Kiến trúc

| | Frontend | Backend |
|---|---|---|
| Chạy ở | Vercel (SPA + `middleware.js`) | Render (`twelveta.onrender.com`) |
| Công nghệ | React + Vite + MUI + react-router, axios, dayjs, react-quill (Quill 1.x), firebase (Client SDK), react-easy-crop, yet-another-react-lightbox | Node ≥ 20, Express, firebase-admin (Firestore + Auth), Cloudinary, DOMPurify + jsdom (worker riêng), EJS (SSR), helmet, express-rate-limit, express-validator |
| Đăng nhập | **Client SDK** đăng nhập (email/mật khẩu), gửi ID token cho backend | `verifyIdToken` + kiểm thu hồi có cache 60s; trạng thái tài khoản đọc **tươi** từ Firestore mỗi request |
| Dữ liệu | Gọi backend qua axios (`src/api/*`); **chỉ nghe realtime** document của chính mình + bài/blog đang xem (`onSnapshot`) | Toàn bộ ghi đi qua backend (Admin SDK). `firestore.rules`: Client SDK chỉ đọc được rất ít (xem mục 4) |

- **SEO/SSR**: `frontend/middleware.js` nhận diện bot/AI agent (danh sách token trong file) rồi *rewrite* sang trang HTML do backend dựng (`backend/src/routes/ssr.routes.js` + `views/*.ejs`); người dùng thật nhận SPA. Hai bên chia sẻ bí mật `SSR_PROXY_SECRET`; backend chỉ cộng view khi secret khớp. `?spa=1` luôn trả SPA. Matcher: `/`, `/blog`, `/post/*`, `/blog/*`, `/u/*`, `/trending`, `robots.txt`, `sitemap*.xml`, `/csp-report`.
- **CSP**: `vercel.json` đặt CSP **đầy đủ ở chế độ Report-Only** (báo cáo về `/api/csp-report`, xem ở Cài đặt › Quản trị) và **enforce** một phần (`object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'` + từ 2.5.3 `script-src 'self' https://challenges.cloudflare.com; script-src-attr 'none'` — SPA không có script nội tuyến; **đừng thêm `<script>` nội tuyến vào `index.html`**). `img-src`/`frame-src` còn Report-Only vì phụ thuộc allowlist domain nhúng do SA sửa lúc chạy (`npm run csp:sources` in nguồn). Hai header cùng áp dụng (giao của hai chính sách), cùng `X-Frame-Options`, `nosniff`, `Referrer-Policy`, `Permissions-Policy`. Template SSR **không dùng `style=""` inline**.
- Backend khởi động: `app.listen` trước, rồi chạy nền `startEmbedConfigSync`, `contentPipeline.warmUp` (nạp worker sanitize), `accountDeletion.startSweeper` (mỗi phút nhặt việc xoá tài khoản dở), `pendingCleanup.startPendingSweeper` (2.5.3: dọn tài khoản `pending` quá hạn, mặc định 7 ngày, chạy lần đầu ~3 phút sau khởi động rồi mỗi 6 giờ; tắt bằng `PENDING_SWEEPER=off`). Không có cron ngoài: tuần xu hướng chốt **lười** khi có request đầu tiên của tuần mới.

## 2. Cấu trúc thư mục (chỉ những gì cần biết)

```
backend/
  server.js                     dựng app, helmet/CORS/limiter chung, mount route, khởi động nền
  firestore.rules / .indexes.json
  src/
    routes/*.routes.js          mỗi file = một nhóm endpoint (xem mục 6)
    controllers/                xử lý nghiệp vụ; trending.controller.js (881 dòng) = xu hướng + chốt tuần
    middleware/                 auth.js (requireAuth/optionalAuth), roles.js (requireSA…), rateLimiters.js, validators.js, idParams.js, captcha.js, upload.js
    services/                   accountDeletion, achievements, profileVisitors, profileLookup, pins, userPrivate, sanitize.service, contentPipeline, assets.service, các job dọn dẹp
    utils/                      constants.js (NGUỒN HẰNG SỐ), helpers.js (1449 dòng: điểm số, hồ sơ công khai, view/share, tag), badges.js, profileExtras.js, input.js, seoMeta.js, ssrContent.js, weekCode.js, time.js …
    views/                      EJS SSR: top/bottom/style partials, content, list, profile, hashtag
    debug/                      khung "Gỡ lỗi" (hồi quy bảo mật chạy được ở production) + support/fakeFirebase.js
    seed/                       seedCountries, seedVersion, resanitizeContent
  scripts/                      migrate/dọn dữ liệu (nhiều script chạy thử khô mặc định, thêm --apply mới ghi) — xem scripts/README.md
  test/                         node --test, Firestore/Auth GIẢ; danh sách file test nằm trong package.json "test"
frontend/
  middleware.js  vercel.json  vite.config.js  vitest.config.mjs  index.html
  public/version.json           số phiên bản frontend (phải khớp package.json)
  src/
    App.jsx                     route + tải lười từng trang
    api/*.api.js                lớp gọi backend (client.js: axios + gắn token)
    context/                    AuthContext, PageHeaderContext, SnackbarContext, ThemeModeContext, CreatePostContext
    hooks/                      usePaginatedFeed, useAuthGate, useTabTree (components/tabs), useSeo, useContentEngagement…
    pages/                      Index, Blog, PostDetail, PublicProfile, Settings (+ settings/), Trending, Login, Register
    components/                 dùng chung; components/profile/ (trang Profile); components/tabs/ (hệ tab dùng chung)
    theme/                      theme.js (sáng/tối), fonts.js
    utils/                      badges, profilePath, profileExtras, bio, time, postScore, authGate, navStack, …
  tests/                        vitest + jsdom
```

## 3. Khái niệm lõi

**Nhóm / vai trò / trạng thái** (`constants.js`). Nhóm: `SA` (quyền cao), `RA` (người dùng thường), `LLA` (thử nghiệm, có thể bị tước quyền). Vai trò: SA → `admin|dev|moderator`; RA → `pro_user|user`; LLA → `test`. Trạng thái: `pending` (chưa kích hoạt) · `active` · `suspended` · `deleting` (đang xoá, hồ sơ công khai trả 404). **Quyền thật dựa vào `accountGroup`** (`requireSA`, `isSA`), không phải `accountRole`. Frontend: `isLoggedIn` = `status === "active"`; `isSA` = active + group SA.

**Huy hiệu** (`backend/utils/badges.js` ⇄ `frontend/utils/badges.js`): dữ liệu **suy ra**, không lưu. Backend trả mảng id (`badges: ["admin","legacy"]`) trong mọi hồ sơ công khai (`toPublicUser`); frontend lo icon/tên. Id: `sa admin dev moderator pro tester legacy` (`legacy` = `isLegacyMember`, thành viên Twelve cũ).

**Điểm** (`helpers.js`). `postScore` = view×1 + like×2 − dislike×2 + comment×3 + share×4 — **luôn tính lại từ 5 bộ đếm**, không phải nguồn sự thật. `postsScoreSum` = tổng điểm (từ tương tác của *người khác* — `externalPostScore`, chống tự farm). `positiveScore` = bộ đếm cộng/trừ thuần cho **người thực hiện** hành động (đăng bài, like, comment, view, share…), ghi **cùng transaction** với hành động, **có thể âm**. `accountScore = postsScoreSum + positiveScore`, tự chữa lành khi gọi `GET /users/me` (`syncAccountScore`). Link share có chữ ký HMAC (`SHARE_LINK_SECRET`) chống bơm điểm.

**Xu hướng** (`trending.controller.js`, `weekCode.js`). Mã tuần `"N.K.MM.YYYY"` (N = số tuần tổng tăng dần từ `TRENDING_EPOCH_DATE`; mỗi tháng đúng 4 "tuần": ngày 1-7, 8-14, 15-21, 22-hết). Mỗi user có `weeklySnapshot = {weekCode, accountScoreAtStart}`; **tăng điểm tuần = accountScore − accountScoreAtStart**. Request đầu tiên của tuần mới "giành quyền" chốt tuần (có lease/claim chống hai instance chốt cùng lúc): ghi **vĩnh viễn, không ghi đè** `weeklyLeaderboards/{mãTuần}` = `{weekCode, top10:[{rank,uid,weeklyGrowth,…}], totalParticipants, finalizedAt}`, rồi reset snapshot. LLA và tài khoản không active bị loại. Hashtag có bảng riêng (`hashtagWeeklyLeaderboards`, `hashtagExploreSnapshots`) — **không gắn người dùng**. Bảng xếp hạng cache 60s trong RAM từng instance (single-flight).

**Tag Name Search & URL hồ sơ** (`profilePath` ở cả hai phía — giữ cùng luật). Tag: `[a-z0-9_]{3,20}`, duy nhất, lưu id không có "@" ở `tagNames/{tag}`. URL: `/u/@<tag>` (dấu @ bắt buộc để phân biệt với route phụ), `/u/myProfile` = hồ sơ người đang đăng nhập, `/u/<uid>` là dạng cũ (tự chuyển sang `@tag`). Mọi liên kết tới hồ sơ phải đi qua `profilePath(user)`. Có danh sách tag dành riêng (`isReservedTagName`, env `RESERVED_TAG_NAMES_EXTRA`).

**Hồ sơ công khai**: `toPublicUser` (nhẹ, gắn vào `author` của mọi thẻ bài/bình luận) và `toPublicProfile` (đầy đủ: cover, crop, **bio**). **Không bao giờ** trả email/tên thật/ngày sinh/giới tính ra endpoint công khai (ngày sinh/giới tính chỉ ra qua `GET /users/:uid/extra-info` khi chính chủ bật). Tên thật ở `userPrivate/{uid}` (xem lại cần nhập lại mật khẩu).

**Nội dung & an toàn**: bài/blog là HTML do Quill sinh ra ở frontend; backend **làm sạch lại** (DOMPurify+jsdom, chạy ở worker, có giới hạn kích thước/độ sâu/timeout — `CONTENT_LIMITS`). Blog nháp (`isPublished !== true`) không bao giờ lộ công khai (`utils/visibility.js`). Domain nhúng iframe cấu hình ở `config/embedDomains` (SA sửa ở Cài đặt › Quản trị).

**Xoá tài khoản** (`services/accountDeletion.js`): bền vững qua sập server — sổ `accountDeletions`, lease 3 phút, nhiều bước (lock → … → `residual` → `verify`), sweeper mỗi phút, hồ sơ xoá **sau cùng**. Thêm collection/dữ liệu gắn với uid ⇒ **phải** thêm bước dọn ở `stepResidual` (+ kiểm ở `stepVerify`). Các script `purge-*`/`cleanup-*` dọn dữ liệu mồ côi.

**Trang Profile (2.4 → 2.5.2)**: ảnh bìa (+crop), avatar, huy hiệu, **Tiểu sử** (`users.bio`), ghim bài (`pinnedPostIds`), tab (Trang chủ · Bài viết · **Blog** chỉ SA — cây tab ở `components/profile/profileTabs.jsx`), headZone (Chỉnh sửa hồ sơ · **Khách ghé thăm** chỉ chủ · Sao chép URL), hộp **Xem thêm** (thông tin mở rộng + thành tích). Chi tiết thiết kế 2.5.2: `PATCH-23-NOTES.md`.

## 4. Dữ liệu Firestore

| Collection | Ghi chú |
|---|---|
| `users/{uid}` | `uid, displayName, tagName, birthday, gender, country, email, avatarUrl, coverUrl, coverCrop, accountRole, accountGroup, status, isFirstLogin, postsScoreSum, positiveScore, accountScore, weeklySnapshot, pinnedPostIds, isLegacyMember, **bio**, **profileExtras**, createdAt` (**createdAt khi đăng ký là chuỗi ISO**, nơi khác là Timestamp — dùng `toIsoString`). Subcollection `positiveScoreLogs` (từ 2.5.3 Client SDK **không đọc** được: log "share" chứa uid người mở link). Client SDK chỉ **đọc** document `users/{uid}` của chính mình |
| `tagNames/{tag}` | `{uid}` — giữ chỗ tag |
| `posts/{id}`, `blogs/{id}` | `id, authorUid, title, contentHtml, excerpt, coverImageUrl, hashtags, hashtagsLower, like/dislike/comment/view/aiView/shareCount, postScore (cache), externalPostScore, createdAt, updatedAt`; blog thêm `isPublished`. Subcollection `comments`, `reactions`, `shares`, `views`. Client SDK đọc được để realtime |
| `weeklyLeaderboards/{mãTuần}` | top 10 người đã chốt (bất biến) |
| `hashtags`, `hashtagWeeklyLeaderboards`, `hashtagExploreSnapshots` | xu hướng hashtag |
| `userPrivate/{uid}` | tên thật |
| `profileVisitors/{uid chủ}` | `{visitors:[{uid,at}], updatedAt}` ≤ 50, mới nhất đầu (2.5.2) |
| `configAudit/{id}` | (2.5.3) nhật ký thay đổi cấu hình của SA: ai/lúc nào/diff; **append-only**, ghi cùng batch với thay đổi; SA đọc qua `GET /api/admin/config-audit` |
| `accountDeletions`, `registrationMarkers`, `activations`, `assets`, `debugRuns`, `config`, `countries` | hạ tầng; `config/*` (từ 2.5.3 **KHÔNG** đọc công khai — Client SDK bị chặn; chỉ backend) giữ phiên bản (`config/version`), trạng thái chốt tuần xu hướng, cấu hình domain nhúng và font… |

**Index** (`firestore.indexes.json`): posts/blogs theo `authorUid+postScore`, `authorUid+createdAt↓`, hashtag(`hashtags`/`hashtagsLower`)+`createdAt↓`; blogs thêm `isPublished+createdAt↓`, `isPublished+hashtags*+createdAt↓`, `isPublished+authorUid+createdAt↓`. **Truy vấn mới có `where` + `orderBy` khác trường ⇒ gần như chắc chắn cần index mới** — thêm vào file này và nhắc deploy.

**Rules** (`firestore.rules`; mọi `write` đều `false` — chỉ backend ghi): `countries` **đọc công khai**; **`config/*` và `positiveScoreLogs` khoá hẳn** (2.5.3: `config/*` từng đọc công khai và chứa uid của SA); `users/{uid}` đọc = chỉ chủ; `posts` (`get` công khai, `list` giới hạn 50), `blogs` (chỉ bài đã xuất bản hoặc chính tác giả), và `comments` của chúng đọc được để realtime; `assets`, `userPrivate`, `profileVisitors`, `configAudit`, `accountDeletions` và mọi collection khác (`{document=**}`) bị chặn hoàn toàn. Module Gỡ lỗi kiểm rules đã deploy thật chưa.

## 5. Quy ước bắt buộc (đã thành "luật" của dự án)

1. **Chú thích tiếng Việt dày, có số phiên bản và lý do** ở đầu mỗi thay đổi đáng kể (`v2.5.2 — …`). Giữ phong cách này; ghi cả **vì sao không làm cách khác**.
2. **Mỗi bản có**: `PATCH-N-NOTES.md`, mục mới ở đầu `backend/README.md`, cập nhật `SECURITY-STATUS.md` nếu đụng bảo mật, tăng version (mục 10), test mới, và **cập nhật `TWELVE-MAP.md`** nếu bản đó đổi kiến trúc/khái niệm/dữ liệu/quy ước/số test (đổi dòng "cập nhật ở …" ở tiêu đề).
3. **Hai phía phản chiếu nhau, có test đối chiếu**: huy hiệu, `profileExtras`+nhãn, hằng số bio, `profilePath`. Sửa một phía ⇒ sửa phía kia + test.
4. **Ẩn/hiện dữ liệu phải áp dụng ở BACKEND** (ẩn ở giao diện không phải bảo mật). Kiểm quyền bằng `accountGroup`; backend là lớp chặn thật, frontend chỉ ẩn nút.
5. Route có `:id`/`:uid` đi qua `router.param` (`middleware/idParams.js`) để id lạ (có `/`) không bao giờ tới Firestore. Route cố định (`/me/...`, `/by-tag/:tag`) **đặt trước** `/:uid`.
6. Thao tác ghi quan trọng: **transaction, đọc trước ghi sau**, kèm `assertActorActive` (không dựng lại dữ liệu cho tài khoản đã xoá). Lỗi phụ (cache, thành tích…) **không được làm hỏng** request chính.
7. Mọi endpoint ghi/đọc nặng có limiter riêng (`rateLimiters.js`). `authOrIpKeyGenerator` khoá `uid:<uid>` nếu có `req.authUid`, nếu không thì `ip:<getClientKey(req)>` (2.5.3 — xem điều 11) — nên limiter theo tài khoản **phải đặt SAU `requireAuth`/`optionalAuth`** trong route, đặt trước là mất khoá theo uid.
8. Frontend: màu lấy từ theme (không hardcode, hỗ trợ sáng/tối); `borderRadius: 1` = 16px (theme dùng 16px/đơn vị — `2` thành 32px quá tròn); hiển thị nội dung người dùng bằng **React text** (không `dangerouslySetInnerHTML` ngoài bài viết đã sanitize); không `style=""` inline trong EJS.
9. Mọi liên kết hồ sơ qua `profilePath`; mọi thao tác ghi (like/comment/đăng bài…) qua `useAuthGate`.
10. `key` trong cây Cài đặt/tab là một đoạn URL — **đừng đổi** (gãy liên kết đã lưu).
11. **IP client chỉ lấy qua `getClientKey(req)`** (`utils/clientIp.js`, 2.5.3) — **không đọc `req.ip`, `X-Forwarded-For` hay `CF-Connecting-IP` trực tiếp** ở nơi khác (có test quét mã nguồn). Backend nằm sau Cloudflare → Render: `req.ip` chỉ là IP edge; `CF-Connecting-IP` chỉ được tin khi hop kế cuối thuộc dải Cloudflare. `TRUST_PROXY_HOPS` mặc định 1 vì chưa đo topology thật — **đo rồi mới đổi**, đừng đoán — từ 2.5.3.2 đo bằng panel Cài đặt › Quản trị › **Nhận diện IP** (`GET /api/admin/ip-topology`, `describeIpTopology`) hoặc `DEBUG_IP_TOPOLOGY=on`; `TRUST_PROXY_MODE=cloudflare` (tuỳ chọn) tin theo dải IP thay vì số hop. Test nhận diện IP phải chạy trên **Express thật** (`test/security-2532.test.js`), không giả `req.ip`.
12. **Thao tác GHI cấu hình của SA** (domain nhúng, font, xoá báo cáo CSP…): `requireRecentAuth()` ở route + ghi `configAudit` **cùng batch** với thay đổi (`services/configAudit.js`); frontend dùng `useReauthRetry` để hỏi mật khẩu và gửi lại. Thêm route ghi cấu hình mới ⇒ làm đủ ba thứ này.
13. **Không thêm bí mật/định danh vào `config/*` hay collection mà Client SDK đọc được**; mặc định mọi collection mới đã bị chặn bởi `{document=**}`, chỉ mở khi frontend thật sự cần đọc.

## 6. API (tiền tố `/api`, trừ SSR/SEO)

`auth`: register, forgot-password, check-tagname, activation/{sync,send,verify}. `users`: `me` (GET/PATCH), `me/{avatar,cover,cover/crop,extras,visitors,real-name,tag-name,deletion}`, `by-tag/:tag`, `:uid`, `:uid/{posts,pinned,blogs,extra-info,visit}`. `posts` & `blogs` (cùng khuôn, `makeContentApi`): list, create, `:id` (get/patch/delete), `:id/{react,share,comments,comments/:commentId}`; posts thêm `:id/pin`; **blog create/patch/delete chỉ SA**. `trending`: users/{weekly,alltime}, hashtags/{weekly,alltime,:tag/posts}, search. `admin` (chỉ SA): embed-domains, csp-reports, fonts, assets/stats, ip-topology, config-audit, debug/modules. Khác: `countries`, `fonts`, `csp-report`, `version`, `/health`. Ngoài `/api`: SSR (`/post/:id`, `/blog/:id`, `/u/:ref`, `/__ssr/home`, `/__ssr/blog`), `robots.txt`, `sitemap.xml`. Bảng middleware/limiter từng route: đọc thẳng `routes/*.routes.js` (ngắn).

## 7. Frontend — các khuôn dùng lại

- **headZone / Smart Page Header**: trang gọi `useRegisterPageHeader({ title, back, actions:[{key,label,icon,onClick}] })` (`PageHeaderContext`); `Navbar` vẽ. Test thường kiểm danh sách `actions[].key`.
- **Cây tab** (`components/tabs/`): `useTabTree(TABS, {ctx})` đồng bộ với URL `?tab=`; mỗi tab `{key,label,icon,Component,visible(ctx)}`; tab không hiện thì URL rơi về mặc định. Thêm tab = thêm một dòng ở `profileTabs.jsx`.
- **Cây Cài đặt** (`pages/settings/registry.jsx` + `settingsTree.js`): tab `app` (giao diện, font), `account` (Thông tin, Bảo mật › Đổi mật khẩu/Xóa tài khoản; `requires:"user"`), `admin` (`requires:"sa"`). Panel luôn `React.lazy`; test `settingsTree.test.js` kiểm cây.
- **Nhận diện người dùng dùng chung**: `components/UserIdentity.jsx` (`UserAvatar`, `UserName` — kèm huy hiệu —, `UserTagChip`; nhận `onProfileClick`). Khối "info user" trong Navbar chỉ là markup riêng của menu.
- **Feed**: `usePaginatedFeed({api:{list(cursor,limit)}, listKey, isAuthReady})` + `FeedList` + `PostCardList`; `api` truyền `postsApi`/`blogsApi`, `detailPath`, `collectionName`.
- **Realtime**: `AuthContext` nghe `onSnapshot(users/{uid})` — hồ sơ trong `useAuth().profile` luôn tươi (kể cả `bio`, `profileExtras`); `getMe` bổ sung. (`RouteGuards.jsx` đã bị xoá ở 2.5.3 — không ai dùng; Cài đặt tự chặn theo `requires` ở `settingsTree.js`.)
- **Code splitting**: trang tải lười ở `App.jsx`; modal nặng (Quill, cropper) tải khi mở; `chunkReload.js` phục hồi khi deploy làm đổi tên chunk.

## 8. Chạy test & cạm bẫy môi trường

**Backend** — `cd backend && npm ci && npm test` (`node --test`, Firestore/Auth **giả**, không cần mạng). File test mới **phải được thêm vào script `"test"`** trong `package.json`. Hiện **312** test.
Giới hạn của Firestore giả (`src/debug/support/fakeFirebase.js`): `where` chỉ `==` và `array-contains`; `startAfter(snapshot)` được hỗ trợ từ 2.5.3 (kiểm được quét phân trang; khi không có `orderBy` thì sắp theo id tài liệu) — nhưng cursor kiểu `startAfter(giáTrị)` thì không; `select` no-op; `orderBy` so sánh bằng phép trừ (dùng số hoặc `Date`); transaction đọc ngay, ghi dồn; không hiểu đường dẫn có dấu chấm trong `update` (đọc–gộp–ghi thay vì `"a.b": …`). Có `getAll`, `batch`, `listCollections`, `recursiveDelete`, `FieldValue.increment/serverTimestamp`. Dựng app test: `install({tokens,authTimes})` rồi nạp route thật (mẫu: `test/profile-252.test.js`); đặt `FRONTEND_URL`, `SSR_PROXY_SECRET`; reset limiter (`resetKey`) giữa các ca.

**Frontend** — `package.json` **không có** vitest/jsdom/testing-library. Cài tạm: `npm ci && npm i -D --no-save vitest@^2 jsdom @testing-library/react@^16 @testing-library/dom && npx vitest run` (cấu hình `vitest.config.mjs`, môi trường jsdom). Hiện **403** test. Cạm bẫy: (a) `vi.mock("…/users.api", () => ({…}))` là **tường minh** — thêm hàm API mới thì mọi test render trang đó phải thêm vào mock (truy cập hàm thiếu sẽ ném lỗi); (b) jsdom không phân giải `gap` (kiểm trong CSS emotion), nhưng phân giải được `border*`, `display`, `white-space`; (c) một số test đọc thẳng file backend để đối chiếu (bỏ qua nếu không có thư mục `../backend`).
`npx vite build` để kiểm biên dịch (vite cảnh báo chunk > 500 kB ở bundle chính).

**Khi chạy lệnh trong sandbox**: đừng dùng `cut -c` trên văn bản tiếng Việt (cắt giữa ký tự → lỗi UTF-8); dùng Python để cắt.

## 9. Biến môi trường

**Backend**: `FIREBASE_SERVICE_ACCOUNT` (JSON) *hoặc* bộ `FIREBASE_PROJECT_ID/CLIENT_EMAIL/PRIVATE_KEY/DATABASE_URL`, `FIREBASE_WEB_API_KEY` (+`_REFERER`), `CLOUDINARY_*`, `CORS_ORIGIN` (bắt buộc ở production), `FRONTEND_URL`, `SSR_PROXY_SECRET`, `SHARE_LINK_SECRET` (bắt buộc ở production), `TURNSTILE_SECRET_KEY`, `TRENDING_EPOCH_DATE`, `SITEMAP_REFRESH_TOKEN`, `RESERVED_TAG_NAMES_EXTRA`, `SITE_LOGO_URL`, `SITE_OG_IMAGE_URL`, `DEBUG_PANEL_ENABLED`, `VIEW_SCORE_ONCE_PER_PAIR` (2.5.3: mặc định BẬT), `SHARE_REWARD_DAILY_CAP`, `SHARE_DEBUG`, `TRUST_PROXY_HOPS`, `CLIENT_IP_MODE`, `DEBUG_IP_TOPOLOGY`, `CLOUDFLARE_EXTRA_RANGES`, `TURNSTILE_TIMEOUT_MS`, `TURNSTILE_ALLOWED_HOSTNAMES`, `TURNSTILE_HOSTNAME_CHECK`, `PENDING_SWEEPER`, `PENDING_MAX_AGE_DAYS`, `PENDING_SWEEP_INTERVAL_MIN`, `PENDING_SWEEP_MAX_PER_RUN`, `SANITIZE_WORKER`, `FONTS_DIR`, `ACCOUNT_DELETION_CONCURRENCY`, `ACCOUNT_DELETION_VERIFY_DELAY_MS`, `BACKEND_VERSION`, `RENDER_INSTANCE_ID`, `PORT`, `NODE_ENV`.
**Frontend (Vite)**: `VITE_API_BASE_URL`, `VITE_FIREBASE_{API_KEY,AUTH_DOMAIN,PROJECT_ID,STORAGE_BUCKET,MESSAGING_SENDER_ID,APP_ID}`, `VITE_TURNSTILE_SITE_KEY`, `VITE_FIREBASE_APPCHECK_SITE_KEY` (+`_PROVIDER`, `_DEBUG_TOKEN`; tuỳ chọn, tắt khi trống — xem `PATCH-24-NOTES.md` TW-04 trước khi bật). **Vercel (middleware)**: `BACKEND_ORIGIN` (không có `/` cuối), `SSR_PROXY_SECRET` (cùng giá trị với Render).

## 10. Nâng phiên bản — chạm những file nào

Định dạng `MAJOR.MINOR.PATCH.ddmmyy` (vd `2.5.3.081126` = 08/11/2026). Sửa **cùng một chuỗi** ở: `backend/package.json`, `backend/package-lock.json` (2 chỗ), `frontend/package.json`, `frontend/package-lock.json` (2 chỗ), `frontend/public/version.json`. Tiêu đề `backend/README.md` (+ mục `-N` mới), `backend/.env.example` (`BACKEND_VERSION=`), `PATCH-N-NOTES.md`, dòng đầu `SECURITY-STATUS.md`, đầu `TWELVE-MAP.md`. Test `security-253d` ("TW-23") **fail nếu một nơi nào bị lệch**. `npm run seed:version` ghi `config/version = {backend}` lên Firestore (nhãn phiên bản backend hiện trong giao diện; mặc định lấy từ `package.json`).

## 11. Việc thường làm — lối đi nhanh

- **Thêm endpoint**: controller → route (limiter + `requireAuth/optionalAuth`, đặt **trước** `/:uid` nếu là `/me/...`) → validator nếu có body → test trong file `test/*.test.js` mới **và thêm vào script `npm test`** → frontend `api/*.api.js` (+ cập nhật mock ở test cũ).
- **Thêm tab Profile**: `components/profile/<Tab>.jsx` + một dòng ở `profileTabs.jsx` (`visible(ctx)` nếu có điều kiện; `ctx` do `PublicProfilePage` truyền) + cập nhật SSR (`ssr.routes.js`, `profile.ejs`, `seoMeta.js`) nếu nội dung nên có cho bot.
- **Thêm mục Cài đặt**: một nút ở `registry.jsx` (lazy) + panel; không tự vẽ tiêu đề.
- **Thêm huy hiệu**: `BADGE_ID` + `badgeIdsForUser` ở backend, khai báo hình/tên ở `frontend/utils/badges.js`, thêm ca vào hai bộ test đối chiếu.
- **Thêm mục "Thông tin mở rộng"**: khoá + mặc định + luật ở `backend/utils/profileExtras.js` (`EXTRA_KEYS`, `EXTRA_DEFAULTS`, `buildExtraFields`), nhãn ở `frontend/utils/profileExtras.js` (`EXTRA_FIELDS`); chỉ đưa vào `SSR_EXTRA_KEYS` nếu **không nhạy cảm**.
- **Trường mới trên hồ sơ công khai**: `toPublicProfile` (đầy đủ) hay `toPublicUser` (đi kèm mọi thẻ — chỉ khi thật cần)? Dữ liệu nhạy cảm đừng đưa vào cả hai.
- **Thêm dữ liệu theo uid**: thêm bước dọn ở `accountDeletion.js` (`stepResidual` + `stepVerify`), cân nhắc rules tường minh (`firestore.rules`) và module Gỡ lỗi nếu là dữ liệu riêng.
- **Điều cần nhớ khi báo cáo cho chủ dự án**: nêu rõ số test (backend/frontend), file nào đổi, test cũ nào phải sửa **và vì sao**, việc cần deploy (rules/index), và các quyết định cần họ chốt.
