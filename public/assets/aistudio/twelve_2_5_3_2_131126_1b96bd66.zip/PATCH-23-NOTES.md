# PATCH 23 — v2.5.2.031126: Hoàn thiện trang Profile

Backend + frontend. Test: backend **240/240** (206 → +34), frontend **368/368** (317 → +51), `vite build` sạch.
Thêm 5 endpoint, 3 trường/collection dữ liệu mới. **Không cần index Firestore mới** (blog theo tác giả dùng lại index `blogs(isPublished, authorUid, createdAt ↓)` của 2.5.0). Không đổi biến môi trường, `middleware.js`, `vercel.json`.

## 0. Tóm tắt 6 hạng mục

| # | Yêu cầu | Làm ở đâu | Kết quả |
|---|---|---|---|
| 1 | Tab **Blog** trên Profile (tài khoản SA) | `profileTabs.jsx`, `ProfileBlogTab.jsx`, `GET /users/:uid/blogs` | Tab hiện khi **chủ hồ sơ** là SA; liệt kê Blog đã xuất bản, cùng khuôn với tab Bài viết |
| 2 | **Tiểu sử (Bio)** ở Profile + sửa trong Cài đặt | `ProfileHeader.jsx`, `AccountInfoPanel.jsx`, `BioField`, `cleanBio` | Hiện dưới tên/tag; sửa trong *Cài đặt › Tài khoản › Thông tin* |
| 3 | **Khách ghé thăm** | headZone, `ProfileVisitorsDialog.jsx`, `services/profileVisitors.js` | 50 người gần nhất, không trùng, mới nhất trên cùng; chỉ chủ hồ sơ xem |
| 4 | Mục **"Xem thêm"** + **Thông tin mở rộng** | `ProfileMoreDialog.jsx`, `ProfileExtrasCard.jsx`, `utils/profileExtras.js` (2 phía), `services/achievements.js` | 9 công tắc; hộp hiện trường hồ sơ + thành tích từ bảng chốt tuần của Xu hướng |
| 5 | Sửa hộp **Sao chép URL Profile** không có viền/màu | `CopyProfileUrlDialog.jsx` | Hai lựa chọn là hai **thẻ** có nền + viền + khoảng cách |
| 6 | Cập nhật **SSR** của Profile | `ssr.routes.js`, `profile.ejs`, `seoMeta.js` | Bio, Blog của SA, thông tin mở rộng (tập an toàn), meta/JSON-LD |

---

## 1. Tab Blog (SA)

- **Điều kiện hiện tab** là bậc của **chủ hồ sơ đang xem** (`user.accountGroup === "SA"`, truyền qua `ctx.isSA`), không phải của người xem và không phải `isOwn`. Lý do: chỉ SA đăng được Blog (`requireSA`), nên tab chỉ có ý nghĩa với hồ sơ SA.
- `?tab=blog` trên hồ sơ không phải SA tự rơi về tab mặc định (cơ chế sẵn có của `useTabTree`), không lỗi, không gọi API.
- `GET /api/users/:uid/blogs?cursor&limit` (`optionalAuth`, `userPostsLimiter`): chỉ blog **đã xuất bản** của **chính người đó**, mới nhất trước, đúng dạng thẻ như `GET /api/blogs` (kèm `myReaction` của người xem). **Bản nháp không bao giờ có ở đây, kể cả khi người xem là chính tác giả.** Cursor phải là blog đã xuất bản của chính người đó — id lạ bị bỏ qua (không dùng để dò bản nháp).
- Backend **không** tự lọc theo bậc: ai từng đăng Blog thì bài vẫn liệt kê được (ví dụ SA bị hạ bậc rồi thì tab ẩn nhưng API vẫn trả đúng). Việc ẩn/hiện tab là của frontend.
- Tái dùng `buildProfileCards` (thêm tham số `collection`); thẻ blog **không có** `isPinned`.

## 2. Tiểu sử (Bio)

- Lưu ở `users/{uid}.bio` (chuỗi). Giới hạn **300 ký tự** (đếm theo code point) và **6 dòng** (`PROFILE.BIO_MAX`, `BIO_MAX_LINES`). Đổi ở một chỗ.
- **Văn bản thuần**: không HTML, không liên kết hoạt động. Hiển thị bằng React text + `white-space: pre-wrap`; SSR thoát bằng EJS `<%= %>`. Test chứng minh `<img onerror>`/`<script>` chỉ hiện thành chữ.
- `cleanBio` (backend, `utils/input.js`): NFC, chuẩn hoá xuống dòng, bỏ ký tự bidi/vô hình **nhưng giữ ZWJ** để emoji ghép không vỡ, gộp khoảng trắng và dòng trống liên tiếp. Chuỗi rỗng hợp lệ (= xoá).
- Lưu qua `PATCH /users/me` (`bio` thêm vào `allowedFields` + `bioField()` validator). Frontend đếm trực tiếp, báo đỏ và **khoá nút Lưu** khi quá giới hạn (`utils/bio.js`, khớp backend — có test kiểm hằng số).
- `bio` chỉ có trong `toPublicProfile` (hồ sơ đầy đủ), **không** nằm trong `toPublicUser` (thứ gắn vào `author` của mỗi thẻ bài/bình luận) để khỏi tốn băng thông.

## 3. Khách ghé thăm

**Lưu trữ**: một document `profileVisitors/{uid chủ hồ sơ}` = `{ visitors: [{ uid, at }], updatedAt }`, mới nhất đứng đầu, tối đa **50**. Ghi trong **transaction**: bỏ dòng cũ của cùng người rồi đưa lên đầu → **không trùng**. Chỉ lưu `uid` + thời điểm; tên/tag/huy hiệu/avatar đọc **tươi** từ hồ sơ khi xem (đổi tên thì danh sách đổi theo; không nhân bản dữ liệu cá nhân).

**Ghi nhận**: `POST /api/users/:uid/visit` (`requireAuth`, `visitRecordLimiter` 120/15 phút/tài khoản).
- Frontend gọi **một lần** khi người **đã đăng nhập** mở hồ sơ **người khác** (phụ thuộc `user.uid`, nên việc trang tự thay URL sang dạng chuẩn không báo lần hai). Lỗi nuốt im.
- Cố ý là POST riêng, không gộp vào GET hồ sơ: GET không có tác dụng phụ; bot/SSR/xem trước link không để lại dấu; khách ẩn danh không ghi được.
- Chống ghi dồn: người đang đứng đầu mà vào lại trong **5 phút** (`VISIT_REFRESH_MS`) thì không ghi lại.
- Chủ hồ sơ đã xoá/đang xoá/pending/"ma" → **không dựng lại** document (cùng nguyên tắc `assertActorActive`).

**Xem**: `GET /api/users/me/visitors` (`requireAuth`) — uid lấy từ **token**, không nhận từ client; **không có** `/:uid/visitors`. Trả `{ visitors: [{...toPublicUser, visitedAt}], max: 50 }`, `Cache-Control: no-store`. Khách đã xoá tài khoản/hồ sơ ma/pending bị lọc khi đọc; khách `suspended` vẫn hiện.

**Giao diện**: nút **"Khách ghé thăm"** ở headZone, chỉ chủ hồ sơ, đứng giữa "Chỉnh sửa hồ sơ" và "Sao chép URL Profile". Hộp dùng **module nhận diện người dùng dùng chung** `components/UserIdentity.jsx` (`UserAvatar` + `UserName` — đã kèm huy hiệu — + `UserTagChip`, cùng bộ với thẻ bài/bình luận) rồi thời gian. Bạn nhớ đúng: module đó chính là `UserIdentity.jsx`; khối "info user" trong Navbar chỉ là markup riêng của menu, không phải module dùng lại được. Bấm tên/avatar/tag → đóng hộp rồi sang hồ sơ khách.

**Dọn dẹp**: xoá tài khoản xoá luôn `profileVisitors/{uid}` (bước `residual`, và `verify` kiểm lại). `firestore.rules` có khối `profileVisitors` **chặn hoàn toàn** Client SDK (dữ liệu về hành vi người khác — không để phụ thuộc vào "quên thêm rule"); module Gỡ lỗi *rules-private-collections* kiểm thêm collection này.

## 4. "Xem thêm" và Thông tin mở rộng

### 4.1 Công tắc (Cài đặt › Tài khoản › Thông tin › "Thông tin mở rộng")
9 mục: Tên hiển thị, Nhóm tài khoản, Vai trò tài khoản, Ngày sinh, Ngày tham gia, Giới tính, Trạng thái tài khoản, UID, Thành tích. Cờ lưu ở `users/{uid}.profileExtras` (`{ khoá: boolean }`); khoá vắng = mặc định.

- **Công tắc áp dụng ngay, không có nút Lưu.** Với dữ liệu riêng tư, "tắt rồi quên bấm Lưu" nghĩa là vẫn đang công khai. Mỗi lần gửi **riêng khoá vừa đổi** (`PUT /users/me/extras`, đọc–gộp–ghi trong transaction nên hai lần bật/tắt sát nhau không ghi đè nhau). Công tắc đổi ngay, bị khoá trong lúc gửi, **quay lại** kèm thông báo nếu máy chủ từ chối. Có giữ giá trị vừa đặt cho tới khi hồ sơ realtime theo kịp (không nhảy lại trạng thái cũ).
- Công tắc có tên truy cập "Hiện … trong hộp Xem thêm" để không trùng tên với ô nhập cùng nhãn.

### 4.2 Ẩn/hiện được áp dụng ở BACKEND
`GET /api/users/:uid/extra-info` chỉ trả mục chủ đang **bật**; mục tắt **không rời máy chủ**. (Ẩn ở giao diện thì ai mở DevTools vẫn thấy ngày sinh.) `Cache-Control: no-store` nên tắt là có hiệu lực ngay. Hộp "Xem thêm" tải **khi mở** (không nằm trong GET hồ sơ) vì phần thành tích cần đọc bảng xếp hạng tuần.

### 4.3 Mặc định
| BẬT (vốn đã công khai ở nơi khác) | TẮT (trước giờ riêng tư / chủ đích không lộ) |
|---|---|
| Tên hiển thị, Nhóm, Vai trò, Ngày tham gia, Thành tích | **Ngày sinh, Giới tính, Trạng thái, UID** |

Chọn để nâng cấp lên 2.5.2 **không làm lộ thêm gì**: ngày sinh/giới tính trước nay không bao giờ ra endpoint công khai; UID bị bỏ khỏi URL từ 2.4.2.1. Hộp "Xem thêm" của người chưa chỉnh gì vẫn không rỗng.

> **Ranh giới cần hiểu đúng** (UI cũng nói rõ): chỉ 4 mục **riêng tư** là *thật sự* được bảo vệ bởi công tắc. Tên hiển thị, nhóm/vai trò (huy hiệu), UID, ngày tham gia vốn đã nằm trong `author` của mọi thẻ bài/bình luận (`toPublicUser`), nên tắt chúng chỉ ẩn khỏi hộp "Xem thêm".

### 4.4 Thành tích
Nguồn: **`weeklyLeaderboards/{mãTuần}`** — top 10 người tăng điểm tài khoản mạnh nhất mỗi tuần, do Xu hướng chốt một lần và **không bao giờ ghi đè**. `services/achievements.js` quét collection (≈ 1 doc/tuần), dựng chỉ mục uid → các tuần, **cache 5 phút** (single-flight, không cache lỗi). Hộp hiện: điểm tài khoản, số lần vào top 10 (trên tổng số tuần đã chốt), số lần top 3 / hạng 1, hạng cao nhất, 10 tuần gần nhất.
- Tuần mới chốt xuất hiện ở hồ sơ sau tối đa 5 phút.
- Bảng **Hashtag** của Xu hướng (`hashtagWeeklyLeaderboards`, `hashtagExploreSnapshots`) là thành tích của *hashtag*, không gắn với người dùng nên **không dùng**.
- Điểm tài khoản (`accountScore`) vốn công khai ở bảng xếp hạng. `postsScoreSum`/`positiveScore` chỉ chủ xem nên **không** đưa vào.

## 5. Sửa hộp "Sao chép URL Profile"
Hai `ListItemButton` trước đây phẳng (không nền, không viền, dính liền) nên nhìn như chữ thường. Nay là **thẻ**: `bgcolor: action.hover`, `border: 1px solid divider`, `gap` giữa hai thẻ, rê chuột/focus bàn phím → nền `action.selected` + viền `primary.light` (cùng kiểu thẻ của Menu trong Navbar). Màu lấy từ theme nên đúng cả sáng/tối; thẻ bị vô hiệu vẫn có viền, chỉ mờ đi. Dùng `borderRadius: 1` (= 16px của theme; `2` sẽ thành 32px quá tròn như ghi chú 2.4.0).

## 6. SSR của Profile (`/u/:ref`)
- **Tiểu sử** trong thân trang (đã thoát HTML), đầu mô tả meta (`Hồ sơ An (@tag) trên Twelve. <bio> …`) và `Person.description` (JSON-LD).
- **Mục "Bài Blog"** + `ItemList` riêng cho tài khoản **SA** (blog đã xuất bản). Hồ sơ chỉ có blog (chưa có bài thường) giờ cũng được `index`. Tài khoản `suspended`: không liệt kê bài/blog (như cũ).
- **Thông tin mở rộng** chỉ in tập **không nhạy cảm** (`SSR_EXTRA_KEYS`: tên, nhóm, vai trò, ngày tham gia) cộng thành tích nếu chủ bật. **Ngày sinh/giới tính/trạng thái/UID KHÔNG BAO GIỜ lên SSR dù đã bật**: trang SSR được CDN giữ tới ~40 phút (`s-maxage` + `stale-while-revalidate`) và công cụ tìm kiếm lưu bản chụp còn lâu hơn — chủ vừa tắt mà bản SSR vẫn lộ thì phản tác dụng; các mục này cũng không có giá trị SEO. Có test "chốt chặn" cho điều này.
- "Tham gia từ" và `dateCreated` theo công tắc ngày tham gia. Lỗi đọc thành tích không làm hỏng trang (log rồi bỏ phần đó).
- Markup "Tham gia từ …" giữ nguyên như 2.5.0 (test cũ vẫn đúng).

---

## 7. API mới

| Method | Đường dẫn | Auth | Limiter | Ghi chú |
|---|---|---|---|---|
| GET | `/api/users/:uid/blogs` | tuỳ chọn | `userPostsLimiter` | Blog đã xuất bản của người này |
| GET | `/api/users/:uid/extra-info` | không | `profileReadLimiter` | `{ fields, achievements }`, chỉ mục chủ bật, `no-store` |
| PUT | `/api/users/me/extras` | bắt buộc | `profileExtrasWriteLimiter` (60/15p) | `{ extras: { khoá: boolean } }` |
| POST | `/api/users/:uid/visit` | bắt buộc | `visitRecordLimiter` (120/15p) | Ghi lượt ghé; tự xem mình = bỏ qua |
| GET | `/api/users/me/visitors` | bắt buộc | `profileReadLimiter` | Khách của **chính mình** |
| PATCH | `/api/users/me` | bắt buộc | (sẵn có) | nhận thêm `bio` |

Tag Name trùng tên đường dẫn con mới (`blogs`, `extra_info`, `visitors`…) vẫn tra đúng qua `/by-tag/:tag` (có test).

## 8. Điều bạn nên biết / cần quyết

1. **Quyền riêng tư của người ghé thăm.** Tính năng ghi lại *ai đã xem hồ sơ ai*, và người ghé không được báo gì; nhiều mạng xã hội có tính năng tương tự thường cho phép người dùng tắt việc để lại dấu. Hộp của chủ hồ sơ có nói "chỉ ghi nhận người đã đăng nhập", nhưng **phía người ghé thì không có thông báo hay công tắc từ chối**. Cân nhắc một công tắc "Không để lại dấu khi ghé thăm" ở Cài đặt (điểm ghi nhận nằm gọn ở một hàm, `profileVisitors.recordVisit`, nên thêm điều kiện bỏ qua khá dễ), và/hoặc dòng nêu trong Điều khoản/Chính sách. Mình không tự thêm vì đây là quyết định sản phẩm/pháp lý của bạn.
2. **Công tắc "Trạng thái tài khoản"**: một tài khoản `suspended` có thể giữ công tắc tắt để không lộ việc bị khoá ở hộp "Xem thêm". Trạng thái vẫn công khai ở nơi khác theo cách cũ (hồ sơ `suspended` vẫn xem được, SSR `noindex`). Nếu bạn muốn *bắt buộc* hiện khi bị khoá, đổi một dòng ở `buildExtraFields`.
3. **Ngày sinh** hiện đủ `DD/MM/YYYY` khi chủ bật. Nếu muốn chỉ hiện ngày/tháng (không lộ năm sinh — dữ liệu hay bị dùng để xác minh danh tính), báo mình.
4. Thành tích trễ tối đa 5 phút (cache); chỉ có **top 10 tuần**. Thành tích hashtag không gắn người dùng nên không có.
5. Khách ghé thăm ghi trong **một document**: các lượt ghé *cùng lúc* vào một hồ sơ được tuần tự hoá (Firestore ~1 ghi/giây/doc). Ở quy mô hiện tại dư sức (có thêm lớp bỏ qua lượt lặp 5 phút). Nếu có hồ sơ "viral", chuyển sang mô hình mỗi khách một document là việc hậu kiểm nhỏ, giao diện không đổi.
6. Danh sách khách của người khác có thể còn `uid` của tài khoản đã xoá — chỉ là một mã, **bị lọc khi đọc**, tự rơi ra sau 50 lượt mới; không cần quét dọn.

## 9. Test

- **Backend** `test/profile-252.test.js` (34 ca): `cleanBio`; bio lưu/giới hạn/chống HTML; cờ mặc định + giá trị hỏng; `PUT /me/extras` (xác thực, khoá lạ, gộp từng phần, tài khoản không active); `extra-info` (mục tắt không xuất hiện trong JSON, dữ liệu sai bị bỏ); thành tích (tổng hợp, sắp tuần theo **số**, cache, dữ liệu hỏng); khách ghé (không trùng, mới nhất đầu, cap 50, chống ghi lặp, chủ không còn không dựng lại doc, lọc khách đã xoá, **chỉ chủ xem**); xoá tài khoản dọn doc; `/:uid/blogs`; SSR (bio thoát HTML, blog SA, tập khoá không nhạy cảm, công tắc, thành tích, lỗi phần phụ); rules + module Gỡ lỗi.
- **Frontend** `profile252.test.jsx` (35) + `profileSettings252.test.jsx` (16): bảng mở rộng **khớp backend** (khoá, mặc định, nhãn, hằng số Bio — đọc thẳng file backend nếu có); tab Blog theo bậc chủ hồ sơ; Bio như văn bản; hộp Xem thêm (thứ tự, thành tích, rỗng, lỗi); ghi lượt ghé (một lần, kể cả khi đổi URL; không khi là mình/chưa đăng nhập; im lặng khi lỗi); hộp Khách ghé thăm; hộp Sao chép URL có viền; công tắc áp dụng ngay/hoàn lại khi lỗi; Bio trong form.
- Đã chạy **đột biến** để chắc test bắt được lỗi: bỏ viền thẻ → đỏ; tab Blog hiện cho mọi hồ sơ → đỏ; ghi lượt ghé cả hồ sơ của mình → đỏ; backend không áp dụng công tắc → đỏ; không lọc khách trùng → đỏ; công tắc không hoàn lại khi lỗi → đỏ.
- **Test cũ được cập nhật theo thay đổi chủ ý** (không phải để né lỗi): `debug-230` (6 → 7 mục kiểm vì thêm `profileVisitors`); `profile240`/`profileUrl2421`/`profileCopyUrl2422` (mock thêm `recordProfileVisit`; danh sách action headZone của chủ hồ sơ thêm `profile-visitors`; cây tab thêm `blog`).

## 10. Triển khai

1. `firebase deploy --only firestore:rules` (thêm khối `profileVisitors`; trước đó collection vẫn bị rule chung `{document=**}` chặn nên **không khẩn cấp**, chỉ để rule khai báo tường minh). **Không cần** deploy index.
2. Deploy backend → frontend (như thường lệ).
3. Kiểm tay sau deploy: mở hồ sơ một tài khoản SA → thấy tab **Blog**; bấm **Xem thêm**; vào *Cài đặt › Thông tin* thử Bio và công tắc; dùng tài khoản khác ghé hồ sơ của bạn rồi mở **Khách ghé thăm**; `curl -s -A "Googlebot/2.1" https://<miền>/u/@<tag>` thấy Bio và mục Blog.

## 11. File

**Backend (sửa):** `controllers/users.controller.js`, `routes/users.routes.js`, `routes/ssr.routes.js`, `middleware/validators.js`, `middleware/rateLimiters.js`, `services/accountDeletion.js`, `utils/{constants,helpers,input,profilePosts,seoMeta}.js`, `views/{profile.ejs,partials/style.ejs}`, `debug/modules/rules-private-collections.js`, `firestore.rules`, `test/debug-230.test.js`.
**Backend (mới):** `services/achievements.js`, `services/profileVisitors.js`, `utils/profileExtras.js`, `test/profile-252.test.js`.
**Frontend (sửa):** `api/users.api.js`, `components/ProfileFields.jsx`, `components/profile/{CopyProfileUrlDialog,ProfileHeader,profileTabs}.jsx`, `pages/PublicProfilePage.jsx`, `pages/settings/AccountInfoPanel.jsx`, `tests/{profile240,profileUrl2421,profileCopyUrl2422}.test.jsx`.
**Frontend (mới):** `components/profile/{ProfileBlogTab,ProfileMoreDialog,ProfileVisitorsDialog}.jsx`, `pages/settings/ProfileExtrasCard.jsx`, `utils/{bio,profileExtras}.js`, `tests/{profile252,profileSettings252}.test.jsx`.
**Tài liệu mới:** `TWELVE-MAP.md` (bản đồ mã nguồn toàn dự án: kiến trúc, khái niệm lõi, dữ liệu Firestore, quy ước, cách chạy test và cạm bẫy, checklist việc thường làm — đọc trước khi đọc mã).
**Phiên bản `2.5.2.031126`:** `package.json` ×2, `package-lock.json` ×2, `frontend/public/version.json`; tài liệu: `backend/README.md` (mục -31), `SECURITY-STATUS.md` (dòng đầu + mục 3).
