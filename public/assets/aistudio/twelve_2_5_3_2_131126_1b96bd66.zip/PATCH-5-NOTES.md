# v2.0.8 — Hoàn thiện Font chữ: #1.1 font server + #2 font tuỳ chỉnh qua URL

Xây trên v2.0.7. Version: `2.0.8.051026` (version.json, 2 package.json).
Giả định của mình: "phần còn lại" = hai nhóm font chưa làm ở v2.0.7. Nếu bạn muốn nói tới việc khác (vd. CSP `vercel.json`, tái cấu trúc frontend) hãy báo.

## Cấu trúc font sau v2.0.8
| Nhóm | Nguồn | Ai quản lý | Lưu ở đâu |
|---|---|---|---|
| #1.2 Client | hard-code trong `theme/fonts.js` | dev | mã nguồn |
| **#1.1 Server** | link https **hoặc** file trong `backend/fonts/` | **SA** (Cài đặt > Quản trị > Font chữ trên server) | Firestore `config/fonts` |
| **#2 Tuỳ chỉnh** | URL https người dùng nhập (tối đa 5) | từng người dùng | `localStorage` thiết bị đó |

## Backend (#1.1)
- `GET /api/fonts` (công khai, cache RAM 60 giây): danh sách font đã lọc, không lộ field nội bộ.
- `GET /api/fonts/files/:name` (công khai): CHỈ phục vụ file nằm trong `backend/fonts/` **và** đã được SA thêm vào danh sách; whitelist tên file + đuôi, chặn path traversal; header CORS `*`, `Cross-Origin-Resource-Policy: cross-origin`, `nosniff`, cache 1 ngày.
- `GET/PUT /api/admin/fonts` (SA): kiểm tra chặt — https, không user:pass, không localhost/IP, từ chối link CSS (Google Fonts), đuôi chỉ woff2/woff/ttf/otf, tối đa 20 font, chống trùng, độ đậm `400` hoặc `100 900`. File phải thật sự có trên server lúc lưu.
- File bị xoá khỏi server => tự ẩn khỏi người dùng, admin thấy cảnh báo.
- Thư mục `backend/fonts/` + README. Biến tuỳ chọn `FONTS_DIR`.

## Frontend
- `theme/fonts.js`: dựng font từ nguồn ngoài, kiểm tra URL người dùng, cache font server trong `localStorage` (font đang chọn dùng được ngay từ khung hình đầu, không chờ mạng), `verifyFontLoads` (thử tải thật trước khi lưu).
- **Lỗi mạng không làm mất font đang chọn**; chỉ khi API trả thành công mà thiếu font thì mới về mặc định (và nếu SA thêm lại thì tự dùng lại).
- Cài đặt > Ứng dụng > Font chữ: 3 nhóm, xem trước bằng chính font, nút xoá cho font tuỳ chỉnh, form "Thêm font từ URL" (thêm xong dùng luôn, báo lỗi tiếng Việt rõ nguyên nhân/CORS).
- Quản trị: panel "Font chữ trên server" (thêm từ link / từ file có sẵn, sửa tên/độ đậm, xoá, lưu).
- `vercel.json`: CSP `font-src 'self' https: data:` (CSP đang là Report-Only nên không chặn; khi chuyển sang enforce phải giữ `https:` vì URL font do SA/người dùng nhập).

## Kiểm thử
Backend 42/42 (5 ca mới: URL xấu, file xấu/traversal, luồng PUT→GET→phục vụ file, chỉ file đã thêm được phục vụ, file mất). Frontend 41/41 (26 ca mới: validate URL, server/cache/lỗi mạng/font bị gỡ, thêm/xoá/lỗi tải font tuỳ chỉnh, localStorage bị sửa, UI). `vite build` OK. **Chưa thử trên trình duyệt thật/Firestore thật.**

## Triển khai
1. Deploy backend rồi frontend. Không cần index mới, không đổi rules (collection `config` chỉ backend đọc/ghi).
2. (Tuỳ chọn) đặt file font vào `backend/fonts/`, commit, deploy; vào Quản trị chọn "Thêm từ file".
3. Kiểm tra: `curl -s https://<backend>/api/fonts` → `{"fonts":[]}`; sau khi SA thêm font file: `curl -sI https://<backend>/api/fonts/files/<tên>` → `200`, `content-type: font/woff2`, `access-control-allow-origin: *`.

## Lưu ý / quyết định cần bạn xác nhận
- Font tuỳ chỉnh (#2) chỉ lưu trên thiết bị; không đồng bộ qua tài khoản (cần thêm field hồ sơ + validate phía server — chưa làm).
- URL font do người dùng nhập khiến trình duyệt của CHÍNH họ gọi tới máy chủ đó (lộ IP cho máy chủ đó) — chấp nhận được vì tự nguyện, nhưng nên nói rõ nếu bạn muốn.
- Render có hệ thống file tạm: file font chỉ tồn tại khi nằm trong repo deploy. Upload font qua giao diện (không cần deploy) chưa có; nếu muốn, bản sau có thể lưu vào Cloudinary/Storage.
- Link CDN của bên thứ ba có thể chết hoặc đổi nội dung; với font quan trọng nên dùng "file trên server".
- Font không hỗ trợ đủ tiếng Việt sẽ rơi về font mặc định ở ký tự thiếu (không báo lỗi). Chưa có kiểm tra tự động độ phủ glyph.
