# PATCH 24 — v2.5.3.081126: Vá theo "Báo cáo bảo mật tổng hợp cuối v2.5.2" (TW-01 … TW-27)

Backend + frontend. Test: backend **312** (240 → +72), frontend **385** (368 → +17), `vite build` sạch.
**Không cần index Firestore mới.** Có thay đổi `firestore.rules` (deploy **sau cùng**), `vercel.json` (CSP), nhiều biến môi trường mới (đều có mặc định an toàn) và **vài mặc định đổi chiều có chủ đích** — đọc mục 2 trước khi deploy.

Nguyên tắc làm bản này: (1) báo cáo gắn nhãn `[M]` (đọc mã) / `[B1]`,`[B2]` (bên khác đã kiểm) — chỗ nào mình không đo được trên hệ thống thật (topology IP, hành vi Vercel) thì **không đoán**: làm cơ chế đo + mặc định không tệ hơn 2.5.2; (2) mọi thay đổi hành vi có công tắc quay lại; (3) mỗi bản vá có test, và test mới chạy lại trên mã 2.5.2 phải **đỏ** (đã chạy đột biến — mục 8).

## 0. Tóm tắt 27 phát hiện

| ID | Mức | Kết quả | Làm gì / ở đâu |
|---|---|---|---|
| **TW-01** | 🟠 High | ✅ Vá (cần **đo** 1 lần để chốt số hop) | `utils/clientIp.js` viết lại: một hàm duy nhất `getClientKey(req)`; đọc `CF-Connecting-IP` **chỉ khi** hop kế cuối thuộc dải Cloudflare; `TRUST_PROXY_HOPS`; IPv6 gộp /64; `DEBUG_IP_TOPOLOGY` để đo. Limiter (`rateLimiters.js`) và khoá khách ẩn danh (`helpers.js` `viewerKey`) dùng chung hàm này |
| **TW-02** | 🟡 Med | ✅ Vá một nửa có chủ đích | `vercel.json`: header **chặn thật** nay có `script-src 'self' https://challenges.cloudflare.com` + `script-src-attr 'none'`; chính sách đầy đủ vẫn Report-Only nhưng đã thu hẹp `img-src`/`frame-src` về danh sách thật; `npm run csp:sources` in nguồn từ allowlist domain nhúng. Enforce nốt `img-src`/`frame-src` là bước sau (mục 9) |
| **TW-03** | 🟡 Med | ✅ Vá — **đổi mặc định** | `VIEW_SCORE_ONCE_PER_PAIR` nay **mặc định BẬT** (đặt `off` để về cũ); thưởng share có trần **25 lần/ngày/người chia sẻ** (`SHARE_REWARD_DAILY_CAP`) |
| **TW-04** | 🟡 Med* | 🟡 Có sẵn, **tắt** | `src/firebase.js`: App Check tuỳ chọn (`VITE_FIREBASE_APPCHECK_*`), tree-shaking khi để trống. Bật theo thứ tự bắt buộc ở mục 9 |
| **TW-05** | 🟡 Med (vận hành) | 🔧 Công cụ + checklist | `npm run sessions:revoke` / `:apply` (mặc định dry-run). **Việc đổi mật khẩu/xoay khoá là của bạn** — mục 9 |
| TW-06 | 🔵 Low | ✅ Vá | `sanitize.service.js`: `class` theo allowlist (`ql-*` hợp lệ), `data-*`/`aria-*` bị tắt (trừ `data-list` ép về giá trị hợp lệ); `resanitizeContent.js` **mặc định dry-run** |
| TW-07 | 🔵 Low | ✅ Vá | `firestore.rules`: `config/*` khóa hẳn (frontend không đọc, backend dùng Admin SDK) — hết lộ UID của SA qua REST |
| TW-08 | 🔵 Low | ✅ Vá — **đổi mặc định** | `services/pendingCleanup.js`: sweeper nền, **mặc định BẬT**, hạn **7 ngày** (cũ: 14, chỉ chạy tay); trần mỗi lượt, công tắc khẩn `PENDING_SWEEPER=off` |
| TW-09 | 🔵 Low | ✅ Vá | 3 route ghi của SA (`PUT /admin/embed-domains`, `PUT /admin/fonts`, `DELETE /admin/csp-reports`) đòi nhập lại mật khẩu (`403 REAUTH_REQUIRED`) + nhật ký append-only `configAudit` + `GET /api/admin/config-audit` |
| TW-10 | 🔵 Low | ✅ Vá | `middleware/captcha.js`: timeout (mặc định 5 s), kiểm `hostname` của widget (tự suy từ `CORS_ORIGIN`+`FRONTEND_URL` ở production; đặt `TURNSTILE_ALLOWED_HOSTNAMES` thì kiểm ở mọi môi trường; mục viết kiểu URL/có cổng được chuẩn hoá) |
| TW-11 | 🔵 Low | ✅ Vá | `debugLog.js` chỉ ghi khi DEV + che bí mật; getter ở `AuthContext` chỉ DEV và trả bản chiếu, không phải đối tượng `User` |
| TW-12 | 🔵 Low | ⏸ **Chờ bạn quyết** | Công tắc "không để lại dấu khi ghé thăm" là quyết định sản phẩm/pháp lý (đã nêu ở PATCH-23 mục 8). **Không tự thêm** |
| TW-13 | 🔵 Low | ✅ Vá | `firestore.rules`: `positiveScoreLogs` khóa hẳn (log "share" chứa UID người mở link; frontend không đọc) |
| TW-14 | 🔵 Low | ✅ Vá | `utils/authors.js`, `comments.controller.js`: lọc `authorUid` null/không hợp lệ (`isSafeDocId`), không còn `.doc(null)` → 500; `seo.controller.js` cùng bộ lọc |
| TW-15 | 🔵 Low | ⏸ Ghi nhận | Express 4 giữ nguyên; lưới an toàn A-01 (try/catch + `unhandledRejection`) còn nguyên. Chuyển Express 5 là đợt riêng |
| TW-16 | 🔵 Low | ⏸ **Chờ bạn quyết** | Đăng ký báo "email đã tồn tại": đổi sang trả lời trung tính làm hỏng UX đăng ký. Chính sách của bạn (mục 9) |
| TW-17 | ⚪ Info | ✅ Xoá | `requireOwnerCapable` (không ai gọi) bị xoá; `middleware/roles.js` chỉ còn `requireGroup`, `requireSA` |
| TW-18 | ⚪ Info | ✅ Xoá | `RouteGuards.jsx` (không ai import) bị xoá |
| TW-19 | ⚪ Info | ✅ Vá | `quillSafeClipboard.js`: `style` khi dán đi qua `sanitizeStyleForPaste` thay vì giữ nguyên văn |
| TW-20 | ⚪ Info | ✅ Vá | SSR đọc bài/blog: "dây vấp" (`ssrTripwireHit`, kiểm cả dạng thô, dạng đã giải mã thực thể và dạng đã bỏ TAB/LF) — HTML sạch không tốn gì, HTML có dấu hiệu nguy hiểm được **sanitize lần hai** trước khi in; lỗi ⇒ in rỗng (đóng an toàn) |
| TW-21 | ⚪ Info | 🔧 Vận hành | Đặt `DEBUG_PANEL_ENABLED=off` khi không dùng module Gỡ lỗi (mã không đổi) |
| TW-22 | ⚪ Info | ✅ Một phần | Bỏ `credentials:true` và `express.urlencoded`. **`GET /` vẫn liệt kê endpoint admin** (có chủ đích "AI agent discovery") — chờ bạn quyết |
| TW-23 | ⚪ Info | ✅ Vá | Avatar "10MB" → 2MB; số test/phiên bản/mô tả đồng bộ; test "lưới an toàn" giữ chúng khớp nhau từ nay |
| TW-24 | ⚪ Info | 🟢 Một phần | Lockfile: `body-parser` 1.20.9, `multer` 2.5.0 (backend), `follow-redirects` 1.16.2 (frontend) — mục 6 |
| TW-25 | ⚪ Info | ✅ Vá | `updateMe` ghi **một** lần; `syncActivation` chạy trong transaction, chỉ kích hoạt nếu đang `pending` |
| TW-26 | ⚪ Info | ⏸ Ghi nhận | Trending quét toàn bộ / limiter quên mật khẩu theo RAM: theo dõi khi tăng quy mô. IPv6 /64 đã xử lý trong TW-01 |
| TW-27 | ⚪ Info | ✅ Vá | `[SHARE DEBUG]` tắt mặc định (`SHARE_DEBUG=on` để bật), tối đa 20 dòng/phút, không còn ghi UID |

---

## 1. Chi tiết các hạng mục quan trọng

### TW-01 — IP client (High)
- **Vấn đề**: sau Cloudflare → Render mà chỉ tin 1 hop, `req.ip` là IP **edge Cloudflare** (đổi theo đường đi, dùng chung giữa nhiều người) ⇒ né limiter, bucket dùng chung, khoá chống đếm trùng view/share đổi liên tục.
- **Cách làm** (xem comment đầu `clientIp.js`): *không* đổi cứng `trust proxy` và *không* đọc thẳng `CF-Connecting-IP`, vì chưa ai đo topology thật và header này giả được nếu gọi thẳng origin.
  - `CLIENT_IP_MODE=auto` (mặc định): chỉ tin `CF-Connecting-IP` khi `req.ip` nằm trong dải IP Cloudflare (danh sách chính thức; `CLOUDFLARE_EXTRA_RANGES` để bổ sung). Gọi thẳng origin ⇒ bỏ qua header ⇒ như 2.5.2 (không tệ hơn, không giả được).
  - `TRUST_PROXY_HOPS` mặc định **1** (= 2.5.2). **Đo rồi mới đổi** — cách đo ở mục 3 bước 4.
  - IPv6 gộp /64, bỏ `::ffff:` (đóng luôn phần IPv6 của A-07).
- Các nơi cần IP đều gọi một hàm; `getRawClientIp` chỉ cho nơi cần địa chỉ thật (Turnstile `remoteip`, log chẩn đoán).

### TW-02 — CSP
- Hai header CSP cùng áp dụng (giao của hai chính sách): header **chặn thật** có `object-src/base-uri/form-action/frame-ancestors` (từ trước) **+ `script-src 'self' https://challenges.cloudflare.com; script-src-attr 'none'`**. Đã kiểm `dist/index.html`: không có script nội tuyến, chỉ `/theme-init.js` và bundle module ⇒ tương thích.
- Header Report-Only mang chính sách đầy đủ; `img-src` thu từ `https:` rộng về `self data: blob: res.cloudinary.com`, `frame-src` thu về Turnstile + các nhà cung cấp video/âm thanh trong allowlist nhúng. **Chưa enforce** hai directive này vì ảnh/iframe hợp lệ phụ thuộc danh sách domain do SA sửa lúc chạy — enforce sai là hỏng ảnh/video của người dùng. `npm run csp:sources` in đúng dòng cần dán khi bạn sẵn sàng.
- **Phải kiểm trên bản xem trước Vercel** (mình không có Vercel): mở trang đăng ký (Turnstile hiện), một bài có ảnh + video nhúng; DevTools › Console không có lỗi `Refused to load`; bảng **Báo cáo vi phạm CSP** không có nguồn lạ.

### TW-03 — Cày điểm xem / thưởng chia sẻ
- Điểm xem chỉ cộng **1 lần cho mỗi cặp (người xem, bài)**. `viewCount` hiển thị **không đổi**. Công tắc quay lại: `VIEW_SCORE_ONCE_PER_PAIR=off`.
- Thưởng share: mỗi người chia sẻ tối đa **25 lần +8 điểm/ngày (UTC)**; `shareCount` hiển thị không đổi. `SHARE_REWARD_DAILY_CAP=0`/`off` = không giới hạn.
- Khoá khách ẩn danh (`viewerKey`) đổi định dạng theo TW-01 ⇒ **sau deploy, mỗi khách ẩn danh được tính thêm 1 lượt xem** (chỉ một lần). Không ảnh hưởng điểm.

### TW-04 — App Check (tắt mặc định)
Chống đọc Firestore công khai bằng REST/script (không đi qua Express nên không có limiter). Bật sai thứ tự sẽ **chặn đăng nhập/đọc của người dùng thật**, nên:
1. Mở rộng CSP (`vercel.json`) cho nguồn reCAPTCHA **trước**.
2. Đặt `VITE_FIREBASE_APPCHECK_SITE_KEY` (+ `_PROVIDER`), deploy frontend.
3. Firebase Console › App Check ở chế độ **Monitor** vài ngày, xem tỉ lệ request có token.
4. Chỉ khi gần 100% mới **Enforce**.
Khi biến để trống, bundler loại bỏ hẳn mã App Check (đã kiểm bằng `vite build`).

### TW-05 — Tài khoản SA thử nghiệm đã giao cho công cụ AI
Mình không thể và không nên tự làm các bước này — chúng là việc trên hệ thống thật của bạn:
1. **Đổi mật khẩu** các tài khoản đó (Firebase Console › Authentication, hoặc "Quên mật khẩu"). Không đưa mật khẩu qua dòng lệnh.
2. **Thu hồi phiên**: `npm run sessions:revoke -- --uid=UID1,UID2 --demote --disable` (xem dry-run) rồi `npm run sessions:revoke:apply -- --uid=… --demote --disable`. `--demote` hạ về RA/user, `--disable` vô hiệu hoá Auth, và luôn `revokeRefreshTokens`. Token cũ bị từ chối trong ≤ 1 phút (cache `checkRevoked` 60 s).
3. Nếu từng giao tài khoản này làm việc: đọc `GET /api/admin/config-audit` (mới) và Firebase Auth › Users (lần đăng nhập gần nhất) để xem có thay đổi cấu hình lạ; kiểm `profileVisitors/*` và `positiveScoreLogs/*` của các tài khoản ấy.
4. **Xoay** mọi khoá/biến môi trường mà tài khoản hoặc công cụ đó từng nhìn thấy (`SSR_PROXY_SECRET`, `SHARE_LINK_SECRET`, `SITEMAP_REFRESH_TOKEN`, khoá Turnstile secret nếu cần).
5. Về lâu dài: tài khoản thử nghiệm dùng nhóm **LLA/`test`**, không dùng SA.

### TW-06 — `class`/`data-*`/`aria-*`
- `class` chỉ giữ các mẫu `ql-*` hợp lệ (căn lề, indent, code-block…); mọi lớp khác bị bỏ ⇒ không còn dùng `class` để ẩn chữ qua CSS của site. `data-*`/`aria-*` tắt tường minh (mặc định DOMPurify là bật), ngoại lệ duy nhất `data-list` ép về `ordered|bullet|checked|unchecked`.
- **Bài cũ không tự sạch**: chỉ sạch theo bộ lọc lúc ghi. Chạy lại bộ lọc: `npm run content:resanitize` (**mặc định dry-run**, in số bài sẽ đổi và mẫu thay đổi) → **sao lưu Firestore** → `npm run content:resanitize:apply`. Có sao lưu vì thao tác ghi đè nội dung hàng loạt.

### TW-07, TW-13 — rules khoá hẳn
- `config/*`: chứa 5 document (`version`, `embedDomains`, `embedDomainsRescan`, `fonts`, `trendingState`), trong đó có UID của SA. Frontend **không** đọc qua Client SDK (đã grep) ⇒ khoá là an toàn.
- `positiveScoreLogs/*`: log share ghi UID người mở link vào log của người chia sẻ — vốn đọc được bằng Client SDK. Frontend không đọc ở đâu ⇒ khoá.
- Module Gỡ lỗi `rules-private-collections` trước dùng `config/` làm "đối chứng cho đọc công khai"; nay là `countries/`.
- **Lưu ý kiểm chứng**: probe không đăng nhập không phân biệt được "chính chủ đọc được" với "khoá hẳn" (cả hai 403). Kiểm bằng Rules Playground.

### TW-08 — Dọn tài khoản `pending`
Sweeper nền (timer `unref`, chạy lần đầu ~3 phút sau khi khởi động, mỗi 6 giờ). Chỉ xếp hàng xoá tài khoản `pending` **quá hạn** mà Firebase Auth **chưa xác minh email**; hồ sơ có `createdAt` thiếu/không phải chuỗi ISO không bao giờ bị đụng; kiểm lại ngay trước khi xoá **và `requestDeletion({onlyIfStatus:"pending"})` kiểm lại trạng thái ngay trong transaction** (người vừa được kích hoạt không bị lật sang `deleting`); lỗi Auth tạm thời với một hồ sơ chỉ bỏ qua hồ sơ đó; trần 500 tài khoản/lượt; xoá đi qua `accountDeletions` (cùng quy trình xoá bền vững như người dùng tự xoá). Quét phân trang, không cần index mới. Tắt khẩn: `PENDING_SWEEPER=off`.

### TW-09 — Thao tác ghi của SA
- Nhập lại mật khẩu (`requireRecentAuth`, cùng cơ chế với đổi tên thật và chạy module Gỡ lỗi) cho `PUT /admin/embed-domains`, `PUT /admin/fonts`, `DELETE /admin/csp-reports`. Các route GET (kể cả `GET /admin/embed-domains/rescan`) không đổi. Frontend: `useReauthRetry` + `PasswordConfirmDialog` — nhận `REAUTH_REQUIRED`, hỏi mật khẩu, **gửi lại đúng thao tác**; người dùng không phải làm lại từ đầu.
- Nhật ký `configAudit/{id}` **append-only**, ghi cùng batch với thay đổi cấu hình (không có chuyện đổi mà thiếu nhật ký): ai (uid), lúc nào, loại, diff tóm tắt. Rules: chỉ backend; SA đọc qua `GET /api/admin/config-audit`.

### TW-20 — SSR không tin tuyệt đối HTML đã lưu
`SSR_TRIPWIRE` bắt `<script>`, `on*=`, `javascript:`/`data:text/html`, `<iframe srcdoc>`, `<svg on…>`, `<object>`, `<style>`, `<form>`, `<meta refresh>`… **`ssrTripwireHit` kiểm thêm hai dạng mà trình duyệt thực sự thấy**: đã giải mã thực thể (`&#106;avascript:`, `javascript&colon;`) và đã bỏ TAB/LF/CR (`java&#9;script:`) — bản đầu chỉ kiểm chuỗi thô nên bị lách (phát hiện ở bước rà soát độc lập; có test 16 biến thể). Nội dung Quill bình thường **không** bị bắt (test với mẫu thật, gồm `<pre>` chứa chữ "script" đã thoát — cố ý không giải mã `&lt; &gt;`). Chỉ khi bắt mới chạy lại DOMPurify ⇒ không tốn chi phí cho bài sạch.

---

## 2. Mặc định ĐỔI chiều (cố ý) — đọc trước khi deploy

| Việc | 2.5.2 | 2.5.3 | Quay lại |
|---|---|---|---|
| Điểm xem một lần/cặp | tắt | **bật** | `VIEW_SCORE_ONCE_PER_PAIR=off` |
| Trần thưởng share | không | **25/ngày/người** | `SHARE_REWARD_DAILY_CAP=0` |
| Dọn `pending` | chạy tay, 14 ngày | **tự động, 7 ngày** | `PENDING_SWEEPER=off`, `PENDING_MAX_AGE_DAYS=14` |
| Kiểm hostname Turnstile | không | **bật ở production** (suy từ `CORS_ORIGIN` + `FRONTEND_URL`) | `TURNSTILE_HOSTNAME_CHECK=off` (khẩn), hoặc `TURNSTILE_ALLOWED_HOSTNAMES` |
| `config/*`, `positiveScoreLogs` | đọc được | **khoá** | (sửa rules) |
| 3 route ghi của SA | chỉ cần token | **nhập lại mật khẩu** | — |
| CSP chặn thật | không có `script-src` | **có** | đổi `vercel.json` |
| `class`/`data-*` trong bài mới | giữ | **lọc** | — |

## 3. Triển khai (theo thứ tự)

1. **Không có index mới.** Không cần `firestore:indexes`.
2. **Render (biến môi trường)** — xem `.env.example`. Tối thiểu: không bắt buộc biến nào mới. Nên: kiểm `TURNSTILE_ALLOWED_HOSTNAMES` nếu widget chạy ở tên miền khác `CORS_ORIGIN`/`FRONTEND_URL`.
3. **Deploy backend → frontend** (như thường lệ). Trước khi để sweeper tự chạy, xem trước nó sẽ xoá gì: `npm run pending:cleanup` (dry-run, liệt kê tài khoản `pending` quá 7 ngày chưa xác minh email). Sweeper chạy lần đầu ~3 phút sau khi khởi động và **chỉ ghi log khi có tài khoản bị xếp hàng** (`[pending-sweeper] đã quét …`) hoặc khi lỗi (`[pending-sweeper] lỗi:`) — không thấy log nghĩa là không có gì quá hạn; xem hàng chờ xoá bằng `npm run deletions:list`.
4. **Đo topology IP (TW-01)**: đặt `DEBUG_IP_TOPOLOGY=on` → redeploy → từ máy bạn gọi `https://<backend>/api/version` vài lần (cả Wi-Fi lẫn 4G) → đọc 20 dòng `[IP-TOPO]` trong log Render. Nếu `xff` = `IP-của-bạn, IP-edge` thì đặt `TRUST_PROXY_HOPS=2`. **Gỡ `DEBUG_IP_TOPOLOGY`** sau khi đo. Kiểm tra: `for i in $(seq 1 10); do curl -s -o /dev/null -D - https://<backend>/api/version | grep -i '^ratelimit-remaining'; sleep 1; done` — dãy số phải **giảm đều**; lặp lại kèm `-H 'X-Forwarded-For: 203.0.113.7' -H 'CF-Connecting-IP: 203.0.113.7'` — dãy số **không** được nhảy/reset. (Backend dùng `express-rate-limit` v7 với `standardHeaders`, nên tên header là `RateLimit-Remaining`; lệnh mẫu ở §8 báo cáo bảo mật grep `x-ratelimit-remaining` — tên cũ, sẽ không khớp.)
5. **Kiểm CSP trên bản xem trước Vercel** (TW-02, ở trên).
6. **`firebase deploy --only firestore:rules` — SAU CÙNG**, khi backend + frontend mới đã chạy ổn.
7. Chạy `npm run content:resanitize` (dry-run) → sao lưu → `:apply` (TW-06).
8. Làm checklist TW-05 (mục 1).
9. Sau deploy: Cài đặt › Quản trị › **Gỡ lỗi › Chạy tất cả** (module rules đã cập nhật).

## 4. API / hành vi thay đổi

| Method | Đường dẫn | Thay đổi |
|---|---|---|
| GET | `/api/admin/config-audit` | **Mới** (SA): nhật ký thay đổi cấu hình, phân trang |
| PUT / PUT / DELETE | `/api/admin/embed-domains`, `/api/admin/fonts`, `/api/admin/csp-reports` | Thêm `403 {code:"REAUTH_REQUIRED"}` khi phiên chưa nhập lại mật khẩu gần đây |
| (mọi route có limiter) | — | Khoá bucket theo `getClientKey` (IP thật theo TW-01) |
| GET | `/` | Không đổi (vẫn liệt kê admin — quyết định của bạn) |

## 5. Biến môi trường mới

Backend (`backend/.env.example`): `TRUST_PROXY_HOPS`, `CLIENT_IP_MODE`, `DEBUG_IP_TOPOLOGY`, `CLOUDFLARE_EXTRA_RANGES`, `TURNSTILE_TIMEOUT_MS`, `TURNSTILE_ALLOWED_HOSTNAMES`, `TURNSTILE_HOSTNAME_CHECK`, `SHARE_REWARD_DAILY_CAP`, `SHARE_DEBUG`, `PENDING_SWEEPER`, `PENDING_MAX_AGE_DAYS`, `PENDING_SWEEP_INTERVAL_MIN`, `PENDING_SWEEP_MAX_PER_RUN`; **đổi nghĩa mặc định**: `VIEW_SCORE_ONCE_PER_PAIR`.
Frontend (`frontend/.env.example`): `VITE_FIREBASE_APPCHECK_SITE_KEY`, `VITE_FIREBASE_APPCHECK_PROVIDER`, `VITE_FIREBASE_APPCHECK_DEBUG_TOKEN`.
`BACKEND_VERSION=2.5.3.081126` trong `.env.example`.

## 6. Phụ thuộc (TW-24) — kết quả `npm audit`

Đã chạy được ở bản này (có mạng tới registry). **Đã vá, không phá vỡ**: backend `body-parser` ≥ 1.20.9, `multer` ≥ 2.5.0 (hết mức *high* ở backend); frontend `follow-redirects` ≥ 1.16.2.

Còn lại (đều cần **nâng bản lớn**, để đợt riêng có hồi quy trình duyệt):
- **Backend**: 10 *moderate* (8 ở bản production) — chuỗi `firebase-admin` 13 → 14 (`uuid`, `google-gax`, `@google-cloud/*`), cộng `nodemon`/`minimatch` (chỉ dev). Không còn *high*. `firebase-admin` 14 bỏ `admin.firestore.*`/`admin.auth()` và cần Node ≥ 22 — test `firebase-admin-surface.test.js` sẽ đỏ rõ ràng nếu ai nâng trước khi di chuyển mã.
- **Frontend**: 6 *high* + 11 *moderate*. Nhóm `firebase` (`@grpc/grpc-js`, `undici`, `@firebase/firestore` — các gói này nằm sâu trong chuỗi SDK; mình **không khẳng định** khả năng khai thác trong trình duyệt) và **`vite` ≤ 6.4.3 — toàn bộ lỗi là của *dev server* (`server.fs`, `launch-editor`), không có trong bundle phát hành**. `npm audit fix --force` gợi ý "firebase 9.14.0" là bản **hạ cấp** — **không** làm theo. `react-router`, `react-quill`/`quill` là các nâng bản lớn còn lại (G2/G3 trong `SECURITY-STATUS.md`).

## 7. Test

- **Backend** 312 (240 cũ + 72 mới): `security-253.test.js` (18: IP/limiter, điểm xem/share, captcha, `[SHARE DEBUG]`, CORS), `security-253b.test.js` (13: CSP `vercel.json`, sanitize `class`/`data-*`, resanitize dry-run, rules `config/*` + `positiveScoreLogs`), `security-253c.test.js` (21: sweeper `pending` — gồm race kích hoạt/xoá, `createdAt` lạ, lỗi Auth từng hồ sơ —, `requireRecentAuth` + `configAudit`, `.doc(null)`, `syncActivation`/`updateMe`), `security-253d.test.js` (19: SSR tripwire gồm 16 biến thể lách bằng thực thể/TAB, mã chết, App Check, đồng bộ phiên bản, lockfile, **công cụ thu hồi phiên**), + 1 ca SSR trong `security-ssr.test.js`.
- **Frontend** 385 (368 + 17): `security253.test.jsx` (15), `quillSafeClipboard.test.jsx` (+2).
- Có 2 test "lưới an toàn" mới: (a) mọi `test/*.test.js` phải nằm trong script `test` của `package.json` (test viết xong mà không chạy = không tồn tại); (b) số phiên bản khớp ở **mọi** nơi quy ước.
- `fakeFirebase.js` (dùng chung cho test và module Gỡ lỗi) nay hỗ trợ con trỏ `startAfter(snapshot)` và sắp theo id khi không có `orderBy` — để quét phân trang của sweeper chạy đúng như Firestore thật.

## 8. Đã chạy đột biến

Chạy các test mới trên mã **2.5.2 gốc**: các ca TW-14 (×2) và TW-25 (×2) **đỏ** đúng như dự kiến (bằng chứng test thật sự bắt lỗi, không phải test tự thoả mãn). Các hạng mục còn lại kiểm bằng cách đọc cấu trúc/chạy thật mã mới.

**Test cũ được sửa theo thay đổi chủ ý** (không phải để né lỗi):
- `security-session3.test.js` — F3 giờ mặc định **bật** (đổi kỳ vọng "mặc định tắt" → "mặc định bật, `off` mới tắt").
- `debug-230.test.js` — module rules không còn dùng `config/` làm đối chứng đọc công khai (dùng `countries/`); thêm `configAudit`.
- `fonts.test.js` — mock Firestore thêm `batch()`/`doc()` không đối số/`path` vì thao tác ghi cấu hình nay đi cùng nhật ký trong một batch.
- `fonts-admin.test.jsx` — mock `utils/reauth` (module này nạp `firebase.js` thật ⇒ khởi tạo SDK với khoá API giả).

## 8b. Rà soát độc lập (một agent chưa thấy quá trình làm) — kết quả

Giao cho agent khác chỉ **mã nguồn + diff** (không kèm kết luận của mình), yêu cầu chứng minh từng lỗi bằng cách chạy thật. Nó tìm ra **4 lỗi thật trong chính bản vá**, đã sửa và thêm test (đã chạy đột biến: gỡ bản sửa thì test đỏ):

| Mức | Lỗi | Sửa |
|---|---|---|
| Medium | Tripwire SSR (TW-20) chỉ kiểm chuỗi thô ⇒ `<a href="&#106;avascript:…">`, `javascript&colon;`, `java<TAB>script:`, `da<TAB>ta:text/html`, `on*` viết bằng thực thể… lọt qua mà không bị sanitize lần hai | `ssrTripwireHit`: kiểm thô + đã giải mã thực thể + đã bỏ TAB/LF; 16 biến thể có test; không bắt oan `<pre>` mã đã thoát |
| Medium | Sweeper `pending` (TW-08): người dùng được kích hoạt đúng khe giữa lần kiểm lại và transaction xếp hàng xoá vẫn có thể bị lật `active → deleting` | `requestDeletion(uid, {onlyIfStatus})` kiểm trong transaction; test mô phỏng đúng khe này. **Khe còn lại không đóng được**: Firebase Auth là hệ thống khác — người dùng bấm link xác minh đúng vài mili-giây giữa lần kiểm Auth và transaction. Hồ sơ `pending` quá 7 ngày chưa có nội dung, hậu quả chỉ là đăng ký lại |
| Low–Med | `TURNSTILE_ALLOWED_HOSTNAMES=https://twelveta.vercel.app` (viết kiểu `CORS_ORIGIN`) không bao giờ khớp ⇒ khoá cả đăng ký ở production | Chuẩn hoá mục (bỏ scheme/cổng/đường dẫn, giữ `*.`); log lệch hostname nêu biến cần chỉnh và công tắc khẩn |
| Low | `Date.parse(createdAt)` coi `"2020"` hoặc số `5` là ngày xa xưa; một lỗi Auth tạm thời huỷ cả lượt quét | Chỉ nhận chuỗi ISO; lỗi Auth từng hồ sơ ⇒ bỏ qua hồ sơ đó (`skippedError`), không xoá |

Đã kiểm và thấy đúng: phép tính dải Cloudflare (biên IPv4/IPv6, IPv4-mapped, zone id), không còn nơi nào đọc `req.ip`/XFF trực tiếp, `CF-Connecting-IP` từ hop không phải Cloudflare bị bỏ qua, allowlist `class` giữ nguyên đầu ra Quill 1.3.7 thật, 3 route ghi của SA đều có `requireRecentAuth` và nhật ký cùng batch, frontend chỉ đọc `users/posts/blogs/comments` (khoá `config/*` và `positiveScoreLogs` không làm gãy gì), `revokeSessions` dry-run chỉ đọc, `useReauthRetry` gửi lại đúng một lần, CSP chặn thật không làm hỏng bundle (không script nội tuyến/`eval`/nguồn lạ). App Check **không còn trong bundle khi để trống khoá** (đã đối chiếu hai bản build: URL `firebaseappcheck.googleapis.com` chỉ xuất hiện khi đặt khoá; chuỗi `app-check-internal` còn lại là tham chiếu tuỳ chọn của Auth/Firestore).
Không sửa, ghi nhận: trần share theo ngày có thể bị **phá bĩnh** — ai cầm link chia sẻ có chữ ký của một người có thể mở từ 25 tài khoản phụ để dùng hết lượt thưởng +8 trong ngày của người đó (đánh đổi vốn có của trần theo người chia sẻ; chỉ ảnh hưởng điểm thưởng, không ảnh hưởng `shareCount`). Nếu bạn thấy đáng ngại: nâng `SHARE_REWARD_DAILY_CAP` hoặc đặt `0`.

## 9. Việc cần BẠN quyết / làm (mình không tự quyết)

1. **TW-12 — khách ghé thăm**: có thêm công tắc "không để lại dấu" không? (kèm dòng trong Điều khoản).
2. **TW-16 — lộ "email đã tồn tại" khi đăng ký**: chấp nhận đánh đổi UX, hay chuyển sang thông báo trung tính ("nếu email hợp lệ, chúng tôi đã gửi thư xác minh")? Bật *Email enumeration protection* ở Firebase cũng liên quan.
3. **`GET /` liệt kê `/api/admin/*`** (TW-22): giữ cho "AI agent discovery" hay ẩn các endpoint admin?
4. **Trần share 25/ngày**, **điểm xem một lần/cặp mặc định bật**, **pending 7 ngày tự động**: đều do mình chọn mặc định — chỉnh bằng biến môi trường nếu không hợp sản phẩm.
5. **TW-04 App Check**: có muốn bật không (và theo thứ tự ở mục 1)?
6. **Nâng bản lớn**: `firebase-admin` 14 (Node ≥ 22), frontend `firebase`, `react-router`, `vite`, Quill 2 — một đợt riêng.
7. **Express 5** (TW-15) — đợt riêng.
8. **Ngày trong số phiên bản**: mình đặt `081126` theo ngày làm bản này (08/11/2026). Nếu bạn quy ước theo ngày phát hành thật, đổi ở các nơi liệt kê trong `TWELVE-MAP.md` §10.

**Mình không kiểm chứng được** (không có hệ thống thật): topology IP thật (nên mặc định 1 hop), hành vi chồng hai header CSP trên Vercel, cấu hình Cloudflare/Render/Firebase Console (mục 9 của báo cáo bảo mật), và việc bản của bạn có cần hostname Turnstile khác ngoài `CORS_ORIGIN`/`FRONTEND_URL`.

## 10. File

**Backend (sửa):** `server.js`, `firestore.rules`, `.env.example`, `package.json`, `package-lock.json`, `README.md`; `controllers/{apiInfo,auth,comments,csp,embedDomains,fonts,seo,users}.controller.js`; `debug/modules/{cfg-runtime,rules-private-collections}.js`, `debug/support/fakeFirebase.js`; `middleware/{captcha,rateLimiters,roles}.js`; `routes/{admin,auth,csp,ssr}.routes.js`; `seed/resanitizeContent.js`; `services/{pendingCleanup,sanitize.service}.js`; `utils/{authors,clientIp,constants,helpers,ssrContent}.js`; `scripts/cleanup-pending-accounts.js`; `test/{debug-230,fonts,security-session3,security-ssr}.test.js`.
**Backend (mới):** `controllers/configAudit.controller.js`, `services/{configAudit,revokeSessions}.js`, `scripts/{print-csp-sources,revoke-user-sessions}.js`, `test/security-253{,b,c,d}.test.js`.
**Frontend (sửa):** `vercel.json`, `.env.example`, `package.json`, `package-lock.json`, `public/version.json`; `src/{firebase}.js`; `src/context/AuthContext.jsx`; `src/pages/PublicProfilePage.jsx`; `src/pages/settings/{AdminCspReportsPanel,AdminEmbedDomainsPanel,AdminFontsPanel}.jsx`; `src/utils/{debugLog,quillSafeClipboard,reauth}.js`; `tests/{fonts-admin,quillSafeClipboard}.test.jsx`.
**Frontend (mới):** `src/hooks/useReauthRetry.jsx`, `tests/security253.test.jsx`. **Xoá:** `src/components/RouteGuards.jsx`.
**Tài liệu:** `PATCH-24-NOTES.md` (file này), `backend/README.md` (mục -32), `SECURITY-STATUS.md`, `TWELVE-MAP.md`.
**Phiên bản `2.5.3.081126`:** `package.json` ×2, `package-lock.json` ×2, `frontend/public/version.json`, `backend/.env.example`, tiêu đề `backend/README.md`, đầu `SECURITY-STATUS.md`, đầu `TWELVE-MAP.md`.
