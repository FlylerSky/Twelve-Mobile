# Bản vá 1 — theo báo cáo 1 (blog nháp, bơm view, sitemap, SSR/SEO, tái sử dụng)

Nhãn "v2.0.4" trong comment chỉ là nhãn tạm cho bản vá này; đổi theo quy ước phiên bản của bạn.

## Triển khai (theo thứ tự)
1. **Tạo secret**: `openssl rand -hex 32`. Đặt CÙNG giá trị cho `SSR_PROXY_SECRET` ở Render (backend) và Vercel (frontend, Production).
   Tuỳ chọn: `SITEMAP_REFRESH_TOKEN` (Render), `SITE_OG_IMAGE_URL`.
2. **Deploy Firestore index trước** (cần cho "N bài mới nhất" ở SSR): `firebase deploy --only firestore:indexes`, chờ trạng thái *Enabled*.
   Chưa xong index thì SSR tự lùi về quét 100 bài rồi sort (có log cảnh báo), không lỗi.
3. **Deploy backend** rồi **frontend** (middleware.js, useSeo, favicon, og-default.png).
4. **Deploy Firestore rules cuối cùng**, sau khi frontend mới (`useNewContentBanner` thêm `where isPublished==true`) đã lên:
   `firebase deploy --only firestore:rules`. Nếu deploy rules trước, banner "có blog mới" trên bản frontend cũ sẽ lỗi (chỉ log, không vỡ trang).
5. **Thay `frontend/public/og-default.png`** (đang là ảnh placeholder) bằng ảnh thương hiệu 1200×630.

## Kiểm tra sau deploy
```bash
# 1) Vercel có chuyển tiếp header bí mật sang Render không? (phải ra 1)
curl -sI -A "Googlebot/2.1" https://<frontend>/post/<id> | grep -i x-twelve-ssr-trusted
# 2) Blog nháp: phải 404 (kể cả khi gọi thẳng Render)
curl -s -o /dev/null -w "%{http_code}\n" -A "Googlebot/2.1" https://<backend>/blog/<id-nhap>
# 3) Gọi thẳng Render với UA/XFF giả: view KHÔNG tăng, header trả về 0
curl -sI -A "Googlebot/2.1" -H "X-Forwarded-For: 1.2.3.4" https://<backend>/post/<id> | grep -i x-twelve-ssr-trusted
# 4) Sitemap
curl -s https://<frontend>/sitemap.xml | head
# 5) iPhone thật: mở https://<frontend>/post/<id> => phải ra SPA, không ra trang tĩnh
```
Nếu (1) ra `0`: Vercel không chuyển tiếp header tuỳ chỉnh trên rewrite ngoài. Khi đó SSR vẫn hoạt động nhưng
view bot sẽ không được cộng — báo lại để đổi sang cơ chế khác (vd. path bí mật).

## Quyết định cần bạn xác nhận
- Hồ sơ `suspended`: vẫn xem được ở API, SSR trả `noindex, nofollow` và ẩn danh sách bài. (`suspended` đang dùng cho LLA "bị tước quyền", nên không 404.)
- Hồ sơ `pending`: 404 ở cả API và SSR.
- Hồ sơ chưa có bài: SSR `noindex, follow`; sitemap chỉ có hồ sơ active có bài; hashtag trong sitemap khi dùng >= 2 lần.
- Chi phí sitemap: dựng 1 lần/giờ (trước: 5 phút), đọc tới 45.000 bài + 45.000 blog tối đa mỗi lần dựng.

## Chưa làm trong bản vá này (thuộc báo cáo 2 / cần thử thật)
- `vercel.json`: CSP vẫn Report-Only và hardcode host onrender (Vercel không có biến môi trường trong vercel.json; cần bước build để sinh file).
- Chưa chạy được Firestore rules emulator trong môi trường này (cần Java): hãy thử `rules` bằng Emulator/Rules Playground
  với 3 ca: khách đọc blog nháp (từ chối), tác giả đọc nháp của mình (cho phép), `list` blogs không kèm `isPublished==true` (từ chối).
